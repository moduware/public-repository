window.nexpaqAPI.setCurrentModule("LaserMeasurement");

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('Laser Measurement');
	nexpaqAPI.LaserMeasurement.addEventListener('onDataUpdated', nativeDataUpdateHandler);

	document.getElementById('turnLaserOn').addEventListener('click', function() {
		nexpaqAPI.LaserMeasurement.on();
	});

	document.getElementById('turnLaserOff').addEventListener('click', function() {
		nexpaqAPI.LaserMeasurement.off();
	});
	document.getElementById('makeSingleMeasurment').addEventListener('click', function() {
		nexpaqAPI.LaserMeasurement.singleMeasurement();
	});
	document.getElementById('makeContMeasurment').addEventListener('click', function() {
		nexpaqAPI.LaserMeasurement.continuousMeasurement();
	});

	nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
		nexpaqAPI.LaserMeasurement.off();
		nexpaqAPI.util.closeApplication();
	});

});
