nexpaqAPI.setCurrentModule("Hotkey");
var function_choosed_event = new Event('function-choosed');
window.initialMarginTop=0;
window.lastCurrentItem=0;
window.available_functions=[];
window.original_indexes=[0, 0];

function openConfigScreen() {
	document.getElementById('wrapper').classList.add('no-bg');
	document.getElementById('hotkey-modules').classList.add('hidden');
	document.getElementById('config-screen').classList.remove('hidden');
	document.getElementById('big-module').children[0].click();
}
function openMainScreen() {
	document.getElementById('wrapper').classList.remove('no-bg');
	document.getElementById('hotkey-modules').classList.remove('hidden');
	document.getElementById('config-screen').classList.add('hidden');
}
function hotkeyModuleInListClickHandler(e) {
	openConfigScreen();
	storeOriginalIndexes();
}
function cancelConfigScreenHandler(e) {
	openMainScreen();
	restoreOriginalIndexes();
}
function doneConfigScreenHandler(e) {
	openMainScreen();
	applyNewIndexes();
	updateMain();
}
function bigModuleButtonClickHandler(e) {
	var buttons = document.getElementById('big-module').children;
	for(var i=0; i < buttons.length; i++) {
		buttons[i].classList.remove('used');
	}
	this.classList.add('used');
	setCurrentFunction(this.dataset.function);
}
function functionIndexUpdatedHandler(e) {
	//console.log(this, this.children);
	var items = this.children[0].children;
	for(var i=0; i < items.length; i++) {
		if(items[i].classList.contains('s0')) {
			document.getElementById('big-module').getElementsByClassName('used')[0].dataset.function = i;
			break;
		}
	}

}
function storeOriginalIndexes() {
	var buttons = document.getElementById('big-module').children;
	window.original_indexes=[];
	for(var i=0; i < buttons.length; i++) {
		window.original_indexes.push(buttons[i].dataset.function);
	}
}
function restoreOriginalIndexes() {
	var buttons = document.getElementById('big-module').children;
	for(var i=0; i < buttons.length; i++) {
		buttons[i].dataset.function = window.original_indexes[i];
	}
}
function updateMain() {
	var buttons = document.getElementById('big-module').children,
			function_one_index = parseInt(buttons[0].dataset.function)-1,//available_functions[parseInt(buttons[0].dataset.function)-1].name,
			function_two_index = parseInt(buttons[1].dataset.function)-1,
			function_one_name = function_one_index<0?'empty':available_functions[function_one_index].name,
			function_two_name = function_two_index<0?'empty':available_functions[function_two_index].name,
			function_one_title = function_one_index<0?'empty':available_functions[function_one_index].title,
			function_two_title = function_two_index<0?'empty':available_functions[function_two_index].title,
			function_one_icon = known_functions[function_one_name]===undefined?'empty':known_functions[function_one_name][0],
			function_two_icon = known_functions[function_two_name]===undefined?'empty':known_functions[function_two_name][0],
			function_one_color = known_functions[function_one_name]===undefined?'empty':known_functions[function_one_name][1],
			function_two_color = known_functions[function_two_name]===undefined?'empty':known_functions[function_two_name][1];

	 setModuleInfo(function_one_icon, function_one_color, function_one_title, function_two_icon, function_two_color, function_two_title);

	 //console.log(function_one_index, function_one_title, function_two_index, function_two_title);
}
function setModuleInfo(icon1, color1, name1, icon2, color2, name2) {
	var names = document.getElementById('hotkey-modules').getElementsByClassName('function-name'),
			img_c = document.getElementById('hotkey-modules').getElementsByClassName('img-container'),
			micro_module = document.getElementById('hotkey-modules').getElementsByClassName('micro-module')[0];

	names[0].textContent = name1;
	names[1].textContent = name2;

	if(icon1 === 'empty') {
		img_c[0].classList.add('empty');
	} else {
		img_c[0].classList.remove('empty');
		img_c[0].children[0].src = defined_icons[icon1];
	}
	if(icon2 === 'empty') {
		img_c[1].classList.add('empty');
	} else {
		img_c[1].classList.remove('empty');
		img_c[1].children[0].src = defined_icons[icon2];
	}
	micro_module.dataset.first = color1;
	micro_module.dataset.last = color2;


}
function applyNewIndexes() {
	var buttons = document.getElementById('big-module').children;
	console.log('New indexes:', buttons[0].dataset.function, buttons[1].dataset.function);
	for(var i=1; i<=2; i++) {
		var function_index = parseInt(buttons[i-1].dataset.function) - 1;
		if(function_index === -1) {
			if(!window.EmulateModule) {
				window.nexpaqAPI.Hotkey.addNativeEventListener('button_'+i+'_pressed', '', []);
			}
		} else {
			if(!window.EmulateModule) {
				window.nexpaqAPI.Hotkey.addNativeEventListener('button_'+i+'_pressed', available_functions[function_index].name, [available_functions[function_index].device]);
			}
		}
	}
}
/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {

	var i;
	var modules_items = document.getElementById('hotkey-modules').children;
	for(i=0; i < modules_items.length; i++) {
		modules_items[i].addEventListener('click', hotkeyModuleInListClickHandler);
	}
	var big_module_buttons = document.getElementById('big-module').children;
	for(i=0; i < big_module_buttons.length; i++) {
		big_module_buttons[i].addEventListener('click', bigModuleButtonClickHandler);
	}
	document.getElementById('cancel-config-screen').addEventListener('click', cancelConfigScreenHandler);
	document.getElementById('done-config-screen').addEventListener('click', doneConfigScreenHandler);
	document.getElementById('function-chooser').addEventListener('function-choosed', functionIndexUpdatedHandler);

	$("#function-chooser").swipe({
    //Generic swipe handler for all directions
    swipeStatus: touchSwipeHandler,
		threshold: 0
	});


	window.nexpaqAPI.global.addEventListener('onEventsReceived', eventsReceivedHandler);
	window.nexpaqAPI.global.addEventListener('onBackButtonClicked', backButtonClickHandler);

	window.nexpaqAPI.emulateMode = window.EmulateModule = !window.nexpaqAPI.isApiAvailable();
  window.nexpaqAPI.emulateMode = window.EmulateModule = false;
  if(window.nexpaqAPI.emulateMode) {
		emulateNativeData();
	} else {
		document.getElementById('tmpl').classList.add('hidden');
	}

});
