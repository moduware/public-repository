function touchSwipeHandler(event, phase, direction, distance, duration, fingers, fingerData, currentDirection) {
	var $function_chooser = document.getElementById('function-chooser'),
			container_height=225,
			element_height=32,
			selector_height=35,
			max_margin=225/2 - 25/2,
			min_margin=max_margin - calculateListHeight($function_chooser.children[0].children) + element_height;
	//console.log(direction, distance, max_margin, min_margin);
	//var $function_chooser = document.getElementById('function-chooser');

	if(phase == "start") {
		window.initialMarginTop = parseInt($function_chooser.children[0].style.transform.match(/-?(\d+)/g)[0]);
		//console.log('Initial margin:', window.initialMarginTop)
	}
	if(direction == "up") {
		var new_transform = window.initialMarginTop - distance;
		if(new_transform < min_margin) new_transform = min_margin;
		$function_chooser.children[0].style.transform = 'translateY('+new_transform+'px)';
		$function_chooser.children[0].style.webkitTransform = 'translateY('+new_transform+'px)';
	} else if(direction == "down") {
		var new_transform = window.initialMarginTop + distance;
		if(new_transform > max_margin) new_transform = max_margin;
		$function_chooser.children[0].style.transform = 'translateY('+new_transform+'px)';
		$function_chooser.children[0].style.webkitTransform = 'translateY('+new_transform+'px)';
	}
	if(direction == "up" || direction == "down") {
		var current_item = calculateCurrentItem($function_chooser.children[0].children, new_transform, selector_height, max_margin);
		if(current_item != window.lastCurrentItem) {
			window.lastCurrentItem = current_item;
			setCurrentItem($function_chooser.children[0].children, current_item);
		}
	}
	if(phase == "end" || phase == "cancel") {
		//document.getElementsByClassName('s0')[0].offsetTop
		// var end_margin = max_margin - document.getElementsByClassName('s0')[0].offsetTop;
		// $function_chooser.children[0].style.transform = 'translateY('+end_margin+'px)';
		// $function_chooser.children[0].style.webkitTransform = 'translateY('+end_margin+'px)';
    scrollToCurrentItem();
    $function_chooser.dispatchEvent(function_choosed_event);
	}

	//$function_chooser.children[0].style.marginTop:
}
function calculateListHeight(list) {
	var total_height = 0;
	for(var i=0; i<list.length; i++) {
		total_height += list[i].offsetHeight;
	}
	return total_height;
}
function calculateCurrentItem(list, transform, selector_height, max_margin) {
	var total_height = 0;
	for(var i=0; i<list.length; i++) {
		total_height += list[i].offsetHeight;
		var position = max_margin - transform;
		if(position + selector_height/2 < total_height) {
			//console.log(i);
			return i;
		}
	}
}
function setCurrentItem(list, index) {
	for(var i=0; i<list.length; i++) {
		list[i].classList.remove('s0','s1','s-1','s2','s-2','s3','s-3');
		for(var j=-3; j<=3; j++) {
			if(i == index+j) {
				list[i].classList.add('s'+j);
			}
		}

	}
}
function scrollToCurrentItem() {
  var max_margin = 225/2 - 25/2,
      $function_chooser = document.getElementById('function-chooser'),
      end_margin = max_margin - document.getElementsByClassName('s0')[0].offsetTop;

  $function_chooser.children[0].style.transform = 'translateY('+end_margin+'px)';
  $function_chooser.children[0].style.webkitTransform = 'translateY('+end_margin+'px)';
}
function setCurrentFunction(index) {
  index = parseInt(index);
  var list = document.getElementById('function-chooser').children[0].children;
  for(var i=0; i<list.length; i++) {
		list[i].classList.remove('s0','s1','s-1','s2','s-2','s3','s-3');
		for(var j=-3; j<=3; j++) {
			if(i == index+j) {
				list[i].classList.add('s'+j);
			}
		}
	}
  scrollToCurrentItem();
}
