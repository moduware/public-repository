/** ================ Handlers == */
function backButtonClickHandler(e) {
	if(document.getElementById('config-screen').classList.contains('hidden')) {
		if(!window.EmulateModule) {
			window.nexpaqAPI.util.closeApplication();
		}
		onNxpAppError('Application closed!', '', '', '', '');
	} else {
		openMainScreen();
		restoreOriginalIndexes();
	}

}

function eventsReceivedHandler(events) {
	window.available_functions=[];
	var j=0;
	var buttons = document.getElementById('big-module').children;
	//var infos = document.getElementById('hotkey-modules').children[0].getElementsByClassName('actions-list')[0].children;
	//var micro_module = document.getElementById('hotkey-modules').children[0].getElementsByClassName('micro-module')[0];
	for(var i=0; i<window.nexpaqAPI.global.functions.length; i++) {
		for(var k=1; k<=2; k++) {
			if(events['button_'+k+'_pressed'].function == window.nexpaqAPI.global.functions[i].name) {
				buttons[k-1].dataset.function = j+1; // cuz 0 is empty

			}
		}

		window.available_functions.push({
			'name' : window.nexpaqAPI.global.functions[i].name,
			'title' : window.nexpaqAPI.global.functions[i].title,
			'device' : window.nexpaqAPI.global.functions[i].device
		});
		j++;
	}
	renderFunctions();
	updateMain();
}
function renderFunctions() {
	var html='<li></li>';
	for(var i=0; i < window.available_functions.length; i++) {
		html += '<li>' + window.available_functions[i].title + '</li>';
	}
	document.getElementById('function-chooser').children[0].innerHTML = html;
}
function emulateNativeData() {
	var data=JSON.stringify({
    "functions": [
        {
            "UUID": 11,
            "name": "NP_white_LED",
						//"title": "Make LED white"
        },
        {
            "UUID": 11,
            "name": "NP_red_LED",
						//"title": "Make LED red"
        },
				{
            "UUID": 11,
            "name": "NP_green_LED",
						//"title": "Make LED green"
        },
				{
            "UUID": 11,
            "name": "NP_blue_LED",
						//"title": "Make LED blue"
        },
				{
            "UUID": 11,
            "name": "NP_flash_red_and_blue_LED",
						//"title": "Flash LED white"
        }
    ],
    "events": [
        {
            "event": "button_1_pressed",
            "function": "NP_white_LED",
            "UUID": [
                11
            ]
        },
				{
            "event": "button_2_pressed",
            "function": "NP_red_LED",
            "UUID": [
                11
            ]
        }
    ]
});
	nxp_receiveEventsTableFromNative(data);
}
