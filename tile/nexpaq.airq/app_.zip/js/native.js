/** ================ Handlers == */
function nativeDataUpdateHandler(data) {
	if(data > 1024) return;
	var level = window.current_level = parseInt(data/1024*7);

	document.getElementById('wrapper').dataset.level = level;
	document.getElementById('level-title').innerText = levels[level].title;
	document.getElementById('level-value').innerText = 1024 - parseInt(data);//levels[level].number;
}
var emulate_heating = true,
		emulate_heating_timeout = null,
		emulate_heating_time = 5;
function emulateNativeData() {
	if(emulate_heating_timeout === null) {
		emulate_heating_timeout = setTimeout(function(e) {
			emulate_heating = false;
		}, emulate_heating_time*1000);
	}

	if(!emulate_heating) {
		var content = {
			"state"	: "" + getRandomInt(0, 7)
		};
	} else {
		var content = {
			"state"	: "heating"
		};
	}
	receiveFromNative(JSON.stringify(content));
}
function forceLevel(level) {
	var content = {
		"state"	: "" + level
	};
	receiveFromNative(JSON.stringify(content));
}
