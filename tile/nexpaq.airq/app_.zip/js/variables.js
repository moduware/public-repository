var levels = [
  {name : 'great', title : 'Great', number : '0'},
  {name : 'very_good', title : 'Very good', number : '1'},
  {name : 'good', title : 'Good', number : '2'},
  {name : 'mandatory', title : 'Mandatory', number : '3'},
  {name : 'average', title : 'Average', number : '4'},
  {name : 'bad', title : 'Bad', number : '5'},
  {name : 'very_bad', title : 'Very bad', number : '6'},
  {name : 'hazardous', title : 'Hazardous', number : '7'},
];
