window.nexpaqAPI.setCurrentModule("AirQ");

function saveButtonClickHandler(e) {
	if(!window.nexpaqAPI.emulateMode) window.nexpaqAPI.util.saveData("nexpaq.airq.quality", window.current_level);
	humane.log("Saved");//hhh
}
function socilaButtonClickHandler(e) {
	this.classList.add('hidden');
	document.getElementById('button-save').classList.add('hidden');
	document.getElementById('social-bar').classList.remove('hidden');
}
function closeSocialBarButtonClickHandler(e) {
	document.getElementById('button-open-social').classList.remove('hidden');
	document.getElementById('button-save').classList.remove('hidden');
	document.getElementById('social-bar').classList.add('hidden');
}
function counterDecreaser() {
  if(typeof window.$cache_init_counter == "undefined") {
    window.$cache_init_counter = document.getElementById('init_counter');
  }
  var val = parseInt(window.$cache_init_counter.textContent);
  if(val>0) {
    window.$cache_init_counter.textContent = --val;
  }
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.global.addEventListener('onLocationReceived', locationReceivedHandler);
	//document.getElementById('button-open-social').addEventListener('click', socilaButtonClickHandler);
	//document.getElementById('button-close-social-bar').addEventListener('click', closeSocialBarButtonClickHandler);
	//document.getElementById('button-save').addEventListener('click', saveButtonClickHandler);
	var current_date = new Date();
	var monthNames = ["january", "february", "march", "april", "may", "june",
    "july", "august", "september", "october", "november", "december"
  ];
	document.getElementById('date').textContent = current_date.getDate() + " " + monthNames[current_date.getMonth()];
	nexpaqAPI.AirQ.addEventListener('onLevelChanged', nativeDataUpdateHandler);

	nexpaqAPI.AirQ.start();
	nexpaqAPI.util.sendLocationRequest();
	setInterval(counterDecreaser, 1000);

	nexpaqAPI.AirQ.addEventListener('onHeating', function(e) {
		// show init screen
		document.getElementById('main-screen').classList.add('hidden');
		document.getElementById('init-screen').classList.remove('hidden');
	});
	nexpaqAPI.AirQ.addEventListener('onReady', function(e) {
		// show main screen
		document.getElementById('main-screen').classList.remove('hidden');
		document.getElementById('init-screen').classList.add('hidden');
	});


});
