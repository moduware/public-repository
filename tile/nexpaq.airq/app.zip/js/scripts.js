nexpaqAPI.setCurrentModule("AirQ");

var RadialProgress = function(size, barSize, barColor, backgroundColor, textColor, zIndex) { // jshint ignore:line
  this.radialProgress = document.createElement('div');
  this.style = document.createElement('style');
  this.progress = 0;
  var requestAnimationFrame = window.requestAnimationFrame ||
    window.mozRequestAnimationFrame ||
    window.webkitRequestAnimationFrame ||
    window.oRequestAnimationFrame ||
    window.msRequestAnimationFrame;

  barSize = (barSize % 2 === 1) ? (barSize + 1) : barSize;
  var innerSize = size - barSize;
  var innerMargin = barSize / 2;

  this.radialProgress.className = 'radial-progress';
  this.radialProgress.innerHTML = '<div class="inner-circle">' +
    '<div class="progress">0%<' + '/div>' +
    '</div>' +
    '<div class="outer-circle">' +
    '<div class="mask full">' +
    '<div class="fill"></div>' +
    '</div>' +
    '<div class="mask">' +
    '<div class="fill"></div>' +
    '<div class="fill fix"></div>' +
    '</div>' +
    '</div>';

  this.style.type = 'text/css';
  this.style.innerHTML = '.radial-progress {' +
    'width:' + size + 'px;' +
    'height: ' + size + 'px;' +
    'position: fixed;' +
    'margin: auto;' +
    'top: 0; right: 0; bottom: 8%; left: 0;' +
    'z-index: ' + zIndex + ';' +
    'background-color: #FFF;' +
    'border-radius: 50%;' +
    '}' +
    '.radial-progress .inner-circle {' +
    'width: ' + innerSize + 'px;' +
    'height: ' + innerSize + 'px;' +
    'position: absolute;' +
    'margin-top: ' + innerMargin + 'px;' +
    'margin-left: ' + innerMargin + 'px;' +
    'background-color: ' + backgroundColor + ';' +
    'border-radius: 50%;' +
    'z-index: 10;' +
    '}' +
    '.radial-progress .inner-circle .progress {' +
    'font-size: 23px;' +
    'position: absolute;' +
    'margin: auto;' +
    'top: 2em; right: 0; bottom: 0; left: 0.2em;' +
    'text-align: center;' +
    'color: ' + textColor + ';' +
    '}' +
    '.radial-progress .outer-circle .mask,' +
    '.radial-progress .outer-circle .fill {' +
    'width: ' + size + 'px;' +
    'height: ' + size + 'px;' +
    'position: absolute;' +
    'border-radius: 50%;' +
    '-webkit-backface-visibility: hidden;' +
    '}' +
    '.radial-progress .outer-circle .mask {' +
    'clip: rect(0px, ' + size + 'px, ' + size + 'px, ' + size / 2 + 'px);' +
    '}' +
    '.radial-progress .outer-circle .mask .fill {' +
    'clip: rect(0px, ' + size / 1.98   + 'px, ' + size + 'px, 0px);' +
    'background-color: ' + barColor + ';' +
    '}';

  document.getElementsByTagName('head')[0].appendChild(this.style);
  document.body.appendChild(this.radialProgress);

  this.remove = function() {
    var self = this;
    var scale = 1;
    var deltaScale = 0.1 / 10;

    function step() {
      scale += deltaScale;
      scale = (scale < 0) ? 0 : scale;
      self.radialProgress.style.transform = 'scale(' + scale + ')';

      if (scale > 1.1) {
        deltaScale = -1.1 / 8;
      }

      if (scale > 0) {
        requestAnimationFrame(step);
      } else {
        document.getElementsByTagName('head')[0].removeChild(self.style);
        document.body.removeChild(self.radialProgress);
      }
    }

    requestAnimationFrame(step);
  };

  this.setProgress = function(progress, duration) {
    progress = (progress > 100) ? 100 : progress;
    var self = this;
    var $maskFull = this.radialProgress.getElementsByClassName('mask full')[0];
    var $fill = this.radialProgress.getElementsByClassName('fill');
    var $fillFix = this.radialProgress.getElementsByClassName('fill fix')[0];
    var $progress = this.radialProgress.getElementsByClassName('progress')[0];
    var deltaProgress = (progress - this.progress) / (duration * 60);

    function step() {
      self.progress += deltaProgress;
      self.progress = (self.progress > progress) ? progress : self.progress;
      var rotate = self.progress * 1.8;
      $maskFull.style.transform = 'rotate(' + rotate + 'deg)';
      $progress.innerHTML = self.progress.toFixed() + '%';

      for (var i = 0; i < $fill.length; ++i) {
        $fill[i].style.transform = 'rotate(' + rotate + 'deg)';
      }

      $fillFix.style.transform = 'rotate(' + 2 * rotate + 'deg)';

      if (self.progress < progress) {
        requestAnimationFrame(step);
      }
      else {
        document.getElementById('warming-text').textContent = "Done!";
        document.getElementById('text').textContent = "";  
      }
    }
    requestAnimationFrame(step);
  };
};

function createProgress() {
  var progress = new RadialProgress(130, 15, '#0EA4E3', '#FFFFFF', '#606060', 1);

  setTimeout(function() {
    progress.setProgress(100, 33);
  }, 0);
}

function setTime(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  document.getElementById('time').textContent = hours + ':' + minutes + ' ' + ampm;;
}

function setDate(date) {
  var month = date.getMonth();
  month = month <= 9 ? '0' + month : month;       // add 0 for single digit numbers
  document.getElementById('date').textContent = month + "/" + date.getDate() + "/" + date.getFullYear() + " - ";
}

function cloudUploadHandler(label) {
  try {
    if(label != undefined) {
      nexpaqAPI.util.cloudRequest("/dataset/nexpaq.airq.quality", "POST", JSON.parse('{"value" : "'+window.current_level+'", "user_id" : "user@nexpaq.com"}'), cloudResponse, cloudError);
    }
    else {
      nexpaqAPI.util.cloudRequest("/dataset/nexpaq.airq.quality", "POST", JSON.parse('{"value" : "'+window.current_level+'", "user_id" : "user@nexpaq.com"}'), cloudResponse, cloudError);
    }
  }
  catch(e) {
      var x = document.getElementById("snackbar");
      x.textContent = "Failed!";
      x.className = "show";
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    }
}

function cloudResponse(response) {
  if(JSON.parse(response).state == 'success') {
    console.log("saved");
    var x = document.getElementById("snackbar");
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
  }
}

function cloudError(error) {
  var x = document.getElementById("snackbar");
  x.textContent = "Error " + JSON.parse(error).error_code + " : " + JSON.parse(error).message;
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
  nexpaqAPI.detectCurrentPlatform();
  if(document.body.classList.contains('platform-android')) {
    document.getElementById('heating-screen').style.height = "calc(100% - 55px)";   //adjusting height for android
    document.getElementById('result-screen').style.height = "calc(100% - 55px)";   //adjusting height for android
    document.getElementById('snapshot-screen').style.height = "calc(100% - 55px)";   //adjusting height for android
  }
	nexpaqAPI.AirQ.addEventListener('onLevelChanged', nativeDataUpdateHandler);
  nexpaqAPI.header.customize({color: "white", iconColor:"white", backgroundColor:"#0EA4E3"});
  nexpaqAPI.header.setTitle("Air Quality");
  
  document.getElementById('button-snapshot').addEventListener('click', function() {
    document.getElementById('result-screen').classList.add('hidden');
    document.getElementById('snapshot-screen').classList.remove('hidden');
    document.getElementById('measurement_table').classList.remove('slideright');
    document.getElementById('measurement_table').classList.remove('slideleft');
    document.getElementById('measurement_table').classList.add('slidedown');
  });

    document.getElementById('button-cancel').addEventListener('click', function() {
    document.getElementById('measurement_table').classList.remove('slidedown');
    document.getElementById('measurement_table').classList.remove('slideright');
    document.getElementById('measurement_table').classList.add('slideleft');
    setTimeout(function() {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById("label").value = "";
      document.getElementById('result-screen').classList.remove('hidden');
    },1000);
  });

  document.getElementById('button-history').addEventListener('click', function() {
    if(document.getElementById("label").value != undefined) {
      cloudUploadHandler(document.getElementById("label").value);
    }
    else {
      cloudUploadHandler();
    }
    document.getElementById('measurement_table').classList.remove('slideleft');
    document.getElementById('measurement_table').classList.remove('slidedown');
    document.getElementById('measurement_table').classList.add('slideright');
    setTimeout(function() {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById("label").value = "";
      document.getElementById('result-screen').classList.remove('hidden');
    },1000);
  });

  var current_date = new Date();

  setDate(current_date);
  setTime(current_date);

	createProgress();
	nexpaqAPI.AirQ.start();
	//emulateNativeData();
	//setInterval(emulateNativeData, 1000);
	nexpaqAPI.AirQ.addEventListener('onHeating', function(e) {
		//Heating
		document.getElementById('result-screen').classList.add('hidden');
		document.getElementById('heating-screen').classList.remove('hidden');		
	});

	nexpaqAPI.AirQ.addEventListener('onReady', function(e) {
		document.getElementById('heating-screen').classList.add('hidden');
    document.getElementsByClassName("radial-progress")[0].classList.add('hidden');
    nexpaqAPI.header.customize({borderBottom : "none"});
		document.getElementById('result-screen').classList.remove('hidden');
});
});

