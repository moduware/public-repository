var levels = [
  {name : 'none', title : 'None', src: 'img/none.svg'},
  {name : 'average', title : 'Average', src: 'img/average.svg'},
  {name : 'average', title : 'Average', src: 'img/average.svg'},
  {name : 'bad', title : 'Bad', src: 'img/bad.svg'},
];
