/** ================ Handlers == */
function nativeDataUpdateHandler(data) {
	if(data > 1024) return;
	var level = window.current_level = parseInt(data*4/1024);
	
	document.getElementById('wrapper').dataset.level = level;
	document.getElementById('result-title').textContent = levels[level].title;
	document.getElementById('result-value').textContent = levels[level].title;
	document.getElementById("result-svg").src  = levels[level].src;
}

var emulate_heating = true,
		emulate_heating_timeout = null,
		emulate_heating_time = 3;


function emulateNativeData() {
	if(emulate_heating_timeout === null) {
		emulate_heating_timeout = setTimeout(function(e) {
			emulate_heating = false;
		}, emulate_heating_time*1000);
	}

	if(!emulate_heating) {
		var content = {
			"state"	: "" + getRandomInt(1, 10)
		};
	} else {
		var content = {
			"state"	: "heating"
		};
	}
	receiveFromNative(JSON.stringify(content));
}
function forceLevel(level) {
	var content = {
		"state"	: "" + level
	};
	receiveFromNative(JSON.stringify(content));
}

function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}

function currentDate() {
	var today = new Date(),
		dd = today.getDate(),
		mm = today.getMonth()+1, //January is 0!
		yyyy = today.getFullYear();

	if(dd<10) {
	    dd='0'+dd;
	} 

	if(mm<10) {
	    mm='0'+mm;
	} 

	return dd+"/"+mm+"/"+yyyy;
}


/**
 * Get current time
 * @return {string} [hh:mm]
 */
function currentTime() {
	var today = new Date(),
		hh = today.getHours(),
		mm = today.getMinutes();

	if(hh<10) {
	    hh='0'+hh;
	} 

	if(mm<10) {
	    mm='0'+mm;
	}

	return hh+":"+mm; 
}