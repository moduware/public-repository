window.map = null;
// Predefined types
window.SOURCES_TYPES = {
  // Here must be default source declaration
  "default" : {
    title : "%(type)s",
    icon : "img/switcher-alcohol.svg",
    format : "%(value)f"
  },
  "nexpaq.hat.ambient_temperature" : {
    title : "Temperature",
    icon : "img/switcher-temperature.png",
    format : "%(val)f &#8451;"
  },
  "nexpaq.airq.quality" : {
    title : "Air Quality",
    icon : "img/switcher-airq.png",
    format : "Polution: %(val)s"
  },
  "nexpaq.alcohol.level" : {
    title : "Alcohol",
    icon : "img/switcher-alcohol.png",
    format : "calc(100 / 7 * %(val)s, 2)%%"
  }
};
window.DATA_RECEIVED_FROM_CLOUD=[];
window.MARKERS = {};
window.KNOWN_TILES = [];



function openSourcesScreen() {
  document.getElementById('main-screen').classList.add("hidden");
  document.getElementById('sources-screen').classList.remove("hidden");
}
function showMainScreen() {
  document.getElementById('main-screen').classList.remove("hidden");
  document.getElementById('sources-screen').classList.add("hidden");
}

document.addEventListener("DOMContentLoaded", function(event) {
  window.nexpaqAPI.global.addEventListener('onDataLoaded', timelineItemsLoadedHandler);
  window.nexpaqAPI.global.addEventListener('onLocationReceived', locationReceivedHandler);

  //initMap();

  var switchers = document.getElementsByClassName('data-switcher');
  for(var i=0; i<switchers.length; i++) {
    switchers[i].addEventListener('click', dataSwitcherClickHandler);
  }

  document.getElementById('show-sources-screen').addEventListener('click', openSourcesScreen);
  document.getElementById('toggle-all-sources').addEventListener('click', toggleAllClickHandler);

  window.nexpaqAPI.emulateMode = !window.nexpaqAPI.isApiAvailable();

  if(window.nexpaqAPI.emulateMode) {

  } else {
    console.log("nexpaqAPI: turning off emulation on real device");

    window.nexpaqAPI.util.sendLocationRequest();
  }
  nexpaqAPI.header.show('Map')

});
