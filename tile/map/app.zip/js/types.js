function dataSwitcherClickHandler(e) {
  this.classList.toggle('active');
  var type = this.dataset.type,
      activity = this.classList.contains('active');

  toggleType(type, activity);
}
function toggleAllClickHandler(e) {
  this.classList.toggle('active');
  var activity = this.classList.contains('active');

  var sources = document.getElementById('sources-list').children;
  for(var i=0; i<sources.length; i++) {
    var type = sources[i].dataset.type;
    toggleType(type, activity);
  }
}

function toggleType(type, activity) {
  var data_switchers = document.getElementById('sources-list').children;
  for(var i=0; i<data_switchers.length; i++) {
    if(data_switchers[i].dataset.type == type) {
      if(activity) {
        data_switchers[i].classList.add('active');
      } else {
        data_switchers[i].classList.remove('active');
      }
    }
  }
  var short_sources = document.getElementById('sources-panel').getElementsByClassName('data-switcher');
  for(var i=0; i<short_sources.length; i++) {
    if(short_sources[i].dataset.type == type) {
      if(activity) {
        short_sources[i].classList.add('active');
      } else {
        short_sources[i].classList.remove('active');
      }
    }
  }

  // for MAP
  toggleMapMarkers(type, activity);
}
