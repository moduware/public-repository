function addItemToTimeline(type, date, value, position_before) {
  var $timeline = document.getElementById('timeline');

  if(position_before == null) position_before = true;
  var source = SOURCES_TYPES["default"];
  if(typeof SOURCES_TYPES[type] !== undefined) {
    source = SOURCES_TYPES[type];
  }

  var title = sprintf(source["title"], {type: type});
  var icon = source["icon"];
  var value = evaluteMath(sprintf(source["format"], {val: value}));

  var html = '<div class="timeline-badge"><img src="' + icon + '" alt="' + title + ' app" /></div>' +
    '<div class="timeline-panel">' +
      '<div class="timeline-heading">' +
        '<h4 class="timeline-title">' + title + '</h4>' +
        '<p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> ' + date + '</small></p>' +
      '</div>' +
      '<div class="timeline-body">' +
        '<p>' + value + '</p>' +
      '</div>' +
    '</div>';

  var node = document.createElement("li");
  node.classList.add('data-' + type);
  node.innerHTML = html;

  if(position_before) {
    $timeline.insertBefore(node, $timeline.children[0]);
  } else {
    $timeline.insertBefore(node, null);
  }
}
function timelineScrollHandler(e) {
  if(this.scrollTop + this.offsetHeight >= this.scrollHeight) {
    console.log("loading more data!");
    if(window.loading_timeout == null) {
      document.getElementById('loading-icon').classList.add('active');

      if(!window.nexpaqAPI.emulateMode) {
        window.loading_timeout = true;
        var offset = document.getElementById('timeline').children.length;
        // here we have cloud request
        requestData("all", offset);

      } else {
        window.loading_timeout = setTimeout(function() {
          window.loading_timeout = null;
          document.getElementById('loading-icon').classList.remove('active');

          // demo data
          addItemToTimeline('nexpaq.hat.ambient_temperature', '16:56 18 Apr 2016', 36);
          addItemToTimeline('nexpaq.hat.ambient_temperature', '16:56 18 Apr 2016', 32);
          addItemToTimeline('nexpaq.airq.quality', '16:56 18 Apr 2016', 73);
          addItemToTimeline('nexpaq.alcohol.level', '16:56 18 Apr 2016', 5);
        }, 2000);
      }
    }
  }
}
