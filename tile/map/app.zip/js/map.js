function addMapMarker(type, lat, lng, value, date) {
  if(typeof window.MARKERS[type] == "undefined") {
    window.MARKERS[type] = [];
  }
  var newMarker = new google.maps.Marker({
    map: window.map,
    position: {lat: lat, lng: lng},
    title: window.SOURCES_TYPES[type].title,
    icon: window.MAP_ICON[type],
    type: type,
    value: value,
    date: date
  });
  newMarker.addListener("click", markerClickHandler);

  window.MARKERS[type].push(newMarker);
}
function toggleMapMarkers(type, activity) {
  if(typeof window.MARKERS[type] == "undefined") return;
  for(var i=0; i<window.MARKERS[type].length; i++) {
    if(activity) {
      window.MARKERS[type][i].setVisible(true);
    } else {
      window.MARKERS[type][i].setVisible(false);
    }
  }
}
function initIcons() {
  window.MAP_ICON = {
    "default" : new google.maps.MarkerImage(
      "img/switcher-alcohol.png",
      null, null, null,
      new google.maps.Size(32, 32)
    ),
    "nexpaq.hat.ambient_temperature" : new google.maps.MarkerImage(
      "img/switcher-temperature.png",
      null, null, null,
      new google.maps.Size(32, 32)
    ),
    "nexpaq.airq.quality" : new google.maps.MarkerImage(
      "img/switcher-airq.png",
      null, null, null,
      new google.maps.Size(32, 32)
    ),
    "nexpaq.alcohol.level" : new google.maps.MarkerImage(
      "img/switcher-alcohol.png",
      null, null, null,
      new google.maps.Size(32, 32)
    )
  };
}
function initMap() {
  initIcons();

  window.map = new google.maps.Map(document.getElementById('map'), {
    center: {lat: 22.5259018, lng: 113.934082},
    zoom: 10,
    //zoom: 1,
    disableDefaultUI: true,
    // mapTypeId: 'coordinate',
    // mapTypeControlOptions: {
    //   mapTypeIds: ['coordinate', google.maps.MapTypeId.ROADMAP],
    //   style: google.maps.MapTypeControlStyle.DROPDOWN_MENU
    // }
    //styles: styleArray
  });
  window.map.overlayMapTypes.insertAt(0, new CoordMapType(new google.maps.Size(256, 256)));
  //window.map.mapTypes.set('coordinate', new CoordMapType(new google.maps.Size(256, 256)));

  if(window.nexpaqAPI.emulateMode) {
    // demo data
    addMapMarker("nexpaq.airq.quality", 22.397, 113.944, 0, "26 Apr 2016");
    addMapMarker("nexpaq.alcohol.level", 22.337, 113.994, 0, "26 Apr 2016");
    addMapMarker("nexpaq.hat.ambient_temperature", 22.237, 114.004, 36.5, "26 Apr 2016");
    addMapMarker("nexpaq.hat.ambient_temperature", 22.600, 114.06, 32, "26 Apr 2016");
    addMapMarker("nexpaq.alcohol.level", 22.660, 114.1, 0, "26 Apr 2016");
  } else {
    //requestMapData("all");
  }

  map.addListener("click", mapClickHandler);
  google.maps.event.addListenerOnce(map, 'projection_changed', function() {
    // the map's projection object can now be used
    window.PROJECTION = map.getProjection() ;
  });
}
function mapClickHandler(e) {
  document.getElementById('item-info').classList.remove('active');
}
function markerClickHandler(e) {
  var type = this.type;
  document.getElementById('item-info').classList.add('active');

  document.getElementById('item-info-img').src = window.SOURCES_TYPES[type].icon;
  document.getElementById('item-info-app-name').innerText = window.SOURCES_TYPES[type].title;
  document.getElementById('item-info-value').innerText = this.value;
  document.getElementById('item-info-date').innerText = this.date;
}
