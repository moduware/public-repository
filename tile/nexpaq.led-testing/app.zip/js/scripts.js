window.nexpaqAPI.setCurrentModule("LED");
function updateLED() {
    // Get R,G,B values
    var R = parseInt(document.getElementById('R_value').value) || 0;
    var G = parseInt(document.getElementById('G_value').value) || 0;
    var B = parseInt(document.getElementById('B_value').value) || 0;
    if (status) {
        nexpaqAPI.LED.setColorRGB(R,G,B)
    } else {
        nexpaqAPI.LED.setColorRGB(0,0,0)
    }
}

function updateFlashTorch() {
    var LED1 = parseInt(document.getElementById('LED1_value').value) || 0;
    var LED2 = parseInt(document.getElementById('LED2_value').value) || 0;
    if (status) {
        nexpaqAPI.LED.turnFlashTorch(LED1,LED2);
    } 
}

function updateFlash() {
    var modeValue = parseInt(document.getElementById('mode_value').value) || 0;
    if (status) {
		nexpaqAPI.LED.makeFlash(modeValue,1000);
    } 
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	status = false;
	nexpaqAPI.header.setTitle('LED');
	nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
		nexpaqAPI.LED.turnOff();
		nexpaqAPI.util.closeApplication();
	});

	document.getElementById('turnLEDOn').addEventListener('click', function() {
		status = true;
		updateLED();
	});

	document.getElementById('turnLEDOff').addEventListener('click', function() {
		nexpaqAPI.LED.turnOff();
		status = false;
	});
	document.getElementById('flash').addEventListener('click', function() {
		status = true;
		updateFlash();
	});
	
	document.getElementById('flashOff').addEventListener('click', function() {
		status = false;
		console.log("I turnOff");
		nexpaqAPI.LED.turnFlashOff();
	});
	document.getElementById('flashTorchOff').addEventListener('click', function() {
		status = false;
		nexpaqAPI.LED.turnFlashOff();
	});
	document.getElementById('flashTorch').addEventListener('click', function() {
		status = true;
		updateFlashTorch();
	});

});
