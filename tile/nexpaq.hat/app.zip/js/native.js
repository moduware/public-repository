var current_temperature = 'ambient';
/** ================ Handlers == */

function nativeDataUpdateHandler(data) {
	if(data != undefined) {
		temperature = current_temperature == 'ambient' ? data.ambient_temperature.toFixed(1) : data.object_temperature.toFixed(1);
		if(parseInt(temperature) > 50 && parseInt(temperature) < -50) {
			document.getElementById('temp-value1').textContent = 'Error';
			return;
		}
		window.current_temp = data.ambient_temperature.toFixed(1);
		document.getElementById('temp-value1').textContent = temperature+'°';
		document.getElementById('scale-svg').style.top = ((temperature-25)*7)+'px';		//setting temperature scale
		window.current_humidity = data.ambient_humidity.toFixed(0);
		document.getElementById('humidity-value1').textContent = data.ambient_humidity.toFixed(0)+'%';
	}
}

/**
 * Convert celsius value to farnheit value
 * @param {float} value [celsius value]
 */
function Celsius2Farenheit(value) {
	return value*1.8 + 32;
}
