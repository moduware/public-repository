nexpaqAPI.setCurrentModule('HaT');

function setTime(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  document.getElementById('time').textContent = hours + ':' + minutes + ' ' + ampm;;
}

function setDate(date) {
  var month = date.getMonth()+1;
  month = month <= 9 ? '0' + month : month;       // add 0 for single digit numbers
  document.getElementById('date').textContent = month + "/" + date.getDate() + "/" + date.getFullYear() + " - ";
}

function changeMeasureTypeHandler(e) {
  document.getElementById('button-object').classList.toggle('active');
  if(document.getElementById('button-object').classList.contains('active')) {
    current_temperature = 'object';
  }
  else {
    current_temperature = 'ambient';
  }
}

function cloudUploadHandler(label) {
  try {
      nexpaqAPI.util.cloudRequest("/dataset/nexpaq.hat.humidity", "POST", JSON.parse('{"value" : "'+window.current_humidity+'", "user_id" : "user@nexpaq.com"}'), cloudResponse, cloudError);
      nexpaqAPI.util.cloudRequest("/dataset/nexpaq.hat.temperature", "POST", JSON.parse('{"value" : "'+window.current_temp+'", "user_id" : "user@nexpaq.com"}'), cloudResponse, cloudError);
  }
  catch(e) {
      var x = document.getElementById("snackbar");
      x.textContent = "Failed!";
      x.className = "show";
      setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    }
}

function cloudResponse(response) {
  if(JSON.parse(response).state == 'success') {
    console.log("saved");
    var x = document.getElementById("snackbar");
    x.textContent = "Saved";
    x.className = "show";
    setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
  }
}

function cloudError(error) {
  var x = document.getElementById("snackbar");
  x.textContent = "Error " + JSON.parse(error).error_code + " : " + JSON.parse(error).message;
  x.className = "show";
  setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
  nexpaqAPI.header.customize({color: "white", iconColor:"white", backgroundColor:"#FFB931", borderBottom:"none"});
  nexpaqAPI.header.setTitle("Temperature");
	
  var tempValue = parseInt(document.getElementById('temp-value1').textContent);
  document.getElementById('scale-svg').style.top = ((tempValue-25)*7)+'px';       ////setting temperature scale
  
  nexpaqAPI.HaT.addEventListener('onDataUpdated', nativeDataUpdateHandler);
	
  document.getElementById('button-object').addEventListener('click', changeMeasureTypeHandler);
  document.getElementById('button-snapshot').addEventListener('click', function() {
    var current_date = new Date();
    setDate(current_date);
    setTime(current_date);
    document.getElementById('result-screen').classList.add('hidden');
    document.getElementById('snapshot-screen').classList.remove('hidden');
    document.getElementById('measurement_table').classList.remove('slideright');
    document.getElementById('measurement_table').classList.remove('slideleft');
    document.getElementById('measurement_table').classList.add('slidedown');
    document.getElementById('temp-value2').textContent = document.getElementById('temp-value1').textContent;
    document.getElementById('humidity-value2').textContent = document.getElementById('humidity-value1').textContent;

  });

    document.getElementById('button-cancel').addEventListener('click', function() {
    document.getElementById('measurement_table').classList.remove('slidedown');
    document.getElementById('measurement_table').classList.remove('slideright');
    document.getElementById('measurement_table').classList.add('slideleft');
    setTimeout(function() {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById("label").value = "";
      document.getElementById('result-screen').classList.remove('hidden');
    },1000);
  });

  document.getElementById('button-history').addEventListener('click', function() {
    if(document.getElementById("label").value != undefined) {
      cloudUploadHandler(document.getElementById("label").value);
    }
    else {
      cloudUploadHandler();
    }
    document.getElementById('measurement_table').classList.remove('slideleft');
    document.getElementById('measurement_table').classList.remove('slidedown');
    document.getElementById('measurement_table').classList.add('slideright');
    setTimeout(function() {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById("label").value = "";
      document.getElementById('result-screen').classList.remove('hidden');
    },1000);
  });

  nexpaqAPI.global.addEventListener('onBackButtonClicked', function(e) {
    if(document.getElementById('result-screen').classList.contains('hidden')) {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById('result-screen').classList.remove('hidden');
    } else {
      nexpaqAPI.util.closeApplication();
    }
  });

	nexpaqAPI.HaT.start();
	
});
