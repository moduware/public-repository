if(typeof JSON === "undefined") {
	@@include('../vendor/json3.min.js')
}
@@include('../js/lib/nexpaqAPI.js')

window.nexpaqAPI.emulateMode = window.EmulateModule = false;
window.nexpaqAPI.setCurrentModule('HaT');

//Default hotkeys events calls are enough, but here is example:
window.nexpaqAPI.HaT.addEventListener('onModuleConnected', moduleConnectedHandler);
window.nexpaqAPI.HaT.addEventListener('onModuleDisconnected', moduleConnectedHandler);
window.nexpaqAPI.HaT.addEventListener('onIntervalCalled', moduleIntervalHandler);
window.nexpaqAPI.HaT.addEventListener('onDataUpdated', sensorDataUpdated);

function moduleConnectedHandler() {
	// TODO: start sensor
	window.nexpaqAPI.HaT.start();
	window.nexpaqAPI.util.setInterval('hat_tile_update', 5*60*1000, false);
}
function moduleDisconnectedHandler() {
	// TODO: reset tile?
}
function moduleIntervalHandler(name) {
	window.nexpaqAPI.HaT.start();
}
function sensorDataUpdated(data) {
	// TODO: show info on tile?
	var percent = parseInt(data.ambient_humidity);
	if(percent > 100) percent = 100;
	var update = {
		data: data.ambient_temperature.toFixed(1) + '°C',
		data_second: percent + '%'
	};
	window.nexpaqAPI.HaT.stop();
	window.nexpaqAPI.util.updateTile(update);
}
