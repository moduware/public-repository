nexpaqAPI.setCurrentModule("Alcohol");

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('Alcohol');
	nexpaqAPI.Alcohol.addEventListener('onLevelChanged', nativeDataUpdateHandler);

	document.getElementById('startSensor').addEventListener('click', function() {
		console.log("sensor on");
		nexpaqAPI.Alcohol.start();
	});

	nexpaqAPI.AirQ.addEventListener('onHeating', function(e) {
		document.getElementById('alcoholValue').innerText = "Heating..";
	});

	document.getElementById('stopSensor').addEventListener('click', function() {
		console.log("sensor off");
		nexpaqAPI.Alcohol.stop();
	});

	nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
		nexpaqAPI.Alcohol.stop();
		nexpaqAPI.util.closeApplication();
	});

});
