nexpaqAPI.setCurrentModule("USBStick");

function checkStatus() {
	console.log("checking status");
	nexpaqAPI.USBStick.statusCheck();
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
  	nexpaqAPI.header.setTitle("USB");
	nexpaqAPI.header.customize({color: "white", iconColor:"white", backgroundColor:"#4BC3DA"});
	nexpaqAPI.USBStick.addEventListener('onPluggedIn', function() {
		document.getElementById('button-connect').classList.add('hidden');
		document.getElementById('svg-disconnected').classList.add('hidden');
		document.getElementById('svg-connected').classList.remove('hidden');
		document.getElementById('button-file-manager').classList.remove('hidden');
	});
	nexpaqAPI.USBStick.addEventListener('onPluggedOut', function() {
		document.getElementById('button-file-manager').classList.add('hidden');
		document.getElementById('svg-connected').classList.add('hidden');
		document.getElementById('svg-disconnected').classList.remove('hidden');
		document.getElementById('button-connect').classList.remove('hidden');
	});

	document.getElementById('button-connect').addEventListener('click', function() {
		console.log("connecting..");
		nexpaqAPI.USBStick.connect();
		document.getElementById('button-connect').textContent = "Connecting...";
	});

	document.getElementById('button-file-manager').addEventListener('click', function() {
		
	});

	setInterval(checkStatus, 5000);
	
});
