
/** ================ Handlers == */
function nativeDataUpdateHandler(data) {	
	
	if(data.state=='pluggedIn') {

	}
	else if(data.state=='pluggedOut') {

	}
}
