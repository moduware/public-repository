nexpaqAPI.setCurrentModule("TFCard");

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.customize({backgroundColor:"#D43755",color:"#FFFFFF",iconColor:"#FFFFFF", borderBottom: "none"});
	nexpaqAPI.header.setTitle('SD Card');

	
	nexpaqAPI.TFCard.addEventListener('onSdCardIn', function(){
		console.log("connected");
		document.getElementById('connect-panel').style.backgroundImage = 'url(img/connect_active.svg)';
		document.getElementById('connect').classList.add("hidden");
		document.getElementById('open').classList.remove("hidden");
	});
	nexpaqAPI.TFCard.addEventListener('onSdCardOut', function(){
		console.log("disconnected");
		document.getElementById('connect-panel').style.backgroundImage = 'url(img/connect.svg)';
		document.getElementById('open').classList.add("hidden");
		document.getElementById('connect').classList.remove("hidden");
		clearInterval(interval);
	});
	document.getElementById('connect').addEventListener('click', function() {
		console.log("connecting");
		nexpaqAPI.TFCard.connect();
		nexpaqAPI.TFCard.statusCheck()
		var interval = setInterval(function() {
			nexpaqAPI.TFCard.statusCheck();
		}, 5000);
	});

	document.getElementById('open').addEventListener('click', function() {
		// File Manager
	});

});
