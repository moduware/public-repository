
var subject= "";
var selected= "";
var body= "";

function mainButtonClickHandler(e){
	selected = document.querySelector('input[name="option"]:checked');
	// We cannot continue if nothing selected
	if(selected == null) return;
	subject = document.querySelector('label[for="' + selected.id +'"]').innerText;
	document.getElementById('feedback-form').dataset.name = subject;
	document.getElementById('send-message').classList.remove('hidden');
	document.getElementById('write-message').classList.add('hidden');
	console.log(subject);
};
function sendButtonClickHandler(e){
	body = document.getElementById("body").value;
	// We cannot send message if it is empty of full of spaces
	if(document.getElementById("body").value.replace(/\s/g, '') == '') return;
	window.location.href = 'mailto:info@nexpaq.com?body='+body+'&subject='+subject;
}


/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	$main_button = document.getElementById('main-button');
	$send_button= document.getElementById('send-button');
	$main_button.addEventListener('click', mainButtonClickHandler);
	$send_button.addEventListener('click', sendButtonClickHandler);
	//Sets up the title in the header
	nexpaqAPI.header.show("Feedback");
	nexpaqAPI.global.addEventListener('onBackButtonClicked', function(e) {
		if(document.getElementById('write-message').classList.contains('hidden')) {
			// going to previous page
			document.getElementById('send-message').classList.add('hidden');
			document.getElementById('write-message').classList.remove('hidden');
		} else {
			nexpaqAPI.util.closeApplication();
		}
	});
});
