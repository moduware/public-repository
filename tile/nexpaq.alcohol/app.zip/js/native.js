
window.lastTimeRecieved = 0;
window.lastData = -1;

function resultImage() {
  if (lastData >= 700) {
    document.getElementById("resultImg").style.backgroundImage = 'url("img/intoxicated.svg")';
    document.getElementById('result-text').textContent = "Intoxicated";
  } else {
     document.getElementById("resultImg").style.backgroundImage = 'url("img/sober.svg")';
    document.getElementById('result-text').textContent = "Sober";
  }
}

/** ================ Handlers == */
function nativeDataUpdateHandler(data) {
  if(data > 1024) return;
  if(data != lastData) {
    lastData = data;
  }
  resultImage();
}


