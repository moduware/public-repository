nexpaqAPI.setCurrentModule("Alcohol");
preloadImages([]);


function createProgress() {
  var progress = new RadialProgress(130, 15, '#00C3BD', '#FFFFFF', '#606060', 1);

  setTimeout(function() {
    progress.setProgress(100, 75);
  }, 0);
}

function setTime(date) {
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var ampm = hours >= 12 ? 'PM' : 'AM';
  hours = hours % 12;
  hours = hours ? hours : 12; 
  minutes = minutes < 10 ? '0'+minutes : minutes;
  document.getElementById('time').textContent = hours + ':' + minutes + ' ' + ampm;;
}

function setDate(date) {
  var month = date.getMonth();
  month = month <= 9 ? '0' + month : month;       
  document.getElementById('date').textContent = month + "/" + date.getDate() + "/" + date.getFullYear() + " - ";
}




/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
  nexpaqAPI.header.customize({backgroundColor:"#00C3BD",color:"#FFFFFF",iconColor:"#FFFFFF", borderBottom: "none"});
  var number=1;
  nexpaqAPI.header.setTitle('Alcohol');



  nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
    nexpaqAPI.Alcohol.stop();
    nexpaqAPI.util.closeApplication();
  });

  nexpaqAPI.Alcohol.start();
  createProgress();


  nexpaqAPI.global.addEventListener('onLocationReceived', locationReceivedHandler);
  nexpaqAPI.util.sendLocationRequest();

  nexpaqAPI.Alcohol.addEventListener('onLevelChanged', nativeDataUpdateHandler);

  nexpaqAPI.Alcohol.addEventListener('onHeating', function(e) {
		document.getElementById('result-screen').classList.add('hidden');
		document.getElementById('init-screen').classList.remove('hidden');
    window.randomize = function() {
      document.getElementById('radial-progress').setAttribute('data-progress',100);
    }
    setTimeout(window.randomize, 200);
    function progressUpdate() {
    document.getElementById('numbers').textContent = number + "%";
      if (number<100) {
        number++;
      }
    }
    setInterval(progressUpdate, 650);
	});

	nexpaqAPI.Alcohol.addEventListener('onReady', function(e) {
		document.getElementById('init-screen').classList.add('hidden');
		document.getElementById('result-screen').classList.remove('hidden');
    document.getElementById("wrapper").style.backgroundColor = "#00C3BD";
    resultImage();
    console.log("sensor on");
	});
  
  document.getElementById('button-snapshot').addEventListener('click', function() {
    var current_date = new Date();
    setDate(current_date);
    setTime(current_date);
    document.getElementById('value').textContent = document.getElementById('result-text').textContent;
    document.getElementById('result-screen').classList.add('hidden');
    document.getElementById('snapshot-screen').classList.remove('hidden');
    document.getElementById('measurement_table').classList.remove('slideright');
    document.getElementById('measurement_table').classList.remove('slideleft');
    document.getElementById('measurement_table').classList.add('slidedown');
  });

  document.getElementById('button-cancel').addEventListener('click', function() {
    document.getElementById('measurement_table').classList.remove('slidedown');
    document.getElementById('measurement_table').classList.remove('slideright');
    document.getElementById('measurement_table').classList.add('slideleft');
    setTimeout(function() {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById('value').textContent = "";
      document.getElementById('label').value = "";
      document.getElementById('result-screen').classList.remove('hidden');
    },1000);
  });

  document.getElementById('button-history').addEventListener('click', function() {
    var result = document.getElementById("value").textContent;
    var tagTitle = document.getElementById('label').value;
   
    if(result != undefined) {
      var name = "nexpaq.alcohol";
      var params = {value:result};
     //  if (tagTitle != "") {
     //    var tag = [];
     //    tag.push(tagTitle);
     //    params.tags = tag;
     // }
     //console.log(params);
      nexpaqAPI.util.saveDataset(name,params);
    }
  
    document.getElementById('measurement_table').classList.remove('slideleft');
    document.getElementById('measurement_table').classList.remove('slidedown');
    document.getElementById('measurement_table').classList.add('slideright');
    setTimeout(function() {
      document.getElementById('snapshot-screen').classList.add('hidden');
      document.getElementById('value').textContent = "";
       document.getElementById('label').value = "";
      document.getElementById('result-screen').classList.remove('hidden');
    },1000);
  });



});
