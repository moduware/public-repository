function locationReceivedHandler(location) {
  console.log(location);
  window.geo_location = location;
  var location_label = '';
  if(location.city != null) location_label += location.city;
  if(location.province != null) location_label += ' ' + location.province;
  if(location.country != null) location_label += ' ' + location.country;
  document.getElementById("location-city").innerText = location_label;
}
