nexpaqAPI.setCurrentModule("Alcohol");
preloadImages([]);
window.conImages=[];

function saveButtonClickHandler(e) {
	if(!nexpaqAPI.emulateMode) {
		if(typeof window.geo_location !== "undefined") {
			nexpaqAPI.util.saveData("nexpaq.alcohol.level", window.current_value, null, geo_location.coords);
		} else {
			nexpaqAPI.util.saveData("nexpaq.alcohol.level", window.current_value);
		}
	}

	humane.log("Saved");
}
function setCon(grad) {
	document.getElementById('init-screen').dataset.angle = grad;
}
var color_range = [
	'#59bbea', '#30C6E1', '#1DC9C0', '#26D2A9', '#ADF881', '#E2D065', '#DE8D5E', '#e7686a'
];
function setResult(value) {
	var angle = -145 + value/100*290,
			color = parseInt(value/100*7);
	console.log(angle);
	document.getElementById('result-value').textContent = value + '%';
	document.getElementById('result-dot').style.transform = 'rotate(' + angle + 'deg)';
	document.getElementById('result-dot').style.webkitTransform = 'rotate(' + angle + 'deg)';
	document.getElementById('result-circle').style.color = color_range[color];
	//document.getElementById('result-screen').dataset.value = window.current_value = value;
}
function setBiggestResult(value) {
	var color = parseInt(value/100*7);
	document.getElementById('max-value').textContent = value;
	document.getElementById('max-value').style.color = color_range[color];
}
function startCountdown(time) {
	if(typeof window.con_time_interval !== 'undefined') return;
	nexpaqAPI.Alcohol.start();
	document.getElementById('init-screen').classList.add('countdown');
	window.con_grad = 0;
	window.con_time = 1;
	window.con_time_fin = time;
	document.getElementById('button-start-sensor-counter').innerText =  window.con_time_fin - window.con_time + 1;
	window.con_time_interval = setInterval(function() {
		if(window.con_time >= window.con_time_fin) {
			clearInterval(window.con_time_interval);
			// document.getElementById('init-screen').classList.add('hidden');
			// startProbe();
		}
		document.getElementById('button-start-sensor-counter').innerText =  window.con_time_fin - window.con_time;
		window.con_time++;
	}, 1000);
}
function startProbe() {
	// document.getElementById('result-screen').classList.add('hidden');
	// document.getElementById('help-screen').classList.remove('hidden');
	// results = [];
	// setTimeout(stopProbe, 3*1000);
	window.last_result = window.biggest_result = 0;
	setResult(0);
	setBiggestResult(0);
}
function stopProbe() {
	var highest = 0;
	for(var i=0; i<results.length; i++) {
		if(results[i] > highest) highest = results[i];
	}
	setResult(highest);
	document.getElementById('help-screen').classList.add('hidden');
	document.getElementById('result-screen').classList.remove('hidden');
}

var sheet = (function() {
	// Create the <style> tag
	var style = document.createElement('style');

	// WebKit hack :(
	style.appendChild(document.createTextNode(''));

	// Add the <style> element to the page
	document.head.appendChild(style);

	return style.sheet;
})();

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.global.addEventListener('onLocationReceived', locationReceivedHandler);
	document.getElementById('button-start-sensor').addEventListener('click', function() {startCountdown(60);});
	document.getElementById('button-try-again').addEventListener('click', startProbe);
	document.getElementById('button-save').addEventListener('click', saveButtonClickHandler);

	nexpaqAPI.Alcohol.addEventListener('onLevelChanged', onNativeDataUpdate);
	nexpaqAPI.AirQ.addEventListener('onHeating', function(e) {
		//document.getElementById('help-screen').classList.add('hidden');
		document.getElementById('result-screen').classList.add('hidden');

		// show init screen
		document.getElementById('init-screen').classList.remove('hidden');
		startCountdown(60);
	});
	nexpaqAPI.AirQ.addEventListener('onReady', function(e) {
		window.con_time = window.con_time_fin;
		document.getElementById('init-screen').classList.add('hidden');
		document.getElementById('result-screen').classList.remove('hidden');
		//startProbe();
		// show main screen
		// document.getElementById('main-screen').classList.remove('hidden');
		// document.getElementById('init-screen').classList.add('hidden');
	});
	nexpaqAPI.util.sendLocationRequest();
});
