/** ================ Handlers == */
var last_result = 0;
var biggest_result = 0;
function onNativeDataUpdate(value) {
	if(value > 1024) return;
	value = parseInt(value) / 1024 * 100;
	value = parseInt(value);
	if(value != last_result) {
		if(value > biggest_result) {
			biggest_result = value;
			setBiggestResult(biggest_result);
		}
		last_result = value;
		setResult(value);
		//var percent = nexpaqAPI.Alcohol.adc/1024*100;
		//console.log('Detailed percent: ' + percent + '%');
	}
}
function emulateNativeData() {
	var content = {
		"state"	: getRandomInt(0, 7)
	};
	receiveFromNative(JSON.stringify(content));
}
