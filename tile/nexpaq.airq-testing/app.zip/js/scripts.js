nexpaqAPI.setCurrentModule("AirQ");

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('Air Quality');
	nexpaqAPI.AirQ.addEventListener('onLevelChanged', nativeDataUpdateHandler);

	document.getElementById('startSensor').addEventListener('click', function() {
		console.log("sensor on");
		nexpaqAPI.AirQ.start();
	});

	nexpaqAPI.AirQ.addEventListener('onHeating', function(e) {
	document.getElementById('airqValue').innerText = "Heating..";
	});

	document.getElementById('stopSensor').addEventListener('click', function() {
		console.log("sensor off");
		nexpaqAPI.AirQ.stop();
	});

	nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
		nexpaqAPI.AirQ.stop();
		nexpaqAPI.util.closeApplication();
	});

});
