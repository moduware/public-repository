var test = {
  showDashboard: function() {
    myApp.mainView.router.load({pageName: 'dashboard'});
  },
  connectGateway: function() {
    nxp_gatewayConnected(JSON.stringify({
      uuid: '124',
      name: 'alex',
      type: 'nexpaq.gateway',
      slots: 6,
      modules: []
    }));
  },
  connectModule: function() {
    nxp_moduleConnected(JSON.stringify({
        slot: 0,
        size: 1,
        productUUID: '666',
        gatewayUUID: '124',
        productID: 'nexpaq.led',
        name: 'LED',
        tileID: 'nexpaq.led'
    }));
  },
  sendUpdate: function() {
    nxp_updateAvailable(JSON.stringify({
      item: 'tile:nexpaq.led',
      icon: '../../../icons/tiles/nexpaq.led.svg',
      color: 'red',
      text: 'LED tile update',
      version: '0.0.1',
      size: '2Mb',
      action: 'update-tile',
      actionArguments: ['nexpaq.led', '0.0.1']
    }));
  }
};
