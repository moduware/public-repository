nexpaqAPI.setCurrentModule("Backup");

function checkStatus() {
	console.log("checking status");
	nexpaqAPI.Backup.statusCheck();
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
  	nexpaqAPI.header.setTitle("Backup");
	nexpaqAPI.header.customize({color: "white", iconColor:"white", backgroundColor:"#5999DE"});
	nexpaqAPI.Backup.addEventListener('onSdCardIn', function() {
		document.getElementById('button-connect').classList.add('hidden');
		document.getElementById('svg-disconnected').classList.add('hidden');
		document.getElementById('svg-connected').classList.remove('hidden');
		document.getElementById('button-file-manager').classList.remove('hidden');
	});
	nexpaqAPI.Backup.addEventListener('onSdCardOut', function() {
		document.getElementById('button-file-manager').classList.add('hidden');
		document.getElementById('svg-connected').classList.add('hidden');
		document.getElementById('svg-disconnected').classList.remove('hidden');
		document.getElementById('button-connect').classList.remove('hidden');
	});

	document.getElementById('button-connect').addEventListener('click', function() {
		console.log("connecting..");
		nexpaqAPI.Backup.connect();
		document.getElementById('button-connect').textContent = "Connecting...";
	});

	document.getElementById('button-file-manager').addEventListener('click', function() {
		
	});

	setInterval(checkStatus, 5000);
	
});
