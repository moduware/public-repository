nexpaqAPI.setCurrentModule("Laser");
window.presentation_mode_active = false;

function coverOpenHandler() {
	document.getElementById('control_panel').classList.remove('hidden');
	document.getElementById('instructions_panel').classList.add('hidden');
}
function presentationModeClickHandler(e) {
	if(window.presentation_mode_active) {
		window.presentation_mode_active = false;
	} else {
		window.presentation_mode_active = true;
	}
	document.getElementById('myonoffswitch').classList.toggle('active');
}
function buttonMouseDownHandler(e) {
	if(window.presentation_mode_active) {
		if(this.classList.contains('active')) {
			this.classList.remove('active');
			cover_indicator.classList.remove('active');
			console.log("laser off");
			window.nexpaqAPI.Laser.off();
		} else {
			this.classList.add('active');
			cover_indicator.classList.add('active');
			console.log("laser on");
			window.nexpaqAPI.Laser.on();
		}
	} else {
		this.classList.add('active');
		cover_indicator.classList.add('active');
		console.log("laser on");
		window.nexpaqAPI.Laser.on();
	}
}
function buttonMouseUpHandler(e) {
	if(!window.presentation_mode_active) {
		this.classList.remove('active');
		cover_indicator.classList.remove('active');
		console.log("laser off");
		window.nexpaqAPI.Laser.off();
	}
}
/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.cleanButtons();
	document.getElementById('myonoffswitch').addEventListener('change', presentationModeClickHandler);
	document.getElementById('button-close-instruction').addEventListener('click', coverOpenHandler);
	document.getElementById('laser_button').addEventListener('touchstart', buttonMouseDownHandler);
	document.getElementById('laser_button').addEventListener('touchend', buttonMouseUpHandler);
});
