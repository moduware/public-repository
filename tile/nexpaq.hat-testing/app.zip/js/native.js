window.lastTimeRecieved = 0;
window.lastData = {
	ambient_temperature: null,
	object_temperature: null,
	ambient_humidity: null
};

/** ================ Handlers == */
function nativeDataUpdateHandler(data) {
	var ambient_temperature = data.ambient_temperature.toFixed(1),
			object_temperature = data.object_temperature.toFixed(1),
			ambient_humidity = data.ambient_humidity.toFixed(1),
			current_time = new Date().getTime(),
			interval = current_time - window.lastTimeRecieved;

	if(window.lastTimeRecieved == 0) {
		document.getElementById('intervalValue').textContent = -1;
	} else {
		document.getElementById('intervalValue').textContent = interval;
	}
	window.lastTimeRecieved = current_time;

	if(ambient_temperature != lastData.ambient_temperature) {
		lastData.ambient_temperature = ambient_temperature;
		document.getElementById('ambientTemperatureValue').textContent = ambient_temperature;
	}
	if(object_temperature != lastData.object_temperature) {
		lastData.object_temperature = object_temperature;
		document.getElementById('objectTemperatureValue').textContent = object_temperature;
	}
	if(ambient_humidity != lastData.ambient_humidity) {
		lastData.ambient_humidity = ambient_humidity;
		document.getElementById('humidityValue').textContent = ambient_humidity;
	}
}
