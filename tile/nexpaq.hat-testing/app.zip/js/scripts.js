window.nexpaqAPI.setCurrentModule("HaT");

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('Temperature & Humidity #');
	nexpaqAPI.HaT.addEventListener('onDataUpdated', nativeDataUpdateHandler);

	nexpaqAPI.HaT.start();
});
