// title: Turn on speaker
function NP_start_Speaker () {
	window.nexpaqAPI.Speaker.connect();
}
// title: Turn off speaker
function NP_stop_Speaker () {
	window.nexpaqAPI.Speaker.disconnect();
}

/*! JSON v3.3.2 | http://bestiejs.github.io/json3 | Copyright 2012-2014, Kit Cambridge | http://kit.mit-license.org */
(function(){function N(p,r){function q(a){if(q[a]!==w)return q[a];var c;if("bug-string-char-index"==a)c="a"!="a"[0];else if("json"==a)c=q("json-stringify")&&q("json-parse");else{var e;if("json-stringify"==a){c=r.stringify;var b="function"==typeof c&&s;if(b){(e=function(){return 1}).toJSON=e;try{b="0"===c(0)&&"0"===c(new t)&&'""'==c(new A)&&c(u)===w&&c(w)===w&&c()===w&&"1"===c(e)&&"[1]"==c([e])&&"[null]"==c([w])&&"null"==c(null)&&"[null,null,null]"==c([w,u,null])&&'{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}'==
c({a:[e,!0,!1,null,"\x00\b\n\f\r\t"]})&&"1"===c(null,e)&&"[\n 1,\n 2\n]"==c([1,2],null,1)&&'"-271821-04-20T00:00:00.000Z"'==c(new C(-864E13))&&'"+275760-09-13T00:00:00.000Z"'==c(new C(864E13))&&'"-000001-01-01T00:00:00.000Z"'==c(new C(-621987552E5))&&'"1969-12-31T23:59:59.999Z"'==c(new C(-1))}catch(f){b=!1}}c=b}if("json-parse"==a){c=r.parse;if("function"==typeof c)try{if(0===c("0")&&!c(!1)){e=c('{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}');var n=5==e.a.length&&1===e.a[0];if(n){try{n=!c('"\t"')}catch(d){}if(n)try{n=
1!==c("01")}catch(g){}if(n)try{n=1!==c("1.")}catch(m){}}}}catch(X){n=!1}c=n}}return q[a]=!!c}p||(p=k.Object());r||(r=k.Object());var t=p.Number||k.Number,A=p.String||k.String,H=p.Object||k.Object,C=p.Date||k.Date,G=p.SyntaxError||k.SyntaxError,K=p.TypeError||k.TypeError,L=p.Math||k.Math,I=p.JSON||k.JSON;"object"==typeof I&&I&&(r.stringify=I.stringify,r.parse=I.parse);var H=H.prototype,u=H.toString,v,B,w,s=new C(-0xc782b5b800cec);try{s=-109252==s.getUTCFullYear()&&0===s.getUTCMonth()&&1===s.getUTCDate()&&
10==s.getUTCHours()&&37==s.getUTCMinutes()&&6==s.getUTCSeconds()&&708==s.getUTCMilliseconds()}catch(Q){}if(!q("json")){var D=q("bug-string-char-index");if(!s)var x=L.floor,M=[0,31,59,90,120,151,181,212,243,273,304,334],E=function(a,c){return M[c]+365*(a-1970)+x((a-1969+(c=+(1<c)))/4)-x((a-1901+c)/100)+x((a-1601+c)/400)};(v=H.hasOwnProperty)||(v=function(a){var c={},e;(c.__proto__=null,c.__proto__={toString:1},c).toString!=u?v=function(a){var c=this.__proto__;a=a in(this.__proto__=null,this);this.__proto__=
c;return a}:(e=c.constructor,v=function(a){var c=(this.constructor||e).prototype;return a in this&&!(a in c&&this[a]===c[a])});c=null;return v.call(this,a)});B=function(a,c){var e=0,b,f,n;(b=function(){this.valueOf=0}).prototype.valueOf=0;f=new b;for(n in f)v.call(f,n)&&e++;b=f=null;e?B=2==e?function(a,c){var e={},b="[object Function]"==u.call(a),f;for(f in a)b&&"prototype"==f||v.call(e,f)||!(e[f]=1)||!v.call(a,f)||c(f)}:function(a,c){var e="[object Function]"==u.call(a),b,f;for(b in a)e&&"prototype"==
b||!v.call(a,b)||(f="constructor"===b)||c(b);(f||v.call(a,b="constructor"))&&c(b)}:(f="valueOf toString toLocaleString propertyIsEnumerable isPrototypeOf hasOwnProperty constructor".split(" "),B=function(a,c){var e="[object Function]"==u.call(a),b,h=!e&&"function"!=typeof a.constructor&&F[typeof a.hasOwnProperty]&&a.hasOwnProperty||v;for(b in a)e&&"prototype"==b||!h.call(a,b)||c(b);for(e=f.length;b=f[--e];h.call(a,b)&&c(b));});return B(a,c)};if(!q("json-stringify")){var U={92:"\\\\",34:'\\"',8:"\\b",
12:"\\f",10:"\\n",13:"\\r",9:"\\t"},y=function(a,c){return("000000"+(c||0)).slice(-a)},R=function(a){for(var c='"',b=0,h=a.length,f=!D||10<h,n=f&&(D?a.split(""):a);b<h;b++){var d=a.charCodeAt(b);switch(d){case 8:case 9:case 10:case 12:case 13:case 34:case 92:c+=U[d];break;default:if(32>d){c+="\\u00"+y(2,d.toString(16));break}c+=f?n[b]:a.charAt(b)}}return c+'"'},O=function(a,c,b,h,f,n,d){var g,m,k,l,p,r,s,t,q;try{g=c[a]}catch(z){}if("object"==typeof g&&g)if(m=u.call(g),"[object Date]"!=m||v.call(g,
"toJSON"))"function"==typeof g.toJSON&&("[object Number]"!=m&&"[object String]"!=m&&"[object Array]"!=m||v.call(g,"toJSON"))&&(g=g.toJSON(a));else if(g>-1/0&&g<1/0){if(E){l=x(g/864E5);for(m=x(l/365.2425)+1970-1;E(m+1,0)<=l;m++);for(k=x((l-E(m,0))/30.42);E(m,k+1)<=l;k++);l=1+l-E(m,k);p=(g%864E5+864E5)%864E5;r=x(p/36E5)%24;s=x(p/6E4)%60;t=x(p/1E3)%60;p%=1E3}else m=g.getUTCFullYear(),k=g.getUTCMonth(),l=g.getUTCDate(),r=g.getUTCHours(),s=g.getUTCMinutes(),t=g.getUTCSeconds(),p=g.getUTCMilliseconds();
g=(0>=m||1E4<=m?(0>m?"-":"+")+y(6,0>m?-m:m):y(4,m))+"-"+y(2,k+1)+"-"+y(2,l)+"T"+y(2,r)+":"+y(2,s)+":"+y(2,t)+"."+y(3,p)+"Z"}else g=null;b&&(g=b.call(c,a,g));if(null===g)return"null";m=u.call(g);if("[object Boolean]"==m)return""+g;if("[object Number]"==m)return g>-1/0&&g<1/0?""+g:"null";if("[object String]"==m)return R(""+g);if("object"==typeof g){for(a=d.length;a--;)if(d[a]===g)throw K();d.push(g);q=[];c=n;n+=f;if("[object Array]"==m){k=0;for(a=g.length;k<a;k++)m=O(k,g,b,h,f,n,d),q.push(m===w?"null":
m);a=q.length?f?"[\n"+n+q.join(",\n"+n)+"\n"+c+"]":"["+q.join(",")+"]":"[]"}else B(h||g,function(a){var c=O(a,g,b,h,f,n,d);c!==w&&q.push(R(a)+":"+(f?" ":"")+c)}),a=q.length?f?"{\n"+n+q.join(",\n"+n)+"\n"+c+"}":"{"+q.join(",")+"}":"{}";d.pop();return a}};r.stringify=function(a,c,b){var h,f,n,d;if(F[typeof c]&&c)if("[object Function]"==(d=u.call(c)))f=c;else if("[object Array]"==d){n={};for(var g=0,k=c.length,l;g<k;l=c[g++],(d=u.call(l),"[object String]"==d||"[object Number]"==d)&&(n[l]=1));}if(b)if("[object Number]"==
(d=u.call(b))){if(0<(b-=b%1))for(h="",10<b&&(b=10);h.length<b;h+=" ");}else"[object String]"==d&&(h=10>=b.length?b:b.slice(0,10));return O("",(l={},l[""]=a,l),f,n,h,"",[])}}if(!q("json-parse")){var V=A.fromCharCode,W={92:"\\",34:'"',47:"/",98:"\b",116:"\t",110:"\n",102:"\f",114:"\r"},b,J,l=function(){b=J=null;throw G();},z=function(){for(var a=J,c=a.length,e,h,f,k,d;b<c;)switch(d=a.charCodeAt(b),d){case 9:case 10:case 13:case 32:b++;break;case 123:case 125:case 91:case 93:case 58:case 44:return e=
D?a.charAt(b):a[b],b++,e;case 34:e="@";for(b++;b<c;)if(d=a.charCodeAt(b),32>d)l();else if(92==d)switch(d=a.charCodeAt(++b),d){case 92:case 34:case 47:case 98:case 116:case 110:case 102:case 114:e+=W[d];b++;break;case 117:h=++b;for(f=b+4;b<f;b++)d=a.charCodeAt(b),48<=d&&57>=d||97<=d&&102>=d||65<=d&&70>=d||l();e+=V("0x"+a.slice(h,b));break;default:l()}else{if(34==d)break;d=a.charCodeAt(b);for(h=b;32<=d&&92!=d&&34!=d;)d=a.charCodeAt(++b);e+=a.slice(h,b)}if(34==a.charCodeAt(b))return b++,e;l();default:h=
b;45==d&&(k=!0,d=a.charCodeAt(++b));if(48<=d&&57>=d){for(48==d&&(d=a.charCodeAt(b+1),48<=d&&57>=d)&&l();b<c&&(d=a.charCodeAt(b),48<=d&&57>=d);b++);if(46==a.charCodeAt(b)){for(f=++b;f<c&&(d=a.charCodeAt(f),48<=d&&57>=d);f++);f==b&&l();b=f}d=a.charCodeAt(b);if(101==d||69==d){d=a.charCodeAt(++b);43!=d&&45!=d||b++;for(f=b;f<c&&(d=a.charCodeAt(f),48<=d&&57>=d);f++);f==b&&l();b=f}return+a.slice(h,b)}k&&l();if("true"==a.slice(b,b+4))return b+=4,!0;if("false"==a.slice(b,b+5))return b+=5,!1;if("null"==a.slice(b,
b+4))return b+=4,null;l()}return"$"},P=function(a){var c,b;"$"==a&&l();if("string"==typeof a){if("@"==(D?a.charAt(0):a[0]))return a.slice(1);if("["==a){for(c=[];;b||(b=!0)){a=z();if("]"==a)break;b&&(","==a?(a=z(),"]"==a&&l()):l());","==a&&l();c.push(P(a))}return c}if("{"==a){for(c={};;b||(b=!0)){a=z();if("}"==a)break;b&&(","==a?(a=z(),"}"==a&&l()):l());","!=a&&"string"==typeof a&&"@"==(D?a.charAt(0):a[0])&&":"==z()||l();c[a.slice(1)]=P(z())}return c}l()}return a},T=function(a,b,e){e=S(a,b,e);e===
w?delete a[b]:a[b]=e},S=function(a,b,e){var h=a[b],f;if("object"==typeof h&&h)if("[object Array]"==u.call(h))for(f=h.length;f--;)T(h,f,e);else B(h,function(a){T(h,a,e)});return e.call(a,b,h)};r.parse=function(a,c){var e,h;b=0;J=""+a;e=P(z());"$"!=z()&&l();b=J=null;return c&&"[object Function]"==u.call(c)?S((h={},h[""]=e,h),"",c):e}}}r.runInContext=N;return r}var K=typeof define==="function"&&define.amd,F={"function":!0,object:!0},G=F[typeof exports]&&exports&&!exports.nodeType&&exports,k=F[typeof window]&&
window||this,t=G&&F[typeof module]&&module&&!module.nodeType&&"object"==typeof global&&global;!t||t.global!==t&&t.window!==t&&t.self!==t||(k=t);if(G&&!K)N(k,G);else{var L=k.JSON,Q=k.JSON3,M=!1,A=N(k,k.JSON3={noConflict:function(){M||(M=!0,k.JSON=L,k.JSON3=Q,L=Q=null);return A}});k.JSON={parse:A.parse,stringify:A.stringify}}K&&define(function(){return A})}).call(this);

if(window === undefined) {
	var window={};
}
if(console === undefined) {
	var console={
		log: function(data) {
			if(typeof print == "function") {
				print(data);
			} else {
				// any other ways to print to console?
			}
		}
	};
}
window.nexpaqAPI = {
	version: "0.7.10",
	currentModule: null,
	availableModules: ["LED", "TFCard", "Backup", "USBStick", "Speaker", "Laser", "Alcohol", "AirQ", "Battery", "HaT", "Hotkey"],

	/**
	 * Sets the current module API is working with, this is required to be done before using htee API
	 * @param {string} name [module name]
	 */
	setCurrentModule: function (name) {
		if(this.availableModules.indexOf(name) === -1) return false;

		console.log("nexpaqAPI: version " + this.version);
		console.log("nexpaqAPI: module " + name);
		if(window.EmulateModule) {
			console.log("nexpaqAPI: emulating mode");
		}
		this.currentModule=name;
		return true;
	},
	util: {
		/**
		 * Sends a command to native application
		 * @param  {string} command [command name]
		 * @param  {array} options [array of integers]
		 */
		sendCommand: function (command, options) {
			var data=JSON.stringify({Name: command, Param: options});
			/*try {
				nxpAPI.onControl( data );
			} catch (e) {
				if(typeof onNxpAppError !== "undefined") onNxpAppError(e, "nxpAPI.js", "", "", "");
			}*/
			/* Temporary fix for iOS */
			if(window.webkit !== undefined) {
				try {
					window.webkit.messageHandlers.AppModel.postMessage({body: data});
				} catch (e) {
					if( typeof onNxpAppError !== "undefined" ) onNxpAppError(e, "nexpaqAPI.js", "", "", "");
				}
			} else {
				try {
					if( typeof nxpAPI == "undefined") {
						var rhinoAPI = java.lang.Class.forName("com.nexpack.nexpaq.HomeFragment", true, javaLoader),
							onControl = rhinoAPI.getMethod("onControl", [java.lang.String]);
						onControl.invoke(null , data);
					} else {
						nxpAPI.onControl( data );
					}

				} catch (e) {
					if( typeof onNxpAppError !== "undefined" ) onNxpAppError(e, "nexpaqAPI.js", "", "", "");
				}
			}
			return;
		},

		/**
		 * Receives data from native application and delivers it to the current module
		 * @param  {array} data [array of integers]
		 * @return {bool}      [result of delivering data to module]
		 */
		receiveData: function (data) {
			if(window.nexpaqAPI.currentModule === null || window.nexpaqAPI.availableModules.indexOf(window.nexpaqAPI.currentModule) === -1) return false;
			if(window.nexpaqAPI[window.nexpaqAPI.currentModule].recieve === undefined) return false;

			var decodedData=JSON.parse(data);
			window.nexpaqAPI[window.nexpaqAPI.currentModule].recieve(decodedData);
			return true;
		},

		/**
		 * Receives events defined in app, and functions defined in all apps
		 * @param  {json string} data [object with functions and events]
		 * @return {bool}      [result of parsing events object]
		 */
		receiveEvents: function (data) {
			var decodedData=JSON.parse(data),
				functions_list=[];
			var i;
			window.nexpaqAPI.global.functions=[];
			for(i in decodedData.functions) {
				functions_list.push(decodedData.functions[i].name);
				//may be it will be better to make a tree by device property? :-\, not sure
				window.nexpaqAPI.global.functions.push({
					'title':decodedData.functions[i].name,
					'name':decodedData.functions[i].name,
					'device':decodedData.functions[i].UUID
				});
			}

			if(decodedData.events==="") decodedData.events=[];
			for(i in decodedData.events) {
				var event_object={
					'title':decodedData.events[i].event,
					'name':decodedData.events[i].event
				};
				if(functions_list.indexOf(decodedData.events[i].function)!=-1) {
					event_object.function=decodedData.events[i].function;
					event_object.devices=decodedData.events[i].UUID;
				}
				window.nexpaqAPI[window.nexpaqAPI.currentModule].events[event_object.name]=event_object;
			}

			for(i in window.nexpaqAPI.global.onEventsReceived) {
				window.nexpaqAPI.global.onEventsReceived[i](window.nexpaqAPI[window.nexpaqAPI.currentModule].events);
			}
			return true;
		},

		/**
		 * Saving data via native device
		 * @param  {object} data [what we are saving]
		 * @return {bool}      [saving result]
		 */
		saveData: function (data) {
			var encodedData=JSON.stringify({value: data});
			try {
				nxpAPI.onSave( encodedData );
			} catch (e) {
				if(typeof onNxpAppError !== "undefined") onNxpAppError(e, "nxpAPI.js", "", "", "");
			}
			return true;
		},

		/**
		 * Adding event handler to module
		 * @param {string} module     [module to set event on]
		 * @param {string} event_name [event name]
		 * @param {string} func       [function name to call on event]
		 */
		addEventListener: function (module, event_name, func) {
			if(window.nexpaqAPI[module] === undefined || window.nexpaqAPI[module][event_name] === undefined) return false;
			window.nexpaqAPI[module][event_name].push(func);
			return true;
		},

		/**
		 * Defines new event inside module, can not be used to redefine event
		 * @param {string} module      [module to add event]
		 * @param {string} event_title [title of event]
		 * @param {string} event_name  [name of event]
		 */
		addNativeEvent: function (module, event_title, event_name) {
			if(window.nexpaqAPI[module] === undefined || window.nexpaqAPI[module].events[event_name] !== undefined) return false;
			window.nexpaqAPI[module].events[event_name]={
				'title' : event_title,
				'name' : event_name
			};
			return true;
		},

		/**
		 * Bind function of one or more devices to some event
		 * @param {string} module        [module we are working with]
		 * @param {string} event_name    [name of event]
		 * @param {string} function_name [name of function]
		 * @param {array of integers} devices       [UUIDs if devices]
		 */
		addNativeEventListener: function (module, event_name, function_name, devices) {
			if(window.nexpaqAPI[module] === undefined || window.nexpaqAPI[module].events[event_name] === undefined) return false;
			window.nexpaqAPI[module].events[event_name].function=function_name;
			window.nexpaqAPI[module].events[event_name].devices=devices;

			window.nexpaqAPI.util.updateEvents();

			return true;
		},

		updateEvents: function() {
			var events=[],
				module=window.nexpaqAPI.currentModule;
			for(var i in window.nexpaqAPI[module].events) {
				events.push({
					'event' : window.nexpaqAPI[module].events[i].name,
					'function' : window.nexpaqAPI[module].events[i].function,
					'UUID' : window.nexpaqAPI[module].events[i].devices
				});
			}
			var events_json_string=JSON.stringify(events);
			try {
				// iOS
				if(window.webkit !== undefined) {
					window.webkit.messageHandlers.ConfigEvents.postMessage(events_json_string);
				// Android
				} else {
					nxpAPI.nxp_ConfigEvents(events_json_string);
				}
			} catch (e) {
				if(typeof onNxpAppError !== "undefined") onNxpAppError(e, "nexpaqAPI.js", "", "", "");
			}
		},
		/**
		 * Calling event from native app, if some function binded to it, this function will be executed
		 * @param  {string} event_name [name of event to call]
		 */
		callEvent: function (event_name) {
			try {
				// iOS
				if(typeof window.webkit !== "undefined") {
					console.log('iOS: toggle event - '+event_name);
					window.webkit.messageHandlers.callNativeEvent.postMessage(event_name);
				// Android
				} else {
					console.log('Android: toggle event - '+event_name);
					/*var rhinoAPI = java.lang.Class.forName("com.nexpack.nexpaq.HomeFragment", true, javaLoader),
						callNativeEvent = rhinoAPI.getMethod("callNativeEvent", [java.lang.String]);
					callNativeEvent.invoke(null , event_name);*/
					var ScriptAPI = java.lang.Class.forName("com.nexpack.nexpaq.HomeFragment", true, javaLoader);
					var methodRead = ScriptAPI.getMethod("callNativeEvent", [java.lang.String]);
					methodRead.invoke(null, event_name);
				}
			} catch (e) {
				if(typeof onNxpAppError !== "undefined") onNxpAppError(e, "nexpaqAPI.js", "", "", "");
			}
		},

		/**
		 * Closing current application
		 */
		closeApplication: function () {
			window.nexpaqAPI.util.sendCommand('close', []);
		}
	}	
};

/**
 * LED control object
 *
 * * Events:
 * 
 * * Functions:
 * turnOff : turn LED off
 * setColorRed : red color of LED
 * setColorGreen : green color of LED
 * setColorBlue : blue color of LED
 * setColorWhite : white color of LED
 * flashRedAndBlue : flash LED with red and blue colors
 * setColorRGB : set color of LED in RGB
 * setColorHSL : set color of LED in number betwee 0 and 359
 */
window.nexpaqAPI.LED = {
	/* BASIC */
	turnOff: function () {
		window.nexpaqAPI.util.sendCommand("basic", [0]);
	},

	setColorRed: function () {
		window.nexpaqAPI.util.sendCommand("basic", [2]);
	},
	setColorGreen: function () {
		window.nexpaqAPI.util.sendCommand("basic", [3]);
	},
	setColorBlue: function () {
		window.nexpaqAPI.util.sendCommand("basic", [4]);
	},
	setColorWhite: function () {
		window.nexpaqAPI.util.sendCommand("basic", [5]);
	},

	flashRedAndBlue: function () {
		window.nexpaqAPI.util.sendCommand("basic", [6]);
	},

	/* RGB */
	setColorRGB: function (R, G, B) {
		if(R < 0 || G < 0 || B < 0) return false;
		if(R > 255 || G > 255 || B > 255) return false;

		window.nexpaqAPI.util.sendCommand("rgb", [R, G, B]);
		return true;
	},

	/* HSL */
	setColorHSL: function (value) {
		if(value<0 || value>359) return false;
		var Z=value,
			t=Z%256,
			max=359,
			maxY=max-256,
			result=[0,0];

		if( Z <= maxY ) {
			result=[0, Z];
		} else if( Z <= 256 ) {
			result=[Z/256, 0];
		} else {
			result=[(Z-t)/256, t];
		}

		window.nexpaqAPI.util.sendCommand("hsl", result);
	}
};

/**
 * USB device control object
 *
 * * Events:
 * onPluggedIn() : when device is plugged in
 * onPluggedOut() : when device is plugged out
 * 
 * * Functions:
 * connect : connect to USB HUB
 * disconnect : disconnect from USB HUB
 */
window.nexpaqAPI.USBDevice = {
	pluggedIn: false,
	events: {},

	onPluggedIn: [],
	onPluggedOut: [],

	recieve: function (data) {
		var i;
		if(data.state=='connected' && !this.pluggedIn) {
			this.pluggedIn=true;
			for(i in this.onPluggedIn) {
				this.onPluggedIn[i]();
			}
		} else if(data.state=='disconnected' && this.pluggedIn) {
			this.pluggedIn=false;
			for(i in this.onPluggedOut) {
				this.onPluggedOut[i]();
			}
		}
	},

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener(window.nexpaqAPI.currentModule, event_name, func);
	},
	addNativeEvent: function(event_title, event_name) {
		window.nexpaqAPI.util.addNativeEvent(window.nexpaqAPI.currentModule, event_title, event_name);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	},

	connect: function () {
		window.nexpaqAPI.util.sendCommand("conn", [1]);
	},
	disconnect: function () {
		window.nexpaqAPI.util.sendCommand("conn", [0]);
	}
};

/**
 * Hotkey control object
 *
 * * Events:
 * onButton1Down() : when button 1 down
 * onButton2Down() : when button 2 down
 * onButton1Up() : when button 1 up
 * onButton2Up() : when button 2 up
 * 
 * * Functions:
 * 
 */
window.nexpaqAPI.Hotkey = {
	button1_is_pressed: false,
	button2_is_pressed: false,
	//Default events
	events: {
		'button_1_pressed':{
			'title' : 'Button 1 pressed', 
			'name' : 'button_1_pressed'
		},
		'button_1_released':{
			'title' : 'Button 1 released', 
			'name' : 'button_1_released'
		},
		'button_2_pressed':{
			'title' : 'Button 2 pressed', 
			'name' : 'button_2_pressed'
		},
		'button_2_released':{
			'title' : 'Button 2 released', 
			'name' : 'button_2_released'
		}
	},

	onButton1Down: [],
	onButton2Down: [],
	onButton1Up: [],
	onButton2Up: [],

	recieve: function (data) {
		var i;
		// Button 1
		if(data.state.indexOf("A")!=-1 && !this.button1_is_pressed) {
			this.button1_is_pressed=true;
			window.nexpaqAPI.util.callEvent('button_1_pressed');
			for(i in this.onButton1Down) {
				this.onButton1Down[i]();
			}
		} else if(data.state.indexOf("A")==-1 && this.button1_is_pressed) {
			this.button1_is_pressed=false;
			window.nexpaqAPI.util.callEvent('button_1_released');
			for(i in this.onButton1Up) {
				this.onButton1Up[i]();
			}
		}

		// Button 2
		if(data.state.indexOf("B")!=-1 && !this.button2_is_pressed) {
			this.button2_is_pressed=true;
			window.nexpaqAPI.util.callEvent('button_2_pressed');
			for(i in this.onButton2Down) {
				this.onButton2Down[i]();
			}
		} else if(data.state.indexOf("B")==-1 && this.button2_is_pressed) {
			this.button2_is_pressed=false;
			window.nexpaqAPI.util.callEvent('button_2_released');
			for(i in this.onButton2Up) {
				this.onButton2Up[i]();
			}
		}
	},

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener(window.nexpaqAPI.currentModule, event_name, func);
	},
	addNativeEvent: function(event_title, event_name) {
		window.nexpaqAPI.util.addNativeEvent(window.nexpaqAPI.currentModule, event_title, event_name);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	}
};

/**
 * Laser control object
 *
 * * Events:
 * onCoverOpen() : when laser cover is pulled
 * onCoverClosed() : when laser cover is pushed
 * 
 * * Functions:
 * on : turn laser on
 * off : turn laser off
 */
window.nexpaqAPI.Laser = {
	coverOpen: false,
	events: {},

	onCoverOpen: [],
	onCoverClosed: [],

	recieve: function (data) {
		var i;
		if(data.state=="cover open" && !this.coverOpen) {
			this.coverOpen=true;
			for(i in this.onCoverOpen) {
				this.onCoverOpen[i]();
			}
		} else if(data.state=="cover closed" && this.coverOpen) {
			this.coverOpen=false;
			for(i in this.onCoverClosed) {
				this.onCoverClosed[i]();
			}
		}
	},

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener(window.nexpaqAPI.currentModule, event_name, func);
	},
	addNativeEvent: function(event_title, event_name) {
		window.nexpaqAPI.util.addNativeEvent(window.nexpaqAPI.currentModule, event_title, event_name);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	},

	on: function () {
		window.nexpaqAPI.util.sendCommand("sw", [1]);
	},
	off: function () {
		window.nexpaqAPI.util.sendCommand("sw", [0]);
	}
};

/**
 * Humidity & Temperature control object
 *
 * * Events:
 * onDataUpdated() : when data from HaT is updated
 * 
 * * Functions:
 *
 */
window.nexpaqAPI.HaT = {
	last_data: false,
	events: {},

	onDataUpdated: [],

	recieve: function (data) {
		this.last_data={
			"ambient_temperature"	: data.ambient_temperature,
			"ambient_humidity"		: data.ambient_humidity,
			"object_temperature"	: data.object_temperature
		};
		var i;
		for(i in this.onDataUpdated) {
			this.onDataUpdated[i](this.last_data);
		}
	},

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener(window.nexpaqAPI.currentModule, event_name, func);
	},
	addNativeEvent: function(event_title, event_name) {
		window.nexpaqAPI.util.addNativeEvent(window.nexpaqAPI.currentModule, event_title, event_name);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	},

	start: function () {
		window.nexpaqAPI.util.sendCommand("sw", [3]);
	},
	stop: function () {
		window.nexpaqAPI.util.sendCommand("sw", [4]);
	}
};

/**
 * Air sensor control object
 *
 * * Events:
 * onHeating() : when air sensor start heating
 * onReady() : when air sensor is ready for measurment
 * onLevelChanged() : when air sensor mesured value changed
 * 
 * * Functions:
 * start : start air sensor (heating)
 * stop : stop air sensor (heating)
 */
window.nexpaqAPI.AirSensor = {
	isReady: false,
	level: 0,
	events: {},

	onHeating: [],
	onReady: [],
	onLevelChanged: [],

	recieve: function (data) {
		var i, 
			is_preparing = false;

		if(data.state !== undefined) {
			is_preparing = data.state=="heating" || data.state=="updating the reference";
		}

		if(is_preparing && this.isReady) {
			this.isReady=false;

			for(i in this.onHeating) {
				this.onHeating[i]();
			}
		}
		if(!is_preparing && !this.isReady) {
			this.isReady=true;

			for(i in this.onReady) {
				this.onReady[i]();
			}
		}
		if(this.isReady && this.level!=data.state) {
			this.level=data.state;
			for(i in this.onLevelChanged) {
				this.onLevelChanged[i](this.level);
			}
		}
	},

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener(window.nexpaqAPI.currentModule, event_name, func);
	},
	addNativeEvent: function(event_title, event_name) {
		window.nexpaqAPI.util.addNativeEvent(window.nexpaqAPI.currentModule, event_title, event_name);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	},

	start: function () {
		window.nexpaqAPI.util.sendCommand("sw", [3]);
	},
	stop: function () {
		window.nexpaqAPI.util.sendCommand("sw", [4]);
	}
};

/**
 * Battery control object
 *
 * * Events:
 * onCharging() : when battery starts charging
 * onDischarging() : when battery starts discharging
 * onStandby() : when battery starts standby
 * onFull() : when battery is full
 * onVoltageChanged() : when voltage value is changed
 * onListUpdate() : when list of batteries updated
 * 
 * * Functions:
 * enableList: start receiving list of batteries
 * setDischarging : set battery to discharging mode
 * setCharging : set battery to charging mode
 * setStandby : set battery to standby mode
 */
window.nexpaqAPI.Battery = {
	state: 0, //1 - charging, 2 - discharging, 3 - standby, 4 - full
	voltage: 0,
	list: [],
	events: {},

	onCharging: [],
	onDischarging: [],
	onStandby: [],
	onFull: [],
	onVoltageChanged: [],
	onListUpdate: [],

	recieve: function (data) {
		var i;
		if(Array.isArray(data)) {
			this.list=data;

			for(i in this.onListUpdate) {
				this.onListUpdate[i](this.list);
			}
			return;
		}

		if(data.state=="charging" && this.state!==1) {
			this.state=1;

			for(i in this.onCharging) {
				this.onCharging[i]();
			}
		}
		if(data.state=="discharging" && this.state!==2) {
			this.state=2;

			for(i in this.onDischarging) {
				this.onDischarging[i]();
			}
		}
		if(data.state=="standby" && this.state!==3) {
			this.state=3;

			for(i in this.onStandby) {
				this.onStandby[i]();
			}
		}
		if(data.state=="full" && this.state!==4) {
			this.state=4;

			for(i in this.onFull) {
				this.onFull[i]();
			}
		}
		var new_voltage=data.value;
		if(new_voltage!=this.voltage) {
			this.voltage=new_voltage;

			for(i in this.onVoltageChanged) {
				this.onVoltageChanged[i](this.voltage);
			}
		}

	},

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener(window.nexpaqAPI.currentModule, event_name, func);
	},
	addNativeEvent: function(event_title, event_name) {
		window.nexpaqAPI.util.addNativeEvent(window.nexpaqAPI.currentModule, event_title, event_name);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	},


	enableList: function () {
		window.nexpaqAPI.util.sendCommand("GetBatteryList", []);
	},


	setDischarging: function () {
		window.nexpaqAPI.util.sendCommand("charge", [0]);
	},
	setCharging: function () {
		window.nexpaqAPI.util.sendCommand("charge", [1]);
	},
	setStandby: function () {
		window.nexpaqAPI.util.sendCommand("charge", [2]);
	}
};

/**
 * Global controls object
 * 
 * * Events:
 * onChargeValueUpdated() : when charge value in percentages updates
 * onBackButtonClicked() : when back button clicked
 * onSocialButtonClicked() : when social button clicked
 */
window.nexpaqAPI.global = {
	chargeValue: null,
	functions: [],

	onChargeValueUpdated: [],
	onBackButtonClicked: [],
	onSocialButtonClicked: [],
	onEventsReceived: [],

	addEventListener: function(event_name, func) {
		window.nexpaqAPI.util.addEventListener('global', event_name, func);
	},
	addNativeEventListener: function(event_name, function_name, devices) {
		window.nexpaqAPI.util.addNativeEventListener(window.nexpaqAPI.currentModule, event_name, function_name, devices);
	},

	updateCharge: function (value) {
		if(value !== this.chargeValue) {
			this.chargeValue = value;
		}
		for(var i in this.onChargeValueUpdated) {
			this.onChargeValueUpdated[i]();
		}
	},
	clickBackButton: function() {
		for(var i in this.onBackButtonClicked) {
			this.onBackButtonClicked[i]();
		}
	},
	clickSocialButton: function() {
		for(var i in this.onSocialButtonClicked) {
			this.onSocialButtonClicked[i]();
		}
	}
};

window.nexpaqAPI.TFCard=window.nexpaqAPI.Backup=window.nexpaqAPI.USBStick=window.nexpaqAPI.Speaker=window.nexpaqAPI.USBDevice;
window.nexpaqAPI.Alcohol=window.nexpaqAPI.AirQ=window.nexpaqAPI.AirSensor;




/* =========== LOW LEVEL FUNCTIONS */
function receiveFromNative(content) {
	window.nexpaqAPI.util.receiveData(content);
}
function nxp_receiveEventsTableFromNative(table) {
	window.nexpaqAPI.util.receiveEvents(table);
}
function clickBack() {
	window.nexpaqAPI.global.clickBackButton();
	if(window.EmulateModule) onNxpAppError("back button clicked", "", "", "", "");
}
function clickSocial() {
	window.nexpaqAPI.global.clickSocialButton();
	if(window.EmulateModule) onNxpAppError("social button clicked", "", "", "", "");
}
function chargeValue(num) {
	window.nexpaqAPI.global.updateCharge(num);
	if(window.EmulateModule) onNxpAppError("phone charge "+num, "", "", "", "");
}

/* =========== LOW LEVEL INITIAL COMMANDS */
if(typeof window.addEventListener != "undefined") {
	window.addEventListener("load", function(event) {
		if(!window.EmulateModule) {
			nxpAPI.pageReady();
		}
	});
}

window.EmulateModule=false;
window.nexpaqAPI.setCurrentModule("Speaker");
