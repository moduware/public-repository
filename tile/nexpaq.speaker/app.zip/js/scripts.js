window.nexpaqAPI.setCurrentModule("Speaker");

function speakerButtonClickHandler(e) {
	this.classList.toggle('active');

	if(this.classList.contains('active')) {
		nexpaqAPI.Speaker.connect();
	} else {
		nexpaqAPI.Speaker.disconnect();
	}
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.detectCurrentPlatform();
	nexpaqAPI.header.setTitle("Speaker");
	nexpaqAPI.header.cleanButtons();
	nexpaqAPI.header.customize({color: "white", iconColor:"white", backgroundColor:"#E1514C"});
	document.getElementById('speaker-button').addEventListener('touchstart', speakerButtonClickHandler);

});
