// title: Turn on speaker
function NP_start_Speaker () {
	window.nexpaqAPI.Speaker.connect();
}
// title: Turn off speaker
function NP_stop_Speaker () {
	window.nexpaqAPI.Speaker.disconnect();
}

@@include('../vendor/json3.min.js')
@@include('../js/lib/nexpaqAPI.js')

window.EmulateModule=false;
window.nexpaqAPI.setCurrentModule("Speaker");
