/** ================ Handlers == */
function backButtonClickHandler(e) {
	//if(document.getElementById('config-screen').classList.contains('hidden')) {
		if(!window.EmulateModule) {
			window.nexpaqAPI.util.closeApplication();
		}
		onNxpAppError('Application closed!', '', '', '', '');
	// } else {
	// 	openMainScreen();
	// 	restoreOriginalIndexes();
	// }

}
