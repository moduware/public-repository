window.nexpaqAPI.setCurrentModule("Battery");

var hide = function(el) {
	document.getElementById(el).classList.add('hidden');
};
var show = function(el) {
	document.getElementById(el).classList.remove('hidden');
};

function confirmButtonHandler () {
	if(firstPage) {
		hide('onboarding-one');
		show('onboarding-two');
		firstPage=false;
	} else {
		hide('explanation-board');
		show('battery-board');
	}
}


//Charges the nexpaq
function chargeSwitchHandler() {
	if($checkBox.checked) {
		nexpaqAPI.Battery.setCharging();
		standBy=false;
	} else {
		nexpaqAPI.Battery.setStandby();
		standBy=true;
	}
	nexpaqAPI.Battery.statusCheck();
}

function voltageHandler (value) {
	if(!standBy){
		document.getElementsByClassName('voltage')[0].textContent = "Voltage is: " + value + "V";
	} else {
		document.getElementsByClassName('voltage')[0].textContent = "-";
	}
}

//Checks percentage and change the background color.
function percentageHandler (percentage) {
	document.getElementsByClassName('percentage')[0].textContent = percentage +"%";
	if (percentage < 50 && percentage >= 20) {
		document.getElementsByClassName('battery-status')[0].style.backgroundColor = "#FFB931";
		nexpaqAPI.header.customize({backgroundColor: '#FFB931'});
	}
	if (percentage < 20) {
		document.getElementsByClassName('battery-status')[0].style.backgroundColor = "#DF5250";
		nexpaqAPI.header.customize({backgroundColor: '#DF5250'});
	}
}
function dataHandler () {
	if(nexpaqAPI.Battery.state == 1) {
		document.getElementsByClassName("status")[0].textContent="Charging";
	}
	if(nexpaqAPI.Battery.state == 3) {
		document.getElementsByClassName("status")[0].textContent="Not Charging";
	}
}



document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle("Battery");
	//Header Customization
	header = {
		backgroundColor: '#90CF42',
		color: '#FFFFFF',
		iconColor: '#FFFFFF',
	};
	nexpaqAPI.header.customize(header);
	nexpaqAPI.header.cleanButtons();
	firstPage=true;
	standBy=true;
	$checkBox = document.getElementById('myonoffswitch');



	$checkBox.addEventListener('click', chargeSwitchHandler);
	document.getElementById('confirm-button').addEventListener('click', confirmButtonHandler);
	nexpaqAPI.Battery.addEventListener('onPercentageChanged', percentageHandler);
	nexpaqAPI.Battery.addEventListener("onCharging",dataHandler);
	nexpaqAPI.Battery.addEventListener("onStandby", dataHandler);
	nexpaqAPI.Battery.addEventListener("onVoltageChanged", voltageHandler);
	
});
