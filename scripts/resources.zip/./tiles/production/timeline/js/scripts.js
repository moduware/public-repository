// Predefined types
window.SOURCES_TYPES = {
  // Here must be default source declaration
  "default" : {
    title : "%(type)s",
    icon : "img/switcher-alcohol.svg",
    format : "%(value)f"
  },
  "nexpaq.hat.ambient_temperature" : {
    title : "Temperature",
    icon : "img/switcher-temperature.svg",
    format : "%(val)f &#8451;"
  },
  "nexpaq.airq.quality" : {
    title : "Air Quality",
    icon : "img/switcher-airq.svg",
    format : "Polution: %(val)s"
  },
  "nexpaq.alcohol.level" : {
    title : "Alcohol",
    icon : "img/switcher-alcohol.svg",
    format : "calc(100 / 7 * %(val)s, 2)%%"
  }

};
window.LOCATIONS = {

};

function evaluteMath(expression) {
  var search = null,
      preg = /calc\((.+?),\s{0,1}(\d+)\)/g,
      reg = /calc\((.+?)\)/g;
  while((search = preg.exec(expression)) || (search = reg.exec(expression))) {
    console.log(search);
    expression = expression.replace(search[0], math.format(math.eval(search[1]), {precision: search[2]==null?5:search[2]}));
  }
  return expression;
}
function dataSwitcherClickHandler(e) {
  this.classList.toggle('active');
  var type = this.dataset.type,
      activity = this.classList.contains('active');

  toggleType(type, activity);
}
function toggleAllClickHandler(e) {
  this.classList.toggle('active');
  var activity = this.classList.contains('active');

  var sources = document.getElementById('sources-list').children;
  for(var i=0; i<sources.length; i++) {
    var type = sources[i].dataset.type;
    toggleType(type, activity);
  }
}

function toggleType(type, activity) {
  var data_elements = document.getElementById('timeline').getElementsByClassName('data-'+type);
  for(var i=0; i<data_elements.length; i++) {
    if(activity) {
      data_elements[i].classList.remove('hidden');
    } else {
      data_elements[i].classList.add('hidden');
    }
  }
  var data_switchers = document.getElementsByClassName('switcher-'+type);
  for(var i=0; i<data_switchers.length; i++) {
    if(activity) {
      data_switchers[i].classList.add('active');
    } else {
      data_switchers[i].classList.remove('active');
    }
  }
}
function openSourcesScreen() {
  document.getElementById('main-screen').classList.add("hidden");
  document.getElementById('sources-screen').classList.remove("hidden");
}
function showMainScreen() {
  document.getElementById('main-screen').classList.remove("hidden");
  document.getElementById('sources-screen').classList.add("hidden");
}

function timelineScrollHandler(e) {
  if(this.scrollTop + this.offsetHeight >= this.scrollHeight) {
    console.log("loading more data!");
    if(window.loading_timeout == null) {
      document.getElementById('loading-icon').classList.add('active');

      if(!window.nexpaqAPI.emulateMode) {
        window.loading_timeout = true;
        var offset = document.getElementById('timeline').children.length;
        // here we have cloud request
        requestData("all", offset);

      } else {
        window.loading_timeout = setTimeout(function() {
          window.loading_timeout = null;
          document.getElementById('loading-icon').classList.remove('active');

          // demo data
          addItemToTimeline('nexpaq.hat.ambient_temperature', '16:56 18 Apr 2016', 36);
          addItemToTimeline('nexpaq.hat.ambient_temperature', '16:56 18 Apr 2016', 32);
          addItemToTimeline('nexpaq.airq.quality', '16:56 18 Apr 2016', 73);
          addItemToTimeline('nexpaq.alcohol.level', '16:56 18 Apr 2016', 5);
        }, 2000);
      }
    }
  }
}
function onAllDataReceivedHandler() {
  // lets sort items by date
  window.DATA_RECEIVED_FROM_CLOUD.sort(compareRFC3339Dates);
  var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  for(var i=0; i<window.DATA_RECEIVED_FROM_CLOUD.length; i++) {
    var item = window.DATA_RECEIVED_FROM_CLOUD[i],
        time = new Date(item.time);
    time = sprintf("%1d:%2d %3d %4s %5d", time.getHours(), time.getMinutes(), time.getDate(), monthNames[time.getMonth()], time.getFullYear());
    addItemToTimeline(item.datasetName, time, item.value, true, item.Location[0]+","+item.Location[1]);
  }

  window.loading_timeout = null;
  document.getElementById('loading-icon').classList.remove('active');
}
function timelineItemsLoadedHandler(data) {
  if(data.length !== 0) {
    //var type = data[0].datasetName;
    window.DATA_RECEIVED_FROM_CLOUD = window.DATA_RECEIVED_FROM_CLOUD.concat(data);
  }
  // not the safest way, but we don't know what kind of data received if no items...
  //window.REQUESTED_DATA_TYPES.shift();

  //if(window.REQUESTED_DATA_TYPES.length === 0) {
  onAllDataReceivedHandler();
  //}
}
window.DATA_RECEIVED_FROM_CLOUD=[];
function requestData(types, offset, limit) {
  if(limit == null) limit = 10
  window.DATA_RECEIVED_FROM_CLOUD=[];

  if(types == "all") {
    types = Object.keys(window.SOURCES_TYPES);
    // removing default
    types.shift();
  }
  //window.REQUESTED_DATA_TYPES = types;

  //for(var i=0; i < types.length; i++) {
    window.nexpaqAPI.util.sendDataQuery(types.join(), {offset: offset, limit: limit});
  //}
}

function addItemToTimeline(type, date, value, position_before, location) {
  if(typeof location == "undefined" || location == "0,0") location = "";
  if(position_before == null) position_before = true;
  var $timeline = document.getElementById('timeline');

  var source = SOURCES_TYPES["default"];
  if(typeof SOURCES_TYPES[type] !== undefined) {
    source = SOURCES_TYPES[type];
  }

  var title = sprintf(source["title"], {type: type});
  var icon = source["icon"];
  var value = evaluteMath(sprintf(source["format"], {val: value}));

  var html = '<div class="timeline-badge"><img src="' + icon + '" alt="' + title + ' app" /></div>' +
    '<div class="timeline-panel">' +
      '<div class="timeline-heading">' +
        '<h4 class="timeline-title">' + title + '</h4>' +
        '<p><small class="text-muted"><i class="glyphicon glyphicon-time"></i> ' + date + (location==""?"":" - "+location) + '</small></p>' +
      '</div>' +
      '<div class="timeline-body">' +
        '<p>' + value + '</p>' +
      '</div>' +
    '</div>';

  var node = document.createElement("li");
  node.classList.add('data-' + type);
  node.innerHTML = html;

  if(position_before) {
    $timeline.insertBefore(node, $timeline.children[0]);
  } else {
    $timeline.insertBefore(node, null);
  }
}
function compareRFC3339Dates(a, b) {
  var aDate = Date.parse(a.time),
      bDate = Date.parse(b.time);

  if (aDate < bDate) {
    return -1;
  }
  if (aDate > bDate) {
    return 1;
  }
  return 0;
}

document.addEventListener("DOMContentLoaded", function(event) {
  window.nexpaqAPI.global.addEventListener('onDataLoaded', timelineItemsLoadedHandler);

  var switchers = document.getElementsByClassName('data-switcher');
  for(var i=0; i<switchers.length; i++) {
    switchers[i].addEventListener('click', dataSwitcherClickHandler);
  }

  document.getElementById('show-sources-screen').addEventListener('click', openSourcesScreen);
  document.getElementById('toggle-all-sources').addEventListener('click', toggleAllClickHandler);
  document.getElementById('timeline-container').addEventListener('scroll', timelineScrollHandler);

  window.nexpaqAPI.emulateMode = !window.nexpaqAPI.isApiAvailable();
  //window.nexpaqAPI.emulateMode = false;
  nexpaqAPI.header.show('Timeline');
  if(window.nexpaqAPI.emulateMode) {
    addItemToTimeline('nexpaq.hat.ambient_temperature', '16:56 18 Apr 2016', 36, true, "Shenzhen");
    addItemToTimeline('nexpaq.hat.ambient_temperature', '16:56 18 Apr 2016', 32, true, "Hong Kong");
    addItemToTimeline('nexpaq.airq.quality', '16:56 18 Apr 2016', 0, true, "Shenzhen");
    addItemToTimeline('nexpaq.alcohol.level', '16:56 18 Apr 2016', 5, true, "Shenzhen");
  } else {
    console.log("nexpaqAPI: turning off emulation on real device");
    document.getElementById('loading-icon').classList.add('active');
    window.loading_timeout = true;

    // here we have cloud request
    window.nexpaqAPI.global.addEventListener('onApiReady', function() {
      requestData("all", 0);
    });

  }
});
