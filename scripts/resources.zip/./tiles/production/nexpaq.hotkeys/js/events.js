@@include('../js/lib/nexpaqAPI.js')

nexpaqAPI.setCurrentModule('Hotkey');

//Default hotkeys events calls are enough, but here is example:
nexpaqAPI.Hotkey.addNativeEvent('buttons 1 and 2 pressed', 'buttons_1_2_pressed');
nexpaqAPI.Hotkey.addEventListener('onButton1Down', buttonsStateChangeHandler);
nexpaqAPI.Hotkey.addEventListener('onButton2Down', buttonsStateChangeHandler);

console.log('isApiAvailable: ' + nexpaqAPI.isApiAvailable());

function buttonsStateChangeHandler() {
	if(nexpaqAPI.Hotkey.button1_is_pressed && nexpaqAPI.Hotkey.button2_is_pressed) {
		nexpaqAPI.Hotkey.triggerNativeEvent('buttons_1_2_pressed');
	}
}
