var util = {
  renameGateway: function(uuid) {
    var gateway = application.gateways.filter(function(x) {return x.uuid == uuid})[0],
        name = gateway.name;
    var modal = myApp.modal({
      title: 'Renaming device',
      text: 'Please enter new name for "' + name + '"',
      afterText: '<input type="text" class="modal-text-input" maxlength="17" value="'+name+'">',
      buttons: [{
        text: 'OK',
        onClick: function(e) {
          var value = e[0].getElementsByClassName('modal-text-input')[0].value;
          if(value == '') return;
          nexpaqAPI.Gateway.renameGateway(uuid, value);
          var i = application.gateways.indexOf(gateway);
          application.set('gateways.' + i + '.name', value);
        }
      }, {
        text: 'Cancel',
        onClick: function() {

        }
      },
    ]});
    Dom7(modal).on('opened', function() {
      this.getElementsByClassName('modal-text-input')[0].focus();
    });
  },
  addCSS: function(fileName) {
    var head = document.head,
        link = document.createElement('link');

    link.type = 'text/css';
    link.rel = 'stylesheet';
    link.href = fileName;

    head.appendChild(link);
  },
  showAndroidCloseButton: function() {
    nexpaqAPI.header.addButton({image:'img/icon-clear-android.svg', width:20}, function(e) {
      myApp.mainView.router.load({pageName: 'dashboard'});
    });
  }
};
