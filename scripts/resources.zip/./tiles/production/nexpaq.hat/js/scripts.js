window.nexpaqAPI.setCurrentModule("HaT");

function changeMeasureTypeHandler(e) {
	if(current_temperature === 'ambient') {
		this.textContent = 'Measure surrounding';
		current_temperature = 'object';
		nexpaqAPI.header.hide();
		document.getElementById('instruction-screen').classList.remove('hidden');
	} else {
		current_temperature = 'ambient';
		this.textContent = 'Measure object';
	}
}
function startMeasureHandler(e) {
	nexpaqAPI.header.show();
	document.getElementById('instruction-screen').classList.add('hidden');
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('Temperature');
	window.nexpaqAPI.global.addEventListener('onLocationReceived', locationReceivedHandler);
	window.nexpaqAPI.HaT.addEventListener('onDataUpdated', nativeDataUpdateHandler);
	document.getElementById('change-measure-type').addEventListener('click', changeMeasureTypeHandler);
	document.getElementById('start-measure').addEventListener('click', startMeasureHandler);
	document.getElementById('close-instruction').addEventListener('click', startMeasureHandler);

	window.nexpaqAPI.HaT.start();
	window.nexpaqAPI.util.sendLocationRequest();

	var current_date = new Date();
	var monthNames = ["January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
  ];
	document.getElementById('current-date').textContent = current_date.getDate() + " " + monthNames[current_date.getMonth()];

	window.nexpaqAPI.emulateMode = window.EmulateModule = !window.nexpaqAPI.isApiAvailable();
	if(window.nexpaqAPI.emulateMode) {
		//emulateNativeData();
		//window.dataEmulationInterval = setInterval(emulateNativeData, 5000);
	}
});
