nexpaqAPI.setCurrentModule("Speaker");
var status_check_timer_initial_value = 15,
		status_check_timer = status_check_timer_initial_value;
var check_status_text = 'Check status';

function checkStatus() {
	status_check_timer = status_check_timer_initial_value;

	console.log("checking status");
	nexpaqAPI.Speaker.statusCheck();
}

function updateTimer() {
	if(status_check_timer < 0) {
		checkStatus();
	}

	var text = check_status_text + ' (' + status_check_timer + ')';
	document.getElementById('checkStatus').textContent = text;

	status_check_timer--;
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('Speaker');
	nexpaqAPI.Speaker.addEventListener('onPluggedIn', function(){document.getElementById('speakerStatus').textContent = "Connected"});
	nexpaqAPI.Speaker.addEventListener('onPluggedOut', function(){document.getElementById('speakerStatus').textContent = "Disconnected"});

	document.getElementById('checkStatus').addEventListener('click', function() {
		checkStatus();
	});

	document.getElementById('connect').addEventListener('click', function() {
		console.log("connecting");
		nexpaqAPI.Speaker.connect();
		status_check_timer = 5;
	});

	document.getElementById('disconnect').addEventListener('click', function() {
		console.log("disconnecting");
		nexpaqAPI.Speaker.disconnect();
		status_check_timer = 5;
	});

	checkStatus();
	setInterval(updateTimer, 1000);
	
});
