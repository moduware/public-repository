var levels = [
  {name : 'good', title : 'Good', info : 'No significant health risk', color: '#1FBA19'},
  {name : 'average', title : 'Average', info : 'Wear a mask if you can', color: '#BFB121'},
  {name : 'average', title : 'Average', info : 'Wear a mask if you can', color: '#BFB121'},
  {name : 'bad', title : 'Bad', info : 'Health risk!', color: '#E9DB3A'},
];
