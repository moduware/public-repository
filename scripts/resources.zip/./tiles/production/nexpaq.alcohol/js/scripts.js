nexpaqAPI.setCurrentModule("Alcohol");
preloadImages([]);


function setResult(value) {
	document.getElementById('result-value').textContent = value;
  last_Data= value;
}

function setBiggestResult(value) {
	document.getElementById('max-value').textContent = value;
  biggest_result= value;
}

function reset() {
	window.last_Data = window.biggest_result = 0;
	setResult(0);
	setBiggestResult(0);
	setDate();
}

function setDate() {
  var current_date = new Date();
  var hours = current_date.getHours();
  var minutes = current_date.getMinutes();
  var ampm = hours >= 12 ? 'pm' : 'am';
  hours = hours % 12;
  hours = hours ? hours : 12; // the hour '0' should be '12'
  minutes = minutes < 10 ? '0'+minutes : minutes;
  var strTime = hours + ':' + minutes + ' ' + ampm;
  var monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"];

  document.getElementById('dateTime').textContent= monthNames[current_date.getMonth()] + " " +current_date.getDate()+", " + strTime;

}



/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
  var number=1;
  nexpaqAPI.header.setTitle('Alcohol');

  nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
    nexpaqAPI.Alcohol.stop();
    nexpaqAPI.util.closeApplication();
  });

  nexpaqAPI.Alcohol.start();

  nexpaqAPI.global.addEventListener('onLocationReceived', locationReceivedHandler);
  nexpaqAPI.util.sendLocationRequest();

	document.getElementById('button-try-again').addEventListener('click', reset);
  nexpaqAPI.Alcohol.addEventListener('onLevelChanged', nativeDataUpdateHandler);

  nexpaqAPI.Alcohol.addEventListener('onHeating', function(e) {
		document.getElementById('result-screen').classList.add('hidden');
		document.getElementById('init-screen').classList.remove('hidden');
    window.randomize = function() {
      document.getElementById('radial-progress').setAttribute('data-progress',100);
    }
    setTimeout(window.randomize, 200);
    function progressUpdate() {
    document.getElementById('numbers').textContent = number + "%";
      if (number<100) {
        number++;
      }
    }
    setInterval(progressUpdate, 650);
	});

	nexpaqAPI.Alcohol.addEventListener('onReady', function(e) {
		document.getElementById('init-screen').classList.add('hidden');
		document.getElementById('result-screen').classList.remove('hidden');
    resultImage();
    setDate();
    console.log("sensor on");
	});


});
