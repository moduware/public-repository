nexpaqAPI.setCurrentModule("TFCard");
var status_check_timer_initial_value = 15,
		status_check_timer = status_check_timer_initial_value;
var check_status_text = 'Check status';

function checkStatus() {
	status_check_timer = status_check_timer_initial_value;

	console.log("checking status");
	nexpaqAPI.TFCard.statusCheck();
}
function updateTimer() {
	if(status_check_timer < 0) {
		checkStatus();
	}

	var text = check_status_text + ' (' + status_check_timer + ')';
	document.getElementById('checkStatus').textContent = text;

	status_check_timer--;
}

/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('SD Card');
	nexpaqAPI.TFCard.addEventListener('onUsbEnabled', function(){document.getElementById('usbStatus').textContent = "Connected"});
	nexpaqAPI.TFCard.addEventListener('onUsbDisabled', function(){document.getElementById('usbStatus').textContent = "Disconnected"});
	nexpaqAPI.TFCard.addEventListener('onSdCardIn', function(){document.getElementById('sdCardStatus').textContent = "SD Card in"});
	nexpaqAPI.TFCard.addEventListener('onSdCardOut', function(){document.getElementById('sdCardStatus').textContent = "SD Card out"});
	nexpaqAPI.TFCard.addEventListener('onPluggedIn', function(){document.getElementById('sdCardStatus').textContent = "Plugged in"});
	nexpaqAPI.TFCard.addEventListener('onPluggedOut', function(){document.getElementById('sdCardStatus').textContent = "Plugged out"});

	document.getElementById('checkStatus').addEventListener('click', function() {
		checkStatus();
	});

	document.getElementById('connect').addEventListener('click', function() {
		console.log("connecting");
		nexpaqAPI.TFCard.connect();
		status_check_timer = 5;
	});

	document.getElementById('disconnect').addEventListener('click', function() {
		console.log("disconnecting");
		nexpaqAPI.TFCard.disconnect();
		status_check_timer = 5;
	});

	checkStatus();
	setInterval(updateTimer, 1000);
});
