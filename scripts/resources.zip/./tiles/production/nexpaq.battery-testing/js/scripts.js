window.nexpaqAPI.setCurrentModule("Battery");
var status_check_timer_initial_value = 15,
		status_check_timer = status_check_timer_initial_value;
var check_status_text = 'Check status';

function checkStatus() {
	status_check_timer = status_check_timer_initial_value;

	console.log("checking status");
	nexpaqAPI.Battery.statusCheck();
}
function updateTimer() {
	if(status_check_timer < 0) {
		checkStatus();
	}

	var text = check_status_text + ' (' + status_check_timer + ')';
	document.getElementById('checkStatus').textContent = text;

	status_check_timer--;
}

function dataHandler () {
	var stateMessage= "";

	switch(nexpaqAPI.Battery.state)
	{
		case 1 :
		stateMessage = "The Battery tile is charging...";
		break;

		case 2 :
		stateMessage = "The Phone is charging...";
		break;

		case 3 :
		stateMessage = "The Battery is on standby...";
		break;

		default:
		console.log("Didn't receive any data");
		break;
	}

	document.getElementsByClassName('state-control')[0].innerHTML = stateMessage;
}

function voltageHandler (value) {
	document.getElementsByClassName('value')[0].innerHTML = "Current voltage is :" + value;
}
function percentageHandler (percentage) {
	document.getElementsByClassName('percentage')[0].innerHTML = "Battery power is :" + percentage +"%";
}
function currentSend() {
	if (document.getElementById('option-1').checked) {
		nexpaqAPI.Battery.chargeCurrent100();
	}
	if (document.getElementById('option-2').checked) {
		nexpaqAPI.Battery.chargeCurrent250();
	}
}




/* =========== ON PAGE LOAD HANDLER */
document.addEventListener("DOMContentLoaded", function(event) {
	nexpaqAPI.header.setTitle('#Battery');
	nexpaqAPI.global.addEventListener('onBackButtonClicked', function() {
		nexpaqAPI.util.closeApplication();
	});

	document.getElementById('checkStatus').addEventListener('click', function() {
		checkStatus();
	});
	checkStatus();
	setInterval(updateTimer, 1000);


	nexpaqAPI.Battery.addEventListener('onPercentageChanged', percentageHandler);
	nexpaqAPI.Battery.addEventListener("onCharging",dataHandler);
	nexpaqAPI.Battery.addEventListener("onStandby", dataHandler);
	nexpaqAPI.Battery.addEventListener("onDischarging", dataHandler);
	nexpaqAPI.Battery.addEventListener("onVoltageChanged", voltageHandler);

	document.getElementById('Standby').addEventListener('click', function() {
		nexpaqAPI.Battery.setStandby();
		nexpaqAPI.Battery.statusCheck();
	});
	document.getElementById('Current').addEventListener('click', function() {
		currentSend();
	});

	document.getElementById('ChargePhone').addEventListener('click', function() {
		nexpaqAPI.Battery.setDischarging();
		nexpaqAPI.Battery.statusCheck();
	});

	document.getElementById('ChargeBattery').addEventListener('click', function() {
		nexpaqAPI.Battery.setCharging();
		nexpaqAPI.Battery.statusCheck();
	});



});
