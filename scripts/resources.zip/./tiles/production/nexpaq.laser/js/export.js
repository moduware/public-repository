// title: Start Laser
function NP_start_LASER () {
	nexpaqAPI.Laser.on();
}
// title: Stop Laser
function NP_stop_LASER () {
	nexpaqAPI.Laser.off();
}

if(typeof JSON === "undefined") {
	@@include('../vendor/json3.min.js')
}
@@include('../js/lib/nexpaqAPI.js')


window.EmulateModule=false;
nexpaqAPI.setCurrentModule("Laser");
