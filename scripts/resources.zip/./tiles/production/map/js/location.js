function locationReceivedHandler(location) {
  console.log(location);
  window.map.setCenter(new google.maps.LatLng(location.coords[0], location.coords[1]));
}
