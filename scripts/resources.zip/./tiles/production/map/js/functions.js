function evaluteMath(expression) {
  var search = null,
      preg = /calc\((.+?),\s{0,1}(\d+)\)/g,
      reg = /calc\((.+?)\)/g;
  while((search = preg.exec(expression)) || (search = reg.exec(expression))) {
    console.log(search);
    expression = expression.replace(search[0], math.format(math.eval(search[1]), {precision: search[2]==null?5:search[2]}));
  }
  return expression;
}
function compareRFC3339Dates(a, b) {
  var aDate = Date.parse(a.time),
      bDate = Date.parse(b.time);

  if (aDate < bDate) {
    return -1;
  }
  if (aDate > bDate) {
    return 1;
  }
  return 0;
}
function ISODateString(d){
 function pad(n){return n<10 ? '0'+n : n}
 return d.getUTCFullYear()+'-'
      + pad(d.getUTCMonth()+1)+'-'
      + pad(d.getUTCDate())+'T'
      + pad(d.getUTCHours())+':'
      + pad(d.getUTCMinutes())+':'
      + pad(d.getUTCSeconds())+'Z'
}
