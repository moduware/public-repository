function requestData(types, offset, limit) {
  if(limit == null) limit = 10;
  window.DATA_RECEIVED_FROM_CLOUD=[];

  if(types == "all") {
    types = Object.keys(window.SOURCES_TYPES);
    // removing default
    types.shift();
  }
  window.REQUESTED_DATA_TYPES = types;

  for(var i=0; i < types.length; i++) {
    window.nexpaqAPI.util.sendDataQuery(types[i], {offset: offset, limit: limit});
  }
}
function getCurrentDuration() {
  return parseInt(document.querySelector('#period-selector .period-radio:checked').value);
}
function getCurrentBoundingBox() {
  var bounds = window.map.getBounds(),
      cor1 = bounds.getNorthEast(),
      cor2 = bounds.getSouthWest();

  return [cor1.lat(), cor1.lng(), cor2.lat(), cor2.lng()];
}
function requestMapData(types, duration, boundingBox) {
  window.DATA_RECEIVED_FROM_CLOUD=[];
  if(duration == null) duration = getCurrentDuration();
  if(boundingBox == null) boundingBox = getCurrentBoundingBox();

  if(types == "all") {
    types = Object.keys(window.SOURCES_TYPES);
    // removing default
    types.shift();
  }
  //window.REQUESTED_DATA_TYPES = types;
  // var start_time = new Date(),
  //     end_time = new Date();//,
      //bounding_box = boundingBox[0] + "," + boundingBox[1] + "," + boundingBox[2] + "," + boundingBox[3];
  //start_time.setDate(end_time.getDate() - duration);

  //for(var i=0; i < types.length; i++) {
    //window.nexpaqAPI.util.sendDataQuery(types.join(), {startTime: ISODateString(start_time), endTime: ISODateString(end_time), boundingBox: boundingBox});
    //console.log(boundingBox);
    window.nexpaqAPI.util.sendDataQuery(types.join(), {boundingBox: boundingBox});
  //}
}
function requestMapTile(types, duration, coords, zoom) {
  if(duration == null) duration = getCurrentDuration();
  if(typeof window.PROJECTION == "undefined") {
    window.PROJECTION = map.getProjection();
  }
  var start_lat_lng = window.PROJECTION.fromPointToLatLng(coords),
      end_lat_lng = window.PROJECTION.fromPointToLatLng(new google.maps.Point(coords.x+1,coords.y+1)),
      slat = start_lat_lng.lat(),
      elat = end_lat_lng.lat(),
      slng = start_lat_lng.lng(),
      elng = end_lat_lng.lng();

  // check if tile known
  if(typeof window.KNOWN_TILES[zoom] !== "undefined" && typeof window.KNOWN_TILES[zoom][coords.x + ";" + coords.y] !== "undefined") return;
  // check if any master tile is known
  for(var i=1; i<zoom; i++) {
    var coord_x = Math.ceil((coords.x/(2*(zoom-i)))),
        coord_y = Math.ceil((coords.y/(2*(zoom-i))));
    // console.log("Zoom: "+zoom, "oX,Y: {"+coords.x+";"+coords.y+"}", "Master Zoom: "+i, "X,Y: {"+coord_x+";"+coord_y+"}");
    if(typeof window.KNOWN_TILES[i] !== "undefined" && typeof window.KNOWN_TILES[i][coord_x + ";" + coord_y] !== "undefined") {
      // and mark child tile as known
      if(typeof window.KNOWN_TILES[zoom] == "undefined") window.KNOWN_TILES[zoom] = {};
      window.KNOWN_TILES[zoom][coords.x + ";" + coords.y] = true;
      return;
    }
  }
  // if not, lets request the tile
  if(!window.nexpaqAPI.emulateMode) requestMapData(types, duration, tileCoordsToBBox(map, coords, zoom, 256, 256));
  //console.log(coords.x, coords.y, tileCoordsToBBox(map, coords, zoom, 256, 256));

  // and mark it as known
  if(typeof window.KNOWN_TILES[zoom] == "undefined") window.KNOWN_TILES[zoom] = {};
  window.KNOWN_TILES[zoom][coords.x + ";" + coords.y] = true;

  //console.log(slat, slng, elat, slat);
}
function tileCoordsToBBox(map, coord, zoom, tileWidth, tileHeight) {
    var proj = map.getProjection();

    // scale is because the number of tiles shown at each zoom level double.
    var scale = Math.pow(2, zoom);

    // A point is created for the north-east and south-west corners, calculated
    // by taking the tile coord and multiplying it by the tile's width and the map's scale.
    var ne = proj.fromPointToLatLng(new google.maps.Point( (coord.x+1) * tileWidth / scale, coord.y * tileHeight / scale));
    var sw = proj.fromPointToLatLng(new google.maps.Point( coord.x * tileWidth / scale, (coord.y+1) * tileHeight / scale));

    return [
        sw.lat(),
        sw.lng(),
        ne.lat(),
        ne.lng()
    ];
}
function timelineItemsLoadedHandler(data) {
  if(data.length !== 0) {
    //var type = data[0].datasetName;
    window.DATA_RECEIVED_FROM_CLOUD = window.DATA_RECEIVED_FROM_CLOUD.concat(data);
  }
  // not the safest way, but we don't know what kind of data received if no items...
  //window.REQUESTED_DATA_TYPES.shift();

  //if(window.REQUESTED_DATA_TYPES.length === 0) {
    onAllDataReceivedHandler();
  //}
}
function onAllDataReceivedHandler() {
  // lets sort items by date
  //window.DATA_RECEIVED_FROM_CLOUD.sort(compareRFC3339Dates);
  var monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
  ];
  for(var i=0; i<window.DATA_RECEIVED_FROM_CLOUD.length; i++) {
    var item = window.DATA_RECEIVED_FROM_CLOUD[i],
        time = new Date(item.time);
    time = sprintf("%1d:%2d %3d %4s %5d", time.getHours(), time.getMinutes(), time.getDate(), monthNames[time.getMonth()], time.getFullYear());
    //addItemToTimeline(item.datasetName, time, item.value);
    addMapMarker(item.datasetName, item.Location[0], item.Location[1], item.value, time);
  }

  //window.loading_timeout = null;
  //document.getElementById('loading-icon').classList.remove('active');
}
