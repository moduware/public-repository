var current_temperature = 'ambient';
/** ================ Handlers == */
function backButtonClickHandler(e) {
		if(!window.EmulateModule) {
			window.nexpaqAPI.HaT.stop();
			window.nexpaqAPI.util.closeApplication();
		}
		onNxpAppError('Application closed!', '', '', '', '');
}

function nativeDataUpdateHandler(data) {
	if(temperature != data.ambient_temperature.toFixed(1)) {
		var temp_c = data.ambient_temperature.toFixed(1),
				temp_f = Celsius2Farenheit( data.ambient_temperature ).toFixed(1);
		temperature = current_temperature == 'ambient' ? temp_c : data.object_temperature.toFixed(1);
		if(temperature > 0 && temperature < 4) temperature = '+' + temperature;
		document.getElementById('temperature-value').innerText = temperature;
		document.getElementById('humidity-value').innerText = data.ambient_humidity.toFixed(0);
	}
}
function emulateNativeData() {
	var content = {
		"ambient_temperature"	: getRandomArbitrary(-50, 50),
		"ambient_humidity"		: getRandomInt(0, 100),
		"object_temperature"	: 32+getRandomArbitrary(0, 7)
	};
	receiveFromNative(JSON.stringify(content));
}
/**
 * Returns a random number between min (inclusive) and max (exclusive)
 */
function getRandomArbitrary(min, max) {
    return Math.random() * (max - min) + min;
}


/**
 * Returns a random integer between min (inclusive) and max (inclusive)
 * Using Math.round() will give you a non-uniform distribution!
 */
function getRandomInt(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
/**
 * Convert celsius value to farnheit value
 * @param {float} value [celsius value]
 */
function Celsius2Farenheit(value) {
	return value*1.8 + 32;
}
