var defined_icons = [
  'img/icon-led.svg'
];
var known_functions = {
  'NP_white_LED' : [0, 'blue'],
  'NP_red_LED' : [0, 'blue'],
  'NP_green_LED' : [0, 'blue'],
  'NP_blue_LED' : [0, 'blue'],
  'NP_flash_red_and_blue_LED' : [0, 'blue']
}
