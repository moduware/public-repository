nexpaqAPI.setCurrentModule('DevMod');

// Actions when click button or change color  
function updateLED() {
    // Get R,G,B values
    var R = parseInt(document.getElementById('R_value').value);
    var G = parseInt(document.getElementById('G_value').value);
    var B = parseInt(document.getElementById('B_value').value);
    document.getElementById('rgbLED').style.backgroundColor = 'rgb(' + R + ',' + G + ',' + B + ')';
    window.nexpaqAPI.DevMod.send("RGB_LED", [R, G, B]);
}

function updateDigIO(pin) {
    var digID = 'dig' + pin + 'v';
    var mode=parseInt(document.getElementById(digID).value);
    window.nexpaqAPI.DevMod.send("PIN_MODE", [parseInt(pin,16), mode]);
}

function dataHandler() {
    var ain_0v = 6 * parseInt(window.nexpaqAPI.DevMod.last_data.AIN_0) / ((1<<16) -1);
    var ain_1v = 6 * parseInt(window.nexpaqAPI.DevMod.last_data.AIN_1) / ((1<<16) -1);
    var ain_2v = 6 * parseInt(window.nexpaqAPI.DevMod.last_data.AIN_2) / ((1<<16) -1);
    var ain_3v = 6 * parseInt(window.nexpaqAPI.DevMod.last_data.AIN_3) / ((1<<16) -1);
    var dig_io = parseInt(window.nexpaqAPI.DevMod.last_data.DIG_IO);
    var i=0;
    var digID= '';
    document.getElementById('ana0v').value = ain_0v.toFixed(2) + 'V';
//    document.getElementById('ana0p').style.backgroundColor = 'rgb(' + ain_0 + ',' + ain_0 + ',' + ain_0 + ')';
    document.getElementById('ana1v').value = ain_1v.toFixed(2) + 'V';
//    document.getElementById('ana1p').style.backgroundColor = 'rgb(' + ain_1 + ',' + ain_1 + ',' + ain_1 + ')';
    document.getElementById('ana2v').value = ain_2v.toFixed(2) + 'V';
//    document.getElementById('ana2p').style.backgroundColor = 'rgb(' + ain_2 + ',' + ain_2 + ',' + ain_2 + ')';
    document.getElementById('ana3v').value = ain_3v.toFixed(2) + 'V';
//    document.getElementById('ana3p').style.backgroundColor = 'rgb(' + ain_3 + ',' + ain_3 + ',' + ain_3 + ')';
    for (i=0; i<16; i++) {
        digID = 'dig' + i.toString(16).toUpperCase() + 'l';
        if (dig_io & 1) {
            document.getElementById(digID).className = "greenLight";
        } else {
            document.getElementById(digID).className = "greenOff";            
        }
        dig_io = dig_io >> 1;
    }
    
}

// when page is finished loading
document.addEventListener("DOMContentLoaded", function (e) {
    var i=0;
    for (i=0; i<16; i++) {
       window.nexpaqAPI.DevMod.send("PIN_MODE", [i, 3]); 
    }
    updateLED();
	// call dataHandler function whenever data is received
	window.nexpaqAPI.DevMod.addEventListener("onDataReceived", dataHandler);
});