function locationReceivedHandler(location) {

  if(lat == null) {
    console.log(location);
    window.geo_location = location;
    var location_label = '';
    var location_arr = [];

    if(location.city != null) location_arr.push(location.city);
    if(location.province != null) location_arr.push(location.province);
    if(location.country != null) location_arr.push(location.country);

    if(location_arr.length != 0) {
      location_label = location_arr.join(', ');
      document.getElementById("heating-location-city").textContent = location_label;
      document.getElementById("result-location-city").textContent = location_label;
    }

    if(location.coords[0]!=null||location.coords[1]!=null) {
      lat = location.coords[0]; long = location.coords[1];
    }
  }
  else {
    window.map.setCenter(new google.maps.LatLng(lat, long));
  }
}
