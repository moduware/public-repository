
window.lastTimeRecieved = 0;
window.lastData = -1;
window.biggest_result = 0;

function resultImage() {
  if (biggest_result >=0 && biggest_result <=50) {
    document.getElementById("resultImg").style.backgroundImage = 'url("img/good.svg")';
  }

  if (biggest_result >=51 && biggest_result <=400) {
    document.getElementById("resultImg").style.backgroundImage = 'url("img/moderate.svg")';
  }

  if (biggest_result >=401) {
    document.getElementById("resultImg").style.backgroundImage = 'url("img/bad.svg")';
  }
}

/** ================ Handlers == */
function nativeDataUpdateHandler(data) {
  if(data > 1024) return;
  data = parseInt(data*1000/1024);
  if(data != lastData) {
    if(data > biggest_result) {
      biggest_result = data;
      setBiggestResult(biggest_result);
    }
    lastData = data;
    setResult(data);
  }
  resultImage();

}


