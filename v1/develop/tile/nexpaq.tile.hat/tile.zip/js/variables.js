var user_location = 'inside',
    temperature = 0;
