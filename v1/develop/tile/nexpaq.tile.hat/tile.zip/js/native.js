var current_temperature = 'ambient';
/** ================ Handlers == */

function nativeDataUpdateHandler(data) {
	if(data != undefined) {
		var ambient_temperature = parseFloat(data.ambient_temperature).toFixed(1);
		var	object_temperature = parseFloat(data.object_temperature).toFixed(1);
		var	humidity = parseFloat(data.humidity).toFixed(1);

		temperature = current_temperature == 'ambient' ? ambient_temperature : object_temperature;
		if(document.getElementById('fahrenheit').checked == true) {
			temperature = Celsius2Farenheit(temperature).toFixed(1);
			var tempValue = parseFloat(document.getElementById('temp-value1').textContent);
        	document.getElementById('scale-svg').style.top = ((tempValue-77)*3)+'px';		//setting temperature scale
        	document.getElementById('gradient').style.top = (((tempValue-77)*3)-400)+'px';
		} else {
			document.getElementById('scale-svg').style.top = ((temperature-25)*7)+'px';		//setting temperature scale
        	document.getElementById('gradient').style.top = (((temperature-25)*7)-400)+'px'; 
		}
		document.getElementById('temp-value1').textContent = temperature+'°';		
		document.getElementById('humidity-value1').textContent = humidity+'%';
	}
}

/**
 * Convert celsius value to farnheit value
 * @param {float} value [celsius value]
 */
function Celsius2Farenheit(value) {
	return value*1.8 + 32;
}
