define(["exports", "./my-app.js"], function (_exports, _myApp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.ifDefined = _exports.MorphSwipeout = _exports.MorphListViewTitle = _exports.MorphListViewItem = _exports.MorphListView = _exports.$morphSwipeout = _exports.$morphListViewTitle = _exports.$morphListViewItem = _exports.$morphListView = _exports.$ifDefined = void 0;

  function _templateObject18_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        :host {\n          display: flex;\n        \toverflow-y: scroll;\n        \tbackground-color: #F9F9F9;\n        }\n\n        morph-list-view {\n          margin-bottom: 0;\n          width: 100%;\n        }\n        morph-list-view-title {\n        \tbackground-color: #eff0f4;\n        \tmargin: 0;\n        \tpadding: 10px;\n        }\n\n        morph-list-view-item {\n        \t--display-inner-item-bottom-line: none;\n        \t--container-align-items: stretch;\n        \tmargin-bottom: 0px;\n        \twidth: 100%;\n        }\n\n        morph-tabbar {\n        \t--ios-bar-color: transparent;\n        \tbox-shadow: 0px -0.5px 0px 1px rgba(0, 0, 0, 0.3);\n        }\n        .history-placeholder {\n          font-family: Roboto;\n          display: flex;\n          flex-direction: column;\n          justify-content: center;\n          align-items: center;\n          height: 100%;\n          width: 100%;\n          margin: auto 0;\n        }\n\n        .history-placeholder-icon {\n          margin-bottom: 35px;\n        }\n\n        .history-placeholder-title {\n          font-size: 17px;\n          line-height: 17px;\n          color: #000000;\n          margin-bottom: 8px;\n        }\n\n        :host([platform=\"ios\"]) .history-placeholder-title {\n          color: #535353;\n        }\n\n        .history-placeholder-text {\n          font-size: 14px;\n          line-height: 18px;\n          color: #929292;\n          display: inline-block;\n          text-align: center;\n        }\n\n        :host([platform=\"ios\"]) .history-placeholder-text {\n          color: #7A7A7A;\n        }\n\n        .temperature-list-item {\n          font-family: Roboto;\n          color: #535353;\n        }\n\n        .temperature-list-item__title:empty::after {\n          content: 'Unlabeled';\n        }\n\n        .temperature-list-item__title {\n          margin-bottom: 5px;\n        }\n\n        .temperature-list-item__value,\n        .temperature-list-item__title {\n          font-weight: bold;\n          color: black;\n        }\n        .temperature-list-item__content {\n          line-height: 1.5em;\n        }\n\n        .temperature-list-item__value--temperature::after {\n          content: '\xB0';\n        }\n\n        .temperature-list-item__value--humidity::after {\n          content: '%';\n        }\n\n        .temperature-list-item__time,\n        .temperature-list-item__address {\n          color: #929292;\n          font-size: 14px;\n          font-weight: 300;\n        }\n\n        .temperature-list-item__address {\n          margin-top: 8px;\n          text-overflow: initial;\n          white-space: initial;\n        }\n\n        .temperature-list-item__time {\n          margin-bottom: auto;\n          margin-top: 8px;\n          margin-right: 17px;\n        }\n\n        .temperature-list-item__icon-container {\n          display: flex;\n          flex-direction: column;\n          align-items: center;\n          justify-content: space-between;\n\n          min-width: auto;\n          padding-top: 10px;\n          padding-bottom: 10px;\n          margin-right: 25px;\n        }\n      "]);

    _templateObject18_49588b906ebf11ea9e7797d125c65125 = function _templateObject18_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject17_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n\t\t\t\t\t\t\t<morph-swipeout class=\"temperature-list-item\">\n\t\t\t\t\t\t\t\t<morph-list-view-item class=\"temperature-list-item\">\n\t\t\t\t\t\t\t\t\t<span class=\"temperature-list-item__icon-container\" slot=\"icon\">\n\t\t\t\t\t\t\t\t\t\t<img src=\"images/temperature-icon-ambient-square.svg\" />\n\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t<span slot=\"header\" class=\"temperature-list-item__title\">", "</span>\n\t\t\t\t\t\t\t\t\t<span class=\"temperature-list-item__content\">\n\t\t\t\t\t\t\t\t\t\t", ":\n\t\t\t\t\t\t\t\t\t\t<span class=\"temperature-list-item__value temperature-list-item__value--temperature\">", "</span>\n\t\t\t\t\t\t\t\t\t\t<br> ", ":\n\t\t\t\t\t\t\t\t\t\t<span class=\"temperature-list-item__value temperature-list-item__value--humidity\">", "</span>\n\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t\t<span slot=\"secondary-content\" class=\"temperature-list-item__time\">\n\t\t\t\t\t\t\t\t\t\t", "\n\t\t\t\t\t\t\t\t\t\t<br>\n\t\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t\t</morph-list-view-item>\n\t\t\t\t\t\t\t\t<span slot=\"right-buttons\">\n\t\t\t\t\t\t\t\t\t<morph-button class=\"swiper-integration-class\" color=\"red\" \n\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tfilled flat item-delete @click=\"", "\" >", "</morph-button>\n\t\t\t\t\t\t\t\t</span>\n\t\t\t\t\t\t\t</morph-swipeout>\n\t\t\t\t\t\t"]);

    _templateObject17_49588b906ebf11ea9e7797d125c65125 = function _templateObject17_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject16_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n\t\t\t\t\t\t<morph-list-view-title>", "</morph-list-view-title>\n\t\t\t\t\t\t", "\n      \t\t"]);

    _templateObject16_49588b906ebf11ea9e7797d125c65125 = function _templateObject16_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject15_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n\t\t\t\t<morph-list-view class=\"temperature-list\">\n\t\t\t\t\t", "\n        </morph-list-view>\n\t\t\t"]);

    _templateObject15_49588b906ebf11ea9e7797d125c65125 = function _templateObject15_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject14_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n       <div class=\"history-placeholder\">\n         <img class=\"history-placeholder-icon\" src=\"images/history-empty-icon.svg\" />\n         <div class=\"history-placeholder-title\">", "</div>\n         <span class=\"history-placeholder-text\">", "</span>\n       </div>\n\t\t\t"]);

    _templateObject14_49588b906ebf11ea9e7797d125c65125 = function _templateObject14_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject13_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      ", "\n    "]);

    _templateObject13_49588b906ebf11ea9e7797d125c65125 = function _templateObject13_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject12_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        :host {\n          --swipe-action-after-background-color-right: yellow;\n          --swipe-action-after-background-color-left: yellow;\n      \n          position: relative;\n          display: block;\n          overflow-x: hidden;\n          background-color: var(--back-container-background-color, #fff);\n        }\n      \n        .root-container {\n          display: flex;\n          justify-content: stretch;\n        }\n      \n        .root-container:not(.no-transition) {\n          transition: transform 300ms;\n        }\n      \n        .animation-container {\n          transition: height 0.4s linear;\n          overflow: hidden;\n          width: 100%;\n        }\n      \n        .animation-container.disappear-animation {\n          height: 0 !important;\n        }\n      \n        .left-buttons-container,\n        .right-buttons-container {\n          position: absolute;\n          display: flex;\n          height: 100%;\n          top: 50%;\n        }\n      \n        .left-buttons-container {\n          left: 0;\n          transform: translateY(-50%) translateX(-100%);\n        }\n      \n        .right-buttons-container {\n          right: 0;\n          transform: translateY(-50%) translateX(100%);\n        }\n      \n        :host .left-buttons-container ::slotted([slot=\"left-buttons\"])  morph-button,\n        :host .right-buttons-container ::slotted([slot=\"right-buttons\"])  morph-button {\n          position: relative;\n        }\n      \n        :host .left-buttons-container::after,\n        :host .right-buttons-container::after {\n          content: '';\n          position: absolute;\n          top: 0;\n          height: 100%;\n          width: 600%;\n          \n          z-index: -1;\n          transform: translate3d(0,0,0);\n        }\n      \n        :host .right-buttons-container::after {\n          background-color: var(--swipe-action-after-background-color-right);\n          left: 100%;\n          margin-left: -1px;\n        }\n      \n        :host .left-buttons-container::after {\n          background-color: var(--swipe-action-after-background-color-left, #fff);\n          right: 100%;\n          margin-right: -1px;\n        }\n      \n      "]);

    _templateObject12_49588b906ebf11ea9e7797d125c65125 = function _templateObject12_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject11_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n    <div class=\"animation-container\" id=\"animationContainer\">\n      <div class=\"root-container\" id=\"rootContainer\">\n        <div class=\"left-buttons-container\" id=\"leftButtonsContainer\">\n          <slot name=\"left-buttons\"></slot>\n        </div>\n    \n        <!-- main content of swipeout goes here -->\n        <slot></slot>\n    \n        <div class=\"right-buttons-container\" id=\"rightButtonsContainer\">\n          <slot name=\"right-buttons\"></slot>\n        </div>\n      </div>\n    </div>\n    "]);

    _templateObject11_49588b906ebf11ea9e7797d125c65125 = function _templateObject11_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject10_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        :host {\n          display: block;\n          margin-bottom: 35px;\n        }\n      \n        :host .container ::slotted(morph-list-view-item) {\n          margin-bottom: 0;\n        }\n      \n        :host .container ::slotted(morph-list-view-item:not(:first-of-type)) {\n          --display-top-line: none;\n        }\n      \n        :host .container ::slotted(morph-list-view-item:not(:last-of-type)) {\n          --display-bottom-line: none;\n          --display-inner-item-bottom-line: block;\n        }\n        \n        /* this is fading the inner line in and out using opacity */\n        :host .container ::slotted(morph-list-view-item[expanded]:not(:last-of-type)) {\n          --sub-container-after-opacity: 0;\n        }\n      \n      "]);

    _templateObject10_49588b906ebf11ea9e7797d125c65125 = function _templateObject10_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject9_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <div class=\"container\">\n        <slot id=\"slot\"></slot>\n      </div>\n    "]);

    _templateObject9_49588b906ebf11ea9e7797d125c65125 = function _templateObject9_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject8_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        :host {\n          display: block;\n          position: relative;\n          overflow: hidden;\n          white-space: nowrap;\n          text-overflow: ellipsis;\n          font-size: 14px;\n        }\n      \n        :host([platform=\"ios\"]) {\n          text-transform: uppercase;\n          color: #6d6d72;\n          margin: 35px 15px 10px;\n          line-height: 17px;\n          font-family: -apple-system, 'SF UI Text', 'Helvetica Neue', Helvetica, Arial, sans-serif;\n        }\n      \n        :host([platform=\"android\"]) {\n          color: rgba(0,0,0,.54);\n          margin: 32px 16px 16px;\n          line-height: 16px;\n          font-weight: 500;\n          font-family: Roboto, Noto, Helvetica, Arial, sans-serif;\n        }\n      "]);

    _templateObject8_49588b906ebf11ea9e7797d125c65125 = function _templateObject8_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject7_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <slot></slot>\n    "]);

    _templateObject7_49588b906ebf11ea9e7797d125c65125 = function _templateObject7_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject6_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["<morph-ripple></morph-ripple>"]);

    _templateObject6_49588b906ebf11ea9e7797d125c65125 = function _templateObject6_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject5_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        <svg id=\"chevron-svg\" width=\"8px\" height=\"13px\" viewBox=\"0 0 8 13\" xmlns=\"http://www.w3.org/2000/svg\">\n          <polygon fill=\"#c7c7cc\" transform=\"translate(1.500000, 6.500000) rotate(-45.000000) translate(-1.500000, -6.500000) \"\n            points=\"6 11 6 2 4 2 4 9 -3 9 -3 11 5 11\"></polygon>\n        </svg>\n      "]);

    _templateObject5_49588b906ebf11ea9e7797d125c65125 = function _templateObject5_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject4_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        :host {\n          display: block;\n          margin-bottom: 10px;\n        }\n      \n        /*:host([platform=\"ios\"]) {\n          font-family: -apple-system, 'SF UI Text', 'Helvetica Neue', Helvetica, Arial, sans-serif;\n        }\n      \n        :host([platform=\"android\"]) {\n          font-family: Roboto, Noto, Helvetica, Arial, sans-serif;\n        }*/\n      \n      \n        :host .container {\n          display: flex;\n          justify-content: space-between;\n          align-items: var(--container-align-items, center);\n          position: relative;\n          white-space: nowrap;\n          box-sizing: border-box;\n          background-color: white;\n          z-index: var(--item-container-z-index, 1);\n          height: 100%;\n        }\n      \n        :host .sub-container {\n          width: 100%;\n          display: flex;\n          align-self: stretch;\n          align-items: center;\n          position: relative;\n          min-width: 0;\n        }\n      \n        :host([platform=\"ios\"]) .container {\n          padding-left: 15px;\n          min-height: 44px;\n        }\n      \n        :host([platform=\"android\"]) .container {\n          padding-left: 16px;\n          min-height: 48px;\n        }\n      \n        :host([platform=\"ios\"][href]:not([chevron=\"none\"])) .sub-container,\n        :host([platform=\"ios\"][chevron]:not([chevron=\"none\"])) .sub-container {\n        padding-right: 15px;\n        }\n        \n        :host([platform=\"android\"][href]:not([chevron=\"none\"])) .sub-container,\n        :host([platform=\"android\"][chevron]:not([chevron=\"none\"])) .sub-container {\n          padding-right: 16px;\n        }\n      \n        :host([platform=\"ios\"][contains-media]) ::slotted([slot=\"icon\"]) {\n          padding-top: 14px;\n          padding-bottom: 14px;\n        }\n      \n        :host([platform=\"ios\"]) .container::before,\n        :host([platform=\"ios\"]) .expandable-content-container::after,\n        :host([platform=\"ios\"]:not([expandable])) .container::after,\n        :host([platform=\"ios\"]) .sub-container::after {\n          content: '';\n          position: absolute;\n          background-color: #c8c7cc;\n          left: 0;\n          width: 100%;\n          height: 1px;\n          transform: scaleY(.5);\n          transition: opacity 300ms;\n        }\n        \n        :host([platform=\"ios\"]) .sub-container::after,\n        :host([platform=\"android\"]) .sub-container::after {\n          height: var(--sub-container-after-height, 1px);\n          opacity: var(--sub-container-after-opacity, 1);\n        }\n      \n        :host([platform=\"android\"]) .container::before,\n        :host([platform=\"android\"]) .expandable-content-container::after,\n        :host([platform=\"android\"]:not([expandable])) .container::after,\n        :host([platform=\"android\"]) .sub-container::after {\n          content: '';\n          position: absolute;\n          background-color: rgba(0,0,0,.12);\n          left: 0;\n          width: 100%;\n          height: 1px;\n          transform: scaleY(.5);\n          transition: opacity 300ms;\n        }\n      \n        :host([platform=\"ios\"]) .sub-container::after {\n          display: var(--display-inner-item-bottom-line, none);\n          transform-origin: 50% 100%;\n          bottom: 0;\n        }\n      \n        :host([platform=\"android\"]) .sub-container::after {\n          display: var(--display-inner-item-bottom-line, none);\n          transform-origin: 50% 100%;\n          bottom: 0;\n        }\n      \n        :host([platform=\"ios\"]) .container::before {\n          display: var(--display-top-line, block);\n          transform-origin: 50% 0;\n          top: 0;\n        }\n      \n        :host([platform=\"android\"]) .container::before {\n          display: var(--display-top-line, block);\n          transform-origin: 50% 0;\n          top: 0;\n        }\n      \n        :host([platform=\"ios\"]) .container::after,\n        :host([platform=\"ios\"][expandable]) .expandable-content-container::after {\n          display: var(--display-bottom-line, block);\n          transform-origin: 50% 100%;\n          bottom: 0;\n        }\n      \n        :host([platform=\"android\"]) .container::after,\n        :host([platform=\"android\"][expandable]) .expandable-content-container::after {\n          display: var(--display-bottom-line, block);\n          transform-origin: 50% 100%;\n          bottom: 0;\n        }\n      \n        :host .main-text {\n          display: flex;\n          justify-content: center;\n          flex-direction: column;\n          line-height: normal;\n          width: 100%;\n          padding-top: 8px;\n          padding-bottom: 8px;\n          min-width: 0;\n        }\n      \n        :host([platform=\"ios\"]) .main-text {\n          font-size: 17px;\n        }\n      \n        :host([platform=\"android\"]) .main-text {\n          font-size: 16px;\n        }\n      \n        :host .main-text span {\n          white-space: nowrap;\n          overflow: hidden;\n          text-overflow: ellipsis;\n        }\n      \n        :host([platform=\"android\"]) .main-text ::slotted([slot=\"header\"]),\n        :host([platform=\"android\"]) .main-text ::slotted([slot=\"footer\"]), \n        :host([platform=\"ios\"]) .main-text ::slotted([slot=\"header\"]),\n        :host([platform=\"ios\"]) .main-text ::slotted([slot=\"footer\"]) {\n          font-weight: 400;\n          font-size: 12px;\n          line-height: 1.2;\n          white-space: nowrap;\n          overflow: hidden;\n          text-overflow: ellipsis;\n        }\n      \n        .main-text ::slotted([slot=\"footer\"]) {\n          color: #8e8e93;\n        }\n      \n        :host([platform=\"ios\"]) ::slotted([slot=\"secondary-content\"]) {\n          color: #8e8e93;\n          font-size: 17px;\n          padding-left: 5px;\n          padding-right: 11px;\n        }\n      \n        :host([platform=\"android\"]) ::slotted([slot=\"secondary-content\"]) {\n          color: #757575;\n          font-size: 14px;\n          padding-left: 8px;\n          padding-right: 18px;\n        }\n      \n        :host ::slotted([slot=\"icon\"]) {\n          flex-grow: 0;\n          flex-shrink: 0;\n          margin-right: 15px;\n          display: inline-flex;\n        }\n      \n        /*:host([platform=\"android\"]) ::slotted([slot=\"icon\"]) {\n          min-width: 40px;\n        }*/\n      \n        :host([platform=\"ios\"]) .expandable-content-container {\n          position: relative;\n          background-color: white;\n          display: block;\n          box-sizing: border-box;\n          width: 100%;\n          color: #6d6d72;\n          overflow: hidden;\n          transition: max-height 300ms;\n        }\n      \n        :host([platform=\"android\"]) .expandable-content-container {\n          position: relative;\n          background-color: white;\n          display: block;\n          box-sizing: border-box;\n          width: 100%;\n          color: #212121;\n          overflow: hidden;\n          line-height: 1.5;\n          transition: max-height 300ms;\n        }\n      \n        :host([platform=\"ios\"]:not([expandable])) .expandable-content-container,\n        :host([platform=\"android\"]:not([expandable])) .expandable-content-container {\n          display: none;\n        }\n      \n        :host([platform=\"ios\"]) ::slotted([slot=\"expandable-content\"]) {\n          display: block;\n          padding: 10px 15px;\n        }\n      \n        :host([platform=\"android\"]) ::slotted([slot=\"expandable-content\"]) {\n          display: block;\n          padding: 10px 16px;\n        }\n      \n        :host([platform=\"ios\"]:not([expanded])) .expandable-content-container,\n        :host([platform=\"android\"]:not([expanded])) .expandable-content-container {\n          max-height: 1px !important;\n        }\n      \n        a {\n          color: inherit;\n          cursor: default;\n          text-decoration: none;\n        }\n      \n        svg {\n          flex-grow: 0;\n          flex-shrink: 0;\n        }\n      \n        :host(:not([platform=\"android\"])) morph-ripple {\n          display: none;\n        }\n        :host([platform=\"android\"]) morph-ripple {\n          --ripple-color:  var(--ripple-color-android-light, rgba(0,0,0,0.1));\n        }\n      "]);

    _templateObject4_49588b906ebf11ea9e7797d125c65125 = function _templateObject4_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject3_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <a href=\"", "\" target=\"", "\">\n        <div class=\"container\" @click=\"", "\">\n          <slot name=\"icon\"></slot>\n\n          <div class=\"sub-container\">\n            <div class=\"main-text\">\n              <slot name=\"header\"></slot>\n              <span>\n                <slot></slot>\n              </span>\n              <slot name=\"footer\"></slot>\n            </div>\n\n            <slot name=\"secondary-content\"></slot>\n            \n            ", "\n          </div>\n\n          ", "\n          \n        </div>\n\n        <div class=\"expandable-content-container\" id=\"expandableContentContainer\">\n          <div><slot name=\"expandable-content\"></slot></div>\n        </div>\n      </a>\n    "]);

    _templateObject3_49588b906ebf11ea9e7797d125c65125 = function _templateObject3_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject2_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      \n        :host {\n          --have-access-to-shared-colors: var(--morph-shared-colors-connected, black);\n        }\n      \n        /* if iOS assigning colors from iOS colors table */\n        :host([platform=\"ios\"]) {\n          /* default blue ios colors added here and don't need shared color file to work */\n          --polymorph-ios-blue-color: #007aff;\n          --polymorph-ios-blue-color--background: rgba(0, 122, 255, 0.15);\n      \n          --blue-color: var(--polymorph-ios-blue-color);\n          --blue-color--background: var(--polymorph-ios-blue-color--background);\n      \n          --red-color: var(--polymorph-ios-red-color);\n          --red-color--background: var(--polymorph-ios-red-color--background);\n      \n          --green-color: var(--polymorph-ios-green-color);\n          --green-color--background: var(--polymorph-ios-green-color--background);\n      \n          --gray-color: var(--polymorph-ios-gray-color);\n          --gray-color--background:var(--polymorph-ios-gray-color--background);\n        }\n      \n        /* if Android assigning colors from Android colors table */\n        :host([platform=\"android\"]) {\n          /* default blue android colors added here to make it work without shared colors file */\n          --polymorph-android-blue-color: #2196f3;\n          --polymorph-android-blue-color--background: #0D82DF;\n      \n          --blue-color: var(--polymorph-android-blue-color);\n          --blue-color--background: var(--polymorph-android-blue-color--background);\n      \n          --red-color: var(--polymorph-android-red-color);\n          --red-color--background: var(--polymorph-android-red-color--background);\n      \n          --green-color: var(--polymorph-android-green-color);\n          --green-color--background: var(--polymorph-android-green-color--background);\n      \n          --gray-color: var(--polymorph-android-gray-color);\n          --gray-color--background:var(--polymorph-android-gray-color--background);\n      \n          --android-raised-1-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);\n          --android-raised-2-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);\n        }\n      \n        /* Shared color configuration */\n        :host {\n          --color: var(--blue-color);\n          --active-color--background: var(--blue-color--background);\n          --filled-text-color: white;\n      \n          --font-size: 14px;\n        }\n      \n        /* Prebuilt colors */\n        :host([color=\"red\"]) {\n          --color: var(--red-color);\n          --active-color--background: var(--red-color--background);\n        }\n      \n        :host([color=\"green\"]) {\n          --color: var(--green-color);\n          --active-color--background: var(--green-color--background);\n        }\n      \n        :host([color=\"gray\"]) {\n          --color: var(--gray-color);\n          --active-color--background: var(--gray-color--background);\n        }\n      \n        /* Shared styles between platforms */\n        :host {\n          appearance: none;\n          background: none;\n          box-sizing: border-box;\n          color: var(--color);\n          cursor: pointer;\n          display: flex;\n          justify-content: center;\n          align-items: center;\n          font-size: var(--font-size);\n          margin: 0;\n          outline: 0;\n          overflow: hidden;\n          position: relative;\n          text-align: center;\n          text-decoration: none;\n          text-overflow:ellipsis;\n          white-space: nowrap;\n          -webkit-tap-highlight-color: transparent;\n      \n          /* We need to use system font here */\n          font-family: inherit;\n        }\n        \n        /* class to be used to make morph-button work with morph-swipeout */\n        :host([platform=\"ios\"].swiper-integration-class),\n        :host([platform=\"android\"].swiper-integration-class) {\n          height: 100%;\n          flex: 1;\n        }\n      \n        /* iOS only styles */\n        :host([platform=\"ios\"]) {\n          border-radius: 5px;\n          border: 1px solid var(--color);\n          cursor: pointer;\n          height: 29px;\n          line-height: 27px;\n          padding: 0 10px;\n          position: relative;\n          font-family: -apple-system, 'SF UI Text', 'Helvetica Neue', Helvetica, Arial, sans-serif;\n        }\n      \n        :host([platform=\"ios\"]:active) {\n          background: var(--active-color--background);\n        } \n      \n        :host([platform=\"ios\"][active]) {\n          background: var(--color);\n          color: var(--filled-text-color);\n        }\n      \n        :host([platform=\"ios\"][rounded]) {\n          border-radius: 27px 27px 27px 27px;\n        }\n      \n        :host([platform=\"ios\"][big]) {\n          font-size: 17px;\n          height: 44px;\n          line-height: 42px;\n        }\n      \n        :host([platform=\"ios\"][filled]) {\n          background: var(--color);\n          color: var(--filled-text-color);\n          border-color: transparent;\n        }\n      \n        :host([platform=\"ios\"][filled]:active) {\n          opacity: 0.8;\n        }\n      \n        /* Android only styles */\n        :host([platform=\"android\"]) {\n          border-radius: 2px;\n          height: 36px;\n          line-height: 36px;\n          min-width: 64px;;\n          padding: 0 8px;\n          text-transform: uppercase;\n          transform: translate3d(0,0,0);\n          transition: 300ms;\n          font-family: Roboto, Noto, Helvetica, Arial, sans-serif;\n        }\n      \n        :host([platform=\"android\"]:active) {\n          background: rgba(0, 0, 0, 0.1);\n        } \n      \n        :host([platform=\"android\"][big]) {\n          height: 48px;\n          line-height: 48px;\n          border-radius: 3px;\n        }\n      \n        :host([platform=\"android\"][filled]) {\n          --android-filled-background-color: var(--color);\n          background-color: var(--android-filled-background-color);\n          color: var(--filled-text-color);\n        }\n        \n        :host([platform=\"android\"][filled]:active) {\n          background: var(--active-color--background);\n        }\n      \n        :host([platform=\"android\"][raised]) {\n          box-shadow: var(--android-raised-1-shadow);\n        }\n      \n        :host([platform=\"android\"][raised]:active) {\n          box-shadow: var(--android-raised-2-shadow);\n        }\n      \n        :host(:not([platform=\"android\"])) morph-ripple {\n          display: none;\n        }\n      \n        :host([platform=\"android\"]) morph-ripple {\n          --ripple-color: var(--color);\n        }\n      \n        :host([platform=\"android\"][filled]) morph-ripple {\n          --ripple-color: white;\n        }\n      \n        /* important is to counter the border-radius on big buttons for android and others */\n        :host([flat]) {\n          border-radius: 0 !important;\n        }\n      "]);

    _templateObject2_49588b906ebf11ea9e7797d125c65125 = function _templateObject2_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject_49588b906ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <a href$=\"[[link]]\" target$=\"[[target]]\" rel$=\"[[relation]]\">\n        <slot></slot>\n        <morph-ripple></morph-ripple>\n      </a>\n    "], ["\n      <a href\\$=\"[[link]]\" target\\$=\"[[target]]\" rel\\$=\"[[relation]]\">\n        <slot></slot>\n        <morph-ripple></morph-ripple>\n      </a>\n    "]);

    _templateObject_49588b906ebf11ea9e7797d125c65125 = function _templateObject_49588b906ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  var MorphButton =
  /*#__PURE__*/
  function (_LitElement) {
    babelHelpers.inherits(MorphButton, _LitElement);
    babelHelpers.createClass(MorphButton, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject_49588b906ebf11ea9e7797d125c65125());
      }
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject2_49588b906ebf11ea9e7797d125c65125())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-button';
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          platform: {
            type: String,
            reflect: true
          },

          /** Common for both platforms */
          big: {
            type: Boolean,
            value: false,
            reflect: true
          },

          /** Common for both platforms */
          filled: {
            type: Boolean,
            value: false,
            reflect: true
          },

          /** Common for both platforms */
          color: {
            type: String,
            reflect: true,
            hasChanged: function hasChanged(value, oldValue) {
              return value !== oldValue;
            }
          },

          /** Common for both platforms */
          link: String,
          target: String,
          relation: String,

          /** iOS specific property */
          active: {
            type: Boolean,
            value: false,
            reflect: true
          },

          /** iOS specific property */
          rounded: {
            type: Boolean,
            value: false,
            reflectToAttribute: true
          },

          /** Android specific property */
          raised: {
            type: Boolean,
            value: false,
            reflectToAttribute: true
          },

          /** Remove round corners */
          flat: {
            type: Boolean,
            value: false,
            reflect: true
          }
        };
      }
    }]);

    function MorphButton() {
      var _this;

      babelHelpers.classCallCheck(this, MorphButton);
      _this = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphButton).call(this));
      _this.color = 'blue';
      return _this;
    }
    /**
     * lit-element lifecycle called once before the first updated().
     */


    babelHelpers.createClass(MorphButton, [{
      key: "firstUpdated",
      value: function firstUpdated() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphButton.prototype), "firstUpdated", this).call(this); // check first if platform assigned in html markup before using getPlatform to auto detect platform

        if (!this.hasAttribute('platform')) {
          this.platform = (0, _myApp.getPlatform)();
        }
      }
    }, {
      key: "updated",
      value: function updated(changedProperties) {
        if (this.color) {
          this.colorAssigned(this.color);
        }
      }
    }, {
      key: "connectedCallback",
      value: function connectedCallback() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphButton.prototype), "connectedCallback", this).call(this);
      }
      /**
       * colorAssigned function will fire a console.warn message depending on wether the standard color red gray and green were used
       *
       * @param  {[any]} oldValue old value of color property
       * @param  {any} newValue new value of color property
       *
       * @return {String}          gives a console warn message when shared-colors is not included
       */

    }, {
      key: "colorAssigned",
      value: function colorAssigned(value) {
        var sharedColorsNotConnected = !this.checkIfSharedStylesConnected();

        if (this.checkIfStandardColorUsed(value) && sharedColorsNotConnected) {
          console.warn("WARNING: You need to include morph-shared-colors if you want to use standard colors like ".concat(value, " in the color attribute of morph-button."));
        }
      }
      /**
       * checkIfStandardColorUsed checks if standard colors were used
       *
       * @param  {String} oldValue - old value of the color property from its observer
       *
       * @return {Boolean}          returns true if oldValue is equal to color red, gray or green else returns false
       */

    }, {
      key: "checkIfStandardColorUsed",
      value: function checkIfStandardColorUsed(oldValue) {
        if (oldValue == 'red' || oldValue == 'gray' || oldValue == 'green') {
          return true;
        }

        return false;
      }
      /**
        * checkIfSharedStylesConnected
        *
        * @return {Boolean} - return true if style not equal to 'deepskyblue' meaning shared color file not connected and returns false otherwise
        */

    }, {
      key: "checkIfSharedStylesConnected",
      value: function checkIfSharedStylesConnected() {
        var styleIncludedColor = this.getStyleShadyOrDOM();
        styleIncludedColor = styleIncludedColor.replace(/\s+/, '');

        if (styleIncludedColor != 'deepskyblue') {
          console.warn('WARNING: You need to include morph-shared-colors if you want to use standard colors!');
          return false;
        }

        return true;
      }
      /**
        * @return {Object} - returns the computed style based on if ShadyCSS is used or not 
        */

    }, {
      key: "getStyleShadyOrDOM",
      value: function getStyleShadyOrDOM() {
        if (typeof ShadyCSS != 'undefined') {
          return ShadyCSS.getComputedStyleValue(this, '--have-access-to-shared-colors');
        } else {
          return getComputedStyle(this).getPropertyValue('--have-access-to-shared-colors');
        }
      }
    }]);
    return MorphButton;
  }(_myApp.LitElement);

  window.customElements.define(MorphButton.is, MorphButton);
  var ifDefined = (0, _myApp.directive)(function (value) {
    return function (part) {
      if (value === undefined && babelHelpers.instanceof(part, _myApp.AttributePart)) {
        if (value !== part.value) {
          var name = part.committer.name;
          part.committer.element.removeAttribute(name);
        }
      } else {
        part.setValue(value);
      }
    };
  });
  _exports.ifDefined = ifDefined;
  var ifDefined$1 = {
    ifDefined: ifDefined
  };
  /**
   * `morph-list-view-item`
   * Item component for list view
   *
   * @customElement
   * @extends HTMLElement
   * 
   * @demo demo/index.html
   */

  _exports.$ifDefined = ifDefined$1;

  var MorphListViewItem =
  /*#__PURE__*/
  function (_LitElement2) {
    babelHelpers.inherits(MorphListViewItem, _LitElement2);
    babelHelpers.createClass(MorphListViewItem, [{
      key: "render",
      value: function render() {
        var _this3 = this;

        return (0, _myApp.html)(_templateObject3_49588b906ebf11ea9e7797d125c65125(), ifDefined(this.href), ifDefined(this.target), function (event) {
          return _this3.clickHandler(event);
        }, this.getRenderChevron(), this.getRenderRipple());
      }
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject4_49588b906ebf11ea9e7797d125c65125())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-list-view-item';
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          platform: {
            type: String,
            reflect: true
          },
          href: {
            type: String,
            reflect: true
          },
          target: {
            type: String,
            reflect: true
          },
          containsmedia: {
            type: Boolean,
            reflect: true
          },

          /** remove ripple effect */
          noripple: {
            type: Boolean,
            reflect: true
          },

          /** remove chevron svg on links */
          // nochevron: {
          //   type: Boolean,
          //   reflect: true
          // },
          chevron: Boolean,
          expandable: {
            type: Boolean
          },
          expanded: {
            type: Boolean,
            reflect: true
          }
        };
      }
    }]);

    function MorphListViewItem() {
      var _this2;

      babelHelpers.classCallCheck(this, MorphListViewItem);
      _this2 = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphListViewItem).call(this));

      if (_this2.expandable) {
        _this2._setMaxHeightForExpandableContentContainer();
      }

      return _this2;
    }
    /**
     * LitElement lifecycle called once just before first updated() is called
     */


    babelHelpers.createClass(MorphListViewItem, [{
      key: "firstUpdated",
      value: function firstUpdated() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphListViewItem.prototype), "firstUpdated", this).call(this); // check first if platform is already assigned in the html attribute before auto detecting platform using getPlatform()

        if (!this.hasAttribute('platform')) {
          this.platform = (0, _myApp.getPlatform)();
        }
      }
      /**
       * Handles click events
       * @param {Object} event 
       */

    }, {
      key: "clickHandler",
      value: function clickHandler(event) {
        if (this.expandable) {
          this._setMaxHeightForExpandableContentContainer();

          this.expanded = !this.expanded;

          this._expandedChanged();
        }
      }
      /**
       * Gets height of expandable content and assigns it to max-height to make it transition form open to close smoothly
       */

    }, {
      key: "_setMaxHeightForExpandableContentContainer",
      value: function _setMaxHeightForExpandableContentContainer() {
        var shadow = this.shadowRoot;
        var expandableContent = shadow.querySelector('#expandableContentContainer');
        var height = expandableContent.children[0].offsetHeight;
        expandableContent.style.maxHeight = height + 'px';
      }
      /**
       * returns html template of svg if all conditions are met and returns null if not
       */

    }, {
      key: "getRenderChevron",
      value: function getRenderChevron() {
        if ((this.hasAttribute('chevron') || this.hasAttribute('href')) && this.chevron != 'none') {
          return (0, _myApp.html)(_templateObject5_49588b906ebf11ea9e7797d125c65125());
        } else {
          return null;
        }
      }
      /**
       * returns morph-ripple template if all conditions are met and returns null if not
       */

    }, {
      key: "getRenderRipple",
      value: function getRenderRipple() {
        if (this.platform == 'android' && this.hasAttribute('href') && !this.noripple) {
          return (0, _myApp.html)(_templateObject6_49588b906ebf11ea9e7797d125c65125());
        } else {
          return null;
        }
      }
      /**
       * dispatch custom event expandedChange. This is use together with this.expandable and when this.expanded is toggled
       */

    }, {
      key: "_expandedChanged",
      value: function _expandedChanged() {
        // Fire a custom event for others to listen to when expanded change
        this.dispatchEvent(new CustomEvent('expandedChange', {
          detail: this.expanded
        }));
      }
    }]);
    return MorphListViewItem;
  }(_myApp.LitElement);

  _exports.MorphListViewItem = MorphListViewItem;
  window.customElements.define(MorphListViewItem.is, MorphListViewItem);
  var morphListViewItem = {
    MorphListViewItem: MorphListViewItem
  };
  _exports.$morphListViewItem = morphListViewItem;

  var MorphListViewTitle =
  /*#__PURE__*/
  function (_LitElement3) {
    babelHelpers.inherits(MorphListViewTitle, _LitElement3);

    function MorphListViewTitle() {
      babelHelpers.classCallCheck(this, MorphListViewTitle);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphListViewTitle).apply(this, arguments));
    }

    babelHelpers.createClass(MorphListViewTitle, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject7_49588b906ebf11ea9e7797d125c65125());
      }
    }, {
      key: "firstUpdated",

      /**
       * LitElement lifecycle called once just before first updated() is called
       */
      value: function firstUpdated() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphListViewTitle.prototype), "firstUpdated", this).call(this); // check first if platform attribute is set in HTML before auto detecting and assigning platform using getPlatform()

        if (!this.hasAttribute('platform')) {
          this.platform = (0, _myApp.getPlatform)();
        }
      }
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject8_49588b906ebf11ea9e7797d125c65125())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-list-view-title';
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          platform: {
            type: String,
            reflect: true
          }
        };
      }
    }]);
    return MorphListViewTitle;
  }(_myApp.LitElement);

  _exports.MorphListViewTitle = MorphListViewTitle;
  window.customElements.define(MorphListViewTitle.is, MorphListViewTitle);
  var morphListViewTitle = {
    MorphListViewTitle: MorphListViewTitle
  };
  _exports.$morphListViewTitle = morphListViewTitle;

  var MorphListView =
  /*#__PURE__*/
  function (_LitElement4) {
    babelHelpers.inherits(MorphListView, _LitElement4);

    function MorphListView() {
      babelHelpers.classCallCheck(this, MorphListView);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphListView).apply(this, arguments));
    }

    babelHelpers.createClass(MorphListView, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject9_49588b906ebf11ea9e7797d125c65125());
      }
    }, {
      key: "firstUpdated",

      /**
       * LitElement lifecycle called once just before first updated() is called
       */
      value: function firstUpdated() {
        var _this4 = this;

        babelHelpers.get(babelHelpers.getPrototypeOf(MorphListView.prototype), "firstUpdated", this).call(this); // check for platform if already set in HTML markup before auto detecting platform using getPlatform and assigning new value

        if (!this.hasAttribute('platform')) {
          this.platform = (0, _myApp.getPlatform)();
        }

        this._observer = new _myApp.FlattenedNodesObserver(this, function (info) {
          _this4._processNewNodes(info.addedNodes);
        }); // Flush function needs to be added in order to have changes delivered immediately

        this._observer.flush();
      }
    }, {
      key: "disconnectedCallback",
      value: function disconnectedCallback() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphListView.prototype), "disconnectedCallback", this).call(this);

        this._observer.disconnect();
      }
      /**
       * Process children of morph list view component. 
       * check nodes of morph-list-view-item and attach click event listeners if they are expandable items
       * @param {Object } nodes 
       */

    }, {
      key: "_processNewNodes",
      value: function _processNewNodes(nodes) {
        var _this5 = this;

        if (this.accordion != true) return;

        for (var i = 0; i < nodes.length; i++) {
          // get all the child nodes that are list items
          if (nodes[i].nodeName == 'MORPH-LIST-VIEW-ITEM') {
            var viewItem = nodes[i];

            if (viewItem.hasAttribute('expandable')) {
              viewItem.addEventListener('click', function (e) {
                return _this5._listViewItemClickHandler(e);
              });
            }
          }
        }
      }
      /**
      *  Goes through all non-target item and the expanded attribute if any. This closes open expandable item when a new one is clicked. 
      */

    }, {
      key: "_listViewItemClickHandler",
      value: function _listViewItemClickHandler(e) {
        var items = this.querySelectorAll('morph-list-view-item');

        for (var i = 0; i < items.length; i++) {
          // remove expanded attribute from all other items except the one most recently clicked
          if (items[i] != e.currentTarget) {
            items[i].removeAttribute('expanded');
          }
        }
      }
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject10_49588b906ebf11ea9e7797d125c65125())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-list-view';
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          platform: {
            type: String,
            reflect: true
          },
          accordion: {
            type: Boolean
          }
        };
      }
    }]);
    return MorphListView;
  }(_myApp.LitElement);

  _exports.MorphListView = MorphListView;
  window.customElements.define(MorphListView.is, MorphListView);
  var morphListView = {
    MorphListView: MorphListView
  };
  /**
   * `morph-swipeout`
   * Component to allow swipeout of content by use that will reveal additional actions that don't take screen space normally
   *
   * @customElement
   * @extends HTMLElement
   * @demo demo/index.html
   */

  _exports.$morphListView = morphListView;

  var MorphSwipeout =
  /*#__PURE__*/
  function (_LitElement5) {
    babelHelpers.inherits(MorphSwipeout, _LitElement5);

    function MorphSwipeout() {
      babelHelpers.classCallCheck(this, MorphSwipeout);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphSwipeout).apply(this, arguments));
    }

    babelHelpers.createClass(MorphSwipeout, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject11_49588b906ebf11ea9e7797d125c65125());
      }
    }, {
      key: "firstUpdated",
      value: function firstUpdated() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphSwipeout.prototype), "firstUpdated", this).call(this);
        var self = this; // let morphButtonRightAsync, morphButtonRightAsync;

        (0, _myApp.addListener)(self, 'track', function (e) {
          return self.handleTrack(e);
        });
        this.overswipeTreshold = this.offsetWidth / 2;
      }
    }, {
      key: "updated",
      value: function updated() {
        var _this6 = this;

        babelHelpers.get(babelHelpers.getPrototypeOf(MorphSwipeout.prototype), "updated", this).call(this);
        this._observer = new _myApp.FlattenedNodesObserver(this, function (info) {
          _this6.info = info;
        });

        this._observer.flush();

        (0, _myApp.setTouchAction)(this, 'pan-y');
        var self = this;
        babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee() {
          var morphButtonRight, morphButtonLeft;
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  _context.next = 2;
                  return self._getMorphButtonElement('right');

                case 2:
                  morphButtonRight = _context.sent;
                  _context.next = 5;
                  return self._getMorphButtonElement('left');

                case 5:
                  morphButtonLeft = _context.sent;
                  _this6.noLeftButton = typeof morphButtonLeft === 'undefined'; // get the background-color of morph-button and assign to its ::after swipe-action extension

                  if (morphButtonRight) self.style.setProperty('--swipe-action-after-background-color-right', self._getElementBackgroundColor(morphButtonRight));
                  if (morphButtonLeft) self.style.setProperty('--swipe-action-after-background-color-left', self._getElementBackgroundColor(morphButtonLeft)); // this.$.animationContainer.style.height = this.clientHeight + 'px';
                  // tap event to whole body

                  self._addSwipeoutClickOutsideEventListners(self, morphButtonRight, morphButtonLeft);

                  if (morphButtonRight) morphButtonRight.addEventListener('touchstart', function (event) {
                    return self._onRightButtonClick(event);
                  });
                  if (morphButtonLeft) morphButtonLeft.addEventListener('touchstart', function (event) {
                    return self._onLeftButtonClick(event);
                  });

                case 12:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee);
        }))();
      }
      /**
      * Closes the swipeout element when click outside of itself is detected
      * @param {Object} self - The original 'this' refering to elemnet itself
      * @param {Object} morphButtonRight - The right morph-button
      * @param {Object} morphButtonLeft - The left morph-button
      */

    }, {
      key: "_addSwipeoutClickOutsideEventListners",
      value: function _addSwipeoutClickOutsideEventListners(self, morphButtonRight, morphButtonLeft) {
        window.addEventListener('touchstart', function _tapListener(e) {
          var target = e.target; // if the click is outside the button then close the swipeout component

          if (target != self && target != morphButtonRight && target != morphButtonLeft) {
            self._closeSwipe();
          }
        });
      }
    }, {
      key: "disconnectedCallback",
      value: function disconnectedCallback() {
        var _this7 = this;

        babelHelpers.get(babelHelpers.getPrototypeOf(MorphSwipeout.prototype), "disconnectedCallback", this).call(this);

        this._observer.disconnect(); // REMOVE event window click listener


        window.removeEventListener('click', this._tapListener);
        (0, _myApp.removeListener)(this, 'track', function () {
          return _this7.handleTrack();
        });
      }
      /**
      * Async function callback of click event listener on right most button
      */

    }, {
      key: "_onRightButtonClick",
      value: function () {
        var _onRightButtonClick2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee2(event) {
          var button;
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  event.stopPropagation();
                  button = event.target;

                  if (!button.hasAttribute('item-delete')) {
                    _context2.next = 5;
                    break;
                  }

                  _context2.next = 5;
                  return this._animateDeleteAction(button);

                case 5:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2, this);
        }));

        function _onRightButtonClick(_x) {
          return _onRightButtonClick2.apply(this, arguments);
        }

        return _onRightButtonClick;
      }()
      /**
      * Async function callback of click event listener on left most button
      */

    }, {
      key: "_onLeftButtonClick",
      value: function () {
        var _onLeftButtonClick2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee3(event) {
          var button;
          return regeneratorRuntime.wrap(function _callee3$(_context3) {
            while (1) {
              switch (_context3.prev = _context3.next) {
                case 0:
                  event.stopPropagation();
                  button = event.target;

                  if (!button.hasAttribute('item-delete')) {
                    _context3.next = 5;
                    break;
                  }

                  _context3.next = 5;
                  return this._animateDeleteAction(button);

                case 5:
                case "end":
                  return _context3.stop();
              }
            }
          }, _callee3, this);
        }));

        function _onLeftButtonClick(_x2) {
          return _onLeftButtonClick2.apply(this, arguments);
        }

        return _onLeftButtonClick;
      }()
      /**
      * Async function animate and delete button
      * @param {Object} button - Element animate and delete
      */

    }, {
      key: "_animateDeleteAction",
      value: function () {
        var _animateDeleteAction2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee4(button) {
          var shadow, animationContainer;
          return regeneratorRuntime.wrap(function _callee4$(_context4) {
            while (1) {
              switch (_context4.prev = _context4.next) {
                case 0:
                  shadow = this.shadowRoot;
                  animationContainer = shadow.querySelector('#animationContainer');
                  animationContainer.style.height = this.clientHeight + 'px';
                  _context4.next = 5;
                  return this.waitNextFrame();

                case 5:
                  _context4.next = 7;
                  return this._sleep(0);

                case 7:
                  animationContainer.style.height = '0px';
                  _context4.next = 10;
                  return this.waitForTranstionEnd(animationContainer, 'height');

                case 10:
                  this.remove();

                case 11:
                case "end":
                  return _context4.stop();
              }
            }
          }, _callee4, this);
        }));

        function _animateDeleteAction(_x3) {
          return _animateDeleteAction2.apply(this, arguments);
        }

        return _animateDeleteAction;
      }()
      /**
      * Async function to force to do repaint of frame before going to the next line of js code
      */

    }, {
      key: "waitNextFrame",
      value: function waitNextFrame() {
        return new Promise(function (resolve, reject) {
          requestAnimationFrame(function (timestamp) {
            return resolve(timestamp);
          });
        });
      }
      /**
      * Function to wait for transition end
      * @param {Object} target - Element to listen for transition end
      * @param {String} property - Specific property to listen for transition
      */

    }, {
      key: "waitForTranstionEnd",
      value: function waitForTranstionEnd(target, property) {
        return new Promise(function (resolve, reject) {
          var _dynamicHandler = null;

          _dynamicHandler = function dynamicHandler(event) {
            if (property == null) {
              target.removeEventListener('transitionend', _dynamicHandler);
              resolve();
            } else if (property == event.propertyName) {
              target.removeEventListener('transitionend', _dynamicHandler);
              resolve();
            }
          };

          target.addEventListener('transitionend', _dynamicHandler);
        });
      }
      /**
      * Async function to wait for specified time
      * @param {Number} milliseconds - time delay in milliseconds
      */

    }, {
      key: "_sleep",
      value: function _sleep(milliseconds) {
        return new Promise(function (resolve, reject) {
          setTimeout(function () {
            return resolve();
          }, milliseconds);
        });
      }
      /**
      * Computes for the distance for reveal of right buttons
      * @param {Object} event - The value of the travel of event left or right scroll
      */

    }, {
      key: "handleTrack",
      value: function () {
        var _handleTrack = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee5(event) {
          var shadow, rootContainer, distance, rightButtonsContainer, leftButtonsContainer, newTransform, direction, normalizeTransform;
          return regeneratorRuntime.wrap(function _callee5$(_context5) {
            while (1) {
              switch (_context5.prev = _context5.next) {
                case 0:
                  shadow = this.shadowRoot;
                  rootContainer = shadow.querySelector('#rootContainer');
                  distance = event.detail.dx; //if track distance is just lesst then +/- 10 it will not start the swiping action

                  if (!(Math.abs(distance) < 10)) {
                    _context5.next = 5;
                    break;
                  }

                  return _context5.abrupt("return");

                case 5:
                  if (!this.noLeftButton) {
                    _context5.next = 8;
                    break;
                  }

                  if (!(distance > 0)) {
                    _context5.next = 8;
                    break;
                  }

                  return _context5.abrupt("return");

                case 8:
                  /* START ACTIONS */
                  if (event.detail.state == 'start') {
                    this._trackInitialTransform = this._getTransformTranslateX(rootContainer); // we don't want smooth transitions during user interaction, so removing css smoother

                    rootContainer.classList.add('no-transition'); // determining our buttons container sizes

                    rightButtonsContainer = shadow.querySelector('#rightButtonsContainer');
                    leftButtonsContainer = shadow.querySelector('#leftButtonsContainer');
                    this._rightButtonsContainerSize = rightButtonsContainer.offsetWidth;
                    this._leftButtonsContainerSize = leftButtonsContainer.offsetWidth;
                  }
                  /* SHARED ACTIONS */


                  if (!this.overswiper) distance = this._calculateSwipeSlowDown(distance, this.offsetWidth);
                  newTransform = this._trackInitialTransform + distance;
                  if (newTransform > this.offsetWidth) newTransform = this.offsetWidth - 1;
                  if (newTransform < this.offsetWidth * -1) newTransform = this.offsetWidth * -1 + 1;
                  direction = newTransform > 0 ? 'right' : 'left';
                  /* END ACTIONS */

                  if (!(event.detail.state == 'end')) {
                    _context5.next = 26;
                    break;
                  }

                  // after user finished interaction, enabling css smoother back
                  rootContainer.classList.remove('no-transition'); // calculating positive distance (signless)

                  normalizeTransform = Math.abs(newTransform);

                  if (!(this.overswiper && normalizeTransform > this.overswipeTreshold)) {
                    _context5.next = 25;
                    break;
                  }

                  _context5.next = 20;
                  return this._completeOverswipe(direction);

                case 20:
                  _context5.next = 22;
                  return this._handleOverswipe(direction);

                case 22:
                  newTransform = 0;
                  _context5.next = 26;
                  break;

                case 25:
                  if (newTransform < this._rightButtonsContainerSize / 2 * -1) {
                    newTransform = this._rightButtonsContainerSize * -1;
                  } else if (newTransform > this._leftButtonsContainerSize / 2) {
                    newTransform = this._leftButtonsContainerSize;
                  } else {
                    newTransform = 0;
                  }

                case 26:
                  // Shared code: this is done after every tracking event
                  rootContainer.style.transform = "translateX(".concat(newTransform, "px)");

                case 27:
                case "end":
                  return _context5.stop();
              }
            }
          }, _callee5, this);
        }));

        function handleTrack(_x4) {
          return _handleTrack.apply(this, arguments);
        }

        return handleTrack;
      }()
    }, {
      key: "_getTransformTranslateX",
      value: function _getTransformTranslateX(target) {
        if (target.style.transform == "") return 0;
        var parts = target.style.transform.split(/[\(\)]/g);
        return parseInt(parts[1]);
      }
    }, {
      key: "_completeOverswipe",
      value: function () {
        var _completeOverswipe2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee6(direction) {
          var shadow, rootContainer, buttonPosition;
          return regeneratorRuntime.wrap(function _callee6$(_context6) {
            while (1) {
              switch (_context6.prev = _context6.next) {
                case 0:
                  shadow = this.shadowRoot;
                  rootContainer = shadow.querySelector('#rootContainer');
                  buttonPosition = direction == 'left' ? 'right' : 'left';

                  if (buttonPosition == 'left') {
                    rootContainer.style.transform = "translateX(".concat(this.offsetWidth, "px)");
                  } else if (buttonPosition == 'right') {
                    rootContainer.style.transform = "translateX(-".concat(this.offsetWidth, "px)");
                  }

                  _context6.next = 6;
                  return this.waitForTranstionEnd(rootContainer);

                case 6:
                case "end":
                  return _context6.stop();
              }
            }
          }, _callee6, this);
        }));

        function _completeOverswipe(_x5) {
          return _completeOverswipe2.apply(this, arguments);
        }

        return _completeOverswipe;
      }()
    }, {
      key: "_handleOverswipe",
      value: function () {
        var _handleOverswipe2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee7(direction) {
          var buttonPosition, button, swipeoutPromptText, confirmed;
          return regeneratorRuntime.wrap(function _callee7$(_context7) {
            while (1) {
              switch (_context7.prev = _context7.next) {
                case 0:
                  buttonPosition = direction == 'left' ? 'right' : 'left';
                  _context7.next = 3;
                  return this._getMorphButtonElement(buttonPosition);

                case 3:
                  button = _context7.sent;
                  swipeoutPromptText = button.getAttribute('swipeoutprompttext');
                  confirmed = false;

                  if (!swipeoutPromptText) {
                    _context7.next = 17;
                    break;
                  }

                  _context7.next = 9;
                  return this._confirmDialog(swipeoutPromptText);

                case 9:
                  confirmed = _context7.sent;

                  if (confirmed) {
                    _context7.next = 12;
                    break;
                  }

                  return _context7.abrupt("return");

                case 12:
                  if (!button.hasAttribute('swipeout-delete')) {
                    _context7.next = 15;
                    break;
                  }

                  _context7.next = 15;
                  return this._animateDeleteAction(button);

                case 15:
                  _context7.next = 23;
                  break;

                case 17:
                  if (!(button.hasAttribute('swipeout-delete') || button.hasAttribute('item-delete'))) {
                    _context7.next = 22;
                    break;
                  }

                  _context7.next = 20;
                  return this._animateDeleteAction(button);

                case 20:
                  _context7.next = 23;
                  break;

                case 22:
                  button.click();

                case 23:
                case "end":
                  return _context7.stop();
              }
            }
          }, _callee7, this);
        }));

        function _handleOverswipe(_x6) {
          return _handleOverswipe2.apply(this, arguments);
        }

        return _handleOverswipe;
      }()
    }, {
      key: "_confirmDialog",
      value: function _confirmDialog(text) {
        return new Promise(function (resolve, reject) {
          setTimeout(function () {
            var confirmed = confirm(text);
            resolve(confirmed);
          }, 0);
        });
      }
    }, {
      key: "_calculateSwipeSlowDown",
      value: function _calculateSwipeSlowDown(distance, offset, factor) {
        factor = factor || 2;
        var scaler = Math.abs(distance) / offset / factor;
        var multiplier = 1 - Math.min(scaler, 1);
        return distance * multiplier;
      }
      /**
      * Closes the swipeout element
      */

    }, {
      key: "_closeSwipe",
      value: function _closeSwipe() {
        var shadow = this.shadowRoot;
        var rootContainer = shadow.querySelector('#rootContainer');
        rootContainer.style.transform = "translateX(0px)";
      }
      /**
      * Gets the background-color of morph-button
      * @param {String} buttonPosition - The position of the button being revealed
      */

    }, {
      key: "_getElementBackgroundColor",
      value: function _getElementBackgroundColor(element) {
        if (typeof ShadyCSS != 'undefined') {
          return ShadyCSS.getComputedStyleValue(element, 'background-color');
        } else {
          return getComputedStyle(element).getPropertyValue('background-color');
        }
      }
      /**
      * Gets the element nodes after a set delay
      * @param {Number} delay - The delay in milliseconds
      */

    }, {
      key: "_getNodeElements",
      value: function () {
        var _getNodeElements2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee8(delay) {
          var nodes;
          return regeneratorRuntime.wrap(function _callee8$(_context8) {
            while (1) {
              switch (_context8.prev = _context8.next) {
                case 0:
                  _context8.next = 2;
                  return this._sleep(delay);

                case 2:
                  nodes = this.info.addedNodes;
                  return _context8.abrupt("return", nodes);

                case 4:
                case "end":
                  return _context8.stop();
              }
            }
          }, _callee8, this);
        }));

        function _getNodeElements(_x7) {
          return _getNodeElements2.apply(this, arguments);
        }

        return _getNodeElements;
      }()
      /**
      * Gets the morph-button element being revealed
      * @param {String} buttonPosition - The position of the button being revealed
      */

    }, {
      key: "_getMorphButtonElement",
      value: function () {
        var _getMorphButtonElement2 = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee9(buttonPosition) {
          var items, lastButton, nodes, i, swipeoutChild;
          return regeneratorRuntime.wrap(function _callee9$(_context9) {
            while (1) {
              switch (_context9.prev = _context9.next) {
                case 0:
                  _context9.next = 2;
                  return this._getNodeElements(400);

                case 2:
                  nodes = _context9.sent;

                  for (i = 0; i < nodes.length; i++) {
                    if (nodes[i].nodeName != "#text" && nodes[i].nodeName != "#comment") {
                      swipeoutChild = nodes[i]; // get the button container with the correct id

                      if (swipeoutChild.getAttribute('slot') == buttonPosition + '-buttons') {
                        // check which item matches morph-button id leftLastButton or rightLastButton
                        if (buttonPosition == 'left') {
                          lastButton = swipeoutChild.children[0];
                        } else {
                          lastButton = swipeoutChild.children[swipeoutChild.children.length - 1];
                        }
                      }
                    }
                  }

                  return _context9.abrupt("return", lastButton);

                case 5:
                case "end":
                  return _context9.stop();
              }
            }
          }, _callee9, this);
        }));

        function _getMorphButtonElement(_x8) {
          return _getMorphButtonElement2.apply(this, arguments);
        }

        return _getMorphButtonElement;
      }()
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject12_49588b906ebf11ea9e7797d125c65125())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-swipeout';
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          /**
          *  Property used to decide if action on the left or right is executed when swipe far enough
          */
          overswiper: {
            type: Boolean,
            value: false
          },

          /** The amount of pixel swipe to trigger overswipe */
          overswipeTreshold: {
            type: Number
          },
          _trackInitialTransform: {
            type: Number
          }
        };
      }
    }]);
    return MorphSwipeout;
  }(_myApp.LitElement);

  _exports.MorphSwipeout = MorphSwipeout;
  window.customElements.define(MorphSwipeout.is, MorphSwipeout);
  var morphSwipeout = {
    MorphSwipeout: MorphSwipeout
  };
  _exports.$morphSwipeout = morphSwipeout;

  var SavedReadingsPage =
  /*#__PURE__*/
  function (_connect) {
    babelHelpers.inherits(SavedReadingsPage, _connect);

    function SavedReadingsPage() {
      var _this8;

      babelHelpers.classCallCheck(this, SavedReadingsPage);
      _this8 = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(SavedReadingsPage).call(this));
      _this8._historyList = [];
      return _this8;
    }

    babelHelpers.createClass(SavedReadingsPage, [{
      key: "updated",
      value: function updated(changedProperties) {
        if (changedProperties.has('_language')) {
          (0, _myApp.use)(this._language);
        }
      }
    }, {
      key: "connectedCallback",
      value: function () {
        var _connectedCallback = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee10() {
          return regeneratorRuntime.wrap(function _callee10$(_context10) {
            while (1) {
              switch (_context10.prev = _context10.next) {
                case 0:
                  (0, _myApp.registerTranslateConfig)({
                    loader: function loader(lang) {
                      return Promise.resolve(_myApp.$language[lang]);
                    }
                  });
                  babelHelpers.get(babelHelpers.getPrototypeOf(SavedReadingsPage.prototype), "connectedCallback", this).call(this);

                case 2:
                case "end":
                  return _context10.stop();
              }
            }
          }, _callee10, this);
        }));

        function connectedCallback() {
          return _connectedCallback.apply(this, arguments);
        }

        return connectedCallback;
      }()
    }, {
      key: "render",
      value: function render() {
        var _this9 = this;

        return (0, _myApp.html)(_templateObject13_49588b906ebf11ea9e7797d125c65125(), this._historyList.length == 0 ? (0, _myApp.html)(_templateObject14_49588b906ebf11ea9e7797d125c65125(), (0, _myApp.translate)('history.placeholder.title'), (0, _myApp.translate)('history.placeholder.message')) : (0, _myApp.html)(_templateObject15_49588b906ebf11ea9e7797d125c65125(), this._historyList.map(function (dategroup) {
          return (0, _myApp.html)(_templateObject16_49588b906ebf11ea9e7797d125c65125(), _this9._formatDate(dategroup.date), dategroup.items.map(function (item) {
            return (0, _myApp.html)(_templateObject17_49588b906ebf11ea9e7797d125c65125(), item.label === '' ? (0, _myApp.translate)('history.list.unlabeled') : item.label, (0, _myApp.translate)('history.list.temperature'), item.temperature.toFixed(1) + ' ' + item.unit.symbol, (0, _myApp.translate)('history.list.humidity'), item.humidity.toFixed(1), moment(item.id).format('LT'), function () {
              return _myApp.store.dispatch((0, _myApp.removeReading)(item.id));
            }, (0, _myApp.translate)('history.list.delete'));
          }));
        })));
      }
    }, {
      key: "_groupByDate",
      value: function _groupByDate(historyList) {
        var dateGroups = historyList.reduce(function (dateGroups, item) {
          var date = item.id;
          var jsDate = new Date(date);
          var day = moment(jsDate).local().startOf('day');

          if (!dateGroups[day]) {
            dateGroups[day] = [];
          }

          dateGroups[day].push(item);
          return dateGroups;
        }, {}); // To add it in the array format

        var groupArrays = Object.keys(dateGroups).map(function (date) {
          return {
            date: date,
            items: dateGroups[date]
          };
        });
        return groupArrays;
      }
    }, {
      key: "_formatDate",
      value: function _formatDate(date) {
        var jsDate = new Date(date);
        var otherDates = moment(jsDate).fromNow();

        var callback = function callback() {
          return "[" + otherDates + "]";
        };

        var result = moment(jsDate).calendar(null, {
          sameDay: '[Today]',
          nextDay: 'DD/MM/YYYY',
          nextWeek: 'DD/MM/YYYY',
          lastDay: '[Yesterday]',
          lastWeek: 'DD/MM/YYYY',
          sameElse: 'DD/MM/YYYY'
        });

        if (result === 'Today') {
          return (0, _myApp.translate)('history.list.today');
        } else if (result === 'Yesterday') {
          return (0, _myApp.translate)('history.list.yesterday');
        } else {
          return result;
        }
      }
    }, {
      key: "stateChanged",
      value: function stateChanged(state) {
        this._page = state.app.page;
        this._language = state.app.language;
        this._historyList = this._groupByDate(state.app.historyList);
      }
    }], [{
      key: "properties",
      get: function get() {
        return {
          _page: {
            type: String
          },
          _language: {
            type: String
          },
          _historyList: {
            type: Array
          }
        };
      }
    }, {
      key: "styles",
      get: function get() {
        return [_myApp.ResetStyles, _myApp.SharedStyles, (0, _myApp.css)(_templateObject18_49588b906ebf11ea9e7797d125c65125())];
      }
    }]);
    return SavedReadingsPage;
  }((0, _myApp.connect)(_myApp.store)(_myApp.PageViewElement));

  window.customElements.define('saved-readings-page', SavedReadingsPage);
});