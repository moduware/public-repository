define(["./my-app.js"], function (_myApp) {
  "use strict";

  function _templateObject2_49bc56706ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      :host {\n        display: flex;\n        flex-direction: column;\n        justify-content: space-between;\n        box-sizing: border-box;\n        background-color: #FFB931;\n      }\n\n      :host([platform=\"ios\"]) {\n        padding: 10px;\n      }\n\n      :host([platform=\"android\"]) .button-container {\n        padding: 10px;\n      }\n\n      .snapshot-item {\n          background-color: white;\n          font-size: 16px;\n          padding: 0 15px 10px 15px;\n          overflow: hidden;\n      }\n\n      :host([platform=\"ios\"]) .snapshot-item {\n          border-radius: 12px;\n      }\n\n      :host([platform=\"android\"]) .snapshot-item {\n          box-shadow: 0 0 1px rgba(0,0,0,.12), 0 1px 1px rgba(0,0,0,.24);\n      }\n\n      .snapshot-item__title {\n          width: 100%;\n          line-height: 50px;\n\n          color: black;\n          font-size: 16px;\n          font-weight: 400;\n          text-align: left;\n          border: none;\n          outline: none;\n          outline-offset: 0;\n          -webkit-appearance:none;\n      }\n\n      .snapshot-item__title::-webkit-input-placeholder {\n          color: #929292;\n      }\n\n      :host([platform=\"ios\"]) .snapshot-item__title {\n          font-size: 17px;\n      }\n\n      :host([platform=\"android\"]) .snapshot-item__title {\n          padding-top: 15px;\n          box-sizing: border-box;\n          margin-bottom: 15px;\n          line-height: calc(35px);\n          border-bottom: 1px solid rgba(0,0,0,.12);\n      }\n\n      .snapshot-item__values {\n          width: 100%;\n          margin-bottom: 20px;\n      }\n\n      .snapshot-item__line {\n          line-height: 30px;\n          font-size: 17px;\n      }\n\n      :host([platform=\"android\"]) .snapshot-item__line {\n          line-height: 40px;\n      }\n\n      .snapshot-item__field-value {\n          text-align: right;\n      }\n\n      .snapshot-item__field-value--temperature::after {\n          content: '\xB0';\n      }\n\n      .snapshot-item__field-value--humidity::after {\n          content: '%';\n      }\n\n      .snapshot-item__daytime,\n      .snapshot-item__location {\n          font-size: 14px;\n          color: #929292;\n      }\n\n      .snapshot-item__daytime {\n          margin-bottom: 5px;\n      }\n\n      "]);

    _templateObject2_49bc56706ebf11ea9e7797d125c65125 = function _templateObject2_49bc56706ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject_49bc56706ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <div class=\"snapshot-item\" id=\"snapshot-item\">\n        <input type=\"text\" id=\"snapshot-title\" class=\"snapshot-item__title\" placeholder=\"", "\" .value=\"", "\"\n          onfocus=\"this.placeholder=''\" onblur=\"this.placeholder='", "'\">\n        <div class=\"snapshot-item__daytime\" id=\"snapshotDayAndTime\">", "</div>\n        <table class=\"snapshot-item__values\">\n          <tr class=\"snapshot-item__line\">\n            <td class=\"snapshot-item__field-title\" id=\"snapshot-temperature-title\">\n              <span>", "</span>\n            </td>\n            <td class=\"snapshot-item__field-value snapshot-item__field-value--temperature\">", "</td>\n          </tr>\n          <tr class=\"snapshot-item__line\">\n            <td class=\"snapshot-item__field-title\">", "</td>\n            <td class=\"snapshot-item__field-value snapshot-item__field-value--humidity\">", "</td>\n          </tr>\n        </table>\n      </div>\n      <div class=\"button-container\" id=\"snapshot-buttons-container\">\n        <button class=\"action-button\" id=\"snapshot-button-cancel\" @click=\"", "\">", "</button>\n        <a class=\"action-button action-button--primary\" id=\"history-snapshot\" @click=\"", "\">", "</a>\n      </div>\n    "]);

    _templateObject_49bc56706ebf11ea9e7797d125c65125 = function _templateObject_49bc56706ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  var AddReadingPage =
  /*#__PURE__*/
  function (_connect) {
    babelHelpers.inherits(AddReadingPage, _connect);

    function AddReadingPage() {
      var _this;

      babelHelpers.classCallCheck(this, AddReadingPage);
      _this = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(AddReadingPage).call(this));
      _this._label = '';
      return _this;
    }

    babelHelpers.createClass(AddReadingPage, [{
      key: "updated",
      value: function updated(changedProperties) {
        if (changedProperties.has('_language')) {
          (0, _myApp.use)(this._language);
        }
      }
    }, {
      key: "firstUpdated",
      value: function firstUpdated() {}
    }, {
      key: "connectedCallback",
      value: function () {
        var _connectedCallback = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee() {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  (0, _myApp.registerTranslateConfig)({
                    loader: function loader(lang) {
                      return Promise.resolve(_myApp.$language[lang]);
                    }
                  });
                  babelHelpers.get(babelHelpers.getPrototypeOf(AddReadingPage.prototype), "connectedCallback", this).call(this);

                case 2:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function connectedCallback() {
          return _connectedCallback.apply(this, arguments);
        }

        return connectedCallback;
      }()
    }, {
      key: "render",
      value: function render() {
        var _this2 = this;

        return (0, _myApp.html)(_templateObject_49bc56706ebf11ea9e7797d125c65125(), (0, _myApp.translate)('snapshot.label'), this._label, (0, _myApp.translate)('snapshot.label'), moment(this._toBeSavedReading.id).format('LT'), (0, _myApp.translate)('snapshot.temperature'), this._toBeSavedReading.temperature.toFixed(1) + ' ' + this._toBeSavedReading.unit.symbol, (0, _myApp.translate)('snapshot.humidity'), this._toBeSavedReading.humidity.toFixed(1), function () {
          return _this2._cancelClickHandler();
        }, (0, _myApp.translate)('snapshot.button.cancel'), function () {
          return _this2._saveReading();
        }, (0, _myApp.translate)('snapshot.button.save'));
      }
    }, {
      key: "stateChanged",
      value: function stateChanged(state) {
        this.platform = state.app.platform;
        this._page = state.app.page;
        this._language = state.app.language;
        this._toBeSavedReading = state.app.toBeSavedReading;
      }
    }, {
      key: "_cancelClickHandler",
      value: function _cancelClickHandler() {
        var snapshotLabel = this.shadowRoot.getElementById('snapshot-title');
        snapshotLabel.value = '';

        _myApp.store.dispatch((0, _myApp.navigate)('/temperature-page'));
      }
    }, {
      key: "_saveReading",
      value: function _saveReading() {
        var snapshotLabel = this.shadowRoot.getElementById('snapshot-title');
        this._toBeSavedReading.label = snapshotLabel.value;
        snapshotLabel.value = '';

        _myApp.store.dispatch((0, _myApp.saveReading)(this._toBeSavedReading));
      }
    }], [{
      key: "properties",
      get: function get() {
        return {
          platform: {
            type: String,
            reflect: true
          },
          _page: {
            type: String
          },
          _language: {
            type: String
          },
          _toBeSavedReading: {
            type: Object,
            reflect: true
          },
          _label: {
            type: String
          }
        };
      }
    }, {
      key: "styles",
      get: function get() {
        return [_myApp.ResetStyles, _myApp.SharedStyles, (0, _myApp.css)(_templateObject2_49bc56706ebf11ea9e7797d125c65125())];
      }
    }]);
    return AddReadingPage;
  }((0, _myApp.connect)(_myApp.store)(_myApp.PageViewElement));

  window.customElements.define('add-reading-page', AddReadingPage);
});