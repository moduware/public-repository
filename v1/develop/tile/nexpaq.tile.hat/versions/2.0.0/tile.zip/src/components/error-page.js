define(["./my-app.js"], function (_myApp) {
  "use strict";

  function _templateObject_49c075206ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <section>\n        <h2>Oops! You hit a 404</h2>\n        <p>\n          The page you're looking for doesn't seem to exist. Head back\n          <a href=\"/\">home</a> and try again?\n        </p>\n      </section>\n    "]);

    _templateObject_49c075206ebf11ea9e7797d125c65125 = function _templateObject_49c075206ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  var ErrorPage =
  /*#__PURE__*/
  function (_PageViewElement) {
    babelHelpers.inherits(ErrorPage, _PageViewElement);

    function ErrorPage() {
      babelHelpers.classCallCheck(this, ErrorPage);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(ErrorPage).apply(this, arguments));
    }

    babelHelpers.createClass(ErrorPage, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject_49c075206ebf11ea9e7797d125c65125());
      }
    }], [{
      key: "styles",
      get: function get() {
        return [_myApp.SharedStyles];
      }
    }]);
    return ErrorPage;
  }(_myApp.PageViewElement);

  window.customElements.define('error-page', ErrorPage);
});