define(["exports", "./my-app.js"], function (_exports, _myApp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.Celsius2Farenheit = Celsius2Farenheit;
  _exports.Farenheit2Celsius = Farenheit2Celsius;
  _exports.runCssAnimationByClass = runCssAnimationByClass;
  _exports.$Utils = void 0;

  function _templateObject2_491541006ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        h2 {\n\t\t\t\t\tcolor: red;\n        }\n      :host {\n        box-sizing: border-box;\n        padding: 10px;\n        display: flex;\n        flex-direction: column;\n        justify-content: space-between;\n        background-color: #FFB931;\n      }\n\n      .result-screen__content {\n        flex-grow: 1;\n        display: flex;\n        justify-content: center;\n      }\n\n      .result-screen__left-side {\n        padding-top: 50px;\n        padding-left: 20px;\n      }\n\n      .result-screen__right-side {\n        box-sizing: border-box;\n        display: flex;\n        flex-direction: column;\n        justify-content: center;\n        padding-left: 40px;\n        min-width: 210px;\n      }\n\n      .temperature-numbers {\n        margin-bottom: 20px;\n      }\n\n      .temperature-scale {\n          position: relative;\n          min-width: 72px;\n          height: 100%;\n          overflow: hidden;\n      }\n\n      .temperature-scale::after {\n          content: '';\n          position: absolute;\n          top: 0; left: 0; bottom: 0; right: 0;\n          background-image: linear-gradient(to bottom, rgba(255,185,49,100) 0%, rgba(255,185,49,0) 25%, rgba(255,185,49,0) 50%, rgba(255,185,49,0) 75%, rgba(255,185,49,100) 92%);\n          z-index: 2;\n      }\n\n      .temperature-scale::before {\n          content: '';\n          position: absolute;\n          top: 50%;\n          left: 38px;\n          background-image: url('images/line.svg');\n          transform: translateY(-50%);\n          width: 34px;\n          height: 2px;\n          z-index: 2;\n      }\n\n      .temperature-scale__scale {\n          position: absolute;\n          top: 50%; left: 0;\n          background-position: 0 50%;\n          background-repeat: no-repeat;\n          z-index: 1;\n          transition: transform 0.5s;\n      }\n\n\n      .temperature-scale__scale--celsius {\n          background-image: url('images/celsius_scale_2x.png');\n          background-size: 72px 721px;\n          top: calc(-721px / 2 + 50% - 1px);\n          width: 72px;\n          height: 721px;\n      }\n\n      .temperature-scale__scale--fahrenheit {\n          background-image: url('images/fahrenheit_scale_2x.png');\n          background-size: 71px 746px;\n          top: calc(-746px / 2 + 50% - 301px);\n          width: 71px;\n          height: 746px;\n      }\n\n      .temperature-numbers {\n          color: white;\n      }\n\n      .temperature-numbers__temparature-value {\n          font-size: 60px;\n          font-weight: 400;\n          line-height: 85px;\n      }\n\n      .temperature-numbers__temparature-value::after {\n        content: '\xB0';\n      }\n\n      .temperature-numbers__temparature-value:empty::after {\n        content: '...';\n        font-size: 0.3em;\n        font-style: italic;\n      }\n\n      .temperature-numbers__temparature-unit {\n          font-size: 60px;\n          font-weight: 400;\n          line-height: 85px;\n      }\n\n      .temperature-numbers__humidity {\n          font-size: 17px;\n      }\n\n      .temperature-numbers__humidity-value {\n          font-weight: bold;\n      }\n\n      .temperature-numbers__humidity-value::after {\n          content: '%';\n      }\n\n      .temperature-numbers__humidity-value:empty::after {\n          content: '...';\n          font-style: italic;\n      }\n      "]);

    _templateObject2_491541006ebf11ea9e7797d125c65125 = function _templateObject2_491541006ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function _templateObject_491541006ebf11ea9e7797d125c65125() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <div class=\"result-screen__content\">\n        <div class=\"result-screen__left-side\">\n          <div class=\"temperature-scale\">\n            <div class=\"temperature-scale__scale ", "\" \n\t\t\t\t\t\t\t\t\tstyle=\"transform: translateY(", "px)\"></div>\n          </div>\n        </div>\n        <div class=\"result-screen__right-side\">\n          <div class=\"temperature-numbers\">\n            <span class=\"temperature-numbers__temparature-value\" id=\"temperature-value\">", "</span>\n            <span class=\"temperature-numbers__temparature-unit\" id=\"temperature-unit\">", "</span>\n            <div class=\"temperature-numbers__humidity\">\n              <span class=\"temperature-numbers__humidity-title\">", "</span>\n              <span class=\"temperature-numbers__humidity-value\" id=\"humidity-value\">", "</span>\n            </div>\n          </div>\n        </div>\n      </div>\n      <a class=\"action-button action-button--primary\" @click=\"", "\">", "</a>\n    "]);

    _templateObject_491541006ebf11ea9e7797d125c65125 = function _templateObject_491541006ebf11ea9e7797d125c65125() {
      return data;
    };

    return data;
  }

  function Celsius2Farenheit(value) {
    return value * 1.8 + 32;
  }

  function Farenheit2Celsius(value) {
    return (value - 32) / 1.8;
  }

  function runCssAnimationByClass(target, cssClass) {
    return new Promise(function (resolve, reject) {
      var _handler = null;

      _handler = function handler() {
        target.removeEventListener('animationend', _handler);
        resolve(); //target.classList.remove(cssClass);
      };

      target.addEventListener('animationend', _handler);
      target.classList.add(cssClass);
    });
  }

  var Utils = {
    Celsius2Farenheit: Celsius2Farenheit,
    Farenheit2Celsius: Farenheit2Celsius,
    runCssAnimationByClass: runCssAnimationByClass
  };
  _exports.$Utils = Utils;

  var TemperaturePage =
  /*#__PURE__*/
  function (_connect) {
    babelHelpers.inherits(TemperaturePage, _connect);

    function TemperaturePage() {
      babelHelpers.classCallCheck(this, TemperaturePage);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(TemperaturePage).apply(this, arguments));
    }

    babelHelpers.createClass(TemperaturePage, [{
      key: "render",
      value: function render() {
        var _this = this;

        return (0, _myApp.html)(_templateObject_491541006ebf11ea9e7797d125c65125(), this._unit.name === _myApp.$TemperatureUnitDefault.Celsius.name ? 'temperature-scale__scale--celsius' : 'temperature-scale__scale--fahrenheit', this._temperature * (this._unit.name === _myApp.$TemperatureUnitDefault.Celsius.name ? 7 : 3), this._temperature.toFixed(1), this._unit.symbol, (0, _myApp.translate)('main.humidity'), this._humidity.toFixed(1), function () {
          return _this._saveClickHandler();
        }, (0, _myApp.translate)('main.button.save'));
      }
    }, {
      key: "_saveClickHandler",
      value: function _saveClickHandler() {
        var time = moment();
        var reading = {
          id: time.valueOf(),
          temperature: this._temperature,
          humidity: this._humidity,
          unit: this._unit,
          measureType: this._measureType,
          label: ''
        };

        _myApp.store.dispatch((0, _myApp.addReading)(reading));
      }
    }, {
      key: "updated",
      value: function updated(changedProperties) {
        if (changedProperties.has('_language')) {
          (0, _myApp.use)(this._language);
        }
      }
    }, {
      key: "connectedCallback",
      value: function () {
        var _connectedCallback = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee() {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  (0, _myApp.registerTranslateConfig)({
                    loader: function loader(lang) {
                      return Promise.resolve(_myApp.$language[lang]);
                    }
                  });
                  babelHelpers.get(babelHelpers.getPrototypeOf(TemperaturePage.prototype), "connectedCallback", this).call(this);

                case 2:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function connectedCallback() {
          return _connectedCallback.apply(this, arguments);
        }

        return connectedCallback;
      }()
    }, {
      key: "stateChanged",
      value: function stateChanged(state) {
        this._page = state.app.page;
        this._language = state.app.language;
        this._unit = state.app.unit;
        this._humidity = state.app.humidity;
        this._measureType = state.app.measureType;

        if (state.app.measureType === _myApp.$MeasureTypeDefault.Ambient) {
          if (this._unit.name === _myApp.$TemperatureUnitDefault.Fahrenheit.name) {
            this._temperature = Celsius2Farenheit(state.app.ambientTemperature);
          } else {
            this._temperature = state.app.ambientTemperature;
          }
        } else {
          if (this._unit.name === _myApp.$TemperatureUnitDefault.Fahrenheit.name) {
            this._temperature = Celsius2Farenheit(state.app.objectTemperature);
          } else {
            this._temperature = state.app.objectTemperature;
          }
        }
      }
    }], [{
      key: "styles",
      get: function get() {
        return [_myApp.SharedStyles, (0, _myApp.css)(_templateObject2_491541006ebf11ea9e7797d125c65125())];
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          _page: {
            type: String
          },
          _language: {
            type: String
          },
          _temperature: {
            type: Number
          },
          _unit: {
            type: Object
          },
          _humidity: {
            type: String
          },
          _measureType: {
            type: String
          }
        };
      }
    }]);
    return TemperaturePage;
  }((0, _myApp.connect)(_myApp.store)(_myApp.PageViewElement));

  window.customElements.define('temperature-page', TemperaturePage);
});