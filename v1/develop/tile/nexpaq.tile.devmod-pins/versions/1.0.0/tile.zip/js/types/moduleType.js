var moduleType = {
  MSP: 0,
  MAX: 1
};