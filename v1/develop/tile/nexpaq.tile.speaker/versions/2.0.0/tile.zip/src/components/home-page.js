define(["exports", "./my-app.js"], function (_exports, _myApp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.__asyncDelegator = __asyncDelegator;
  _exports.__asyncGenerator = __asyncGenerator;
  _exports.__asyncValues = __asyncValues;
  _exports.__await = __await;
  _exports.__awaiter = __awaiter;
  _exports.__decorate = __decorate;
  _exports.__exportStar = __exportStar;
  _exports.__extends = __extends;
  _exports.__generator = __generator;
  _exports.__importDefault = __importDefault;
  _exports.__importStar = __importStar;
  _exports.__makeTemplateObject = __makeTemplateObject;
  _exports.__metadata = __metadata;
  _exports.__param = __param;
  _exports.__read = __read;
  _exports.__rest = __rest;
  _exports.__spread = __spread;
  _exports.__spreadArrays = __spreadArrays;
  _exports.__values = __values;
  _exports.addHasRemoveClass$2 = _exports.addHasRemoveClass$1 = _exports.addHasRemoveClass = addHasRemoveClass;
  _exports.applyPassive = applyPassive;
  _exports.closest = closest;
  _exports.findAssignedElement = findAssignedElement;
  _exports.getNormalizedEventCoords = getNormalizedEventCoords;
  _exports.matches = matches;
  _exports.supportsCssVariables = supportsCssVariables;
  _exports.supportsPassiveEventListener = _exports.style$1 = _exports.style = _exports.strings$1 = _exports.strings = _exports.rippleNode = _exports.ripple = _exports.observer$2 = _exports.observer$1 = _exports.observer = _exports.numbers = _exports.cssClasses$1 = _exports.cssClasses = _exports.__assign = _exports.SwitchBase = _exports.Switch = _exports.FormElement = _exports.BaseElement$1 = _exports.BaseElement = _exports.$utils = _exports.$util = _exports.$tslibEs6 = _exports.$rippleDirective = _exports.$ponyfill = _exports.$observer = _exports.$mwcSwitchCss = _exports.$mwcSwitchBase = _exports.$mwcSwitch = _exports.$mwcRippleGlobalCss = _exports.MDCSwitchFoundation = _exports.$foundationDefault$2 = _exports.MDCRippleFoundation = _exports.$foundationDefault$1 = _exports.MDCFoundation = _exports.$foundationDefault = _exports.$foundation$2 = _exports.$foundation$1 = _exports.$foundation = _exports.$formElement = _exports.$events = _exports.$constants$1 = _exports.$constants = _exports.$baseElement = void 0;

  function _templateObject5_7aadc9806ebf11ea8d6a8f399ad958de() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        h2 {\n\t\t\t\t\tcolor: red;\n\t\t\t\t}\n\n\t\t\t\t.default-state-control {\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\tbottom: 0px; left: 0;\n\t\t\t\t\twidth: 100%;\n\t\t\t\t\theight: 72px;\n\t\t\t\t\tdisplay: flex;\n\t\t\t\t\tbackground-color: rgba(0,0,0, 0.28);\n\t\t\t\t\tcolor: rgba(255, 255, 255, 0.87);\n\t\t\t\t\tfont-size: 16px;\n\t\t\t\t\tjustify-content: space-between;\n\t\t\t\t\talign-items: center;\n\t\t\t\t\tpadding: 0 15px;\n\t\t\t\t\tbox-sizing: border-box;\n\t\t\t\t\tfont-weight: 200;\n\t\t\t\t}\n\n\t\t\t\tmwc-switch {\n\t\t\t\t\t--mdc-theme-secondary: #E1514C;\n\t\t\t\t}\n\n\t\t\t\t.explanation {\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\ttop: calc(50% - 115px);\n\t\t\t\t\tleft: 50%;\n\t\t\t\t\t-webkit-transform: translateX(-50%) translateY(-50%);\n\t\t\t\t\t-moz-transform: translateX(-50%) translateY(-50%);\n\t\t\t\t\t-ms-transform: translateX(-50%) translateY(-50%);\n\t\t\t\t\t-o-transform: translateX(-50%) translateY(-50%);\n\t\t\t\t\ttransform: translateX(-50%) translateY(-50%);\n\t\t\t\t\twidth: 100%;\n\t\t\t\t\tmax-width: 250px;\n\t\t\t\t\tdisplay: block;\n\t\t\t\t\tcolor: #FFFFFF;\n\t\t\t\t\tfont-family: Roboto, Helvetica, Arial, sans-serif;\n\t\t\t\t\tfont-size: 14px;\n\t\t\t\t\ttext-align: center;\n\t\t\t\t}\n\n\t\t\t\t.explanation[hidden] {\n\t\t\t\t\tdisplay: none;\n\t\t\t\t}\n\n      "]);

    _templateObject5_7aadc9806ebf11ea8d6a8f399ad958de = function _templateObject5_7aadc9806ebf11ea8d6a8f399ad958de() {
      return data;
    };

    return data;
  }

  function _templateObject4_7aadc9806ebf11ea8d6a8f399ad958de() {
    var data = babelHelpers.taggedTemplateLiteral(["\n\t\t\t<div id=\"wrapper\" class=\"wrapper\">\n\t\t\t\t<div class=\"page page--main\" id=\"pageMain\">\n\t\t\t\t\t<div id=\"speaker-control\" class=\"speaker-control\" >\n\t\t\t\t\t\t<!-- <button class=\"speaker-button\" id=\"speaker-button\"><i class=\"material-icons\">power_settings_new</i></button> -->\n\t\t\t\t\t\t<button class=\"speaker-button\" @click=\"", "\" id=\"speaker-button\" ?active=\"", "\" ?disabled=\"", "\">", "</button>\n\t\t\t\t\t\t<span class=\"explanation explanation--power-on\" ?hidden=\"", "\" id=\"explanationPowerOn\">\n\t\t\t\t\t\t\t", "\n\t\t\t\t\t\t</span>\n\t\t\t\t\t\t<span class=\"explanation explanation--connect\" ?hidden=\"", "\" id=\"explanationConnect\">\n\t\t\t\t\t\t\t", "\n\t\t\t\t\t\t</span>\n\t\t\t\t\t</div>\n\t\t\t\t\t<!-- insert default power on switch markup here -->\n\n\t\t\t\t</div>\n\t\t\t\t<!-- default power on when plug in switch -->\n\t\t\t\t<div id=\"default-state-control\" class=\"default-state-control\">\n\t\t\t\t\t<span>", "</span>\n\t\t\t\t\t<mwc-switch @change=\"", "\" ?checked=\"", "\"></mwc-switch>\n        </div>\n\t\t\t</div>\n    "]);

    _templateObject4_7aadc9806ebf11ea8d6a8f399ad958de = function _templateObject4_7aadc9806ebf11ea8d6a8f399ad958de() {
      return data;
    };

    return data;
  }

  function _templateObject3_7aadc9806ebf11ea8d6a8f399ad958de() {
    var data = babelHelpers.taggedTemplateLiteral([".mdc-switch__thumb-underlay{left:-18px;right:initial;top:-17px;width:48px;height:48px}[dir=rtl] .mdc-switch__thumb-underlay,.mdc-switch__thumb-underlay[dir=rtl]{left:initial;right:-18px}.mdc-switch__native-control{width:68px;height:48px}.mdc-switch{display:inline-block;position:relative;outline:none;user-select:none}.mdc-switch.mdc-switch--checked .mdc-switch__track{background-color:#018786;background-color:var(--mdc-theme-secondary, #018786)}.mdc-switch.mdc-switch--checked .mdc-switch__thumb{background-color:#018786;background-color:var(--mdc-theme-secondary, #018786);border-color:#018786;border-color:var(--mdc-theme-secondary, #018786)}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__track{background-color:#000}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb{background-color:#fff;border-color:#fff}.mdc-switch__native-control{left:0;right:initial;position:absolute;top:0;margin:0;opacity:0;cursor:pointer;pointer-events:auto}[dir=rtl] .mdc-switch__native-control,.mdc-switch__native-control[dir=rtl]{left:initial;right:0}.mdc-switch__track{box-sizing:border-box;width:32px;height:14px;border:1px solid;border-radius:7px;opacity:.38;transition:opacity 90ms cubic-bezier(0.4, 0, 0.2, 1),background-color 90ms cubic-bezier(0.4, 0, 0.2, 1),border-color 90ms cubic-bezier(0.4, 0, 0.2, 1);border-color:transparent}.mdc-switch__thumb-underlay{display:flex;position:absolute;align-items:center;justify-content:center;transform:translateX(0);transition:transform 90ms cubic-bezier(0.4, 0, 0.2, 1),background-color 90ms cubic-bezier(0.4, 0, 0.2, 1),border-color 90ms cubic-bezier(0.4, 0, 0.2, 1)}.mdc-switch__thumb{box-shadow:0px 3px 1px -2px rgba(0, 0, 0, 0.2),0px 2px 2px 0px rgba(0, 0, 0, 0.14),0px 1px 5px 0px rgba(0,0,0,.12);box-sizing:border-box;width:20px;height:20px;border:10px solid;border-radius:50%;pointer-events:none;z-index:1}.mdc-switch--checked .mdc-switch__track{opacity:.54}.mdc-switch--checked .mdc-switch__thumb-underlay{transform:translateX(20px)}[dir=rtl] .mdc-switch--checked .mdc-switch__thumb-underlay,.mdc-switch--checked .mdc-switch__thumb-underlay[dir=rtl]{transform:translateX(-20px)}.mdc-switch--checked .mdc-switch__native-control{transform:translateX(-20px)}[dir=rtl] .mdc-switch--checked .mdc-switch__native-control,.mdc-switch--checked .mdc-switch__native-control[dir=rtl]{transform:translateX(20px)}.mdc-switch--disabled{opacity:.38;pointer-events:none}.mdc-switch--disabled .mdc-switch__thumb{border-width:1px}.mdc-switch--disabled .mdc-switch__native-control{cursor:default;pointer-events:none}@keyframes mdc-ripple-fg-radius-in{from{animation-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transform:translate(var(--mdc-ripple-fg-translate-start, 0)) scale(1)}to{transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}}@keyframes mdc-ripple-fg-opacity-in{from{animation-timing-function:linear;opacity:0}to{opacity:var(--mdc-ripple-fg-opacity, 0)}}@keyframes mdc-ripple-fg-opacity-out{from{animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity, 0)}to{opacity:0}}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay::before,.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay::after{background-color:#9e9e9e}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay:hover::before{opacity:.08}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay.mdc-ripple-upgraded--background-focused::before,.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:.24}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:.24}.mdc-switch:not(.mdc-switch--checked) .mdc-switch__thumb-underlay.mdc-ripple-upgraded{--mdc-ripple-fg-opacity: 0.24}.mdc-switch__thumb-underlay{--mdc-ripple-fg-size: 0;--mdc-ripple-left: 0;--mdc-ripple-top: 0;--mdc-ripple-fg-scale: 1;--mdc-ripple-fg-translate-end: 0;--mdc-ripple-fg-translate-start: 0;-webkit-tap-highlight-color:rgba(0,0,0,0)}.mdc-switch__thumb-underlay::before,.mdc-switch__thumb-underlay::after{position:absolute;border-radius:50%;opacity:0;pointer-events:none;content:\"\"}.mdc-switch__thumb-underlay::before{transition:opacity 15ms linear,background-color 15ms linear;z-index:1}.mdc-switch__thumb-underlay.mdc-ripple-upgraded::before{transform:scale(var(--mdc-ripple-fg-scale, 1))}.mdc-switch__thumb-underlay.mdc-ripple-upgraded::after{top:0;left:0;transform:scale(0);transform-origin:center center}.mdc-switch__thumb-underlay.mdc-ripple-upgraded--unbounded::after{top:var(--mdc-ripple-top, 0);left:var(--mdc-ripple-left, 0)}.mdc-switch__thumb-underlay.mdc-ripple-upgraded--foreground-activation::after{animation:mdc-ripple-fg-radius-in 225ms forwards,mdc-ripple-fg-opacity-in 75ms forwards}.mdc-switch__thumb-underlay.mdc-ripple-upgraded--foreground-deactivation::after{animation:mdc-ripple-fg-opacity-out 150ms;transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}.mdc-switch__thumb-underlay::before,.mdc-switch__thumb-underlay::after{top:calc(50% - 50%);left:calc(50% - 50%);width:100%;height:100%}.mdc-switch__thumb-underlay.mdc-ripple-upgraded::before,.mdc-switch__thumb-underlay.mdc-ripple-upgraded::after{top:var(--mdc-ripple-top, calc(50% - 50%));left:var(--mdc-ripple-left, calc(50% - 50%));width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-switch__thumb-underlay.mdc-ripple-upgraded::after{width:var(--mdc-ripple-fg-size, 100%);height:var(--mdc-ripple-fg-size, 100%)}.mdc-switch__thumb-underlay::before,.mdc-switch__thumb-underlay::after{background-color:#018786;background-color:var(--mdc-theme-secondary, #018786)}.mdc-switch__thumb-underlay:hover::before{opacity:.04}.mdc-switch__thumb-underlay.mdc-ripple-upgraded--background-focused::before,.mdc-switch__thumb-underlay:not(.mdc-ripple-upgraded):focus::before{transition-duration:75ms;opacity:.12}.mdc-switch__thumb-underlay:not(.mdc-ripple-upgraded)::after{transition:opacity 150ms linear}.mdc-switch__thumb-underlay:not(.mdc-ripple-upgraded):active::after{transition-duration:75ms;opacity:.12}.mdc-switch__thumb-underlay.mdc-ripple-upgraded{--mdc-ripple-fg-opacity: 0.12}:host{outline:none}"]);

    _templateObject3_7aadc9806ebf11ea8d6a8f399ad958de = function _templateObject3_7aadc9806ebf11ea8d6a8f399ad958de() {
      return data;
    };

    return data;
  }

  function _templateObject2_7aadc9806ebf11ea8d6a8f399ad958de() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <div class=\"mdc-switch\">\n        <div class=\"mdc-switch__track\"></div>\n        <div class=\"mdc-switch__thumb-underlay\" .ripple=\"", "\">\n          <div class=\"mdc-switch__thumb\">\n            <input\n              type=\"checkbox\"\n              id=\"basic-switch\"\n              class=\"mdc-switch__native-control\"\n              role=\"switch\"\n              @change=\"", "\">\n          </div>\n        </div>\n      </div>\n      <slot></slot>"]);

    _templateObject2_7aadc9806ebf11ea8d6a8f399ad958de = function _templateObject2_7aadc9806ebf11ea8d6a8f399ad958de() {
      return data;
    };

    return data;
  }

  function _templateObject_7aadc9806ebf11ea8d6a8f399ad958de() {
    var data = babelHelpers.taggedTemplateLiteral(["@keyframes mdc-ripple-fg-radius-in{from{animation-timing-function:cubic-bezier(0.4, 0, 0.2, 1);transform:translate(var(--mdc-ripple-fg-translate-start, 0)) scale(1)}to{transform:translate(var(--mdc-ripple-fg-translate-end, 0)) scale(var(--mdc-ripple-fg-scale, 1))}}@keyframes mdc-ripple-fg-opacity-in{from{animation-timing-function:linear;opacity:0}to{opacity:var(--mdc-ripple-fg-opacity, 0)}}@keyframes mdc-ripple-fg-opacity-out{from{animation-timing-function:linear;opacity:var(--mdc-ripple-fg-opacity, 0)}to{opacity:0}}"]);

    _templateObject_7aadc9806ebf11ea8d6a8f399ad958de = function _templateObject_7aadc9806ebf11ea8d6a8f399ad958de() {
      return data;
    };

    return data;
  }

  /**
   * @license
   * Copyright 2016 Google Inc.
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in
   * all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   */
  var MDCFoundation =
  /** @class */
  function () {
    function MDCFoundation(adapter) {
      if (adapter === void 0) {
        adapter = {};
      }

      this.adapter_ = adapter;
    }

    Object.defineProperty(MDCFoundation, "cssClasses", {
      get: function get() {
        // Classes extending MDCFoundation should implement this method to return an object which exports every
        // CSS class the foundation class needs as a property. e.g. {ACTIVE: 'mdc-component--active'}
        return {};
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCFoundation, "strings", {
      get: function get() {
        // Classes extending MDCFoundation should implement this method to return an object which exports all
        // semantic strings as constants. e.g. {ARIA_ROLE: 'tablist'}
        return {};
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCFoundation, "numbers", {
      get: function get() {
        // Classes extending MDCFoundation should implement this method to return an object which exports all
        // of its semantic numbers as constants. e.g. {ANIMATION_DELAY_MS: 350}
        return {};
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCFoundation, "defaultAdapter", {
      get: function get() {
        // Classes extending MDCFoundation may choose to implement this getter in order to provide a convenient
        // way of viewing the necessary methods of an adapter. In the future, this could also be used for adapter
        // validation.
        return {};
      },
      enumerable: true,
      configurable: true
    });

    MDCFoundation.prototype.init = function () {// Subclasses should override this method to perform initialization routines (registering events, etc.)
    };

    MDCFoundation.prototype.destroy = function () {// Subclasses should override this method to perform de-initialization routines (de-registering events, etc.)
    };

    return MDCFoundation;
  }();

  _exports.MDCFoundation = _exports.$foundationDefault = MDCFoundation;
  var foundation = {
    MDCFoundation: MDCFoundation,
    'default': MDCFoundation
  };
  /**
   * @license
   * Copyright 2019 Google Inc.
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in
   * all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   */

  /**
   * Stores result from applyPassive to avoid redundant processing to detect
   * passive event listener support.
   */

  _exports.$foundation = foundation;
  var supportsPassive_;
  /**
   * Determine whether the current browser supports passive event listeners, and
   * if so, use them.
   */

  function applyPassive(globalObj, forceRefresh) {
    if (globalObj === void 0) {
      globalObj = window;
    }

    if (forceRefresh === void 0) {
      forceRefresh = false;
    }

    if (supportsPassive_ === undefined || forceRefresh) {
      var isSupported_1 = false;

      try {
        globalObj.document.addEventListener('test', function () {
          return undefined;
        }, {
          get passive() {
            isSupported_1 = true;
            return isSupported_1;
          }

        });
      } catch (e) {} // tslint:disable-line:no-empty cannot throw error due to tests. tslint also disables console.log.


      supportsPassive_ = isSupported_1;
    }

    return supportsPassive_ ? {
      passive: true
    } : false;
  }

  var events = {
    applyPassive: applyPassive
  };
  /**
   * @license
   * Copyright 2018 Google Inc.
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in
   * all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   */

  /**
   * @fileoverview A "ponyfill" is a polyfill that doesn't modify the global prototype chain.
   * This makes ponyfills safer than traditional polyfills, especially for libraries like MDC.
   */

  _exports.$events = events;

  function closest(element, selector) {
    if (element.closest) {
      return element.closest(selector);
    }

    var el = element;

    while (el) {
      if (matches(el, selector)) {
        return el;
      }

      el = el.parentElement;
    }

    return null;
  }

  function matches(element, selector) {
    var nativeMatches = element.matches || element.webkitMatchesSelector || element.msMatchesSelector;
    return nativeMatches.call(element, selector);
  }

  var ponyfill = {
    closest: closest,
    matches: matches
  };
  _exports.$ponyfill = ponyfill;

  var observer = function observer(_observer) {
    return (// eslint-disable-next-line @typescript-eslint/no-explicit-any
      function (proto, propName) {
        // if we haven't wrapped `updated` in this class, do so
        if (!proto.constructor._observers) {
          proto.constructor._observers = new Map();
          var userUpdated = proto.updated;

          proto.updated = function (changedProperties) {
            var _this2 = this;

            userUpdated.call(this, changedProperties);
            changedProperties.forEach(function (v, k) {
              var observer = _this2.constructor._observers.get(k);

              if (observer !== undefined) {
                observer.call(_this2, _this2[k], v);
              }
            });
          }; // clone any existing observers (superclasses)

        } else if (!proto.constructor.hasOwnProperty('_observers')) {
          var observers = proto.constructor._observers;
          proto.constructor._observers = new Map();
          observers.forEach( // eslint-disable-next-line @typescript-eslint/no-explicit-any
          function (v, k) {
            return proto.constructor._observers.set(k, v);
          });
        } // set this method


        proto.constructor._observers.set(propName, _observer);
      }
    );
  };

  _exports.observer$2 = _exports.observer$1 = _exports.observer = observer;
  var observer$1 = {
    observer: observer
  };
  _exports.$observer = observer$1;

  function findAssignedElement(slot, selector) {
    var _iteratorNormalCompletion = true;
    var _didIteratorError = false;
    var _iteratorError = undefined;

    try {
      for (var _iterator = slot.assignedNodes({
        flatten: true
      })[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
        var node = _step.value;

        if (node.nodeType === Node.ELEMENT_NODE) {
          var el = node;

          if (matches(el, selector)) {
            return el;
          }
        }
      }
    } catch (err) {
      _didIteratorError = true;
      _iteratorError = err;
    } finally {
      try {
        if (!_iteratorNormalCompletion && _iterator.return != null) {
          _iterator.return();
        }
      } finally {
        if (_didIteratorError) {
          throw _iteratorError;
        }
      }
    }

    return null;
  }

  function addHasRemoveClass(element) {
    return {
      addClass: function addClass(className) {
        element.classList.add(className);
      },
      removeClass: function removeClass(className) {
        element.classList.remove(className);
      },
      hasClass: function hasClass(className) {
        return element.classList.contains(className);
      }
    };
  }

  var supportsPassive = false;

  var fn = function fn() {};

  var optionsBlock = {
    get passive() {
      supportsPassive = true;
      return false;
    }

  };
  document.addEventListener('x', fn, optionsBlock);
  document.removeEventListener('x', fn);
  /**
   * Do event listeners suport the `passive` option?
   */

  var supportsPassiveEventListener = supportsPassive;
  _exports.supportsPassiveEventListener = supportsPassiveEventListener;
  var utils = {
    findAssignedElement: findAssignedElement,
    addHasRemoveClass: addHasRemoveClass,
    supportsPassiveEventListener: supportsPassiveEventListener
  };
  _exports.$utils = utils;

  var BaseElement =
  /*#__PURE__*/
  function (_LitElement) {
    babelHelpers.inherits(BaseElement, _LitElement);

    function BaseElement() {
      babelHelpers.classCallCheck(this, BaseElement);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(BaseElement).apply(this, arguments));
    }

    babelHelpers.createClass(BaseElement, [{
      key: "createFoundation",

      /**
       * Create and attach the MDC Foundation to the instance
       */
      value: function createFoundation() {
        if (this.mdcFoundation !== undefined) {
          this.mdcFoundation.destroy();
        }

        this.mdcFoundation = new this.mdcFoundationClass(this.createAdapter());
        this.mdcFoundation.init();
      }
    }, {
      key: "firstUpdated",
      value: function firstUpdated() {
        this.createFoundation();
      }
    }]);
    return BaseElement;
  }(_myApp.LitElement);

  _exports.BaseElement$1 = _exports.BaseElement = BaseElement;
  var baseElement = {
    BaseElement: BaseElement,
    observer: observer,
    addHasRemoveClass: addHasRemoveClass
  };
  _exports.$baseElement = baseElement;

  var FormElement =
  /*#__PURE__*/
  function (_BaseElement) {
    babelHelpers.inherits(FormElement, _BaseElement);

    function FormElement() {
      babelHelpers.classCallCheck(this, FormElement);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(FormElement).apply(this, arguments));
    }

    babelHelpers.createClass(FormElement, [{
      key: "createRenderRoot",
      value: function createRenderRoot() {
        return this.attachShadow({
          mode: 'open',
          delegatesFocus: true
        });
      }
    }, {
      key: "click",
      value: function click() {
        if (this.formElement) {
          this.formElement.focus();
          this.formElement.click();
        }
      }
    }, {
      key: "setAriaLabel",
      value: function setAriaLabel(label) {
        if (this.formElement) {
          this.formElement.setAttribute('aria-label', label);
        }
      }
    }, {
      key: "firstUpdated",
      value: function firstUpdated() {
        var _this3 = this;

        babelHelpers.get(babelHelpers.getPrototypeOf(FormElement.prototype), "firstUpdated", this).call(this);
        this.mdcRoot.addEventListener('change', function (e) {
          _this3.dispatchEvent(new Event('change', e));
        });
      }
    }]);
    return FormElement;
  }(BaseElement);

  _exports.FormElement = FormElement;
  var formElement = {
    FormElement: FormElement,
    observer: observer,
    addHasRemoveClass: addHasRemoveClass,
    BaseElement: BaseElement
  };
  _exports.$formElement = formElement;
  var style = (0, _myApp.css)(_templateObject_7aadc9806ebf11ea8d6a8f399ad958de());
  _exports.style = style;
  var mwcRippleGlobalCss = {
    style: style
  };
  /*! *****************************************************************************
  Copyright (c) Microsoft Corporation. All rights reserved.
  Licensed under the Apache License, Version 2.0 (the "License"); you may not use
  this file except in compliance with the License. You may obtain a copy of the
  License at http://www.apache.org/licenses/LICENSE-2.0
  
  THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
  KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
  WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
  MERCHANTABLITY OR NON-INFRINGEMENT.
  
  See the Apache Version 2.0 License for specific language governing permissions
  and limitations under the License.
  ***************************************************************************** */

  /* global Reflect, Promise */

  _exports.$mwcRippleGlobalCss = mwcRippleGlobalCss;

  var _extendStatics = function extendStatics(d, b) {
    _extendStatics = Object.setPrototypeOf || babelHelpers.instanceof({
      __proto__: []
    }, Array) && function (d, b) {
      d.__proto__ = b;
    } || function (d, b) {
      for (var p in b) {
        if (b.hasOwnProperty(p)) d[p] = b[p];
      }
    };

    return _extendStatics(d, b);
  };

  function __extends(d, b) {
    _extendStatics(d, b);

    function __() {
      this.constructor = d;
    }

    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
  }

  var _assign = function __assign() {
    _exports.__assign = _assign = Object.assign || function __assign(t) {
      for (var s, i = 1, n = arguments.length; i < n; i++) {
        s = arguments[i];

        for (var p in s) {
          if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
        }
      }

      return t;
    };

    return _assign.apply(this, arguments);
  };

  _exports.__assign = _assign;

  function __rest(s, e) {
    var t = {};

    for (var p in s) {
      if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
    }

    if (s != null && typeof Object.getOwnPropertySymbols === "function") for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) {
      if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
    }
    return t;
  }

  function __decorate(decorators, target, key, desc) {
    var c = arguments.length,
        r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc,
        d;
    if ((typeof Reflect === "undefined" ? "undefined" : babelHelpers.typeof(Reflect)) === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);else for (var i = decorators.length - 1; i >= 0; i--) {
      if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    }
    return c > 3 && r && Object.defineProperty(target, key, r), r;
  }

  function __param(paramIndex, decorator) {
    return function (target, key) {
      decorator(target, key, paramIndex);
    };
  }

  function __metadata(metadataKey, metadataValue) {
    if ((typeof Reflect === "undefined" ? "undefined" : babelHelpers.typeof(Reflect)) === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(metadataKey, metadataValue);
  }

  function __awaiter(thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      }

      function rejected(value) {
        try {
          step(generator["throw"](value));
        } catch (e) {
          reject(e);
        }
      }

      function step(result) {
        result.done ? resolve(result.value) : new P(function (resolve) {
          resolve(result.value);
        }).then(fulfilled, rejected);
      }

      step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
  }

  function __generator(thisArg, body) {
    var _ = {
      label: 0,
      sent: function sent() {
        if (t[0] & 1) throw t[1];
        return t[1];
      },
      trys: [],
      ops: []
    },
        f,
        y,
        t,
        g;
    return g = {
      next: verb(0),
      "throw": verb(1),
      "return": verb(2)
    }, typeof Symbol === "function" && (g[Symbol.iterator] = function () {
      return this;
    }), g;

    function verb(n) {
      return function (v) {
        return step([n, v]);
      };
    }

    function step(op) {
      if (f) throw new TypeError("Generator is already executing.");

      while (_) {
        try {
          if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
          if (y = 0, t) op = [op[0] & 2, t.value];

          switch (op[0]) {
            case 0:
            case 1:
              t = op;
              break;

            case 4:
              _.label++;
              return {
                value: op[1],
                done: false
              };

            case 5:
              _.label++;
              y = op[1];
              op = [0];
              continue;

            case 7:
              op = _.ops.pop();

              _.trys.pop();

              continue;

            default:
              if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) {
                _ = 0;
                continue;
              }

              if (op[0] === 3 && (!t || op[1] > t[0] && op[1] < t[3])) {
                _.label = op[1];
                break;
              }

              if (op[0] === 6 && _.label < t[1]) {
                _.label = t[1];
                t = op;
                break;
              }

              if (t && _.label < t[2]) {
                _.label = t[2];

                _.ops.push(op);

                break;
              }

              if (t[2]) _.ops.pop();

              _.trys.pop();

              continue;
          }

          op = body.call(thisArg, _);
        } catch (e) {
          op = [6, e];
          y = 0;
        } finally {
          f = t = 0;
        }
      }

      if (op[0] & 5) throw op[1];
      return {
        value: op[0] ? op[1] : void 0,
        done: true
      };
    }
  }

  function __exportStar(m, exports) {
    for (var p in m) {
      if (!exports.hasOwnProperty(p)) exports[p] = m[p];
    }
  }

  function __values(o) {
    var m = typeof Symbol === "function" && o[Symbol.iterator],
        i = 0;
    if (m) return m.call(o);
    return {
      next: function next() {
        if (o && i >= o.length) o = void 0;
        return {
          value: o && o[i++],
          done: !o
        };
      }
    };
  }

  function __read(o, n) {
    var m = typeof Symbol === "function" && o[Symbol.iterator];
    if (!m) return o;
    var i = m.call(o),
        r,
        ar = [],
        e;

    try {
      while ((n === void 0 || n-- > 0) && !(r = i.next()).done) {
        ar.push(r.value);
      }
    } catch (error) {
      e = {
        error: error
      };
    } finally {
      try {
        if (r && !r.done && (m = i["return"])) m.call(i);
      } finally {
        if (e) throw e.error;
      }
    }

    return ar;
  }

  function __spread() {
    for (var ar = [], i = 0; i < arguments.length; i++) {
      ar = ar.concat(__read(arguments[i]));
    }

    return ar;
  }

  function __spreadArrays() {
    for (var s = 0, i = 0, il = arguments.length; i < il; i++) {
      s += arguments[i].length;
    }

    for (var r = Array(s), k = 0, i = 0; i < il; i++) {
      for (var a = arguments[i], j = 0, jl = a.length; j < jl; j++, k++) {
        r[k] = a[j];
      }
    }

    return r;
  }

  ;

  function __await(v) {
    return babelHelpers.instanceof(this, __await) ? (this.v = v, this) : new __await(v);
  }

  function __asyncGenerator(thisArg, _arguments, generator) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var g = generator.apply(thisArg, _arguments || []),
        i,
        q = [];
    return i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
      return this;
    }, i;

    function verb(n) {
      if (g[n]) i[n] = function (v) {
        return new Promise(function (a, b) {
          q.push([n, v, a, b]) > 1 || resume(n, v);
        });
      };
    }

    function resume(n, v) {
      try {
        step(g[n](v));
      } catch (e) {
        settle(q[0][3], e);
      }
    }

    function step(r) {
      babelHelpers.instanceof(r.value, __await) ? Promise.resolve(r.value.v).then(fulfill, reject) : settle(q[0][2], r);
    }

    function fulfill(value) {
      resume("next", value);
    }

    function reject(value) {
      resume("throw", value);
    }

    function settle(f, v) {
      if (f(v), q.shift(), q.length) resume(q[0][0], q[0][1]);
    }
  }

  function __asyncDelegator(o) {
    var i, p;
    return i = {}, verb("next"), verb("throw", function (e) {
      throw e;
    }), verb("return"), i[Symbol.iterator] = function () {
      return this;
    }, i;

    function verb(n, f) {
      i[n] = o[n] ? function (v) {
        return (p = !p) ? {
          value: __await(o[n](v)),
          done: n === "return"
        } : f ? f(v) : v;
      } : f;
    }
  }

  function __asyncValues(o) {
    if (!Symbol.asyncIterator) throw new TypeError("Symbol.asyncIterator is not defined.");
    var m = o[Symbol.asyncIterator],
        i;
    return m ? m.call(o) : (o = typeof __values === "function" ? __values(o) : o[Symbol.iterator](), i = {}, verb("next"), verb("throw"), verb("return"), i[Symbol.asyncIterator] = function () {
      return this;
    }, i);

    function verb(n) {
      i[n] = o[n] && function (v) {
        return new Promise(function (resolve, reject) {
          v = o[n](v), settle(resolve, reject, v.done, v.value);
        });
      };
    }

    function settle(resolve, reject, d, v) {
      Promise.resolve(v).then(function (v) {
        resolve({
          value: v,
          done: d
        });
      }, reject);
    }
  }

  function __makeTemplateObject(cooked, raw) {
    if (Object.defineProperty) {
      Object.defineProperty(cooked, "raw", {
        value: raw
      });
    } else {
      cooked.raw = raw;
    }

    return cooked;
  }

  ;

  function __importStar(mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) {
      if (Object.hasOwnProperty.call(mod, k)) result[k] = mod[k];
    }
    result.default = mod;
    return result;
  }

  function __importDefault(mod) {
    return mod && mod.__esModule ? mod : {
      default: mod
    };
  }

  var tslib_es6 = {
    __extends: __extends,

    get __assign() {
      return _assign;
    },

    __rest: __rest,
    __decorate: __decorate,
    __param: __param,
    __metadata: __metadata,
    __awaiter: __awaiter,
    __generator: __generator,
    __exportStar: __exportStar,
    __values: __values,
    __read: __read,
    __spread: __spread,
    __spreadArrays: __spreadArrays,
    __await: __await,
    __asyncGenerator: __asyncGenerator,
    __asyncDelegator: __asyncDelegator,
    __asyncValues: __asyncValues,
    __makeTemplateObject: __makeTemplateObject,
    __importStar: __importStar,
    __importDefault: __importDefault
  };
  /**
   * @license
   * Copyright 2016 Google Inc.
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in
   * all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   */

  _exports.$tslibEs6 = tslib_es6;
  var cssClasses = {
    // Ripple is a special case where the "root" component is really a "mixin" of sorts,
    // given that it's an 'upgrade' to an existing component. That being said it is the root
    // CSS class that all other CSS classes derive from.
    BG_FOCUSED: 'mdc-ripple-upgraded--background-focused',
    FG_ACTIVATION: 'mdc-ripple-upgraded--foreground-activation',
    FG_DEACTIVATION: 'mdc-ripple-upgraded--foreground-deactivation',
    ROOT: 'mdc-ripple-upgraded',
    UNBOUNDED: 'mdc-ripple-upgraded--unbounded'
  };
  _exports.cssClasses = cssClasses;
  var strings = {
    VAR_FG_SCALE: '--mdc-ripple-fg-scale',
    VAR_FG_SIZE: '--mdc-ripple-fg-size',
    VAR_FG_TRANSLATE_END: '--mdc-ripple-fg-translate-end',
    VAR_FG_TRANSLATE_START: '--mdc-ripple-fg-translate-start',
    VAR_LEFT: '--mdc-ripple-left',
    VAR_TOP: '--mdc-ripple-top'
  };
  _exports.strings = strings;
  var numbers = {
    DEACTIVATION_TIMEOUT_MS: 225,
    FG_DEACTIVATION_MS: 150,
    INITIAL_ORIGIN_SCALE: 0.6,
    PADDING: 10,
    TAP_DELAY_MS: 300
  };
  _exports.numbers = numbers;
  var constants = {
    cssClasses: cssClasses,
    strings: strings,
    numbers: numbers
  };
  /**
   * Stores result from supportsCssVariables to avoid redundant processing to
   * detect CSS custom variable support.
   */

  _exports.$constants = constants;
  var supportsCssVariables_;

  function supportsCssVariables(windowObj, forceRefresh) {
    if (forceRefresh === void 0) {
      forceRefresh = false;
    }

    var CSS = windowObj.CSS;
    var supportsCssVars = supportsCssVariables_;

    if (typeof supportsCssVariables_ === 'boolean' && !forceRefresh) {
      return supportsCssVariables_;
    }

    var supportsFunctionPresent = CSS && typeof CSS.supports === 'function';

    if (!supportsFunctionPresent) {
      return false;
    }

    var explicitlySupportsCssVars = CSS.supports('--css-vars', 'yes'); // See: https://bugs.webkit.org/show_bug.cgi?id=154669
    // See: README section on Safari

    var weAreFeatureDetectingSafari10plus = CSS.supports('(--css-vars: yes)') && CSS.supports('color', '#00000000');
    supportsCssVars = explicitlySupportsCssVars || weAreFeatureDetectingSafari10plus;

    if (!forceRefresh) {
      supportsCssVariables_ = supportsCssVars;
    }

    return supportsCssVars;
  }

  function getNormalizedEventCoords(evt, pageOffset, clientRect) {
    if (!evt) {
      return {
        x: 0,
        y: 0
      };
    }

    var x = pageOffset.x,
        y = pageOffset.y;
    var documentX = x + clientRect.left;
    var documentY = y + clientRect.top;
    var normalizedX;
    var normalizedY; // Determine touch point relative to the ripple container.

    if (evt.type === 'touchstart') {
      var touchEvent = evt;
      normalizedX = touchEvent.changedTouches[0].pageX - documentX;
      normalizedY = touchEvent.changedTouches[0].pageY - documentY;
    } else {
      var mouseEvent = evt;
      normalizedX = mouseEvent.pageX - documentX;
      normalizedY = mouseEvent.pageY - documentY;
    }

    return {
      x: normalizedX,
      y: normalizedY
    };
  }

  var util = {
    supportsCssVariables: supportsCssVariables,
    getNormalizedEventCoords: getNormalizedEventCoords
  };
  _exports.$util = util;
  var ACTIVATION_EVENT_TYPES = ['touchstart', 'pointerdown', 'mousedown', 'keydown']; // Deactivation events registered on documentElement when a pointer-related down event occurs

  var POINTER_DEACTIVATION_EVENT_TYPES = ['touchend', 'pointerup', 'mouseup', 'contextmenu']; // simultaneous nested activations

  var activatedTargets = [];

  var MDCRippleFoundation =
  /** @class */
  function (_super) {
    __extends(MDCRippleFoundation, _super);

    function MDCRippleFoundation(adapter) {
      var _this = _super.call(this, _assign({}, MDCRippleFoundation.defaultAdapter, adapter)) || this;

      _this.activationAnimationHasEnded_ = false;
      _this.activationTimer_ = 0;
      _this.fgDeactivationRemovalTimer_ = 0;
      _this.fgScale_ = '0';
      _this.frame_ = {
        width: 0,
        height: 0
      };
      _this.initialSize_ = 0;
      _this.layoutFrame_ = 0;
      _this.maxRadius_ = 0;
      _this.unboundedCoords_ = {
        left: 0,
        top: 0
      };
      _this.activationState_ = _this.defaultActivationState_();

      _this.activationTimerCallback_ = function () {
        _this.activationAnimationHasEnded_ = true;

        _this.runDeactivationUXLogicIfReady_();
      };

      _this.activateHandler_ = function (e) {
        return _this.activate_(e);
      };

      _this.deactivateHandler_ = function () {
        return _this.deactivate_();
      };

      _this.focusHandler_ = function () {
        return _this.handleFocus();
      };

      _this.blurHandler_ = function () {
        return _this.handleBlur();
      };

      _this.resizeHandler_ = function () {
        return _this.layout();
      };

      return _this;
    }

    Object.defineProperty(MDCRippleFoundation, "cssClasses", {
      get: function get() {
        return cssClasses;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCRippleFoundation, "strings", {
      get: function get() {
        return strings;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCRippleFoundation, "numbers", {
      get: function get() {
        return numbers;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCRippleFoundation, "defaultAdapter", {
      get: function get() {
        return {
          addClass: function addClass() {
            return undefined;
          },
          browserSupportsCssVars: function browserSupportsCssVars() {
            return true;
          },
          computeBoundingRect: function computeBoundingRect() {
            return {
              top: 0,
              right: 0,
              bottom: 0,
              left: 0,
              width: 0,
              height: 0
            };
          },
          containsEventTarget: function containsEventTarget() {
            return true;
          },
          deregisterDocumentInteractionHandler: function deregisterDocumentInteractionHandler() {
            return undefined;
          },
          deregisterInteractionHandler: function deregisterInteractionHandler() {
            return undefined;
          },
          deregisterResizeHandler: function deregisterResizeHandler() {
            return undefined;
          },
          getWindowPageOffset: function getWindowPageOffset() {
            return {
              x: 0,
              y: 0
            };
          },
          isSurfaceActive: function isSurfaceActive() {
            return true;
          },
          isSurfaceDisabled: function isSurfaceDisabled() {
            return true;
          },
          isUnbounded: function isUnbounded() {
            return true;
          },
          registerDocumentInteractionHandler: function registerDocumentInteractionHandler() {
            return undefined;
          },
          registerInteractionHandler: function registerInteractionHandler() {
            return undefined;
          },
          registerResizeHandler: function registerResizeHandler() {
            return undefined;
          },
          removeClass: function removeClass() {
            return undefined;
          },
          updateCssVariable: function updateCssVariable() {
            return undefined;
          }
        };
      },
      enumerable: true,
      configurable: true
    });

    MDCRippleFoundation.prototype.init = function () {
      var _this = this;

      var supportsPressRipple = this.supportsPressRipple_();
      this.registerRootHandlers_(supportsPressRipple);

      if (supportsPressRipple) {
        var _a = MDCRippleFoundation.cssClasses,
            ROOT_1 = _a.ROOT,
            UNBOUNDED_1 = _a.UNBOUNDED;
        requestAnimationFrame(function () {
          _this.adapter_.addClass(ROOT_1);

          if (_this.adapter_.isUnbounded()) {
            _this.adapter_.addClass(UNBOUNDED_1); // Unbounded ripples need layout logic applied immediately to set coordinates for both shade and ripple


            _this.layoutInternal_();
          }
        });
      }
    };

    MDCRippleFoundation.prototype.destroy = function () {
      var _this = this;

      if (this.supportsPressRipple_()) {
        if (this.activationTimer_) {
          clearTimeout(this.activationTimer_);
          this.activationTimer_ = 0;
          this.adapter_.removeClass(MDCRippleFoundation.cssClasses.FG_ACTIVATION);
        }

        if (this.fgDeactivationRemovalTimer_) {
          clearTimeout(this.fgDeactivationRemovalTimer_);
          this.fgDeactivationRemovalTimer_ = 0;
          this.adapter_.removeClass(MDCRippleFoundation.cssClasses.FG_DEACTIVATION);
        }

        var _a = MDCRippleFoundation.cssClasses,
            ROOT_2 = _a.ROOT,
            UNBOUNDED_2 = _a.UNBOUNDED;
        requestAnimationFrame(function () {
          _this.adapter_.removeClass(ROOT_2);

          _this.adapter_.removeClass(UNBOUNDED_2);

          _this.removeCssVars_();
        });
      }

      this.deregisterRootHandlers_();
      this.deregisterDeactivationHandlers_();
    };
    /**
     * @param evt Optional event containing position information.
     */


    MDCRippleFoundation.prototype.activate = function (evt) {
      this.activate_(evt);
    };

    MDCRippleFoundation.prototype.deactivate = function () {
      this.deactivate_();
    };

    MDCRippleFoundation.prototype.layout = function () {
      var _this = this;

      if (this.layoutFrame_) {
        cancelAnimationFrame(this.layoutFrame_);
      }

      this.layoutFrame_ = requestAnimationFrame(function () {
        _this.layoutInternal_();

        _this.layoutFrame_ = 0;
      });
    };

    MDCRippleFoundation.prototype.setUnbounded = function (unbounded) {
      var UNBOUNDED = MDCRippleFoundation.cssClasses.UNBOUNDED;

      if (unbounded) {
        this.adapter_.addClass(UNBOUNDED);
      } else {
        this.adapter_.removeClass(UNBOUNDED);
      }
    };

    MDCRippleFoundation.prototype.handleFocus = function () {
      var _this = this;

      requestAnimationFrame(function () {
        return _this.adapter_.addClass(MDCRippleFoundation.cssClasses.BG_FOCUSED);
      });
    };

    MDCRippleFoundation.prototype.handleBlur = function () {
      var _this = this;

      requestAnimationFrame(function () {
        return _this.adapter_.removeClass(MDCRippleFoundation.cssClasses.BG_FOCUSED);
      });
    };
    /**
     * We compute this property so that we are not querying information about the client
     * until the point in time where the foundation requests it. This prevents scenarios where
     * client-side feature-detection may happen too early, such as when components are rendered on the server
     * and then initialized at mount time on the client.
     */


    MDCRippleFoundation.prototype.supportsPressRipple_ = function () {
      return this.adapter_.browserSupportsCssVars();
    };

    MDCRippleFoundation.prototype.defaultActivationState_ = function () {
      return {
        activationEvent: undefined,
        hasDeactivationUXRun: false,
        isActivated: false,
        isProgrammatic: false,
        wasActivatedByPointer: false,
        wasElementMadeActive: false
      };
    };
    /**
     * supportsPressRipple Passed from init to save a redundant function call
     */


    MDCRippleFoundation.prototype.registerRootHandlers_ = function (supportsPressRipple) {
      var _this = this;

      if (supportsPressRipple) {
        ACTIVATION_EVENT_TYPES.forEach(function (evtType) {
          _this.adapter_.registerInteractionHandler(evtType, _this.activateHandler_);
        });

        if (this.adapter_.isUnbounded()) {
          this.adapter_.registerResizeHandler(this.resizeHandler_);
        }
      }

      this.adapter_.registerInteractionHandler('focus', this.focusHandler_);
      this.adapter_.registerInteractionHandler('blur', this.blurHandler_);
    };

    MDCRippleFoundation.prototype.registerDeactivationHandlers_ = function (evt) {
      var _this = this;

      if (evt.type === 'keydown') {
        this.adapter_.registerInteractionHandler('keyup', this.deactivateHandler_);
      } else {
        POINTER_DEACTIVATION_EVENT_TYPES.forEach(function (evtType) {
          _this.adapter_.registerDocumentInteractionHandler(evtType, _this.deactivateHandler_);
        });
      }
    };

    MDCRippleFoundation.prototype.deregisterRootHandlers_ = function () {
      var _this = this;

      ACTIVATION_EVENT_TYPES.forEach(function (evtType) {
        _this.adapter_.deregisterInteractionHandler(evtType, _this.activateHandler_);
      });
      this.adapter_.deregisterInteractionHandler('focus', this.focusHandler_);
      this.adapter_.deregisterInteractionHandler('blur', this.blurHandler_);

      if (this.adapter_.isUnbounded()) {
        this.adapter_.deregisterResizeHandler(this.resizeHandler_);
      }
    };

    MDCRippleFoundation.prototype.deregisterDeactivationHandlers_ = function () {
      var _this = this;

      this.adapter_.deregisterInteractionHandler('keyup', this.deactivateHandler_);
      POINTER_DEACTIVATION_EVENT_TYPES.forEach(function (evtType) {
        _this.adapter_.deregisterDocumentInteractionHandler(evtType, _this.deactivateHandler_);
      });
    };

    MDCRippleFoundation.prototype.removeCssVars_ = function () {
      var _this = this;

      var rippleStrings = MDCRippleFoundation.strings;
      var keys = Object.keys(rippleStrings);
      keys.forEach(function (key) {
        if (key.indexOf('VAR_') === 0) {
          _this.adapter_.updateCssVariable(rippleStrings[key], null);
        }
      });
    };

    MDCRippleFoundation.prototype.activate_ = function (evt) {
      var _this = this;

      if (this.adapter_.isSurfaceDisabled()) {
        return;
      }

      var activationState = this.activationState_;

      if (activationState.isActivated) {
        return;
      } // Avoid reacting to follow-on events fired by touch device after an already-processed user interaction


      var previousActivationEvent = this.previousActivationEvent_;
      var isSameInteraction = previousActivationEvent && evt !== undefined && previousActivationEvent.type !== evt.type;

      if (isSameInteraction) {
        return;
      }

      activationState.isActivated = true;
      activationState.isProgrammatic = evt === undefined;
      activationState.activationEvent = evt;
      activationState.wasActivatedByPointer = activationState.isProgrammatic ? false : evt !== undefined && (evt.type === 'mousedown' || evt.type === 'touchstart' || evt.type === 'pointerdown');
      var hasActivatedChild = evt !== undefined && activatedTargets.length > 0 && activatedTargets.some(function (target) {
        return _this.adapter_.containsEventTarget(target);
      });

      if (hasActivatedChild) {
        // Immediately reset activation state, while preserving logic that prevents touch follow-on events
        this.resetActivationState_();
        return;
      }

      if (evt !== undefined) {
        activatedTargets.push(evt.target);
        this.registerDeactivationHandlers_(evt);
      }

      activationState.wasElementMadeActive = this.checkElementMadeActive_(evt);

      if (activationState.wasElementMadeActive) {
        this.animateActivation_();
      }

      requestAnimationFrame(function () {
        // Reset array on next frame after the current event has had a chance to bubble to prevent ancestor ripples
        activatedTargets = [];

        if (!activationState.wasElementMadeActive && evt !== undefined && (evt.key === ' ' || evt.keyCode === 32)) {
          // If space was pressed, try again within an rAF call to detect :active, because different UAs report
          // active states inconsistently when they're called within event handling code:
          // - https://bugs.chromium.org/p/chromium/issues/detail?id=635971
          // - https://bugzilla.mozilla.org/show_bug.cgi?id=1293741
          // We try first outside rAF to support Edge, which does not exhibit this problem, but will crash if a CSS
          // variable is set within a rAF callback for a submit button interaction (#2241).
          activationState.wasElementMadeActive = _this.checkElementMadeActive_(evt);

          if (activationState.wasElementMadeActive) {
            _this.animateActivation_();
          }
        }

        if (!activationState.wasElementMadeActive) {
          // Reset activation state immediately if element was not made active.
          _this.activationState_ = _this.defaultActivationState_();
        }
      });
    };

    MDCRippleFoundation.prototype.checkElementMadeActive_ = function (evt) {
      return evt !== undefined && evt.type === 'keydown' ? this.adapter_.isSurfaceActive() : true;
    };

    MDCRippleFoundation.prototype.animateActivation_ = function () {
      var _this = this;

      var _a = MDCRippleFoundation.strings,
          VAR_FG_TRANSLATE_START = _a.VAR_FG_TRANSLATE_START,
          VAR_FG_TRANSLATE_END = _a.VAR_FG_TRANSLATE_END;
      var _b = MDCRippleFoundation.cssClasses,
          FG_DEACTIVATION = _b.FG_DEACTIVATION,
          FG_ACTIVATION = _b.FG_ACTIVATION;
      var DEACTIVATION_TIMEOUT_MS = MDCRippleFoundation.numbers.DEACTIVATION_TIMEOUT_MS;
      this.layoutInternal_();
      var translateStart = '';
      var translateEnd = '';

      if (!this.adapter_.isUnbounded()) {
        var _c = this.getFgTranslationCoordinates_(),
            startPoint = _c.startPoint,
            endPoint = _c.endPoint;

        translateStart = startPoint.x + "px, " + startPoint.y + "px";
        translateEnd = endPoint.x + "px, " + endPoint.y + "px";
      }

      this.adapter_.updateCssVariable(VAR_FG_TRANSLATE_START, translateStart);
      this.adapter_.updateCssVariable(VAR_FG_TRANSLATE_END, translateEnd); // Cancel any ongoing activation/deactivation animations

      clearTimeout(this.activationTimer_);
      clearTimeout(this.fgDeactivationRemovalTimer_);
      this.rmBoundedActivationClasses_();
      this.adapter_.removeClass(FG_DEACTIVATION); // Force layout in order to re-trigger the animation.

      this.adapter_.computeBoundingRect();
      this.adapter_.addClass(FG_ACTIVATION);
      this.activationTimer_ = setTimeout(function () {
        return _this.activationTimerCallback_();
      }, DEACTIVATION_TIMEOUT_MS);
    };

    MDCRippleFoundation.prototype.getFgTranslationCoordinates_ = function () {
      var _a = this.activationState_,
          activationEvent = _a.activationEvent,
          wasActivatedByPointer = _a.wasActivatedByPointer;
      var startPoint;

      if (wasActivatedByPointer) {
        startPoint = getNormalizedEventCoords(activationEvent, this.adapter_.getWindowPageOffset(), this.adapter_.computeBoundingRect());
      } else {
        startPoint = {
          x: this.frame_.width / 2,
          y: this.frame_.height / 2
        };
      } // Center the element around the start point.


      startPoint = {
        x: startPoint.x - this.initialSize_ / 2,
        y: startPoint.y - this.initialSize_ / 2
      };
      var endPoint = {
        x: this.frame_.width / 2 - this.initialSize_ / 2,
        y: this.frame_.height / 2 - this.initialSize_ / 2
      };
      return {
        startPoint: startPoint,
        endPoint: endPoint
      };
    };

    MDCRippleFoundation.prototype.runDeactivationUXLogicIfReady_ = function () {
      var _this = this; // This method is called both when a pointing device is released, and when the activation animation ends.
      // The deactivation animation should only run after both of those occur.


      var FG_DEACTIVATION = MDCRippleFoundation.cssClasses.FG_DEACTIVATION;
      var _a = this.activationState_,
          hasDeactivationUXRun = _a.hasDeactivationUXRun,
          isActivated = _a.isActivated;
      var activationHasEnded = hasDeactivationUXRun || !isActivated;

      if (activationHasEnded && this.activationAnimationHasEnded_) {
        this.rmBoundedActivationClasses_();
        this.adapter_.addClass(FG_DEACTIVATION);
        this.fgDeactivationRemovalTimer_ = setTimeout(function () {
          _this.adapter_.removeClass(FG_DEACTIVATION);
        }, numbers.FG_DEACTIVATION_MS);
      }
    };

    MDCRippleFoundation.prototype.rmBoundedActivationClasses_ = function () {
      var FG_ACTIVATION = MDCRippleFoundation.cssClasses.FG_ACTIVATION;
      this.adapter_.removeClass(FG_ACTIVATION);
      this.activationAnimationHasEnded_ = false;
      this.adapter_.computeBoundingRect();
    };

    MDCRippleFoundation.prototype.resetActivationState_ = function () {
      var _this = this;

      this.previousActivationEvent_ = this.activationState_.activationEvent;
      this.activationState_ = this.defaultActivationState_(); // Touch devices may fire additional events for the same interaction within a short time.
      // Store the previous event until it's safe to assume that subsequent events are for new interactions.

      setTimeout(function () {
        return _this.previousActivationEvent_ = undefined;
      }, MDCRippleFoundation.numbers.TAP_DELAY_MS);
    };

    MDCRippleFoundation.prototype.deactivate_ = function () {
      var _this = this;

      var activationState = this.activationState_; // This can happen in scenarios such as when you have a keyup event that blurs the element.

      if (!activationState.isActivated) {
        return;
      }

      var state = _assign({}, activationState);

      if (activationState.isProgrammatic) {
        requestAnimationFrame(function () {
          return _this.animateDeactivation_(state);
        });
        this.resetActivationState_();
      } else {
        this.deregisterDeactivationHandlers_();
        requestAnimationFrame(function () {
          _this.activationState_.hasDeactivationUXRun = true;

          _this.animateDeactivation_(state);

          _this.resetActivationState_();
        });
      }
    };

    MDCRippleFoundation.prototype.animateDeactivation_ = function (_a) {
      var wasActivatedByPointer = _a.wasActivatedByPointer,
          wasElementMadeActive = _a.wasElementMadeActive;

      if (wasActivatedByPointer || wasElementMadeActive) {
        this.runDeactivationUXLogicIfReady_();
      }
    };

    MDCRippleFoundation.prototype.layoutInternal_ = function () {
      var _this = this;

      this.frame_ = this.adapter_.computeBoundingRect();
      var maxDim = Math.max(this.frame_.height, this.frame_.width); // Surface diameter is treated differently for unbounded vs. bounded ripples.
      // Unbounded ripple diameter is calculated smaller since the surface is expected to already be padded appropriately
      // to extend the hitbox, and the ripple is expected to meet the edges of the padded hitbox (which is typically
      // square). Bounded ripples, on the other hand, are fully expected to expand beyond the surface's longest diameter
      // (calculated based on the diagonal plus a constant padding), and are clipped at the surface's border via
      // `overflow: hidden`.

      var getBoundedRadius = function getBoundedRadius() {
        var hypotenuse = Math.sqrt(Math.pow(_this.frame_.width, 2) + Math.pow(_this.frame_.height, 2));
        return hypotenuse + MDCRippleFoundation.numbers.PADDING;
      };

      this.maxRadius_ = this.adapter_.isUnbounded() ? maxDim : getBoundedRadius(); // Ripple is sized as a fraction of the largest dimension of the surface, then scales up using a CSS scale transform

      var initialSize = Math.floor(maxDim * MDCRippleFoundation.numbers.INITIAL_ORIGIN_SCALE); // Unbounded ripple size should always be even number to equally center align.

      if (this.adapter_.isUnbounded() && initialSize % 2 !== 0) {
        this.initialSize_ = initialSize - 1;
      } else {
        this.initialSize_ = initialSize;
      }

      this.fgScale_ = "" + this.maxRadius_ / this.initialSize_;
      this.updateLayoutCssVars_();
    };

    MDCRippleFoundation.prototype.updateLayoutCssVars_ = function () {
      var _a = MDCRippleFoundation.strings,
          VAR_FG_SIZE = _a.VAR_FG_SIZE,
          VAR_LEFT = _a.VAR_LEFT,
          VAR_TOP = _a.VAR_TOP,
          VAR_FG_SCALE = _a.VAR_FG_SCALE;
      this.adapter_.updateCssVariable(VAR_FG_SIZE, this.initialSize_ + "px");
      this.adapter_.updateCssVariable(VAR_FG_SCALE, this.fgScale_);

      if (this.adapter_.isUnbounded()) {
        this.unboundedCoords_ = {
          left: Math.round(this.frame_.width / 2 - this.initialSize_ / 2),
          top: Math.round(this.frame_.height / 2 - this.initialSize_ / 2)
        };
        this.adapter_.updateCssVariable(VAR_LEFT, this.unboundedCoords_.left + "px");
        this.adapter_.updateCssVariable(VAR_TOP, this.unboundedCoords_.top + "px");
      }
    };

    return MDCRippleFoundation;
  }(MDCFoundation);

  _exports.MDCRippleFoundation = _exports.$foundationDefault$1 = MDCRippleFoundation;
  var foundation$1 = {
    MDCRippleFoundation: MDCRippleFoundation,
    'default': MDCRippleFoundation
  };
  _exports.$foundation$1 = foundation$1;
  var supportsCssVariablesWin = supportsCssVariables(window); // NOTE: This is a workaround for
  // https://bugs.webkit.org/show_bug.cgi?id=173027. Since keyframes on
  // pseudo-elements (:after) are not supported in Shadow DOM, we put the keyframe
  // style into the <head> element.

  var isSafari = navigator.userAgent.match(/Safari/);
  var didApplyRippleStyle = false;

  var applyRippleStyle = function applyRippleStyle() {
    didApplyRippleStyle = true;
    var styleElement = document.createElement('style');
    var part = new _myApp.NodePart({
      templateFactory: _myApp.templateFactory
    });
    part.appendInto(styleElement);
    part.setValue(style);
    part.commit(); // eslint-disable-next-line @typescript-eslint/no-non-null-assertion

    document.head.appendChild(styleElement);
  };
  /**
   * Applied a ripple to the node specified by {surfaceNode}.
   * @param options {RippleNodeOptions}
   */


  var rippleNode = function rippleNode(options) {
    if (isSafari && !didApplyRippleStyle) {
      applyRippleStyle();
    } // TODO(sorvell): This directive requires bringing css yourself. We probably
    // need to do this because of ShadyCSS, but on Safari, the keyframes styling
    // must be global. Perhaps this directive could fix that.


    var surfaceNode = options.surfaceNode;
    var interactionNode = options.interactionNode || surfaceNode; // only style interaction node if not in the same root

    if (interactionNode.getRootNode() !== surfaceNode.getRootNode()) {
      if (interactionNode.style.position === '') {
        interactionNode.style.position = 'relative';
      }
    }

    var adapter = {
      browserSupportsCssVars: function browserSupportsCssVars() {
        return supportsCssVariablesWin;
      },
      isUnbounded: function isUnbounded() {
        return options.unbounded === undefined ? true : options.unbounded;
      },
      isSurfaceActive: function isSurfaceActive() {
        return matches(interactionNode, ':active');
      },
      isSurfaceDisabled: function isSurfaceDisabled() {
        return Boolean(interactionNode.hasAttribute('disabled'));
      },
      addClass: function addClass(className) {
        return surfaceNode.classList.add(className);
      },
      removeClass: function removeClass(className) {
        return surfaceNode.classList.remove(className);
      },
      containsEventTarget: function containsEventTarget(target) {
        return interactionNode.contains(target);
      },
      registerInteractionHandler: function registerInteractionHandler(type, handler) {
        return interactionNode.addEventListener(type, handler, applyPassive());
      },
      deregisterInteractionHandler: function deregisterInteractionHandler(type, handler) {
        return interactionNode.removeEventListener(type, handler, applyPassive());
      },
      registerDocumentInteractionHandler: function registerDocumentInteractionHandler(evtType, handler) {
        return (// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          document.documentElement.addEventListener(evtType, handler, applyPassive())
        );
      },
      deregisterDocumentInteractionHandler: function deregisterDocumentInteractionHandler(evtType, handler) {
        return (// eslint-disable-next-line @typescript-eslint/no-non-null-assertion
          document.documentElement.removeEventListener(evtType, handler, applyPassive())
        );
      },
      registerResizeHandler: function registerResizeHandler(handler) {
        return window.addEventListener('resize', handler);
      },
      deregisterResizeHandler: function deregisterResizeHandler(handler) {
        return window.removeEventListener('resize', handler);
      },
      updateCssVariable: function updateCssVariable(varName, value) {
        return surfaceNode.style.setProperty(varName, value);
      },
      computeBoundingRect: function computeBoundingRect() {
        return surfaceNode.getBoundingClientRect();
      },
      getWindowPageOffset: function getWindowPageOffset() {
        return {
          x: window.pageXOffset,
          y: window.pageYOffset
        };
      }
    };
    var rippleFoundation = new MDCRippleFoundation(adapter);
    rippleFoundation.init();
    return rippleFoundation;
  };

  _exports.rippleNode = rippleNode;
  var rippleInteractionNodes = new WeakMap();
  /**
   * A directive that applies a Material ripple to a part node. The directive
   * should be applied to a PropertyPart.
   * @param options {RippleOptions}
   */

  var ripple = (0, _myApp.directive)(function () {
    var options = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
    return function (part) {
      var surfaceNode = part.committer.element;
      var interactionNode = options.interactionNode || surfaceNode;
      var rippleFoundation = part.value; // if the interaction node changes, destroy and invalidate the foundation.

      var existingInteractionNode = rippleInteractionNodes.get(rippleFoundation);

      if (existingInteractionNode !== undefined && existingInteractionNode !== interactionNode) {
        rippleFoundation.destroy();
        rippleFoundation = _myApp.noChange;
      } // make the ripple, if needed


      if (rippleFoundation === _myApp.noChange) {
        rippleFoundation = rippleNode(Object.assign({}, options, {
          surfaceNode: surfaceNode
        }));
        rippleInteractionNodes.set(rippleFoundation, interactionNode);
        part.setValue(rippleFoundation); // otherwise update settings as needed.
      } else {
        if (options.unbounded !== undefined) {
          rippleFoundation.setUnbounded(options.unbounded);
        }

        if (options.disabled !== undefined) {
          rippleFoundation.setUnbounded(options.disabled);
        }
      }

      if (options.active === true) {
        rippleFoundation.activate();
      } else if (options.active === false) {
        rippleFoundation.deactivate();
      }
    };
  });
  _exports.ripple = ripple;
  var rippleDirective = {
    rippleNode: rippleNode,
    ripple: ripple
  };
  /**
   * @license
   * Copyright 2018 Google Inc.
   *
   * Permission is hereby granted, free of charge, to any person obtaining a copy
   * of this software and associated documentation files (the "Software"), to deal
   * in the Software without restriction, including without limitation the rights
   * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
   * copies of the Software, and to permit persons to whom the Software is
   * furnished to do so, subject to the following conditions:
   *
   * The above copyright notice and this permission notice shall be included in
   * all copies or substantial portions of the Software.
   *
   * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
   * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
   * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
   * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
   * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
   * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
   * THE SOFTWARE.
   */

  /** CSS classes used by the switch. */

  _exports.$rippleDirective = rippleDirective;
  var cssClasses$1 = {
    /** Class used for a switch that is in the "checked" (on) position. */
    CHECKED: 'mdc-switch--checked',

    /** Class used for a switch that is disabled. */
    DISABLED: 'mdc-switch--disabled'
  };
  /** String constants used by the switch. */

  _exports.cssClasses$1 = cssClasses$1;
  var strings$1 = {
    /** A CSS selector used to locate the native HTML control for the switch.  */
    NATIVE_CONTROL_SELECTOR: '.mdc-switch__native-control',

    /** A CSS selector used to locate the ripple surface element for the switch. */
    RIPPLE_SURFACE_SELECTOR: '.mdc-switch__thumb-underlay'
  };
  _exports.strings$1 = strings$1;
  var constants$1 = {
    cssClasses: cssClasses$1,
    strings: strings$1
  };
  _exports.$constants$1 = constants$1;

  var MDCSwitchFoundation =
  /** @class */
  function (_super) {
    __extends(MDCSwitchFoundation, _super);

    function MDCSwitchFoundation(adapter) {
      return _super.call(this, _assign({}, MDCSwitchFoundation.defaultAdapter, adapter)) || this;
    }

    Object.defineProperty(MDCSwitchFoundation, "strings", {
      /** The string constants used by the switch. */
      get: function get() {
        return strings$1;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCSwitchFoundation, "cssClasses", {
      /** The CSS classes used by the switch. */
      get: function get() {
        return cssClasses$1;
      },
      enumerable: true,
      configurable: true
    });
    Object.defineProperty(MDCSwitchFoundation, "defaultAdapter", {
      /** The default Adapter for the switch. */
      get: function get() {
        return {
          addClass: function addClass() {
            return undefined;
          },
          removeClass: function removeClass() {
            return undefined;
          },
          setNativeControlChecked: function setNativeControlChecked() {
            return undefined;
          },
          setNativeControlDisabled: function setNativeControlDisabled() {
            return undefined;
          }
        };
      },
      enumerable: true,
      configurable: true
    });
    /** Sets the checked state of the switch. */

    MDCSwitchFoundation.prototype.setChecked = function (checked) {
      this.adapter_.setNativeControlChecked(checked);
      this.updateCheckedStyling_(checked);
    };
    /** Sets the disabled state of the switch. */


    MDCSwitchFoundation.prototype.setDisabled = function (disabled) {
      this.adapter_.setNativeControlDisabled(disabled);

      if (disabled) {
        this.adapter_.addClass(cssClasses$1.DISABLED);
      } else {
        this.adapter_.removeClass(cssClasses$1.DISABLED);
      }
    };
    /** Handles the change event for the switch native control. */


    MDCSwitchFoundation.prototype.handleChange = function (evt) {
      var nativeControl = evt.target;
      this.updateCheckedStyling_(nativeControl.checked);
    };
    /** Updates the styling of the switch based on its checked state. */


    MDCSwitchFoundation.prototype.updateCheckedStyling_ = function (checked) {
      if (checked) {
        this.adapter_.addClass(cssClasses$1.CHECKED);
      } else {
        this.adapter_.removeClass(cssClasses$1.CHECKED);
      }
    };

    return MDCSwitchFoundation;
  }(MDCFoundation);

  _exports.MDCSwitchFoundation = _exports.$foundationDefault$2 = MDCSwitchFoundation;
  var foundation$2 = {
    MDCSwitchFoundation: MDCSwitchFoundation,
    'default': MDCSwitchFoundation
  };
  _exports.$foundation$2 = foundation$2;

  var SwitchBase =
  /*#__PURE__*/
  function (_FormElement) {
    babelHelpers.inherits(SwitchBase, _FormElement);

    function SwitchBase() {
      var _this4;

      babelHelpers.classCallCheck(this, SwitchBase);
      _this4 = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(SwitchBase).apply(this, arguments));
      _this4.checked = false;
      _this4.disabled = false;
      _this4.mdcFoundationClass = MDCSwitchFoundation;
      return _this4;
    }

    babelHelpers.createClass(SwitchBase, [{
      key: "_changeHandler",
      value: function _changeHandler(e) {
        this.mdcFoundation.handleChange(e); // catch "click" event and sync properties

        this.checked = this.formElement.checked;
      }
    }, {
      key: "createAdapter",
      value: function createAdapter() {
        var _this5 = this;

        return Object.assign(Object.assign({}, addHasRemoveClass(this.mdcRoot)), {
          setNativeControlChecked: function setNativeControlChecked(checked) {
            _this5.formElement.checked = checked;
          },
          setNativeControlDisabled: function setNativeControlDisabled(disabled) {
            _this5.formElement.disabled = disabled;
          }
        });
      }
    }, {
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject2_7aadc9806ebf11ea8d6a8f399ad958de(), ripple({
          interactionNode: this
        }), this._changeHandler);
      }
    }, {
      key: "ripple",
      get: function get() {
        return this.rippleNode.ripple;
      }
    }]);
    return SwitchBase;
  }(FormElement);

  _exports.SwitchBase = SwitchBase;

  __decorate([(0, _myApp.property)({
    type: Boolean
  }), observer(function (value) {
    this.mdcFoundation.setChecked(value);
  })], SwitchBase.prototype, "checked", void 0);

  __decorate([(0, _myApp.property)({
    type: Boolean
  }), observer(function (value) {
    this.mdcFoundation.setDisabled(value);
  })], SwitchBase.prototype, "disabled", void 0);

  __decorate([(0, _myApp.query)('.mdc-switch')], SwitchBase.prototype, "mdcRoot", void 0);

  __decorate([(0, _myApp.query)('input')], SwitchBase.prototype, "formElement", void 0);

  __decorate([(0, _myApp.query)('.mdc-switch__thumb-underlay')], SwitchBase.prototype, "rippleNode", void 0);

  var mwcSwitchBase = {
    SwitchBase: SwitchBase
  };
  _exports.$mwcSwitchBase = mwcSwitchBase;
  var style$1 = (0, _myApp.css)(_templateObject3_7aadc9806ebf11ea8d6a8f399ad958de());
  _exports.style$1 = style$1;
  var mwcSwitchCss = {
    style: style$1
  };
  _exports.$mwcSwitchCss = mwcSwitchCss;

  var Switch =
  /*#__PURE__*/
  function (_SwitchBase) {
    babelHelpers.inherits(Switch, _SwitchBase);

    function Switch() {
      babelHelpers.classCallCheck(this, Switch);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(Switch).apply(this, arguments));
    }

    return Switch;
  }(SwitchBase);

  _exports.Switch = Switch;
  Switch.styles = style$1;
  _exports.Switch = Switch = __decorate([(0, _myApp.customElement)('mwc-switch')], Switch);
  var mwcSwitch = {
    get Switch() {
      return Switch;
    }

  };
  _exports.$mwcSwitch = mwcSwitch;

  var HomePage =
  /*#__PURE__*/
  function (_connect) {
    babelHelpers.inherits(HomePage, _connect);
    babelHelpers.createClass(HomePage, null, [{
      key: "properties",
      get: function get() {
        return {
          _page: {
            type: String
          },
          _powerOn: {
            type: Boolean
          },
          _turnOnWhenPlugIn: {
            type: Boolean
          }
        };
      }
    }]);

    function HomePage() {
      var _this6;

      babelHelpers.classCallCheck(this, HomePage);
      _this6 = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(HomePage).call(this));
      _this6._powerOn = false;
      return _this6;
    }

    babelHelpers.createClass(HomePage, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject4_7aadc9806ebf11ea8d6a8f399ad958de(), this.powerButtonClickHandler, this._powerOn, false, _myApp.powerIcon, this._powerOn, (0, _myApp.translate)('home-page.instruction-poweron'), !this._powerOn, (0, _myApp.translate)('home-page.instruction-connect'), (0, _myApp.translate)('home-page.toggleTurnOn'), this.defaultSwitchHandler, this._turnOnWhenPlugIn);
      }
    }, {
      key: "powerButtonClickHandler",
      value: function powerButtonClickHandler() {
        _myApp.store.dispatch((0, _myApp.powerOnOff)());
      }
    }, {
      key: "defaultSwitchHandler",
      value: function defaultSwitchHandler() {
        _myApp.store.dispatch((0, _myApp.setPowerOnWhenPluginDefaultState)());
      }
    }, {
      key: "stateChanged",
      value: function stateChanged(state) {
        this._page = state.app.page;
        this._powerOn = state.app.powerOn;
        this._turnOnWhenPlugIn = state.app.turnOnWhenPlugIn;
      }
    }], [{
      key: "styles",
      get: function get() {
        return [_myApp.SharedStyles, _myApp.GlobalStyles, _myApp.Page, _myApp.SpeakerButton, (0, _myApp.css)(_templateObject5_7aadc9806ebf11ea8d6a8f399ad958de())];
      }
    }]);
    return HomePage;
  }((0, _myApp.connect)(_myApp.store)(_myApp.PageViewElement));

  window.customElements.define('home-page', HomePage);
});