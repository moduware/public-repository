define(["exports", "meta"], function (_exports, meta) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.register = register;
  _exports.dumpRegistrations = dumpRegistrations;
  _exports.calculateSplices = calculateSplices;
  _exports.dashToCamelCase = dashToCamelCase;
  _exports.camelToDashCase = camelToDashCase;
  _exports.deepTargetFind = deepTargetFind;
  _exports.addListener = addListener;
  _exports.removeListener = removeListener;
  _exports.register$1 = register$1;
  _exports.setTouchAction = setTouchAction;
  _exports.prevent = prevent;
  _exports.resetMouseCanceller = resetMouseCanceller;
  _exports.isPath = isPath;
  _exports.root = root;
  _exports.isAncestor = isAncestor;
  _exports.isDescendant = isDescendant;
  _exports.translate = translate;
  _exports.matches = matches;
  _exports.normalize = normalize;
  _exports.split = split;
  _exports.get = get;
  _exports.set = set;
  _exports.resolveUrl = resolveUrl;
  _exports.resolveCss = resolveCss;
  _exports.pathFromUrl = pathFromUrl;
  _exports.stylesFromModules = stylesFromModules;
  _exports.stylesFromModule = stylesFromModule;
  _exports.stylesFromTemplate = stylesFromTemplate;
  _exports.stylesFromModuleImports = stylesFromModuleImports;
  _exports.cssFromModules = cssFromModules;
  _exports.cssFromModule = cssFromModule;
  _exports.cssFromTemplate = cssFromTemplate;
  _exports.cssFromModuleImports = cssFromModuleImports;
  _exports.removeNodesFromTemplate = removeNodesFromTemplate;
  _exports.insertNodeIntoTemplate = insertNodeIntoTemplate;
  _exports.templateFactory$1 = _exports.templateFactory = templateFactory;
  _exports.html$1 = _exports.remove = _exports.add = _exports.findOriginalTarget = _exports.recognizers = _exports.gestures = _exports.FlattenedNodesObserver = _exports.Debouncer = _exports.microTask = _exports.idlePeriod = _exports.animationFrame = _exports.timeOut = _exports.TemplateStamp = _exports.PropertyEffects = _exports.PropertyAccessors = _exports.PropertiesMixin = _exports.PropertiesChanged = _exports.GestureEventListeners = _exports.updateStyles = _exports.registrations = _exports.instanceCount = _exports.ElementMixin = _exports.version$1 = _exports.version = _exports.DomModule = _exports.LitElement = _exports.svg$2 = _exports.svg$1 = _exports.svg = _exports.html$4 = _exports.html$3 = _exports.html = _exports.UpdatingElement$1 = _exports.UpdatingElement = _exports.notEqual$1 = _exports.notEqual = _exports.eventOptions$1 = _exports.eventOptions = _exports.queryAll$1 = _exports.queryAll = _exports.query$1 = _exports.query = _exports.property$1 = _exports.property = _exports.customElement$1 = _exports.customElement = _exports.MorphRipple = _exports.getPlatform$2 = _exports.MorphListView = _exports.getPlatform$1 = _exports.MorphListViewItem = _exports.getPlatform = _exports.MorphListViewDivider = _exports.driver = _exports.$litHtml = _exports.$template = _exports.$templateResult = _exports.$templateInstance = _exports.$templateFactory = _exports.$shadyRender = _exports.$render = _exports.$parts = _exports.$part = _exports.$modifyTemplate = _exports.$dom = _exports.$directive = _exports.$defaultTemplateProcessor = _exports.$ifDefined = _exports.$polymerElement = _exports.$styleGather = _exports.$settings = _exports.$resolveUrl = _exports.$path = _exports.$mixin = _exports.$htmlTag = _exports.$gestures = _exports.$flattenedNodesObserver = _exports.$debounce = _exports.$caseMap = _exports.$async = _exports.$arraySplice = _exports.$templateStamp = _exports.$propertyEffects = _exports.$propertyAccessors = _exports.$propertiesMixin = _exports.$propertiesChanged = _exports.$gestureEventListeners = _exports.$elementMixin = _exports.$domModule = _exports.$litElement = _exports.$updatingElement = _exports.$decorators = _exports.$morphRipple = _exports.$morphElement$2 = _exports.$morphListView = _exports.$morphElement$1 = _exports.$morphListViewItem = _exports.$morphElement = _exports.$morphListViewDivider = _exports.$customDriver = void 0;
  _exports.lastAttributeNameRegex = _exports.createMarker$1 = _exports.createMarker = _exports.isTemplatePartActive$1 = _exports.isTemplatePartActive = _exports.Template$1 = _exports.Template = _exports.rewritesStyleAttribute = _exports.markerRegex = _exports.nodeMarker = _exports.marker = _exports.SVGTemplateResult$1 = _exports.SVGTemplateResult = _exports.TemplateInstance$1 = _exports.TemplateInstance = _exports.templateCaches$1 = _exports.templateCaches = _exports.render$1 = _exports.TemplateResult$2 = _exports.TemplateResult$1 = _exports.TemplateResult = _exports.render$2 = _exports.render = _exports.parts$1 = _exports.parts = _exports.EventPart$1 = _exports.EventPart = _exports.PropertyPart$1 = _exports.PropertyPart = _exports.PropertyCommitter$1 = _exports.PropertyCommitter = _exports.BooleanAttributePart$1 = _exports.BooleanAttributePart = _exports.NodePart$1 = _exports.NodePart = _exports.AttributePart$1 = _exports.AttributePart = _exports.AttributeCommitter$1 = _exports.AttributeCommitter = _exports.isPrimitive$1 = _exports.isPrimitive = _exports.noChange$1 = _exports.noChange = _exports.removeNodes$1 = _exports.removeNodes = _exports.reparentNodes$1 = _exports.reparentNodes = _exports.isCEPolyfill = _exports.isDirective$1 = _exports.isDirective = _exports.directive$1 = _exports.directive = _exports.defaultTemplateProcessor$1 = _exports.defaultTemplateProcessor = _exports.DefaultTemplateProcessor$1 = _exports.DefaultTemplateProcessor = _exports.ifDefined = _exports.PolymerElement = _exports.setAllowTemplateFromDomModule = _exports.allowTemplateFromDomModule = _exports.setStrictTemplatePolicy = _exports.strictTemplatePolicy = _exports.setPassiveTouchGestures = _exports.passiveTouchGestures = _exports.setSanitizeDOMValue = _exports.sanitizeDOMValue = _exports.setRootPath = _exports.rootPath = _exports.useNativeCustomElements = _exports.useNativeCSSProperties = _exports.useShadow = _exports.isDeep = _exports.dedupingMixin = _exports.htmlLiteral = _exports.html$2 = void 0;
  meta = babelHelpers.interopRequireWildcard(meta);
  const driver = JSON.stringify({
    "type": "nexpaq.module.devmod",
    "version": "1.0.0",
    "commands": [{
      "name": "SetPinConfig",
      "title": "Set Pin Configuration",
      "description": "Configures pin of module to one of modes: GPIO I, GPIO O, ADC or PWM. 3 bytes long.",
      "command": "2700"
    }]
  });
  _exports.driver = driver;
  var customDriver = {
    driver: driver
  };
  /**
   * @license
   * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at
   * http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at
   * http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at
   * http://polymer.github.io/PATENTS.txt
   */

  _exports.$customDriver = customDriver;
  const directives = new WeakMap();
  /**
   * Brands a function as a directive so that lit-html will call the function
   * during template rendering, rather than passing as a value.
   *
   * @param f The directive factory function. Must be a function that returns a
   * function of the signature `(part: Part) => void`. The returned function will
   * be called with the part object
   *
   * @example
   *
   * ```
   * import {directive, html} from 'lit-html';
   *
   * const immutable = directive((v) => (part) => {
   *   if (part.value !== v) {
   *     part.setValue(v)
   *   }
   * });
   * ```
   */

  const directive = f => (...args) => {
    const d = f(...args);
    directives.set(d, true);
    return d;
  };

  _exports.directive$1 = _exports.directive = directive;

  const isDirective = o => typeof o === 'function' && directives.has(o);

  _exports.isDirective$1 = _exports.isDirective = isDirective;
  var directive$1 = {
    directive: directive,
    isDirective: isDirective
  };
  /**
   * @license
   * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at
   * http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at
   * http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at
   * http://polymer.github.io/PATENTS.txt
   */

  _exports.$directive = directive$1;
  const isCEPolyfill = window.customElements !== undefined && window.customElements.polyfillWrapFlushCallback !== undefined;
  /**
          * Reparents nodes, starting from `startNode` (inclusive) to `endNode`
          * (exclusive), into another container (could be the same container), before
          * `beforeNode`. If `beforeNode` is null, it appends the nodes to the
          * container.
          */

  _exports.isCEPolyfill = isCEPolyfill;

  const reparentNodes = (container, start, end = null, before = null) => {
    let node = start;

    while (node !== end) {
      const n = node.nextSibling;
      container.insertBefore(node, before);
      node = n;
    }
  };
  /**
   * Removes nodes, starting from `startNode` (inclusive) to `endNode`
   * (exclusive), from `container`.
   */


  _exports.reparentNodes$1 = _exports.reparentNodes = reparentNodes;

  const removeNodes = (container, startNode, endNode = null) => {
    let node = startNode;

    while (node !== endNode) {
      const n = node.nextSibling;
      container.removeChild(node);
      node = n;
    }
  };

  _exports.removeNodes$1 = _exports.removeNodes = removeNodes;
  var dom = {
    isCEPolyfill: isCEPolyfill,
    reparentNodes: reparentNodes,
    removeNodes: removeNodes
  };
  /**
   * A sentinel value that signals that a value was handled by a directive and
   * should not be written to the DOM.
   */

  _exports.$dom = dom;
  const noChange = {};
  _exports.noChange$1 = _exports.noChange = noChange;
  var part = {
    noChange: noChange
  };
  /**
   * @license
   * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at
   * http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at
   * http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at
   * http://polymer.github.io/PATENTS.txt
   */

  /**
   * An expression marker with embedded unique key to avoid collision with
   * possible text in templates.
   */

  _exports.$part = part;
  const marker = `{{lit-${String(Math.random()).slice(2)}}}`;
  /**
          * An expression marker used text-positions, not attribute positions,
          * in template.
          */

  _exports.marker = marker;
  const nodeMarker = `<!--${marker}-->`;
  _exports.nodeMarker = nodeMarker;
  const markerRegex = new RegExp(`${marker}|${nodeMarker}`);
  _exports.markerRegex = markerRegex;

  const rewritesStyleAttribute = (() => {
    const el = document.createElement('div');
    el.setAttribute('style', '{{bad value}}');
    return el.getAttribute('style') !== '{{bad value}}';
  })();
  /**
   * An updateable Template that tracks the location of dynamic parts.
   */


  _exports.rewritesStyleAttribute = rewritesStyleAttribute;

  class Template {
    constructor(result, element) {
      this.parts = [];
      this.element = element;
      let index = -1;
      let partIndex = 0;
      const nodesToRemove = [];

      const _prepareTemplate = template => {
        const content = template.content; // Edge needs all 4 parameters present; IE11 needs 3rd parameter to be
        // null

        const walker = document.createTreeWalker(content, 133
        /* NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT |
        NodeFilter.SHOW_TEXT */
        , null, false); // The actual previous node, accounting for removals: if a node is removed
        // it will never be the previousNode.

        let previousNode; // Used to set previousNode at the top of the loop.

        let currentNode;

        while (walker.nextNode()) {
          index++;
          previousNode = currentNode;
          const node = currentNode = walker.currentNode;

          if (node.nodeType === 1
          /* Node.ELEMENT_NODE */
          ) {
              if (node.hasAttributes()) {
                const attributes = node.attributes; // Per
                // https://developer.mozilla.org/en-US/docs/Web/API/NamedNodeMap,
                // attributes are not guaranteed to be returned in document order.
                // In particular, Edge/IE can return them out of order, so we cannot
                // assume a correspondance between part index and attribute index.

                let count = 0;

                for (let i = 0; i < attributes.length; i++) {
                  if (attributes[i].value.indexOf(marker) >= 0) {
                    count++;
                  }
                }

                while (count-- > 0) {
                  // Get the template literal section leading up to the first
                  // expression in this attribute
                  const stringForPart = result.strings[partIndex]; // Find the attribute name

                  const name = lastAttributeNameRegex.exec(stringForPart)[2]; // Find the corresponding attribute
                  // If the attribute name contains special characters, lower-case
                  // it so that on XML nodes with case-sensitive getAttribute() we
                  // can still find the attribute, which will have been lower-cased
                  // by the parser.
                  //
                  // If the attribute name doesn't contain special character, it's
                  // important to _not_ lower-case it, in case the name is
                  // case-sensitive, like with XML attributes like "viewBox".

                  const attributeLookupName = rewritesStyleAttribute && name === 'style' ? 'style$' : /^[a-zA-Z-]*$/.test(name) ? name : name.toLowerCase();
                  const attributeValue = node.getAttribute(attributeLookupName);
                  const strings = attributeValue.split(markerRegex);
                  this.parts.push({
                    type: 'attribute',
                    index,
                    name,
                    strings
                  });
                  node.removeAttribute(attributeLookupName);
                  partIndex += strings.length - 1;
                }
              }

              if (node.tagName === 'TEMPLATE') {
                _prepareTemplate(node);
              }
            } else if (node.nodeType === 3
          /* Node.TEXT_NODE */
          ) {
              const nodeValue = node.nodeValue;

              if (nodeValue.indexOf(marker) < 0) {
                continue;
              }

              const parent = node.parentNode;
              const strings = nodeValue.split(markerRegex);
              const lastIndex = strings.length - 1; // We have a part for each match found

              partIndex += lastIndex; // Generate a new text node for each literal section
              // These nodes are also used as the markers for node parts

              for (let i = 0; i < lastIndex; i++) {
                parent.insertBefore(strings[i] === '' ? createMarker() : document.createTextNode(strings[i]), node);
                this.parts.push({
                  type: 'node',
                  index: index++
                });
              }

              parent.insertBefore(strings[lastIndex] === '' ? createMarker() : document.createTextNode(strings[lastIndex]), node);
              nodesToRemove.push(node);
            } else if (node.nodeType === 8
          /* Node.COMMENT_NODE */
          ) {
              if (node.nodeValue === marker) {
                const parent = node.parentNode; // Add a new marker node to be the startNode of the Part if any of
                // the following are true:
                //  * We don't have a previousSibling
                //  * previousSibling is being removed (thus it's not the
                //    `previousNode`)
                //  * previousSibling is not a Text node
                //
                // TODO(justinfagnani): We should be able to use the previousNode
                // here as the marker node and reduce the number of extra nodes we
                // add to a template. See
                // https://github.com/PolymerLabs/lit-html/issues/147

                const previousSibling = node.previousSibling;

                if (previousSibling === null || previousSibling !== previousNode || previousSibling.nodeType !== Node.TEXT_NODE) {
                  parent.insertBefore(createMarker(), node);
                } else {
                  index--;
                }

                this.parts.push({
                  type: 'node',
                  index: index++
                });
                nodesToRemove.push(node); // If we don't have a nextSibling add a marker node.
                // We don't have to check if the next node is going to be removed,
                // because that node will induce a new marker if so.

                if (node.nextSibling === null) {
                  parent.insertBefore(createMarker(), node);
                } else {
                  index--;
                }

                currentNode = previousNode;
                partIndex++;
              } else {
                let i = -1;

                while ((i = node.nodeValue.indexOf(marker, i + 1)) !== -1) {
                  // Comment node has a binding marker inside, make an inactive part
                  // The binding won't work, but subsequent bindings will
                  // TODO (justinfagnani): consider whether it's even worth it to
                  // make bindings in comments work
                  this.parts.push({
                    type: 'node',
                    index: -1
                  });
                }
              }
            }
        }
      };

      _prepareTemplate(element); // Remove text binding nodes after the walk to not disturb the TreeWalker


      for (const n of nodesToRemove) {
        n.parentNode.removeChild(n);
      }
    }

  }

  _exports.Template$1 = _exports.Template = Template;

  const isTemplatePartActive = part => part.index !== -1; // Allows `document.createComment('')` to be renamed for a
  // small manual size-savings.


  _exports.isTemplatePartActive$1 = _exports.isTemplatePartActive = isTemplatePartActive;

  const createMarker = () => document.createComment('');
  /**
          * This regex extracts the attribute name preceding an attribute-position
          * expression. It does this by matching the syntax allowed for attributes
          * against the string literal directly preceding the expression, assuming that
          * the expression is in an attribute-value position.
          *
          * See attributes in the HTML spec:
          * https://www.w3.org/TR/html5/syntax.html#attributes-0
          *
          * "\0-\x1F\x7F-\x9F" are Unicode control characters
          *
          * " \x09\x0a\x0c\x0d" are HTML space characters:
          * https://www.w3.org/TR/html5/infrastructure.html#space-character
          *
          * So an attribute is:
          *  * The name: any character except a control character, space character, ('),
          *    ("), ">", "=", or "/"
          *  * Followed by zero or more space characters
          *  * Followed by "="
          *  * Followed by zero or more space characters
          *  * Followed by:
          *    * Any character except space, ('), ("), "<", ">", "=", (`), or
          *    * (") then any non-("), or
          *    * (') then any non-(')
          */


  _exports.createMarker$1 = _exports.createMarker = createMarker;
  const lastAttributeNameRegex = /([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F \x09\x0a\x0c\x0d"'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/;
  _exports.lastAttributeNameRegex = lastAttributeNameRegex;
  var template = {
    marker: marker,
    nodeMarker: nodeMarker,
    markerRegex: markerRegex,
    rewritesStyleAttribute: rewritesStyleAttribute,
    Template: Template,
    isTemplatePartActive: isTemplatePartActive,
    createMarker: createMarker,
    lastAttributeNameRegex: lastAttributeNameRegex
  };
  _exports.$template = template;

  class TemplateInstance {
    constructor(template, processor, options) {
      this._parts = [];
      this.template = template;
      this.processor = processor;
      this.options = options;
    }

    update(values) {
      let i = 0;

      for (const part of this._parts) {
        if (part !== undefined) {
          part.setValue(values[i]);
        }

        i++;
      }

      for (const part of this._parts) {
        if (part !== undefined) {
          part.commit();
        }
      }
    }

    _clone() {
      // When using the Custom Elements polyfill, clone the node, rather than
      // importing it, to keep the fragment in the template's document. This
      // leaves the fragment inert so custom elements won't upgrade and
      // potentially modify their contents by creating a polyfilled ShadowRoot
      // while we traverse the tree.
      const fragment = isCEPolyfill ? this.template.element.content.cloneNode(true) : document.importNode(this.template.element.content, true);
      const parts = this.template.parts;
      let partIndex = 0;
      let nodeIndex = 0;

      const _prepareInstance = fragment => {
        // Edge needs all 4 parameters present; IE11 needs 3rd parameter to be
        // null
        const walker = document.createTreeWalker(fragment, 133
        /* NodeFilter.SHOW_{ELEMENT|COMMENT|TEXT} */
        , null, false);
        let node = walker.nextNode(); // Loop through all the nodes and parts of a template

        while (partIndex < parts.length && node !== null) {
          const part = parts[partIndex]; // Consecutive Parts may have the same node index, in the case of
          // multiple bound attributes on an element. So each iteration we either
          // increment the nodeIndex, if we aren't on a node with a part, or the
          // partIndex if we are. By not incrementing the nodeIndex when we find a
          // part, we allow for the next part to be associated with the current
          // node if neccessasry.

          if (!isTemplatePartActive(part)) {
            this._parts.push(undefined);

            partIndex++;
          } else if (nodeIndex === part.index) {
            if (part.type === 'node') {
              const part = this.processor.handleTextExpression(this.options);
              part.insertAfterNode(node);

              this._parts.push(part);
            } else {
              this._parts.push(...this.processor.handleAttributeExpressions(node, part.name, part.strings, this.options));
            }

            partIndex++;
          } else {
            nodeIndex++;

            if (node.nodeName === 'TEMPLATE') {
              _prepareInstance(node.content);
            }

            node = walker.nextNode();
          }
        }
      };

      _prepareInstance(fragment);

      if (isCEPolyfill) {
        document.adoptNode(fragment);
        customElements.upgrade(fragment);
      }

      return fragment;
    }

  }

  _exports.TemplateInstance$1 = _exports.TemplateInstance = TemplateInstance;
  var templateInstance = {
    TemplateInstance: TemplateInstance
  };
  _exports.$templateInstance = templateInstance;

  class TemplateResult {
    constructor(strings, values, type, processor) {
      this.strings = strings;
      this.values = values;
      this.type = type;
      this.processor = processor;
    }
    /**
     * Returns a string of HTML used to create a `<template>` element.
     */


    getHTML() {
      const l = this.strings.length - 1;
      let html = '';
      let isTextBinding = true;

      for (let i = 0; i < l; i++) {
        const s = this.strings[i];
        html += s;
        const close = s.lastIndexOf('>'); // We're in a text position if the previous string closed its last tag, an
        // attribute position if the string opened an unclosed tag, and unchanged
        // if the string had no brackets at all:
        //
        // "...>...": text position. open === -1, close > -1
        // "...<...": attribute position. open > -1
        // "...": no change. open === -1, close === -1

        isTextBinding = (close > -1 || isTextBinding) && s.indexOf('<', close + 1) === -1;

        if (!isTextBinding && rewritesStyleAttribute) {
          html = html.replace(lastAttributeNameRegex, (match, p1, p2, p3) => {
            return p2 === 'style' ? `${p1}style$${p3}` : match;
          });
        }

        html += isTextBinding ? nodeMarker : marker;
      }

      html += this.strings[l];
      return html;
    }

    getTemplateElement() {
      const template = document.createElement('template');
      template.innerHTML = this.getHTML();
      return template;
    }

  }
  /**
   * A TemplateResult for SVG fragments.
   *
   * This class wraps HTMl in an `<svg>` tag in order to parse its contents in the
   * SVG namespace, then modifies the template to remove the `<svg>` tag so that
   * clones only container the original fragment.
   */


  _exports.TemplateResult$2 = _exports.TemplateResult$1 = _exports.TemplateResult = TemplateResult;

  class SVGTemplateResult extends TemplateResult {
    getHTML() {
      return `<svg>${super.getHTML()}</svg>`;
    }

    getTemplateElement() {
      const template = super.getTemplateElement();
      const content = template.content;
      const svgElement = content.firstChild;
      content.removeChild(svgElement);
      reparentNodes(content, svgElement.firstChild);
      return template;
    }

  }

  _exports.SVGTemplateResult$1 = _exports.SVGTemplateResult = SVGTemplateResult;
  var templateResult = {
    TemplateResult: TemplateResult,
    SVGTemplateResult: SVGTemplateResult
  };
  _exports.$templateResult = templateResult;

  const isPrimitive = value => value === null || !(typeof value === 'object' || typeof value === 'function');
  /**
          * Sets attribute values for AttributeParts, so that the value is only set once
          * even if there are multiple parts for an attribute.
          */


  _exports.isPrimitive$1 = _exports.isPrimitive = isPrimitive;

  class AttributeCommitter {
    constructor(element, name, strings) {
      this.dirty = true;
      this.element = element;
      this.name = name;
      this.strings = strings;
      this.parts = [];

      for (let i = 0; i < strings.length - 1; i++) {
        this.parts[i] = this._createPart();
      }
    }
    /**
     * Creates a single part. Override this to create a differnt type of part.
     */


    _createPart() {
      return new AttributePart(this);
    }

    _getValue() {
      const strings = this.strings;
      const l = strings.length - 1;
      let text = '';

      for (let i = 0; i < l; i++) {
        text += strings[i];
        const part = this.parts[i];

        if (part !== undefined) {
          const v = part.value;

          if (v != null && (Array.isArray(v) || typeof v !== 'string' && v[Symbol.iterator])) {
            for (const t of v) {
              text += typeof t === 'string' ? t : String(t);
            }
          } else {
            text += typeof v === 'string' ? v : String(v);
          }
        }
      }

      text += strings[l];
      return text;
    }

    commit() {
      if (this.dirty) {
        this.dirty = false;
        this.element.setAttribute(this.name, this._getValue());
      }
    }

  }

  _exports.AttributeCommitter$1 = _exports.AttributeCommitter = AttributeCommitter;

  class AttributePart {
    constructor(comitter) {
      this.value = undefined;
      this.committer = comitter;
    }

    setValue(value) {
      if (value !== noChange && (!isPrimitive(value) || value !== this.value)) {
        this.value = value; // If the value is a not a directive, dirty the committer so that it'll
        // call setAttribute. If the value is a directive, it'll dirty the
        // committer if it calls setValue().

        if (!isDirective(value)) {
          this.committer.dirty = true;
        }
      }
    }

    commit() {
      while (isDirective(this.value)) {
        const directive$$1 = this.value;
        this.value = noChange;
        directive$$1(this);
      }

      if (this.value === noChange) {
        return;
      }

      this.committer.commit();
    }

  }

  _exports.AttributePart$1 = _exports.AttributePart = AttributePart;

  class NodePart {
    constructor(options) {
      this.value = undefined;
      this._pendingValue = undefined;
      this.options = options;
    }
    /**
     * Inserts this part into a container.
     *
     * This part must be empty, as its contents are not automatically moved.
     */


    appendInto(container) {
      this.startNode = container.appendChild(createMarker());
      this.endNode = container.appendChild(createMarker());
    }
    /**
     * Inserts this part between `ref` and `ref`'s next sibling. Both `ref` and
     * its next sibling must be static, unchanging nodes such as those that appear
     * in a literal section of a template.
     *
     * This part must be empty, as its contents are not automatically moved.
     */


    insertAfterNode(ref) {
      this.startNode = ref;
      this.endNode = ref.nextSibling;
    }
    /**
     * Appends this part into a parent part.
     *
     * This part must be empty, as its contents are not automatically moved.
     */


    appendIntoPart(part) {
      part._insert(this.startNode = createMarker());

      part._insert(this.endNode = createMarker());
    }
    /**
     * Appends this part after `ref`
     *
     * This part must be empty, as its contents are not automatically moved.
     */


    insertAfterPart(ref) {
      ref._insert(this.startNode = createMarker());

      this.endNode = ref.endNode;
      ref.endNode = this.startNode;
    }

    setValue(value) {
      this._pendingValue = value;
    }

    commit() {
      while (isDirective(this._pendingValue)) {
        const directive$$1 = this._pendingValue;
        this._pendingValue = noChange;
        directive$$1(this);
      }

      const value = this._pendingValue;

      if (value === noChange) {
        return;
      }

      if (isPrimitive(value)) {
        if (value !== this.value) {
          this._commitText(value);
        }
      } else if (value instanceof TemplateResult) {
        this._commitTemplateResult(value);
      } else if (value instanceof Node) {
        this._commitNode(value);
      } else if (Array.isArray(value) || value[Symbol.iterator]) {
        this._commitIterable(value);
      } else if (value.then !== undefined) {
        this._commitPromise(value);
      } else {
        // Fallback, will render the string representation
        this._commitText(value);
      }
    }

    _insert(node) {
      this.endNode.parentNode.insertBefore(node, this.endNode);
    }

    _commitNode(value) {
      if (this.value === value) {
        return;
      }

      this.clear();

      this._insert(value);

      this.value = value;
    }

    _commitText(value) {
      const node = this.startNode.nextSibling;
      value = value == null ? '' : value;

      if (node === this.endNode.previousSibling && node.nodeType === Node.TEXT_NODE) {
        // If we only have a single text node between the markers, we can just
        // set its value, rather than replacing it.
        // TODO(justinfagnani): Can we just check if this.value is primitive?
        node.textContent = value;
      } else {
        this._commitNode(document.createTextNode(typeof value === 'string' ? value : String(value)));
      }

      this.value = value;
    }

    _commitTemplateResult(value) {
      const template = this.options.templateFactory(value);

      if (this.value && this.value.template === template) {
        this.value.update(value.values);
      } else {
        // Make sure we propagate the template processor from the TemplateResult
        // so that we use its syntax extension, etc. The template factory comes
        // from the render function options so that it can control template
        // caching and preprocessing.
        const instance = new TemplateInstance(template, value.processor, this.options);

        const fragment = instance._clone();

        instance.update(value.values);

        this._commitNode(fragment);

        this.value = instance;
      }
    }

    _commitIterable(value) {
      // For an Iterable, we create a new InstancePart per item, then set its
      // value to the item. This is a little bit of overhead for every item in
      // an Iterable, but it lets us recurse easily and efficiently update Arrays
      // of TemplateResults that will be commonly returned from expressions like:
      // array.map((i) => html`${i}`), by reusing existing TemplateInstances.
      // If _value is an array, then the previous render was of an
      // iterable and _value will contain the NodeParts from the previous
      // render. If _value is not an array, clear this part and make a new
      // array for NodeParts.
      if (!Array.isArray(this.value)) {
        this.value = [];
        this.clear();
      } // Lets us keep track of how many items we stamped so we can clear leftover
      // items from a previous render


      const itemParts = this.value;
      let partIndex = 0;
      let itemPart;

      for (const item of value) {
        // Try to reuse an existing part
        itemPart = itemParts[partIndex]; // If no existing part, create a new one

        if (itemPart === undefined) {
          itemPart = new NodePart(this.options);
          itemParts.push(itemPart);

          if (partIndex === 0) {
            itemPart.appendIntoPart(this);
          } else {
            itemPart.insertAfterPart(itemParts[partIndex - 1]);
          }
        }

        itemPart.setValue(item);
        itemPart.commit();
        partIndex++;
      }

      if (partIndex < itemParts.length) {
        // Truncate the parts array so _value reflects the current state
        itemParts.length = partIndex;
        this.clear(itemPart && itemPart.endNode);
      }
    }

    _commitPromise(value) {
      this.value = value;
      value.then(v => {
        if (this.value === value) {
          this.setValue(v);
          this.commit();
        }
      });
    }

    clear(startNode = this.startNode) {
      removeNodes(this.startNode.parentNode, startNode.nextSibling, this.endNode);
    }

  }
  /**
   * Implements a boolean attribute, roughly as defined in the HTML
   * specification.
   *
   * If the value is truthy, then the attribute is present with a value of
   * ''. If the value is falsey, the attribute is removed.
   */


  _exports.NodePart$1 = _exports.NodePart = NodePart;

  class BooleanAttributePart {
    constructor(element, name, strings) {
      this.value = undefined;
      this._pendingValue = undefined;

      if (strings.length !== 2 || strings[0] !== '' || strings[1] !== '') {
        throw new Error('Boolean attributes can only contain a single expression');
      }

      this.element = element;
      this.name = name;
      this.strings = strings;
    }

    setValue(value) {
      this._pendingValue = value;
    }

    commit() {
      while (isDirective(this._pendingValue)) {
        const directive$$1 = this._pendingValue;
        this._pendingValue = noChange;
        directive$$1(this);
      }

      if (this._pendingValue === noChange) {
        return;
      }

      const value = !!this._pendingValue;

      if (this.value !== value) {
        if (value) {
          this.element.setAttribute(this.name, '');
        } else {
          this.element.removeAttribute(this.name);
        }
      }

      this.value = value;
      this._pendingValue = noChange;
    }

  }
  /**
   * Sets attribute values for PropertyParts, so that the value is only set once
   * even if there are multiple parts for a property.
   *
   * If an expression controls the whole property value, then the value is simply
   * assigned to the property under control. If there are string literals or
   * multiple expressions, then the strings are expressions are interpolated into
   * a string first.
   */


  _exports.BooleanAttributePart$1 = _exports.BooleanAttributePart = BooleanAttributePart;

  class PropertyCommitter extends AttributeCommitter {
    constructor(element, name, strings) {
      super(element, name, strings);
      this.single = strings.length === 2 && strings[0] === '' && strings[1] === '';
    }

    _createPart() {
      return new PropertyPart(this);
    }

    _getValue() {
      if (this.single) {
        return this.parts[0].value;
      }

      return super._getValue();
    }

    commit() {
      if (this.dirty) {
        this.dirty = false;
        this.element[this.name] = this._getValue();
      }
    }

  }

  _exports.PropertyCommitter$1 = _exports.PropertyCommitter = PropertyCommitter;

  class PropertyPart extends AttributePart {} // Detect event listener options support. If the `capture` property is read
  // from the options object, then options are supported. If not, then the thrid
  // argument to add/removeEventListener is interpreted as the boolean capture
  // value so we should only pass the `capture` property.


  _exports.PropertyPart$1 = _exports.PropertyPart = PropertyPart;
  let eventOptionsSupported = false;

  try {
    const options = {
      get capture() {
        eventOptionsSupported = true;
        return false;
      }

    };
    window.addEventListener('test', options, options);
    window.removeEventListener('test', options, options);
  } catch (_e) {}

  class EventPart {
    constructor(element, eventName, eventContext) {
      this.value = undefined;
      this._pendingValue = undefined;
      this.element = element;
      this.eventName = eventName;
      this.eventContext = eventContext;

      this._boundHandleEvent = e => this.handleEvent(e);
    }

    setValue(value) {
      this._pendingValue = value;
    }

    commit() {
      while (isDirective(this._pendingValue)) {
        const directive$$1 = this._pendingValue;
        this._pendingValue = noChange;
        directive$$1(this);
      }

      if (this._pendingValue === noChange) {
        return;
      }

      const newListener = this._pendingValue;
      const oldListener = this.value;
      const shouldRemoveListener = newListener == null || oldListener != null && (newListener.capture !== oldListener.capture || newListener.once !== oldListener.once || newListener.passive !== oldListener.passive);
      const shouldAddListener = newListener != null && (oldListener == null || shouldRemoveListener);

      if (shouldRemoveListener) {
        this.element.removeEventListener(this.eventName, this._boundHandleEvent, this._options);
      }

      this._options = getOptions(newListener);

      if (shouldAddListener) {
        this.element.addEventListener(this.eventName, this._boundHandleEvent, this._options);
      }

      this.value = newListener;
      this._pendingValue = noChange;
    }

    handleEvent(event) {
      if (typeof this.value === 'function') {
        this.value.call(this.eventContext || this.element, event);
      } else {
        this.value.handleEvent(event);
      }
    }

  } // We copy options because of the inconsistent behavior of browsers when reading
  // the third argument of add/removeEventListener. IE11 doesn't support options
  // at all. Chrome 41 only reads `capture` if the argument is an object.


  _exports.EventPart$1 = _exports.EventPart = EventPart;

  const getOptions = o => o && (eventOptionsSupported ? {
    capture: o.capture,
    passive: o.passive,
    once: o.once
  } : o.capture);

  var parts = {
    isPrimitive: isPrimitive,
    AttributeCommitter: AttributeCommitter,
    AttributePart: AttributePart,
    NodePart: NodePart,
    BooleanAttributePart: BooleanAttributePart,
    PropertyCommitter: PropertyCommitter,
    PropertyPart: PropertyPart,
    EventPart: EventPart
  };
  _exports.$parts = parts;

  class DefaultTemplateProcessor {
    /**
     * Create parts for an attribute-position binding, given the event, attribute
     * name, and string literals.
     *
     * @param element The element containing the binding
     * @param name  The attribute name
     * @param strings The string literals. There are always at least two strings,
     *   event for fully-controlled bindings with a single expression.
     */
    handleAttributeExpressions(element, name, strings, options) {
      const prefix = name[0];

      if (prefix === '.') {
        const comitter = new PropertyCommitter(element, name.slice(1), strings);
        return comitter.parts;
      }

      if (prefix === '@') {
        return [new EventPart(element, name.slice(1), options.eventContext)];
      }

      if (prefix === '?') {
        return [new BooleanAttributePart(element, name.slice(1), strings)];
      }

      const comitter = new AttributeCommitter(element, name, strings);
      return comitter.parts;
    }
    /**
     * Create parts for a text-position binding.
     * @param templateFactory
     */


    handleTextExpression(options) {
      return new NodePart(options);
    }

  }

  _exports.DefaultTemplateProcessor$1 = _exports.DefaultTemplateProcessor = DefaultTemplateProcessor;
  const defaultTemplateProcessor = new DefaultTemplateProcessor();
  _exports.defaultTemplateProcessor$1 = _exports.defaultTemplateProcessor = defaultTemplateProcessor;
  var defaultTemplateProcessor$1 = {
    DefaultTemplateProcessor: DefaultTemplateProcessor,
    defaultTemplateProcessor: defaultTemplateProcessor
  };
  _exports.$defaultTemplateProcessor = defaultTemplateProcessor$1;

  function templateFactory(result) {
    let templateCache = templateCaches.get(result.type);

    if (templateCache === undefined) {
      templateCache = new Map();
      templateCaches.set(result.type, templateCache);
    }

    let template = templateCache.get(result.strings);

    if (template === undefined) {
      template = new Template(result, result.getTemplateElement());
      templateCache.set(result.strings, template);
    }

    return template;
  } // The first argument to JS template tags retain identity across multiple
  // calls to a tag for the same literal, so we can cache work done per literal
  // in a Map.


  const templateCaches = new Map();
  _exports.templateCaches$1 = _exports.templateCaches = templateCaches;
  var templateFactory$1 = {
    templateFactory: templateFactory,
    templateCaches: templateCaches
  };
  _exports.$templateFactory = templateFactory$1;
  const parts$1 = new WeakMap();
  /**
        * Renders a template to a container.
        *
        * To update a container with new values, reevaluate the template literal and
        * call `render` with the new result.
        *
        * @param result a TemplateResult created by evaluating a template tag like
        *     `html` or `svg`.
        * @param container A DOM parent to render to. The entire contents are either
        *     replaced, or efficiently updated if the same result type was previous
        *     rendered there.
        * @param options RenderOptions for the entire render tree rendered to this
        *     container. Render options must *not* change between renders to the same
        *     container, as those changes will not effect previously rendered DOM.
        */

  _exports.parts$1 = _exports.parts = parts$1;

  const render = (result, container, options) => {
    let part = parts$1.get(container);

    if (part === undefined) {
      removeNodes(container, container.firstChild);
      parts$1.set(container, part = new NodePart(Object.assign({
        templateFactory
      }, options)));
      part.appendInto(container);
    }

    part.setValue(result);
    part.commit();
  };

  _exports.render$2 = _exports.render = render;
  var render$1 = {
    parts: parts$1,
    render: render
  };
  _exports.$render = render$1;

  const html = (strings, ...values) => new TemplateResult(strings, values, 'html', defaultTemplateProcessor);
  /**
          * Interprets a template literal as an SVG template that can efficiently
          * render to and update a container.
          */


  _exports.html$4 = _exports.html$3 = _exports.html = html;

  const svg = (strings, ...values) => new SVGTemplateResult(strings, values, 'svg', defaultTemplateProcessor);

  _exports.svg$2 = _exports.svg$1 = _exports.svg = svg;
  var litHtml = {
    html: html,
    svg: svg,
    DefaultTemplateProcessor: DefaultTemplateProcessor,
    defaultTemplateProcessor: defaultTemplateProcessor,
    directive: directive,
    isDirective: isDirective,
    removeNodes: removeNodes,
    reparentNodes: reparentNodes,
    noChange: noChange,
    AttributeCommitter: AttributeCommitter,
    AttributePart: AttributePart,
    BooleanAttributePart: BooleanAttributePart,
    EventPart: EventPart,
    isPrimitive: isPrimitive,
    NodePart: NodePart,
    PropertyCommitter: PropertyCommitter,
    PropertyPart: PropertyPart,
    parts: parts$1,
    render: render,
    templateCaches: templateCaches,
    templateFactory: templateFactory,
    TemplateInstance: TemplateInstance,
    SVGTemplateResult: SVGTemplateResult,
    TemplateResult: TemplateResult,
    createMarker: createMarker,
    isTemplatePartActive: isTemplatePartActive,
    Template: Template
  };
  _exports.$litHtml = litHtml;
  const walkerNodeFilter = NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_COMMENT | NodeFilter.SHOW_TEXT;
  /**
   * Removes the list of nodes from a Template safely. In addition to removing
   * nodes from the Template, the Template part indices are updated to match
   * the mutated Template DOM.
   *
   * As the template is walked the removal state is tracked and
   * part indices are adjusted as needed.
   *
   * div
   *   div#1 (remove) <-- start removing (removing node is div#1)
   *     div
   *       div#2 (remove)  <-- continue removing (removing node is still div#1)
   *         div
   * div <-- stop removing since previous sibling is the removing node (div#1,
   * removed 4 nodes)
   */

  function removeNodesFromTemplate(template, nodesToRemove) {
    const {
      element: {
        content
      },
      parts
    } = template;
    const walker = document.createTreeWalker(content, walkerNodeFilter, null, false);
    let partIndex = nextActiveIndexInTemplateParts(parts);
    let part = parts[partIndex];
    let nodeIndex = -1;
    let removeCount = 0;
    const nodesToRemoveInTemplate = [];
    let currentRemovingNode = null;

    while (walker.nextNode()) {
      nodeIndex++;
      const node = walker.currentNode; // End removal if stepped past the removing node

      if (node.previousSibling === currentRemovingNode) {
        currentRemovingNode = null;
      } // A node to remove was found in the template


      if (nodesToRemove.has(node)) {
        nodesToRemoveInTemplate.push(node); // Track node we're removing

        if (currentRemovingNode === null) {
          currentRemovingNode = node;
        }
      } // When removing, increment count by which to adjust subsequent part indices


      if (currentRemovingNode !== null) {
        removeCount++;
      }

      while (part !== undefined && part.index === nodeIndex) {
        // If part is in a removed node deactivate it by setting index to -1 or
        // adjust the index as needed.
        part.index = currentRemovingNode !== null ? -1 : part.index - removeCount; // go to the next active part.

        partIndex = nextActiveIndexInTemplateParts(parts, partIndex);
        part = parts[partIndex];
      }
    }

    nodesToRemoveInTemplate.forEach(n => n.parentNode.removeChild(n));
  }

  const countNodes = node => {
    let count = node.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? 0 : 1;
    const walker = document.createTreeWalker(node, walkerNodeFilter, null, false);

    while (walker.nextNode()) {
      count++;
    }

    return count;
  };

  const nextActiveIndexInTemplateParts = (parts, startIndex = -1) => {
    for (let i = startIndex + 1; i < parts.length; i++) {
      const part = parts[i];

      if (isTemplatePartActive(part)) {
        return i;
      }
    }

    return -1;
  };
  /**
   * Inserts the given node into the Template, optionally before the given
   * refNode. In addition to inserting the node into the Template, the Template
   * part indices are updated to match the mutated Template DOM.
   */


  function insertNodeIntoTemplate(template, node, refNode = null) {
    const {
      element: {
        content
      },
      parts
    } = template; // If there's no refNode, then put node at end of template.
    // No part indices need to be shifted in this case.

    if (refNode === null || refNode === undefined) {
      content.appendChild(node);
      return;
    }

    const walker = document.createTreeWalker(content, walkerNodeFilter, null, false);
    let partIndex = nextActiveIndexInTemplateParts(parts);
    let insertCount = 0;
    let walkerIndex = -1;

    while (walker.nextNode()) {
      walkerIndex++;
      const walkerNode = walker.currentNode;

      if (walkerNode === refNode) {
        insertCount = countNodes(node);
        refNode.parentNode.insertBefore(node, refNode);
      }

      while (partIndex !== -1 && parts[partIndex].index === walkerIndex) {
        // If we've inserted the node, simply adjust all subsequent parts
        if (insertCount > 0) {
          while (partIndex !== -1) {
            parts[partIndex].index += insertCount;
            partIndex = nextActiveIndexInTemplateParts(parts, partIndex);
          }

          return;
        }

        partIndex = nextActiveIndexInTemplateParts(parts, partIndex);
      }
    }
  }

  var modifyTemplate = {
    removeNodesFromTemplate: removeNodesFromTemplate,
    insertNodeIntoTemplate: insertNodeIntoTemplate
  };
  _exports.$modifyTemplate = modifyTemplate;

  const getTemplateCacheKey = (type, scopeName) => `${type}--${scopeName}`;

  let compatibleShadyCSSVersion = true;

  if (typeof window.ShadyCSS === 'undefined') {
    compatibleShadyCSSVersion = false;
  } else if (typeof window.ShadyCSS.prepareTemplateDom === 'undefined') {
    console.warn(`Incompatible ShadyCSS version detected.` + `Please update to at least @webcomponents/webcomponentsjs@2.0.2 and` + `@webcomponents/shadycss@1.3.1.`);
    compatibleShadyCSSVersion = false;
  }
  /**
   * Template factory which scopes template DOM using ShadyCSS.
   * @param scopeName {string}
   */


  const shadyTemplateFactory = scopeName => result => {
    const cacheKey = getTemplateCacheKey(result.type, scopeName);
    let templateCache = templateCaches.get(cacheKey);

    if (templateCache === undefined) {
      templateCache = new Map();
      templateCaches.set(cacheKey, templateCache);
    }

    let template = templateCache.get(result.strings);

    if (template === undefined) {
      const element = result.getTemplateElement();

      if (compatibleShadyCSSVersion) {
        window.ShadyCSS.prepareTemplateDom(element, scopeName);
      }

      template = new Template(result, element);
      templateCache.set(result.strings, template);
    }

    return template;
  };

  const TEMPLATE_TYPES = ['html', 'svg'];
  /**
   * Removes all style elements from Templates for the given scopeName.
   */

  const removeStylesFromLitTemplates = scopeName => {
    TEMPLATE_TYPES.forEach(type => {
      const templates = templateCaches.get(getTemplateCacheKey(type, scopeName));

      if (templates !== undefined) {
        templates.forEach(template => {
          const {
            element: {
              content
            }
          } = template; // IE 11 doesn't support the iterable param Set constructor

          const styles = new Set();
          Array.from(content.querySelectorAll('style')).forEach(s => {
            styles.add(s);
          });
          removeNodesFromTemplate(template, styles);
        });
      }
    });
  };

  const shadyRenderSet = new Set();
  /**
   * For the given scope name, ensures that ShadyCSS style scoping is performed.
   * This is done just once per scope name so the fragment and template cannot
   * be modified.
   * (1) extracts styles from the rendered fragment and hands them to ShadyCSS
   * to be scoped and appended to the document
   * (2) removes style elements from all lit-html Templates for this scope name.
   *
   * Note, <style> elements can only be placed into templates for the
   * initial rendering of the scope. If <style> elements are included in templates
   * dynamically rendered to the scope (after the first scope render), they will
   * not be scoped and the <style> will be left in the template and rendered
   * output.
   */

  const prepareTemplateStyles = (renderedDOM, template, scopeName) => {
    shadyRenderSet.add(scopeName); // Move styles out of rendered DOM and store.

    const styles = renderedDOM.querySelectorAll('style'); // If there are no styles, there's no work to do.

    if (styles.length === 0) {
      return;
    }

    const condensedStyle = document.createElement('style'); // Collect styles into a single style. This helps us make sure ShadyCSS
    // manipulations will not prevent us from being able to fix up template
    // part indices.
    // NOTE: collecting styles is inefficient for browsers but ShadyCSS
    // currently does this anyway. When it does not, this should be changed.

    for (let i = 0; i < styles.length; i++) {
      const style = styles[i];
      style.parentNode.removeChild(style);
      condensedStyle.textContent += style.textContent;
    } // Remove styles from nested templates in this scope.


    removeStylesFromLitTemplates(scopeName); // And then put the condensed style into the "root" template passed in as
    // `template`.

    insertNodeIntoTemplate(template, condensedStyle, template.element.content.firstChild); // Note, it's important that ShadyCSS gets the template that `lit-html`
    // will actually render so that it can update the style inside when
    // needed (e.g. @apply native Shadow DOM case).

    window.ShadyCSS.prepareTemplateStyles(template.element, scopeName);

    if (window.ShadyCSS.nativeShadow) {
      // When in native Shadow DOM, re-add styling to rendered content using
      // the style ShadyCSS produced.
      const style = template.element.content.querySelector('style');
      renderedDOM.insertBefore(style.cloneNode(true), renderedDOM.firstChild);
    } else {
      // When not in native Shadow DOM, at this point ShadyCSS will have
      // removed the style from the lit template and parts will be broken as a
      // result. To fix this, we put back the style node ShadyCSS removed
      // and then tell lit to remove that node from the template.
      // NOTE, ShadyCSS creates its own style so we can safely add/remove
      // `condensedStyle` here.
      template.element.content.insertBefore(condensedStyle, template.element.content.firstChild);
      const removes = new Set();
      removes.add(condensedStyle);
      removeNodesFromTemplate(template, removes);
    }
  };

  const render$2 = (result, container, options) => {
    const scopeName = options.scopeName;
    const hasRendered = parts$1.has(container);
    render(result, container, Object.assign({
      templateFactory: shadyTemplateFactory(scopeName)
    }, options)); // When rendering a TemplateResult, scope the template with ShadyCSS

    if (container instanceof ShadowRoot && compatibleShadyCSSVersion && result instanceof TemplateResult) {
      // Scope the element template one time only for this scope.
      if (!shadyRenderSet.has(scopeName)) {
        const part = parts$1.get(container);
        const instance = part.value;
        prepareTemplateStyles(container, instance.template, scopeName);
      } // Update styling if this is the initial render to this container.


      if (!hasRendered) {
        window.ShadyCSS.styleElement(container.host);
      }
    }
  };

  _exports.render$1 = render$2;
  var shadyRender = {
    render: render$2,
    html: html,
    svg: svg,
    TemplateResult: TemplateResult
  };
  /**
   * @license
   * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at
   * http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at
   * http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at
   * http://polymer.github.io/PATENTS.txt
   */
  // serializer/deserializers for boolean attribute

  _exports.$shadyRender = shadyRender;

  const fromBooleanAttribute = value => value !== null;

  const toBooleanAttribute = value => value ? '' : null;
  /**
   * Change function that returns true if `value` is different from `oldValue`.
   * This method is used as the default for a property's `hasChanged` function.
   */


  const notEqual = (value, old) => {
    // This ensures (old==NaN, value==NaN) always returns false
    return old !== value && (old === old || value === value);
  };

  _exports.notEqual$1 = _exports.notEqual = notEqual;
  const defaultPropertyDeclaration = {
    attribute: true,
    type: String,
    reflect: false,
    hasChanged: notEqual
  };
  const microtaskPromise = new Promise(resolve => resolve(true));
  const STATE_HAS_UPDATED = 1;
  const STATE_UPDATE_REQUESTED = 1 << 2;
  const STATE_IS_REFLECTING = 1 << 3;
  /**
   * Base element class which manages element properties and attributes. When
   * properties change, the `update` method is asynchronously called. This method
   * should be supplied by subclassers to render updates as desired.
   */

  class UpdatingElement extends HTMLElement {
    constructor() {
      super();
      this._updateState = 0;
      this._instanceProperties = undefined;
      this._updatePromise = microtaskPromise;
      /**
       * Map with keys for any properties that have changed since the last
       * update cycle with previous values.
       */

      this._changedProperties = new Map();
      /**
       * Map with keys of properties that should be reflected when updated.
       */

      this._reflectingProperties = undefined;
      this.initialize();
    }
    /**
     * Returns a list of attributes corresponding to the registered properties.
     */


    static get observedAttributes() {
      // note: piggy backing on this to ensure we're _finalized.
      this._finalize();

      const attributes = [];

      for (const [p, v] of this._classProperties) {
        const attr = this._attributeNameForProperty(p, v);

        if (attr !== undefined) {
          this._attributeToPropertyMap.set(attr, p);

          attributes.push(attr);
        }
      }

      return attributes;
    }
    /**
     * Creates a property accessor on the element prototype if one does not exist.
     * The property setter calls the property's `hasChanged` property option
     * or uses a strict identity check to determine whether or not to request
     * an update.
     */


    static createProperty(name, options = defaultPropertyDeclaration) {
      // ensure private storage for property declarations.
      if (!this.hasOwnProperty('_classProperties')) {
        this._classProperties = new Map(); // NOTE: Workaround IE11 not supporting Map constructor argument.

        const superProperties = Object.getPrototypeOf(this)._classProperties;

        if (superProperties !== undefined) {
          superProperties.forEach((v, k) => this._classProperties.set(k, v));
        }
      }

      this._classProperties.set(name, options); // Allow user defined accessors by not replacing an existing own-property
      // accessor.


      if (this.prototype.hasOwnProperty(name)) {
        return;
      }

      const key = typeof name === 'symbol' ? Symbol() : `__${name}`;
      Object.defineProperty(this.prototype, name, {
        get() {
          return this[key];
        },

        set(value) {
          const oldValue = this[name];
          this[key] = value;

          this._requestPropertyUpdate(name, oldValue, options);
        },

        configurable: true,
        enumerable: true
      });
    }
    /**
     * Creates property accessors for registered properties and ensures
     * any superclasses are also finalized.
     */


    static _finalize() {
      if (this.hasOwnProperty('_finalized') && this._finalized) {
        return;
      } // finalize any superclasses


      const superCtor = Object.getPrototypeOf(this);

      if (typeof superCtor._finalize === 'function') {
        superCtor._finalize();
      }

      this._finalized = true; // initialize Map populated in observedAttributes

      this._attributeToPropertyMap = new Map(); // make any properties

      const props = this.properties; // support symbols in properties (IE11 does not support this)

      const propKeys = [...Object.getOwnPropertyNames(props), ...(typeof Object.getOwnPropertySymbols === 'function' ? Object.getOwnPropertySymbols(props) : [])];

      for (const p of propKeys) {
        // note, use of `any` is due to TypeSript lack of support for symbol in
        // index types
        this.createProperty(p, props[p]);
      }
    }
    /**
     * Returns the property name for the given attribute `name`.
     */


    static _attributeNameForProperty(name, options) {
      const attribute = options !== undefined && options.attribute;
      return attribute === false ? undefined : typeof attribute === 'string' ? attribute : typeof name === 'string' ? name.toLowerCase() : undefined;
    }
    /**
     * Returns true if a property should request an update.
     * Called when a property value is set and uses the `hasChanged`
     * option for the property if present or a strict identity check.
     */


    static _valueHasChanged(value, old, hasChanged = notEqual) {
      return hasChanged(value, old);
    }
    /**
     * Returns the property value for the given attribute value.
     * Called via the `attributeChangedCallback` and uses the property's `type`
     * or `type.fromAttribute` property option.
     */


    static _propertyValueFromAttribute(value, options) {
      const type = options && options.type;

      if (type === undefined) {
        return value;
      } // Note: special case `Boolean` so users can use it as a `type`.


      const fromAttribute = type === Boolean ? fromBooleanAttribute : typeof type === 'function' ? type : type.fromAttribute;
      return fromAttribute ? fromAttribute(value) : value;
    }
    /**
     * Returns the attribute value for the given property value. If this
     * returns undefined, the property will *not* be reflected to an attribute.
     * If this returns null, the attribute will be removed, otherwise the
     * attribute will be set to the value.
     * This uses the property's `reflect` and `type.toAttribute` property options.
     */


    static _propertyValueToAttribute(value, options) {
      if (options === undefined || options.reflect === undefined) {
        return;
      } // Note: special case `Boolean` so users can use it as a `type`.


      const toAttribute = options.type === Boolean ? toBooleanAttribute : options.type && options.type.toAttribute || String;
      return toAttribute(value);
    }
    /**
     * Performs element initialization. By default this calls `createRenderRoot`
     * to create the element `renderRoot` node and captures any pre-set values for
     * registered properties.
     */


    initialize() {
      this.renderRoot = this.createRenderRoot();

      this._saveInstanceProperties();
    }
    /**
     * Fixes any properties set on the instance before upgrade time.
     * Otherwise these would shadow the accessor and break these properties.
     * The properties are stored in a Map which is played back after the
     * constructor runs. Note, on very old versions of Safari (<=9) or Chrome
     * (<=41), properties created for native platform properties like (`id` or
     * `name`) may not have default values set in the element constructor. On
     * these browsers native properties appear on instances and therefore their
     * default value will overwrite any element default (e.g. if the element sets
     * this.id = 'id' in the constructor, the 'id' will become '' since this is
     * the native platform default).
     */


    _saveInstanceProperties() {
      for (const [p] of this.constructor._classProperties) {
        if (this.hasOwnProperty(p)) {
          const value = this[p];
          delete this[p];

          if (!this._instanceProperties) {
            this._instanceProperties = new Map();
          }

          this._instanceProperties.set(p, value);
        }
      }
    }
    /**
     * Applies previously saved instance properties.
     */


    _applyInstanceProperties() {
      for (const [p, v] of this._instanceProperties) {
        this[p] = v;
      }

      this._instanceProperties = undefined;
    }
    /**
     * Returns the node into which the element should render and by default
     * creates and returns an open shadowRoot. Implement to customize where the
     * element's DOM is rendered. For example, to render into the element's
     * childNodes, return `this`.
     * @returns {Element|DocumentFragment} Returns a node into which to render.
     */


    createRenderRoot() {
      return this.attachShadow({
        mode: 'open'
      });
    }
    /**
     * Uses ShadyCSS to keep element DOM updated.
     */


    connectedCallback() {
      if (this._updateState & STATE_HAS_UPDATED) {
        if (window.ShadyCSS !== undefined) {
          window.ShadyCSS.styleElement(this);
        }
      } else {
        this.requestUpdate();
      }
    }
    /**
     * Allows for `super.disconnectedCallback()` in extensions while
     * reserving the possibility of making non-breaking feature additions
     * when disconnecting at some point in the future.
     */


    disconnectedCallback() {}
    /**
     * Synchronizes property values when attributes change.
     */


    attributeChangedCallback(name, old, value) {
      if (old !== value) {
        this._attributeToProperty(name, value);
      }
    }

    _propertyToAttribute(name, value, options = defaultPropertyDeclaration) {
      const ctor = this.constructor;

      const attrValue = ctor._propertyValueToAttribute(value, options);

      if (attrValue !== undefined) {
        const attr = ctor._attributeNameForProperty(name, options);

        if (attr !== undefined) {
          // Track if the property is being reflected to avoid
          // setting the property again via `attributeChangedCallback`. Note:
          // 1. this takes advantage of the fact that the callback is synchronous.
          // 2. will behave incorrectly if multiple attributes are in the reaction
          // stack at time of calling. However, since we process attributes
          // in `update` this should not be possible (or an extreme corner case
          // that we'd like to discover).
          // mark state reflecting
          this._updateState = this._updateState | STATE_IS_REFLECTING;

          if (attrValue === null) {
            this.removeAttribute(attr);
          } else {
            this.setAttribute(attr, attrValue);
          } // mark state not reflecting


          this._updateState = this._updateState & ~STATE_IS_REFLECTING;
        }
      }
    }

    _attributeToProperty(name, value) {
      // Use tracking info to avoid deserializing attribute value if it was
      // just set from a property setter.
      if (!(this._updateState & STATE_IS_REFLECTING)) {
        const ctor = this.constructor;

        const propName = ctor._attributeToPropertyMap.get(name);

        if (propName !== undefined) {
          const options = ctor._classProperties.get(propName);

          this[propName] = ctor._propertyValueFromAttribute(value, options);
        }
      }
    }
    /**
     * Requests an update which is processed asynchronously. This should
     * be called when an element should update based on some state not triggered
     * by setting a property. In this case, pass no arguments. It should also be
     * called when manually implementing a property setter. In this case, pass the
     * property `name` and `oldValue` to ensure that any configured property
     * options are honored. Returns the `updateComplete` Promise which is resolved
     * when the update completes.
     *
     * @param name {PropertyKey} (optional) name of requesting property
     * @param oldValue {any} (optional) old value of requesting property
     * @returns {Promise} A Promise that is resolved when the update completes.
     */


    requestUpdate(name, oldValue) {
      if (name !== undefined) {
        const options = this.constructor._classProperties.get(name) || defaultPropertyDeclaration;
        return this._requestPropertyUpdate(name, oldValue, options);
      }

      return this._invalidate();
    }
    /**
     * Requests an update for a specific property and records change information.
     * @param name {PropertyKey} name of requesting property
     * @param oldValue {any} old value of requesting property
     * @param options {PropertyDeclaration}
     */


    _requestPropertyUpdate(name, oldValue, options) {
      if (!this.constructor._valueHasChanged(this[name], oldValue, options.hasChanged)) {
        return this.updateComplete;
      } // track old value when changing.


      if (!this._changedProperties.has(name)) {
        this._changedProperties.set(name, oldValue);
      } // add to reflecting properties set


      if (options.reflect === true) {
        if (this._reflectingProperties === undefined) {
          this._reflectingProperties = new Map();
        }

        this._reflectingProperties.set(name, options);
      }

      return this._invalidate();
    }
    /**
     * Invalidates the element causing it to asynchronously update regardless
     * of whether or not any property changes are pending. This method is
     * automatically called when any registered property changes.
     */


    async _invalidate() {
      if (!this._hasRequestedUpdate) {
        // mark state updating...
        this._updateState = this._updateState | STATE_UPDATE_REQUESTED;
        let resolver;
        const previousValidatePromise = this._updatePromise;
        this._updatePromise = new Promise(r => resolver = r);
        await previousValidatePromise;

        this._validate();

        resolver(!this._hasRequestedUpdate);
      }

      return this.updateComplete;
    }

    get _hasRequestedUpdate() {
      return this._updateState & STATE_UPDATE_REQUESTED;
    }
    /**
     * Validates the element by updating it.
     */


    _validate() {
      // Mixin instance properties once, if they exist.
      if (this._instanceProperties) {
        this._applyInstanceProperties();
      }

      if (this.shouldUpdate(this._changedProperties)) {
        const changedProperties = this._changedProperties;
        this.update(changedProperties);

        this._markUpdated();

        if (!(this._updateState & STATE_HAS_UPDATED)) {
          this._updateState = this._updateState | STATE_HAS_UPDATED;
          this.firstUpdated(changedProperties);
        }

        this.updated(changedProperties);
      } else {
        this._markUpdated();
      }
    }

    _markUpdated() {
      this._changedProperties = new Map();
      this._updateState = this._updateState & ~STATE_UPDATE_REQUESTED;
    }
    /**
     * Returns a Promise that resolves when the element has completed updating.
     * The Promise value is a boolean that is `true` if the element completed the
     * update without triggering another update. The Promise result is `false` if
     * a property was set inside `updated()`. This getter can be implemented to
     * await additional state. For example, it is sometimes useful to await a
     * rendered element before fulfilling this Promise. To do this, first await
     * `super.updateComplete` then any subsequent state.
     *
     * @returns {Promise} The Promise returns a boolean that indicates if the
     * update resolved without triggering another update.
     */


    get updateComplete() {
      return this._updatePromise;
    }
    /**
     * Controls whether or not `update` should be called when the element requests
     * an update. By default, this method always returns `true`, but this can be
     * customized to control when to update.
     *
     * * @param _changedProperties Map of changed properties with old values
     */


    shouldUpdate(_changedProperties) {
      return true;
    }
    /**
     * Updates the element. This method reflects property values to attributes.
     * It can be overridden to render and keep updated DOM in the element's
     * `renderRoot`. Setting properties inside this method will *not* trigger
     * another update.
     *
     * * @param _changedProperties Map of changed properties with old values
     */


    update(_changedProperties) {
      if (this._reflectingProperties !== undefined && this._reflectingProperties.size > 0) {
        for (const [k, v] of this._reflectingProperties) {
          this._propertyToAttribute(k, this[k], v);
        }

        this._reflectingProperties = undefined;
      }
    }
    /**
     * Invoked whenever the element is updated. Implement to perform
     * post-updating tasks via DOM APIs, for example, focusing an element.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * * @param _changedProperties Map of changed properties with old values
     */


    updated(_changedProperties) {}
    /**
     * Invoked when the element is first updated. Implement to perform one time
     * work on the element after update.
     *
     * Setting properties inside this method will trigger the element to update
     * again after this update cycle completes.
     *
     * * @param _changedProperties Map of changed properties with old values
     */


    firstUpdated(_changedProperties) {}

  }
  /**
   * Maps attribute names to properties; for example `foobar` attribute
   * to `fooBar` property.
   */


  _exports.UpdatingElement$1 = _exports.UpdatingElement = UpdatingElement;
  UpdatingElement._attributeToPropertyMap = new Map();
  /**
   * Marks class as having finished creating properties.
   */

  UpdatingElement._finalized = true;
  /**
   * Memoized list of all class properties, including any superclass properties.
   */

  UpdatingElement._classProperties = new Map();
  UpdatingElement.properties = {};
  var updatingElement = {
    notEqual: notEqual,
    UpdatingElement: UpdatingElement
  };
  /**
   * @license
   * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
   * This code may only be used under the BSD style license found at
   * http://polymer.github.io/LICENSE.txt
   * The complete set of authors may be found at
   * http://polymer.github.io/AUTHORS.txt
   * The complete set of contributors may be found at
   * http://polymer.github.io/CONTRIBUTORS.txt
   * Code distributed by Google as part of the polymer project is also
   * subject to an additional IP rights grant found at
   * http://polymer.github.io/PATENTS.txt
   */

  /**
   * Class decorator factory that defines the decorated class as a custom element.
   *
   * @param tagName the name of the custom element to define
   *
   * In TypeScript, the `tagName` passed to `customElement` must be a key of the
   * `HTMLElementTagNameMap` interface. To add your element to the interface,
   * declare the interface in this module:
   *
   *     @customElement('my-element')
   *     export class MyElement extends LitElement {}
   *
   *     declare global {
   *       interface HTMLElementTagNameMap {
   *         'my-element': MyElement;
   *       }
   *     }
   *
   */

  _exports.$updatingElement = updatingElement;

  const customElement = tagName => clazz => {
    window.customElements.define(tagName, clazz); // Cast as any because TS doesn't recognize the return type as being a
    // subtype of the decorated class when clazz is typed as
    // `Constructor<HTMLElement>` for some reason. `Constructor<HTMLElement>`
    // is helpful to make sure the decorator is applied to elements however.

    return clazz;
  };
  /**
   * A property decorator which creates a LitElement property which reflects a
   * corresponding attribute value. A `PropertyDeclaration` may optionally be
   * supplied to configure property features.
   */


  _exports.customElement$1 = _exports.customElement = customElement;

  const property = options => (proto, name) => {
    proto.constructor.createProperty(name, options);
  };
  /**
   * A property decorator that converts a class property into a getter that
   * executes a querySelector on the element's renderRoot.
   */


  _exports.property$1 = _exports.property = property;

  const query = _query((target, selector) => target.querySelector(selector));
  /**
          * A property decorator that converts a class property into a getter
          * that executes a querySelectorAll on the element's renderRoot.
          */


  _exports.query$1 = _exports.query = query;

  const queryAll = _query((target, selector) => target.querySelectorAll(selector));
  /**
          * Base-implementation of `@query` and `@queryAll` decorators.
          *
          * @param queryFn exectute a `selector` (ie, querySelector or querySelectorAll)
          * against `target`.
          */


  _exports.queryAll$1 = _exports.queryAll = queryAll;

  function _query(queryFn) {
    return selector => (proto, propName) => {
      Object.defineProperty(proto, propName, {
        get() {
          return queryFn(this.renderRoot, selector);
        },

        enumerable: true,
        configurable: true
      });
    };
  }
  /**
   * Adds event listener options to a method used as an event listener in a
   * lit-html template.
   *
   * @param options An object that specifis event listener options as accepted by
   * `EventTarget#addEventListener` and `EventTarget#removeEventListener`.
   *
   * Current browsers support the `capture`, `passive`, and `once` options. See:
   * https://developer.mozilla.org/en-US/docs/Web/API/EventTarget/addEventListener#Parameters
   *
   * @example
   *
   *     class MyElement {
   *
   *       clicked = false;
   *
   *       render() {
   *         return html`<div @click=${this._onClick}`><button></button></div>`;
   *       }
   *
   *       @eventOptions({capture: true})
   *       _onClick(e) {
   *         this.clicked = true;
   *       }
   *     }
   */


  const eventOptions = options => (proto, name) => {
    // This comment is here to fix a disagreement between formatter and linter
    Object.assign(proto[name], options);
  };

  _exports.eventOptions$1 = _exports.eventOptions = eventOptions;
  var decorators = {
    customElement: customElement,
    property: property,
    query: query,
    queryAll: queryAll,
    eventOptions: eventOptions
  };
  _exports.$decorators = decorators;

  class LitElement extends UpdatingElement {
    /**
     * Updates the element. This method reflects property values to attributes
     * and calls `render` to render DOM via lit-html. Setting properties inside
     * this method will *not* trigger another update.
     * * @param _changedProperties Map of changed properties with old values
     */
    update(changedProperties) {
      super.update(changedProperties);
      const templateResult = this.render();

      if (templateResult instanceof TemplateResult) {
        this.constructor.render(templateResult, this.renderRoot, {
          scopeName: this.localName,
          eventContext: this
        });
      }
    }
    /**
     * Invoked on each update to perform rendering tasks. This method must return
     * a lit-html TemplateResult. Setting properties inside this method will *not*
     * trigger the element to update.
     * @returns {TemplateResult} Must return a lit-html TemplateResult.
     */


    render() {}

  }
  /**
   * Render method used to render the lit-html TemplateResult to the element's
   * DOM.
   * @param {TemplateResult} Template to render.
   * @param {Element|DocumentFragment} Node into which to render.
   * @param {String} Element name.
   */


  _exports.LitElement = LitElement;
  LitElement.render = render$2;
  var litElement = {
    LitElement: LitElement,
    notEqual: notEqual,
    UpdatingElement: UpdatingElement,
    customElement: customElement,
    property: property,
    query: query,
    queryAll: queryAll,
    eventOptions: eventOptions,
    html: html,
    svg: svg
  }; //import { LitElement, html} from '../../node_modules/@polymer/lit-element/lit-element.js';

  _exports.$litElement = litElement;

  class DevgamesPinSwitch extends LitElement {
    static get properties() {
      return {
        type: String,
        // gpio i OR gpio o OR adc OR pwm
        value: String,
        // 0\1 for GPIO or 0-255 for ADC and PWM. ReadOnly when GPI or ADC.
        reverse: Boolean,
        // reverses position of controls
        'no-adc': Boolean,
        // if we don't want ADC on that pin
        'no-pwm': Boolean // if we don't want PWM on that pin

      };
    }

    constructor() {
      super();
      this.type = 'gpio i';
      this.value = 'low';
    }
    /**
     * Define a template for the new element by implementing LitElement's
     * `render` function. `render` must return a lit-html TemplateResult.
     */


    render() {
      return html`
      <style>
        :host { display: block; }
        :host([hidden]) { display: none; }
        .container {
          display: flex;
          flex-direction: row;
          width: 159px; height: 35px;
          font-size: 17px;
        }
        .type, .value {
          width: 50%;
          margin: 0;
          box-sizing: border-box;
          text-align: center;
        }
        .type {
          border: 0;
          text-transform: uppercase;
          border-radius: 2px 0 0 2px;
          color: white;
        }
        .container--reverse .type {
          order: 1;
          border-radius: 0 2px 2px 0;
        }
        .type--red-bg {
          background-color: #D12F3E;
        }
        .type--green-bg {
          background-color: #6FB564;
        }
        .value {
          color: #323232;
          text-transform: capitalize;
          border: 1px solid #323232;
          border-width: 1px 1px 1px 0;
          border-radius: 0 2px 2px 0;
        }
        .container--reverse .value {
          border-width: 1px 0 1px 1px;
          border-radius: 2px 0 0 2px;
        }
        .value[value=high] {
          background-color: #323232;
          color: white;
        }
      </style>
      <div class="container ${this.reverse != null ? 'container--reverse' : ''}">
        <button class="type ${this._typeClass()}" @click="${this._typeSwitcher}">
          ${this.type}
        </button>
        <input class="value"
               type="${this._valueType()}"
               value="${this.value}"
               @change="${this._valueChange}"
               ?readonly="${this.type != 'pwm'}"
               @click="${this._valueClick}"
        />
      </div>
    `;
    }

    _typeClass() {
      switch (this.type) {
        case 'gpio i':
          return 'type--green-bg';

        case 'gpio o':
          return 'type--red-bg';

        default:
          return '';
      }
    }

    _valueType() {
      if (this.type == 'gpio i' || this.type == 'gpio o') {
        return 'text';
      } else if (this.type == 'adc' || this.type == 'pwm') {
        return 'number';
      }
    }

    _valueChange(e) {
      this.value = e.target.value;
    }

    _valueClick() {
      if (this.type != 'gpio o') return;
      if (this.value == 'low') this.value = 'high';else this.value = 'low';
    }

    _typeSwitcher() {
      if (this.type == 'gpio i') {
        this.type = 'gpio o';
      } else if (this.type == 'gpio o') {
        this.type = 'adc';

        if (this['no-adc'] != null && this['no-pwm'] == null) {
          this.type = 'pwm';
        } else if (this['no-adc'] != null) {
          this.type = 'gpio i';
        }
      } else if (this.type == 'adc') {
        this.type = 'pwm';
        if (this['no-pwm'] != null) this.type = 'gpio i';
      } else if (this.type == 'pwm') {
        this.type = 'gpio i';
      } // default value


      switch (this.type) {
        case 'gpio i':
        case 'gpio o':
          this.value = 'low';
          break;

        case 'adc':
        case 'pwm':
          this.value = '0';
          break;
      }
    }

  } // Register the element with the browser


  customElements.define('devgames-pin-switch', DevgamesPinSwitch);
  /**
  @license
  Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
  This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
  The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
  The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
  Code distributed by Google as part of the polymer project is also
  subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
  */

  /* eslint-disable no-unused-vars */

  /**
   * When using Closure Compiler, JSCompiler_renameProperty(property, object) is replaced by the munged name for object[property]
   * We cannot alias this function, so we have to use a small shim that has the same behavior when not compiling.
   *
   * @param {string} prop Property name
   * @param {?Object} obj Reference object
   * @return {string} Potentially renamed property name
   */

  window.JSCompiler_renameProperty = function (prop, obj) {
    return prop;
  };
  /* eslint-enable */


  function newSplice(index, removed, addedCount) {
    return {
      index: index,
      removed: removed,
      addedCount: addedCount
    };
  }

  const EDIT_LEAVE = 0;
  const EDIT_UPDATE = 1;
  const EDIT_ADD = 2;
  const EDIT_DELETE = 3; // Note: This function is *based* on the computation of the Levenshtein
  // "edit" distance. The one change is that "updates" are treated as two
  // edits - not one. With Array splices, an update is really a delete
  // followed by an add. By retaining this, we optimize for "keeping" the
  // maximum array items in the original array. For example:
  //
  //   'xxxx123' -> '123yyyy'
  //
  // With 1-edit updates, the shortest path would be just to update all seven
  // characters. With 2-edit updates, we delete 4, leave 3, and add 4. This
  // leaves the substring '123' intact.

  function calcEditDistances(current, currentStart, currentEnd, old, oldStart, oldEnd) {
    // "Deletion" columns
    let rowCount = oldEnd - oldStart + 1;
    let columnCount = currentEnd - currentStart + 1;
    let distances = new Array(rowCount); // "Addition" rows. Initialize null column.

    for (let i = 0; i < rowCount; i++) {
      distances[i] = new Array(columnCount);
      distances[i][0] = i;
    } // Initialize null row


    for (let j = 0; j < columnCount; j++) distances[0][j] = j;

    for (let i = 1; i < rowCount; i++) {
      for (let j = 1; j < columnCount; j++) {
        if (equals(current[currentStart + j - 1], old[oldStart + i - 1])) distances[i][j] = distances[i - 1][j - 1];else {
          let north = distances[i - 1][j] + 1;
          let west = distances[i][j - 1] + 1;
          distances[i][j] = north < west ? north : west;
        }
      }
    }

    return distances;
  } // This starts at the final weight, and walks "backward" by finding
  // the minimum previous weight recursively until the origin of the weight
  // matrix.


  function spliceOperationsFromEditDistances(distances) {
    let i = distances.length - 1;
    let j = distances[0].length - 1;
    let current = distances[i][j];
    let edits = [];

    while (i > 0 || j > 0) {
      if (i == 0) {
        edits.push(EDIT_ADD);
        j--;
        continue;
      }

      if (j == 0) {
        edits.push(EDIT_DELETE);
        i--;
        continue;
      }

      let northWest = distances[i - 1][j - 1];
      let west = distances[i - 1][j];
      let north = distances[i][j - 1];
      let min;
      if (west < north) min = west < northWest ? west : northWest;else min = north < northWest ? north : northWest;

      if (min == northWest) {
        if (northWest == current) {
          edits.push(EDIT_LEAVE);
        } else {
          edits.push(EDIT_UPDATE);
          current = northWest;
        }

        i--;
        j--;
      } else if (min == west) {
        edits.push(EDIT_DELETE);
        i--;
        current = west;
      } else {
        edits.push(EDIT_ADD);
        j--;
        current = north;
      }
    }

    edits.reverse();
    return edits;
  }
  /**
   * Splice Projection functions:
   *
   * A splice map is a representation of how a previous array of items
   * was transformed into a new array of items. Conceptually it is a list of
   * tuples of
   *
   *   <index, removed, addedCount>
   *
   * which are kept in ascending index order of. The tuple represents that at
   * the |index|, |removed| sequence of items were removed, and counting forward
   * from |index|, |addedCount| items were added.
   */

  /**
   * Lacking individual splice mutation information, the minimal set of
   * splices can be synthesized given the previous state and final state of an
   * array. The basic approach is to calculate the edit distance matrix and
   * choose the shortest path through it.
   *
   * Complexity: O(l * p)
   *   l: The length of the current array
   *   p: The length of the old array
   *
   * @param {!Array} current The current "changed" array for which to
   * calculate splices.
   * @param {number} currentStart Starting index in the `current` array for
   * which splices are calculated.
   * @param {number} currentEnd Ending index in the `current` array for
   * which splices are calculated.
   * @param {!Array} old The original "unchanged" array to compare `current`
   * against to determine splices.
   * @param {number} oldStart Starting index in the `old` array for
   * which splices are calculated.
   * @param {number} oldEnd Ending index in the `old` array for
   * which splices are calculated.
   * @return {!Array} Returns an array of splice record objects. Each of these
   * contains: `index` the location where the splice occurred; `removed`
   * the array of removed items from this location; `addedCount` the number
   * of items added at this location.
   */


  function calcSplices(current, currentStart, currentEnd, old, oldStart, oldEnd) {
    let prefixCount = 0;
    let suffixCount = 0;
    let splice;
    let minLength = Math.min(currentEnd - currentStart, oldEnd - oldStart);
    if (currentStart == 0 && oldStart == 0) prefixCount = sharedPrefix(current, old, minLength);
    if (currentEnd == current.length && oldEnd == old.length) suffixCount = sharedSuffix(current, old, minLength - prefixCount);
    currentStart += prefixCount;
    oldStart += prefixCount;
    currentEnd -= suffixCount;
    oldEnd -= suffixCount;
    if (currentEnd - currentStart == 0 && oldEnd - oldStart == 0) return [];

    if (currentStart == currentEnd) {
      splice = newSplice(currentStart, [], 0);

      while (oldStart < oldEnd) splice.removed.push(old[oldStart++]);

      return [splice];
    } else if (oldStart == oldEnd) return [newSplice(currentStart, [], currentEnd - currentStart)];

    let ops = spliceOperationsFromEditDistances(calcEditDistances(current, currentStart, currentEnd, old, oldStart, oldEnd));
    splice = undefined;
    let splices = [];
    let index = currentStart;
    let oldIndex = oldStart;

    for (let i = 0; i < ops.length; i++) {
      switch (ops[i]) {
        case EDIT_LEAVE:
          if (splice) {
            splices.push(splice);
            splice = undefined;
          }

          index++;
          oldIndex++;
          break;

        case EDIT_UPDATE:
          if (!splice) splice = newSplice(index, [], 0);
          splice.addedCount++;
          index++;
          splice.removed.push(old[oldIndex]);
          oldIndex++;
          break;

        case EDIT_ADD:
          if (!splice) splice = newSplice(index, [], 0);
          splice.addedCount++;
          index++;
          break;

        case EDIT_DELETE:
          if (!splice) splice = newSplice(index, [], 0);
          splice.removed.push(old[oldIndex]);
          oldIndex++;
          break;
      }
    }

    if (splice) {
      splices.push(splice);
    }

    return splices;
  }

  function sharedPrefix(current, old, searchLength) {
    for (let i = 0; i < searchLength; i++) if (!equals(current[i], old[i])) return i;

    return searchLength;
  }

  function sharedSuffix(current, old, searchLength) {
    let index1 = current.length;
    let index2 = old.length;
    let count = 0;

    while (count < searchLength && equals(current[--index1], old[--index2])) count++;

    return count;
  }
  /**
   * Returns an array of splice records indicating the minimum edits required
   * to transform the `previous` array into the `current` array.
   *
   * Splice records are ordered by index and contain the following fields:
   * - `index`: index where edit started
   * - `removed`: array of removed items from this index
   * - `addedCount`: number of items added at this index
   *
   * This function is based on the Levenshtein "minimum edit distance"
   * algorithm. Note that updates are treated as removal followed by addition.
   *
   * The worst-case time complexity of this algorithm is `O(l * p)`
   *   l: The length of the current array
   *   p: The length of the previous array
   *
   * However, the worst-case complexity is reduced by an `O(n)` optimization
   * to detect any shared prefix & suffix between the two arrays and only
   * perform the more expensive minimum edit distance calculation over the
   * non-shared portions of the arrays.
   *
   * @function
   * @param {!Array} current The "changed" array for which splices will be
   * calculated.
   * @param {!Array} previous The "unchanged" original array to compare
   * `current` against to determine the splices.
   * @return {!Array} Returns an array of splice record objects. Each of these
   * contains: `index` the location where the splice occurred; `removed`
   * the array of removed items from this location; `addedCount` the number
   * of items added at this location.
   */


  function calculateSplices(current, previous) {
    return calcSplices(current, 0, current.length, previous, 0, previous.length);
  }

  function equals(currentValue, previousValue) {
    return currentValue === previousValue;
  }

  var arraySplice = {
    calculateSplices: calculateSplices
  };
  _exports.$arraySplice = arraySplice;
  let microtaskCurrHandle = 0;
  let microtaskLastHandle = 0;
  let microtaskCallbacks = [];
  let microtaskNodeContent = 0;
  let microtaskNode = document.createTextNode('');
  new window.MutationObserver(microtaskFlush).observe(microtaskNode, {
    characterData: true
  });

  function microtaskFlush() {
    const len = microtaskCallbacks.length;

    for (let i = 0; i < len; i++) {
      let cb = microtaskCallbacks[i];

      if (cb) {
        try {
          cb();
        } catch (e) {
          setTimeout(() => {
            throw e;
          });
        }
      }
    }

    microtaskCallbacks.splice(0, len);
    microtaskLastHandle += len;
  }
  /**
   * Async interface wrapper around `setTimeout`.
   *
   * @namespace
   * @summary Async interface wrapper around `setTimeout`.
   */


  const timeOut = {
    /**
     * Returns a sub-module with the async interface providing the provided
     * delay.
     *
     * @memberof timeOut
     * @param {number=} delay Time to wait before calling callbacks in ms
     * @return {!AsyncInterface} An async timeout interface
     */
    after(delay) {
      return {
        run(fn) {
          return window.setTimeout(fn, delay);
        },

        cancel(handle) {
          window.clearTimeout(handle);
        }

      };
    },

    /**
     * Enqueues a function called in the next task.
     *
     * @memberof timeOut
     * @param {!Function} fn Callback to run
     * @param {number=} delay Delay in milliseconds
     * @return {number} Handle used for canceling task
     */
    run(fn, delay) {
      return window.setTimeout(fn, delay);
    },

    /**
     * Cancels a previously enqueued `timeOut` callback.
     *
     * @memberof timeOut
     * @param {number} handle Handle returned from `run` of callback to cancel
     * @return {void}
     */
    cancel(handle) {
      window.clearTimeout(handle);
    }

  };
  _exports.timeOut = timeOut;
  const animationFrame = {
    /**
     * Enqueues a function called at `requestAnimationFrame` timing.
     *
     * @memberof animationFrame
     * @param {function(number):void} fn Callback to run
     * @return {number} Handle used for canceling task
     */
    run(fn) {
      return window.requestAnimationFrame(fn);
    },

    /**
     * Cancels a previously enqueued `animationFrame` callback.
     *
     * @memberof animationFrame
     * @param {number} handle Handle returned from `run` of callback to cancel
     * @return {void}
     */
    cancel(handle) {
      window.cancelAnimationFrame(handle);
    }

  };
  _exports.animationFrame = animationFrame;
  const idlePeriod = {
    /**
     * Enqueues a function called at `requestIdleCallback` timing.
     *
     * @memberof idlePeriod
     * @param {function(!IdleDeadline):void} fn Callback to run
     * @return {number} Handle used for canceling task
     */
    run(fn) {
      return window.requestIdleCallback ? window.requestIdleCallback(fn) : window.setTimeout(fn, 16);
    },

    /**
     * Cancels a previously enqueued `idlePeriod` callback.
     *
     * @memberof idlePeriod
     * @param {number} handle Handle returned from `run` of callback to cancel
     * @return {void}
     */
    cancel(handle) {
      window.cancelIdleCallback ? window.cancelIdleCallback(handle) : window.clearTimeout(handle);
    }

  };
  _exports.idlePeriod = idlePeriod;
  const microTask = {
    /**
     * Enqueues a function called at microtask timing.
     *
     * @memberof microTask
     * @param {!Function=} callback Callback to run
     * @return {number} Handle used for canceling task
     */
    run(callback) {
      microtaskNode.textContent = microtaskNodeContent++;
      microtaskCallbacks.push(callback);
      return microtaskCurrHandle++;
    },

    /**
     * Cancels a previously enqueued `microTask` callback.
     *
     * @memberof microTask
     * @param {number} handle Handle returned from `run` of callback to cancel
     * @return {void}
     */
    cancel(handle) {
      const idx = handle - microtaskLastHandle;

      if (idx >= 0) {
        if (!microtaskCallbacks[idx]) {
          throw new Error('invalid async handle: ' + handle);
        }

        microtaskCallbacks[idx] = null;
      }
    }

  };
  _exports.microTask = microTask;
  var async = {
    timeOut: timeOut,
    animationFrame: animationFrame,
    idlePeriod: idlePeriod,
    microTask: microTask
  };
  _exports.$async = async;

  function isSlot(node) {
    return node.localName === 'slot';
  }
  /**
   * Class that listens for changes (additions or removals) to
   * "flattened nodes" on a given `node`. The list of flattened nodes consists
   * of a node's children and, for any children that are `<slot>` elements,
   * the expanded flattened list of `assignedNodes`.
   * For example, if the observed node has children `<a></a><slot></slot><b></b>`
   * and the `<slot>` has one `<div>` assigned to it, then the flattened
   * nodes list is `<a></a><div></div><b></b>`. If the `<slot>` has other
   * `<slot>` elements assigned to it, these are flattened as well.
   *
   * The provided `callback` is called whenever any change to this list
   * of flattened nodes occurs, where an addition or removal of a node is
   * considered a change. The `callback` is called with one argument, an object
   * containing an array of any `addedNodes` and `removedNodes`.
   *
   * Note: the callback is called asynchronous to any changes
   * at a microtask checkpoint. This is because observation is performed using
   * `MutationObserver` and the `<slot>` element's `slotchange` event which
   * are asynchronous.
   *
   * An example:
   * ```js
   * class TestSelfObserve extends PolymerElement {
   *   static get is() { return 'test-self-observe';}
   *   connectedCallback() {
   *     super.connectedCallback();
   *     this._observer = new FlattenedNodesObserver(this, (info) => {
   *       this.info = info;
   *     });
   *   }
   *   disconnectedCallback() {
   *     super.disconnectedCallback();
   *     this._observer.disconnect();
   *   }
   * }
   * customElements.define(TestSelfObserve.is, TestSelfObserve);
   * ```
   *
   * @summary Class that listens for changes (additions or removals) to
   * "flattened nodes" on a given `node`.
   */


  class FlattenedNodesObserver {
    /**
     * Returns the list of flattened nodes for the given `node`.
     * This list consists of a node's children and, for any children
     * that are `<slot>` elements, the expanded flattened list of `assignedNodes`.
     * For example, if the observed node has children `<a></a><slot></slot><b></b>`
     * and the `<slot>` has one `<div>` assigned to it, then the flattened
     * nodes list is `<a></a><div></div><b></b>`. If the `<slot>` has other
     * `<slot>` elements assigned to it, these are flattened as well.
     *
     * @param {!HTMLElement|!HTMLSlotElement} node The node for which to
     *      return the list of flattened nodes.
     * @return {!Array<!Node>} The list of flattened nodes for the given `node`.
     * @nocollapse See https://github.com/google/closure-compiler/issues/2763
     */
    static getFlattenedNodes(node) {
      if (isSlot(node)) {
        node =
        /** @type {!HTMLSlotElement} */
        node; // eslint-disable-line no-self-assign

        return node.assignedNodes({
          flatten: true
        });
      } else {
        return Array.from(node.childNodes).map(node => {
          if (isSlot(node)) {
            node =
            /** @type {!HTMLSlotElement} */
            node; // eslint-disable-line no-self-assign

            return node.assignedNodes({
              flatten: true
            });
          } else {
            return [node];
          }
        }).reduce((a, b) => a.concat(b), []);
      }
    }
    /**
     * @param {!HTMLElement} target Node on which to listen for changes.
     * @param {?function(this: Element, { target: !HTMLElement, addedNodes: !Array<!Element>, removedNodes: !Array<!Element> }):void} callback Function called when there are additions
     * or removals from the target's list of flattened nodes.
     */


    constructor(target, callback) {
      /**
       * @type {MutationObserver}
       * @private
       */
      this._shadyChildrenObserver = null;
      /**
       * @type {MutationObserver}
       * @private
       */

      this._nativeChildrenObserver = null;
      this._connected = false;
      /**
       * @type {!HTMLElement}
       * @private
       */

      this._target = target;
      this.callback = callback;
      this._effectiveNodes = [];
      this._observer = null;
      this._scheduled = false;
      /**
       * @type {function()}
       * @private
       */

      this._boundSchedule = () => {
        this._schedule();
      };

      this.connect();

      this._schedule();
    }
    /**
     * Activates an observer. This method is automatically called when
     * a `FlattenedNodesObserver` is created. It should only be called to
     * re-activate an observer that has been deactivated via the `disconnect` method.
     *
     * @return {void}
     */


    connect() {
      if (isSlot(this._target)) {
        this._listenSlots([this._target]);
      } else if (this._target.children) {
        this._listenSlots(
        /** @type {!NodeList<!Node>} */
        this._target.children);

        if (window.ShadyDOM) {
          this._shadyChildrenObserver = ShadyDOM.observeChildren(this._target, mutations => {
            this._processMutations(mutations);
          });
        } else {
          this._nativeChildrenObserver = new MutationObserver(mutations => {
            this._processMutations(mutations);
          });

          this._nativeChildrenObserver.observe(this._target, {
            childList: true
          });
        }
      }

      this._connected = true;
    }
    /**
     * Deactivates the flattened nodes observer. After calling this method
     * the observer callback will not be called when changes to flattened nodes
     * occur. The `connect` method may be subsequently called to reactivate
     * the observer.
     *
     * @return {void}
     */


    disconnect() {
      if (isSlot(this._target)) {
        this._unlistenSlots([this._target]);
      } else if (this._target.children) {
        this._unlistenSlots(
        /** @type {!NodeList<!Node>} */
        this._target.children);

        if (window.ShadyDOM && this._shadyChildrenObserver) {
          ShadyDOM.unobserveChildren(this._shadyChildrenObserver);
          this._shadyChildrenObserver = null;
        } else if (this._nativeChildrenObserver) {
          this._nativeChildrenObserver.disconnect();

          this._nativeChildrenObserver = null;
        }
      }

      this._connected = false;
    }
    /**
     * @return {void}
     * @private
     */


    _schedule() {
      if (!this._scheduled) {
        this._scheduled = true;
        microTask.run(() => this.flush());
      }
    }
    /**
     * @param {Array<MutationRecord>} mutations Mutations signaled by the mutation observer
     * @return {void}
     * @private
     */


    _processMutations(mutations) {
      this._processSlotMutations(mutations);

      this.flush();
    }
    /**
     * @param {Array<MutationRecord>} mutations Mutations signaled by the mutation observer
     * @return {void}
     * @private
     */


    _processSlotMutations(mutations) {
      if (mutations) {
        for (let i = 0; i < mutations.length; i++) {
          let mutation = mutations[i];

          if (mutation.addedNodes) {
            this._listenSlots(mutation.addedNodes);
          }

          if (mutation.removedNodes) {
            this._unlistenSlots(mutation.removedNodes);
          }
        }
      }
    }
    /**
     * Flushes the observer causing any pending changes to be immediately
     * delivered the observer callback. By default these changes are delivered
     * asynchronously at the next microtask checkpoint.
     *
     * @return {boolean} Returns true if any pending changes caused the observer
     * callback to run.
     */


    flush() {
      if (!this._connected) {
        return false;
      }

      if (window.ShadyDOM) {
        ShadyDOM.flush();
      }

      if (this._nativeChildrenObserver) {
        this._processSlotMutations(this._nativeChildrenObserver.takeRecords());
      } else if (this._shadyChildrenObserver) {
        this._processSlotMutations(this._shadyChildrenObserver.takeRecords());
      }

      this._scheduled = false;
      let info = {
        target: this._target,
        addedNodes: [],
        removedNodes: []
      };
      let newNodes = this.constructor.getFlattenedNodes(this._target);
      let splices = calculateSplices(newNodes, this._effectiveNodes); // process removals

      for (let i = 0, s; i < splices.length && (s = splices[i]); i++) {
        for (let j = 0, n; j < s.removed.length && (n = s.removed[j]); j++) {
          info.removedNodes.push(n);
        }
      } // process adds


      for (let i = 0, s; i < splices.length && (s = splices[i]); i++) {
        for (let j = s.index; j < s.index + s.addedCount; j++) {
          info.addedNodes.push(newNodes[j]);
        }
      } // update cache


      this._effectiveNodes = newNodes;
      let didFlush = false;

      if (info.addedNodes.length || info.removedNodes.length) {
        didFlush = true;
        this.callback.call(this._target, info);
      }

      return didFlush;
    }
    /**
     * @param {!Array<!Node>|!NodeList<!Node>} nodeList Nodes that could change
     * @return {void}
     * @private
     */


    _listenSlots(nodeList) {
      for (let i = 0; i < nodeList.length; i++) {
        let n = nodeList[i];

        if (isSlot(n)) {
          n.addEventListener('slotchange', this._boundSchedule);
        }
      }
    }
    /**
     * @param {!Array<!Node>|!NodeList<!Node>} nodeList Nodes that could change
     * @return {void}
     * @private
     */


    _unlistenSlots(nodeList) {
      for (let i = 0; i < nodeList.length; i++) {
        let n = nodeList[i];

        if (isSlot(n)) {
          n.removeEventListener('slotchange', this._boundSchedule);
        }
      }
    }

  }

  _exports.FlattenedNodesObserver = FlattenedNodesObserver;
  var flattenedNodesObserver = {
    FlattenedNodesObserver: FlattenedNodesObserver
  };
  _exports.$flattenedNodesObserver = flattenedNodesObserver;

  const getPlatform = function () {
    let userAgent = navigator.userAgent || navigator.vendor || window.opera; // Windows Phone must come first because its UA also contains "Android"

    if (/windows phone/i.test(userAgent)) {
      return 'windows-phone';
    }

    if (/android/i.test(userAgent)) {
      return 'android';
    } // iOS detection from: http://stackoverflow.com/a/9039885/177710


    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      return 'ios';
    }

    return 'unknown';
  };

  _exports.getPlatform$2 = getPlatform;
  var morphElement = {
    getPlatform: getPlatform
  };
  _exports.$morphElement$2 = morphElement;

  class MorphListView extends LitElement {
    render() {
      return html`
      <style>
        :host {
          display: block;
          margin-bottom: 35px;
        }

        :host .container ::slotted(morph-list-view-item) {
          margin-bottom: 0;
        }

        :host .container ::slotted(morph-list-view-item:not(:first-of-type)) {
          --display-top-line: none;
        }

        :host .container ::slotted(morph-list-view-item:not(:last-of-type)) {
          --display-bottom-line: none;
          --display-inner-item-bottom-line: block;
        }

        /* this is fading the inner line in and out using opacity */
        :host .container ::slotted(morph-list-view-item[expanded]:not(:last-of-type)) {
          --sub-container-after-opacity: 0;
        }
      </style>

      <div class="container">
        <slot id="slot"></slot>
      </div>
    `;
    }

    static get is() {
      return 'morph-list-view';
    }

    static get properties() {
      return {
        platform: {
          type: String,
          reflect: true
        },
        accordion: {
          type: Boolean
        }
      };
    }
    /**
     * LitElement lifecycle called once just before first updated() is called
     */


    firstUpdated() {
      super.firstUpdated(); // check for platform if already set in HTML markup before auto detecting platform using getPlatform and assigning new value

      if (!this.hasAttribute('platform')) {
        this.platform = getPlatform();
      }

      this._observer = new FlattenedNodesObserver(this, info => {
        this._processNewNodes(info.addedNodes);
      }); // Flush function needs to be added in order to have changes delivered immediately

      this._observer.flush();
    }

    disconnectedCallback() {
      super.disconnectedCallback();

      this._observer.disconnect();
    }
    /**
     * Process children of morph list view component.
     * check nodes of morph-list-view-item and attach click event listeners if they are expandable items
     * @param {Object } nodes
     */


    _processNewNodes(nodes) {
      if (this.accordion != true) return;

      for (var i = 0; i < nodes.length; i++) {
        // get all the child nodes that are list items
        if (nodes[i].nodeName == 'MORPH-LIST-VIEW-ITEM') {
          var viewItem = nodes[i];

          if (viewItem.hasAttribute('expandable')) {
            viewItem.addEventListener('click', e => this._listViewItemClickHandler(e));
          }
        }
      }
    }
    /**
    *  Goes through all non-target item and the expanded attribute if any. This closes open expandable item when a new one is clicked.
    */


    _listViewItemClickHandler(e) {
      for (var i = 0; i < this.querySelectorAll('morph-list-view-item').length; i++) {
        // remove expanded attribute from all other items except the one most recently clicked
        if (this.querySelectorAll('morph-list-view-item')[i] != e.target) {
          this.querySelectorAll('morph-list-view-item')[i].removeAttribute('expanded');
        }
      }
    }

  }

  _exports.MorphListView = MorphListView;
  window.customElements.define(MorphListView.is, MorphListView);
  var morphListView = {
    MorphListView: MorphListView
  };
  _exports.$morphListView = morphListView;
  const ifDefined = directive(value => part => {
    if (value === undefined && part instanceof AttributePart) {
      if (value !== part.value) {
        const name = part.committer.name;
        part.committer.element.removeAttribute(name);
      }
    } else {
      part.setValue(value);
    }
  });
  _exports.ifDefined = ifDefined;
  var ifDefined$1 = {
    ifDefined: ifDefined
  };
  _exports.$ifDefined = ifDefined$1;

  const getPlatform$1 = function () {
    let userAgent = navigator.userAgent || navigator.vendor || window.opera; // Windows Phone must come first because its UA also contains "Android"

    if (/windows phone/i.test(userAgent)) {
      return 'windows-phone';
    }

    if (/android/i.test(userAgent)) {
      return 'android';
    } // iOS detection from: http://stackoverflow.com/a/9039885/177710


    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      return 'ios';
    }

    return 'unknown';
  };

  _exports.getPlatform$1 = getPlatform$1;
  var morphElement$1 = {
    getPlatform: getPlatform$1
  };
  _exports.$morphElement$1 = morphElement$1;
  let CSS_URL_RX = /(url\()([^)]*)(\))/g;
  let ABS_URL = /(^\/)|(^#)|(^[\w-\d]*:)/;
  let workingURL;
  let resolveDoc;
  /**
   * Resolves the given URL against the provided `baseUri'.
   *
   * Note that this function performs no resolution for URLs that start
   * with `/` (absolute URLs) or `#` (hash identifiers).  For general purpose
   * URL resolution, use `window.URL`.
   *
   * @param {string} url Input URL to resolve
   * @param {?string=} baseURI Base URI to resolve the URL against
   * @return {string} resolved URL
   */

  function resolveUrl(url, baseURI) {
    if (url && ABS_URL.test(url)) {
      return url;
    } // Lazy feature detection.


    if (workingURL === undefined) {
      workingURL = false;

      try {
        const u = new URL('b', 'http://a');
        u.pathname = 'c%20d';
        workingURL = u.href === 'http://a/c%20d';
      } catch (e) {// silently fail
      }
    }

    if (!baseURI) {
      baseURI = document.baseURI || window.location.href;
    }

    if (workingURL) {
      return new URL(url, baseURI).href;
    } // Fallback to creating an anchor into a disconnected document.


    if (!resolveDoc) {
      resolveDoc = document.implementation.createHTMLDocument('temp');
      resolveDoc.base = resolveDoc.createElement('base');
      resolveDoc.head.appendChild(resolveDoc.base);
      resolveDoc.anchor = resolveDoc.createElement('a');
      resolveDoc.body.appendChild(resolveDoc.anchor);
    }

    resolveDoc.base.href = baseURI;
    resolveDoc.anchor.href = url;
    return resolveDoc.anchor.href || url;
  }
  /**
   * Resolves any relative URL's in the given CSS text against the provided
   * `ownerDocument`'s `baseURI`.
   *
   * @param {string} cssText CSS text to process
   * @param {string} baseURI Base URI to resolve the URL against
   * @return {string} Processed CSS text with resolved URL's
   */


  function resolveCss(cssText, baseURI) {
    return cssText.replace(CSS_URL_RX, function (m, pre, url, post) {
      return pre + '\'' + resolveUrl(url.replace(/["']/g, ''), baseURI) + '\'' + post;
    });
  }
  /**
   * Returns a path from a given `url`. The path includes the trailing
   * `/` from the url.
   *
   * @param {string} url Input URL to transform
   * @return {string} resolved path
   */


  function pathFromUrl(url) {
    return url.substring(0, url.lastIndexOf('/') + 1);
  }

  var resolveUrl$1 = {
    resolveUrl: resolveUrl,
    resolveCss: resolveCss,
    pathFromUrl: pathFromUrl
  };
  _exports.$resolveUrl = resolveUrl$1;
  const useShadow = !window.ShadyDOM;
  _exports.useShadow = useShadow;
  const useNativeCSSProperties = Boolean(!window.ShadyCSS || window.ShadyCSS.nativeCss);
  _exports.useNativeCSSProperties = useNativeCSSProperties;
  const useNativeCustomElements = !window.customElements.polyfillWrapFlushCallback;
  /**
          * Globally settable property that is automatically assigned to
          * `ElementMixin` instances, useful for binding in templates to
          * make URL's relative to an application's root.  Defaults to the main
          * document URL, but can be overridden by users.  It may be useful to set
          * `rootPath` to provide a stable application mount path when
          * using client side routing.
          */

  _exports.useNativeCustomElements = useNativeCustomElements;
  let rootPath = undefined || pathFromUrl(document.baseURI || window.location.href);
  /**
          * Sets the global rootPath property used by `ElementMixin` and
          * available via `rootPath`.
          *
          * @param {string} path The new root path
          * @return {void}
          */

  _exports.rootPath = rootPath;

  const setRootPath = function (path) {
    _exports.rootPath = rootPath = path;
  };
  /**
   * A global callback used to sanitize any value before inserting it into the DOM.
   * The callback signature is:
   *
   *  function sanitizeDOMValue(value, name, type, node) { ... }
   *
   * Where:
   *
   * `value` is the value to sanitize.
   * `name` is the name of an attribute or property (for example, href).
   * `type` indicates where the value is being inserted: one of property, attribute, or text.
   * `node` is the node where the value is being inserted.
   *
   * @type {(function(*,string,string,Node):*)|undefined}
   */


  _exports.setRootPath = setRootPath;
  let sanitizeDOMValue = window.Polymer && window.Polymer.sanitizeDOMValue || undefined;
  /**
          * Sets the global sanitizeDOMValue available via this module's exported
          * `sanitizeDOMValue` variable.
          *
          * @param {(function(*,string,string,Node):*)|undefined} newSanitizeDOMValue the global sanitizeDOMValue callback
          * @return {void}
          */

  _exports.sanitizeDOMValue = sanitizeDOMValue;

  const setSanitizeDOMValue = function (newSanitizeDOMValue) {
    _exports.sanitizeDOMValue = sanitizeDOMValue = newSanitizeDOMValue;
  };
  /**
   * Globally settable property to make Polymer Gestures use passive TouchEvent listeners when recognizing gestures.
   * When set to `true`, gestures made from touch will not be able to prevent scrolling, allowing for smoother
   * scrolling performance.
   * Defaults to `false` for backwards compatibility.
   */


  _exports.setSanitizeDOMValue = setSanitizeDOMValue;
  let passiveTouchGestures = false;
  /**
          * Sets `passiveTouchGestures` globally for all elements using Polymer Gestures.
          *
          * @param {boolean} usePassive enable or disable passive touch gestures globally
          * @return {void}
          */

  _exports.passiveTouchGestures = passiveTouchGestures;

  const setPassiveTouchGestures = function (usePassive) {
    _exports.passiveTouchGestures = passiveTouchGestures = usePassive;
  };
  /**
   * Setting to ensure Polymer template evaluation only occurs based on tempates
   * defined in trusted script.  When true, `<dom-module>` re-registration is
   * disallowed, `<dom-bind>` is disabled, and `<dom-if>`/`<dom-repeat>`
   * templates will only evaluate in the context of a trusted element template.
   */


  _exports.setPassiveTouchGestures = setPassiveTouchGestures;
  let strictTemplatePolicy = false;
  /**
          * Sets `strictTemplatePolicy` globally for all elements
          *
          * @param {boolean} useStrictPolicy enable or disable strict template policy
          *   globally
          * @return {void}
          */

  _exports.strictTemplatePolicy = strictTemplatePolicy;

  const setStrictTemplatePolicy = function (useStrictPolicy) {
    _exports.strictTemplatePolicy = strictTemplatePolicy = useStrictPolicy;
  };
  /**
   * Setting to enable dom-module lookup from Polymer.Element.  By default,
   * templates must be defined in script using the `static get template()`
   * getter and the `html` tag function.  To enable legacy loading of templates
   * via dom-module, set this flag to true.
   */


  _exports.setStrictTemplatePolicy = setStrictTemplatePolicy;
  let allowTemplateFromDomModule = false;
  /**
          * Sets `lookupTemplateFromDomModule` globally for all elements
          *
          * @param {boolean} allowDomModule enable or disable template lookup 
          *   globally
          * @return {void}
          */

  _exports.allowTemplateFromDomModule = allowTemplateFromDomModule;

  const setAllowTemplateFromDomModule = function (allowDomModule) {
    _exports.allowTemplateFromDomModule = allowTemplateFromDomModule = allowDomModule;
  };

  _exports.setAllowTemplateFromDomModule = setAllowTemplateFromDomModule;
  var settings = {
    useShadow: useShadow,
    useNativeCSSProperties: useNativeCSSProperties,
    useNativeCustomElements: useNativeCustomElements,

    get rootPath() {
      return rootPath;
    },

    setRootPath: setRootPath,

    get sanitizeDOMValue() {
      return sanitizeDOMValue;
    },

    setSanitizeDOMValue: setSanitizeDOMValue,

    get passiveTouchGestures() {
      return passiveTouchGestures;
    },

    setPassiveTouchGestures: setPassiveTouchGestures,

    get strictTemplatePolicy() {
      return strictTemplatePolicy;
    },

    setStrictTemplatePolicy: setStrictTemplatePolicy,

    get allowTemplateFromDomModule() {
      return allowTemplateFromDomModule;
    },

    setAllowTemplateFromDomModule: setAllowTemplateFromDomModule
  };
  _exports.$settings = settings;
  let dedupeId = 0;
  /**
   * @constructor
   * @extends {Function}
   * @private
   */

  function MixinFunction() {}
  /** @type {(WeakMap | undefined)} */


  MixinFunction.prototype.__mixinApplications;
  /** @type {(Object | undefined)} */

  MixinFunction.prototype.__mixinSet;
  /* eslint-disable valid-jsdoc */

  /**
   * Wraps an ES6 class expression mixin such that the mixin is only applied
   * if it has not already been applied its base argument. Also memoizes mixin
   * applications.
   *
   * @template T
   * @param {T} mixin ES6 class expression mixin to wrap
   * @return {T}
   * @suppress {invalidCasts}
   */

  const dedupingMixin = function (mixin) {
    let mixinApplications =
    /** @type {!MixinFunction} */
    mixin.__mixinApplications;

    if (!mixinApplications) {
      mixinApplications = new WeakMap();
      /** @type {!MixinFunction} */

      mixin.__mixinApplications = mixinApplications;
    } // maintain a unique id for each mixin


    let mixinDedupeId = dedupeId++;

    function dedupingMixin(base) {
      let baseSet =
      /** @type {!MixinFunction} */
      base.__mixinSet;

      if (baseSet && baseSet[mixinDedupeId]) {
        return base;
      }

      let map = mixinApplications;
      let extended = map.get(base);

      if (!extended) {
        extended =
        /** @type {!Function} */
        mixin(base);
        map.set(base, extended);
      } // copy inherited mixin set from the extended class, or the base class
      // NOTE: we avoid use of Set here because some browser (IE11)
      // cannot extend a base Set via the constructor.


      let mixinSet = Object.create(
      /** @type {!MixinFunction} */
      extended.__mixinSet || baseSet || null);
      mixinSet[mixinDedupeId] = true;
      /** @type {!MixinFunction} */

      extended.__mixinSet = mixinSet;
      return extended;
    }

    return dedupingMixin;
  };
  /* eslint-enable valid-jsdoc */


  _exports.dedupingMixin = dedupingMixin;
  var mixin = {
    dedupingMixin: dedupingMixin
  };
  _exports.$mixin = mixin;
  let modules = {};
  let lcModules = {};
  /**
   * Sets a dom-module into the global registry by id.
   *
   * @param {string} id dom-module id
   * @param {DomModule} module dom-module instance
   * @return {void}
   */

  function setModule(id, module) {
    // store id separate from lowercased id so that
    // in all cases mixedCase id will stored distinctly
    // and lowercase version is a fallback
    modules[id] = lcModules[id.toLowerCase()] = module;
  }
  /**
   * Retrieves a dom-module from the global registry by id.
   *
   * @param {string} id dom-module id
   * @return {DomModule!} dom-module instance
   */


  function findModule(id) {
    return modules[id] || lcModules[id.toLowerCase()];
  }

  function styleOutsideTemplateCheck(inst) {
    if (inst.querySelector('style')) {
      console.warn('dom-module %s has style outside template', inst.id);
    }
  }
  /**
   * The `dom-module` element registers the dom it contains to the name given
   * by the module's id attribute. It provides a unified database of dom
   * accessible via its static `import` API.
   *
   * A key use case of `dom-module` is for providing custom element `<template>`s
   * via HTML imports that are parsed by the native HTML parser, that can be
   * relocated during a bundling pass and still looked up by `id`.
   *
   * Example:
   *
   *     <dom-module id="foo">
   *       <img src="stuff.png">
   *     </dom-module>
   *
   * Then in code in some other location that cannot access the dom-module above
   *
   *     let img = customElements.get('dom-module').import('foo', 'img');
   *
   * @customElement
   * @extends HTMLElement
   * @summary Custom element that provides a registry of relocatable DOM content
   *   by `id` that is agnostic to bundling.
   * @unrestricted
   */


  class DomModule extends HTMLElement {
    static get observedAttributes() {
      return ['id'];
    }
    /**
     * Retrieves the element specified by the css `selector` in the module
     * registered by `id`. For example, this.import('foo', 'img');
     * @param {string} id The id of the dom-module in which to search.
     * @param {string=} selector The css selector by which to find the element.
     * @return {Element} Returns the element which matches `selector` in the
     * module registered at the specified `id`.
     *
     * @export
     * @nocollapse Referred to indirectly in style-gather.js
     */


    static import(id, selector) {
      if (id) {
        let m = findModule(id);

        if (m && selector) {
          return m.querySelector(selector);
        }

        return m;
      }

      return null;
    }
    /* eslint-disable no-unused-vars */

    /**
     * @param {string} name Name of attribute.
     * @param {?string} old Old value of attribute.
     * @param {?string} value Current value of attribute.
     * @param {?string} namespace Attribute namespace.
     * @return {void}
     * @override
     */


    attributeChangedCallback(name, old, value, namespace) {
      if (old !== value) {
        this.register();
      }
    }
    /* eslint-enable no-unused-args */

    /**
     * The absolute URL of the original location of this `dom-module`.
     *
     * This value will differ from this element's `ownerDocument` in the
     * following ways:
     * - Takes into account any `assetpath` attribute added during bundling
     *   to indicate the original location relative to the bundled location
     * - Uses the HTMLImports polyfill's `importForElement` API to ensure
     *   the path is relative to the import document's location since
     *   `ownerDocument` is not currently polyfilled
     */


    get assetpath() {
      // Don't override existing assetpath.
      if (!this.__assetpath) {
        // note: assetpath set via an attribute must be relative to this
        // element's location; accomodate polyfilled HTMLImports
        const owner = window.HTMLImports && HTMLImports.importForElement ? HTMLImports.importForElement(this) || document : this.ownerDocument;
        const url = resolveUrl(this.getAttribute('assetpath') || '', owner.baseURI);
        this.__assetpath = pathFromUrl(url);
      }

      return this.__assetpath;
    }
    /**
     * Registers the dom-module at a given id. This method should only be called
     * when a dom-module is imperatively created. For
     * example, `document.createElement('dom-module').register('foo')`.
     * @param {string=} id The id at which to register the dom-module.
     * @return {void}
     */


    register(id) {
      id = id || this.id;

      if (id) {
        // Under strictTemplatePolicy, reject and null out any re-registered
        // dom-module since it is ambiguous whether first-in or last-in is trusted
        if (strictTemplatePolicy && findModule(id) !== undefined) {
          setModule(id, null);
          throw new Error(`strictTemplatePolicy: dom-module ${id} re-registered`);
        }

        this.id = id;
        setModule(id, this);
        styleOutsideTemplateCheck(this);
      }
    }

  }

  _exports.DomModule = DomModule;
  DomModule.prototype['modules'] = modules;
  customElements.define('dom-module', DomModule);
  var domModule = {
    DomModule: DomModule
  };
  _exports.$domModule = domModule;
  const MODULE_STYLE_LINK_SELECTOR = 'link[rel=import][type~=css]';
  const INCLUDE_ATTR = 'include';
  const SHADY_UNSCOPED_ATTR = 'shady-unscoped';
  /**
   * @param {string} moduleId .
   * @return {?DomModule} .
   */

  function importModule(moduleId) {
    return (
      /** @type {?DomModule} */
      DomModule.import(moduleId)
    );
  }

  function styleForImport(importDoc) {
    // NOTE: polyfill affordance.
    // under the HTMLImports polyfill, there will be no 'body',
    // but the import pseudo-doc can be used directly.
    let container = importDoc.body ? importDoc.body : importDoc;
    const importCss = resolveCss(container.textContent, importDoc.baseURI);
    const style = document.createElement('style');
    style.textContent = importCss;
    return style;
  }
  /** @typedef {{assetpath: string}} */


  let templateWithAssetPath; // eslint-disable-line no-unused-vars

  /**
   * Returns a list of <style> elements in a space-separated list of `dom-module`s.
   *
   * @function
   * @param {string} moduleIds List of dom-module id's within which to
   * search for css.
   * @return {!Array<!HTMLStyleElement>} Array of contained <style> elements
   */

  function stylesFromModules(moduleIds) {
    const modules = moduleIds.trim().split(/\s+/);
    const styles = [];

    for (let i = 0; i < modules.length; i++) {
      styles.push(...stylesFromModule(modules[i]));
    }

    return styles;
  }
  /**
   * Returns a list of <style> elements in a given `dom-module`.
   * Styles in a `dom-module` can come either from `<style>`s within the
   * first `<template>`, or else from one or more
   * `<link rel="import" type="css">` links outside the template.
   *
   * @param {string} moduleId dom-module id to gather styles from
   * @return {!Array<!HTMLStyleElement>} Array of contained styles.
   */


  function stylesFromModule(moduleId) {
    const m = importModule(moduleId);

    if (!m) {
      console.warn('Could not find style data in module named', moduleId);
      return [];
    }

    if (m._styles === undefined) {
      const styles = []; // module imports: <link rel="import" type="css">

      styles.push(..._stylesFromModuleImports(m)); // include css from the first template in the module

      const template =
      /** @type {?HTMLTemplateElement} */
      m.querySelector('template');

      if (template) {
        styles.push(...stylesFromTemplate(template,
        /** @type {templateWithAssetPath} */
        m.assetpath));
      }

      m._styles = styles;
    }

    return m._styles;
  }
  /**
   * Returns the `<style>` elements within a given template.
   *
   * @param {!HTMLTemplateElement} template Template to gather styles from
   * @param {string} baseURI baseURI for style content
   * @return {!Array<!HTMLStyleElement>} Array of styles
   */


  function stylesFromTemplate(template, baseURI) {
    if (!template._styles) {
      const styles = []; // if element is a template, get content from its .content

      const e$ = template.content.querySelectorAll('style');

      for (let i = 0; i < e$.length; i++) {
        let e = e$[i]; // support style sharing by allowing styles to "include"
        // other dom-modules that contain styling

        let include = e.getAttribute(INCLUDE_ATTR);

        if (include) {
          styles.push(...stylesFromModules(include).filter(function (item, index, self) {
            return self.indexOf(item) === index;
          }));
        }

        if (baseURI) {
          e.textContent = resolveCss(e.textContent, baseURI);
        }

        styles.push(e);
      }

      template._styles = styles;
    }

    return template._styles;
  }
  /**
   * Returns a list of <style> elements  from stylesheets loaded via `<link rel="import" type="css">` links within the specified `dom-module`.
   *
   * @param {string} moduleId Id of `dom-module` to gather CSS from
   * @return {!Array<!HTMLStyleElement>} Array of contained styles.
   */


  function stylesFromModuleImports(moduleId) {
    let m = importModule(moduleId);
    return m ? _stylesFromModuleImports(m) : [];
  }
  /**
   * @param {!HTMLElement} module dom-module element that could contain `<link rel="import" type="css">` styles
   * @return {!Array<!HTMLStyleElement>} Array of contained styles
   */


  function _stylesFromModuleImports(module) {
    const styles = [];
    const p$ = module.querySelectorAll(MODULE_STYLE_LINK_SELECTOR);

    for (let i = 0; i < p$.length; i++) {
      let p = p$[i];

      if (p.import) {
        const importDoc = p.import;
        const unscoped = p.hasAttribute(SHADY_UNSCOPED_ATTR);

        if (unscoped && !importDoc._unscopedStyle) {
          const style = styleForImport(importDoc);
          style.setAttribute(SHADY_UNSCOPED_ATTR, '');
          importDoc._unscopedStyle = style;
        } else if (!importDoc._style) {
          importDoc._style = styleForImport(importDoc);
        }

        styles.push(unscoped ? importDoc._unscopedStyle : importDoc._style);
      }
    }

    return styles;
  }
  /**
   *
   * Returns CSS text of styles in a space-separated list of `dom-module`s.
   * Note: This method is deprecated, use `stylesFromModules` instead.
   *
   * @deprecated
   * @param {string} moduleIds List of dom-module id's within which to
   * search for css.
   * @return {string} Concatenated CSS content from specified `dom-module`s
   */


  function cssFromModules(moduleIds) {
    let modules = moduleIds.trim().split(/\s+/);
    let cssText = '';

    for (let i = 0; i < modules.length; i++) {
      cssText += cssFromModule(modules[i]);
    }

    return cssText;
  }
  /**
   * Returns CSS text of styles in a given `dom-module`.  CSS in a `dom-module`
   * can come either from `<style>`s within the first `<template>`, or else
   * from one or more `<link rel="import" type="css">` links outside the
   * template.
   *
   * Any `<styles>` processed are removed from their original location.
   * Note: This method is deprecated, use `styleFromModule` instead.
   *
   * @deprecated
   * @param {string} moduleId dom-module id to gather styles from
   * @return {string} Concatenated CSS content from specified `dom-module`
   */


  function cssFromModule(moduleId) {
    let m = importModule(moduleId);

    if (m && m._cssText === undefined) {
      // module imports: <link rel="import" type="css">
      let cssText = _cssFromModuleImports(m); // include css from the first template in the module


      let t =
      /** @type {?HTMLTemplateElement} */
      m.querySelector('template');

      if (t) {
        cssText += cssFromTemplate(t,
        /** @type {templateWithAssetPath} */
        m.assetpath);
      }

      m._cssText = cssText || null;
    }

    if (!m) {
      console.warn('Could not find style data in module named', moduleId);
    }

    return m && m._cssText || '';
  }
  /**
   * Returns CSS text of `<styles>` within a given template.
   *
   * Any `<styles>` processed are removed from their original location.
   * Note: This method is deprecated, use `styleFromTemplate` instead.
   *
   * @deprecated
   * @param {!HTMLTemplateElement} template Template to gather styles from
   * @param {string} baseURI Base URI to resolve the URL against
   * @return {string} Concatenated CSS content from specified template
   */


  function cssFromTemplate(template, baseURI) {
    let cssText = '';
    const e$ = stylesFromTemplate(template, baseURI); // if element is a template, get content from its .content

    for (let i = 0; i < e$.length; i++) {
      let e = e$[i];

      if (e.parentNode) {
        e.parentNode.removeChild(e);
      }

      cssText += e.textContent;
    }

    return cssText;
  }
  /**
   * Returns CSS text from stylesheets loaded via `<link rel="import" type="css">`
   * links within the specified `dom-module`.
   *
   * Note: This method is deprecated, use `stylesFromModuleImports` instead.
   *
   * @deprecated
   *
   * @param {string} moduleId Id of `dom-module` to gather CSS from
   * @return {string} Concatenated CSS content from links in specified `dom-module`
   */


  function cssFromModuleImports(moduleId) {
    let m = importModule(moduleId);
    return m ? _cssFromModuleImports(m) : '';
  }
  /**
   * @deprecated
   * @param {!HTMLElement} module dom-module element that could contain `<link rel="import" type="css">` styles
   * @return {string} Concatenated CSS content from links in the dom-module
   */


  function _cssFromModuleImports(module) {
    let cssText = '';

    let styles = _stylesFromModuleImports(module);

    for (let i = 0; i < styles.length; i++) {
      cssText += styles[i].textContent;
    }

    return cssText;
  }

  var styleGather = {
    stylesFromModules: stylesFromModules,
    stylesFromModule: stylesFromModule,
    stylesFromTemplate: stylesFromTemplate,
    stylesFromModuleImports: stylesFromModuleImports,
    cssFromModules: cssFromModules,
    cssFromModule: cssFromModule,
    cssFromTemplate: cssFromTemplate,
    cssFromModuleImports: cssFromModuleImports
  };
  _exports.$styleGather = styleGather;

  function isPath(path) {
    return path.indexOf('.') >= 0;
  }
  /**
   * Returns the root property name for the given path.
   *
   * Example:
   *
   * ```
   * root('foo.bar.baz') // 'foo'
   * root('foo')         // 'foo'
   * ```
   *
   * @param {string} path Path string
   * @return {string} Root property name
   */


  function root(path) {
    let dotIndex = path.indexOf('.');

    if (dotIndex === -1) {
      return path;
    }

    return path.slice(0, dotIndex);
  }
  /**
   * Given `base` is `foo.bar`, `foo` is an ancestor, `foo.bar` is not
   * Returns true if the given path is an ancestor of the base path.
   *
   * Example:
   *
   * ```
   * isAncestor('foo.bar', 'foo')         // true
   * isAncestor('foo.bar', 'foo.bar')     // false
   * isAncestor('foo.bar', 'foo.bar.baz') // false
   * ```
   *
   * @param {string} base Path string to test against.
   * @param {string} path Path string to test.
   * @return {boolean} True if `path` is an ancestor of `base`.
   */


  function isAncestor(base, path) {
    //     base.startsWith(path + '.');
    return base.indexOf(path + '.') === 0;
  }
  /**
   * Given `base` is `foo.bar`, `foo.bar.baz` is an descendant
   *
   * Example:
   *
   * ```
   * isDescendant('foo.bar', 'foo.bar.baz') // true
   * isDescendant('foo.bar', 'foo.bar')     // false
   * isDescendant('foo.bar', 'foo')         // false
   * ```
   *
   * @param {string} base Path string to test against.
   * @param {string} path Path string to test.
   * @return {boolean} True if `path` is a descendant of `base`.
   */


  function isDescendant(base, path) {
    //     path.startsWith(base + '.');
    return path.indexOf(base + '.') === 0;
  }
  /**
   * Replaces a previous base path with a new base path, preserving the
   * remainder of the path.
   *
   * User must ensure `path` has a prefix of `base`.
   *
   * Example:
   *
   * ```
   * translate('foo.bar', 'zot', 'foo.bar.baz') // 'zot.baz'
   * ```
   *
   * @param {string} base Current base string to remove
   * @param {string} newBase New base string to replace with
   * @param {string} path Path to translate
   * @return {string} Translated string
   */


  function translate(base, newBase, path) {
    return newBase + path.slice(base.length);
  }
  /**
   * @param {string} base Path string to test against
   * @param {string} path Path string to test
   * @return {boolean} True if `path` is equal to `base`
   */


  function matches(base, path) {
    return base === path || isAncestor(base, path) || isDescendant(base, path);
  }
  /**
   * Converts array-based paths to flattened path.  String-based paths
   * are returned as-is.
   *
   * Example:
   *
   * ```
   * normalize(['foo.bar', 0, 'baz'])  // 'foo.bar.0.baz'
   * normalize('foo.bar.0.baz')        // 'foo.bar.0.baz'
   * ```
   *
   * @param {string | !Array<string|number>} path Input path
   * @return {string} Flattened path
   */


  function normalize(path) {
    if (Array.isArray(path)) {
      let parts = [];

      for (let i = 0; i < path.length; i++) {
        let args = path[i].toString().split('.');

        for (let j = 0; j < args.length; j++) {
          parts.push(args[j]);
        }
      }

      return parts.join('.');
    } else {
      return path;
    }
  }
  /**
   * Splits a path into an array of property names. Accepts either arrays
   * of path parts or strings.
   *
   * Example:
   *
   * ```
   * split(['foo.bar', 0, 'baz'])  // ['foo', 'bar', '0', 'baz']
   * split('foo.bar.0.baz')        // ['foo', 'bar', '0', 'baz']
   * ```
   *
   * @param {string | !Array<string|number>} path Input path
   * @return {!Array<string>} Array of path parts
   * @suppress {checkTypes}
   */


  function split(path) {
    if (Array.isArray(path)) {
      return normalize(path).split('.');
    }

    return path.toString().split('.');
  }
  /**
   * Reads a value from a path.  If any sub-property in the path is `undefined`,
   * this method returns `undefined` (will never throw.
   *
   * @param {Object} root Object from which to dereference path from
   * @param {string | !Array<string|number>} path Path to read
   * @param {Object=} info If an object is provided to `info`, the normalized
   *  (flattened) path will be set to `info.path`.
   * @return {*} Value at path, or `undefined` if the path could not be
   *  fully dereferenced.
   */


  function get(root, path, info) {
    let prop = root;
    let parts = split(path); // Loop over path parts[0..n-1] and dereference

    for (let i = 0; i < parts.length; i++) {
      if (!prop) {
        return;
      }

      let part = parts[i];
      prop = prop[part];
    }

    if (info) {
      info.path = parts.join('.');
    }

    return prop;
  }
  /**
   * Sets a value to a path.  If any sub-property in the path is `undefined`,
   * this method will no-op.
   *
   * @param {Object} root Object from which to dereference path from
   * @param {string | !Array<string|number>} path Path to set
   * @param {*} value Value to set to path
   * @return {string | undefined} The normalized version of the input path
   */


  function set(root, path, value) {
    let prop = root;
    let parts = split(path);
    let last = parts[parts.length - 1];

    if (parts.length > 1) {
      // Loop over path parts[0..n-2] and dereference
      for (let i = 0; i < parts.length - 1; i++) {
        let part = parts[i];
        prop = prop[part];

        if (!prop) {
          return;
        }
      } // Set value to object at end of path


      prop[last] = value;
    } else {
      // Simple property set
      prop[path] = value;
    }

    return parts.join('.');
  }
  /**
   * Returns true if the given string is a structured data path (has dots).
   *
   * This function is deprecated.  Use `isPath` instead.
   *
   * Example:
   *
   * ```
   * isDeep('foo.bar.baz') // true
   * isDeep('foo')         // false
   * ```
   *
   * @deprecated
   * @param {string} path Path string
   * @return {boolean} True if the string contained one or more dots
   */


  const isDeep = isPath;
  _exports.isDeep = isDeep;
  var path = {
    isPath: isPath,
    root: root,
    isAncestor: isAncestor,
    isDescendant: isDescendant,
    translate: translate,
    matches: matches,
    normalize: normalize,
    split: split,
    get: get,
    set: set,
    isDeep: isDeep
  };
  _exports.$path = path;
  const caseMap = {};
  const DASH_TO_CAMEL = /-[a-z]/g;
  const CAMEL_TO_DASH = /([A-Z])/g;
  /**
   * @fileoverview Module with utilities for converting between "dash-case" and
   * "camelCase" identifiers.
   */

  /**
   * Converts "dash-case" identifier (e.g. `foo-bar-baz`) to "camelCase"
   * (e.g. `fooBarBaz`).
   *
   * @param {string} dash Dash-case identifier
   * @return {string} Camel-case representation of the identifier
   */

  function dashToCamelCase(dash) {
    return caseMap[dash] || (caseMap[dash] = dash.indexOf('-') < 0 ? dash : dash.replace(DASH_TO_CAMEL, m => m[1].toUpperCase()));
  }
  /**
   * Converts "camelCase" identifier (e.g. `fooBarBaz`) to "dash-case"
   * (e.g. `foo-bar-baz`).
   *
   * @param {string} camel Camel-case identifier
   * @return {string} Dash-case representation of the identifier
   */


  function camelToDashCase(camel) {
    return caseMap[camel] || (caseMap[camel] = camel.replace(CAMEL_TO_DASH, '-$1').toLowerCase());
  }

  var caseMap$1 = {
    dashToCamelCase: dashToCamelCase,
    camelToDashCase: camelToDashCase
  };
  _exports.$caseMap = caseMap$1;
  const microtask = microTask;
  /**
   * Element class mixin that provides basic meta-programming for creating one
   * or more property accessors (getter/setter pair) that enqueue an async
   * (batched) `_propertiesChanged` callback.
   *
   * For basic usage of this mixin, call `MyClass.createProperties(props)`
   * once at class definition time to create property accessors for properties
   * named in props, implement `_propertiesChanged` to react as desired to
   * property changes, and implement `static get observedAttributes()` and
   * include lowercase versions of any property names that should be set from
   * attributes. Last, call `this._enableProperties()` in the element's
   * `connectedCallback` to enable the accessors.
   *
   * @mixinFunction
   * @polymer
   * @summary Element class mixin for reacting to property changes from
   *   generated property accessors.
   */

  const PropertiesChanged = dedupingMixin(
  /**
          * @template T
          * @param {function(new:T)} superClass Class to apply mixin to.
          * @return {function(new:T)} superClass with mixin applied.
          */
  superClass => {
    /**
     * @polymer
     * @mixinClass
     * @implements {Polymer_PropertiesChanged}
     * @unrestricted
     */
    class PropertiesChanged extends superClass {
      /**
       * Creates property accessors for the given property names.
       * @param {!Object} props Object whose keys are names of accessors.
       * @return {void}
       * @protected
       */
      static createProperties(props) {
        const proto = this.prototype;

        for (let prop in props) {
          // don't stomp an existing accessor
          if (!(prop in proto)) {
            proto._createPropertyAccessor(prop);
          }
        }
      }
      /**
       * Returns an attribute name that corresponds to the given property.
       * The attribute name is the lowercased property name. Override to
       * customize this mapping.
       * @param {string} property Property to convert
       * @return {string} Attribute name corresponding to the given property.
       *
       * @protected
       */


      static attributeNameForProperty(property) {
        return property.toLowerCase();
      }
      /**
       * Override point to provide a type to which to deserialize a value to
       * a given property.
       * @param {string} name Name of property
       *
       * @protected
       */


      static typeForProperty(name) {} //eslint-disable-line no-unused-vars

      /**
       * Creates a setter/getter pair for the named property with its own
       * local storage.  The getter returns the value in the local storage,
       * and the setter calls `_setProperty`, which updates the local storage
       * for the property and enqueues a `_propertiesChanged` callback.
       *
       * This method may be called on a prototype or an instance.  Calling
       * this method may overwrite a property value that already exists on
       * the prototype/instance by creating the accessor.
       *
       * @param {string} property Name of the property
       * @param {boolean=} readOnly When true, no setter is created; the
       *   protected `_setProperty` function must be used to set the property
       * @return {void}
       * @protected
       * @override
       */


      _createPropertyAccessor(property, readOnly) {
        this._addPropertyToAttributeMap(property);

        if (!this.hasOwnProperty('__dataHasAccessor')) {
          this.__dataHasAccessor = Object.assign({}, this.__dataHasAccessor);
        }

        if (!this.__dataHasAccessor[property]) {
          this.__dataHasAccessor[property] = true;

          this._definePropertyAccessor(property, readOnly);
        }
      }
      /**
       * Adds the given `property` to a map matching attribute names
       * to property names, using `attributeNameForProperty`. This map is
       * used when deserializing attribute values to properties.
       *
       * @param {string} property Name of the property
       * @override
       */


      _addPropertyToAttributeMap(property) {
        if (!this.hasOwnProperty('__dataAttributes')) {
          this.__dataAttributes = Object.assign({}, this.__dataAttributes);
        }

        if (!this.__dataAttributes[property]) {
          const attr = this.constructor.attributeNameForProperty(property);
          this.__dataAttributes[attr] = property;
        }
      }
      /**
       * Defines a property accessor for the given property.
       * @param {string} property Name of the property
       * @param {boolean=} readOnly When true, no setter is created
       * @return {void}
       * @override
       */


      _definePropertyAccessor(property, readOnly) {
        Object.defineProperty(this, property, {
          /* eslint-disable valid-jsdoc */

          /** @this {PropertiesChanged} */
          get() {
            return this._getProperty(property);
          },

          /** @this {PropertiesChanged} */
          set: readOnly ? function () {} : function (value) {
            this._setProperty(property, value);
          }
          /* eslint-enable */

        });
      }

      constructor() {
        super();
        this.__dataEnabled = false;
        this.__dataReady = false;
        this.__dataInvalid = false;
        this.__data = {};
        this.__dataPending = null;
        this.__dataOld = null;
        this.__dataInstanceProps = null;
        this.__serializing = false;

        this._initializeProperties();
      }
      /**
       * Lifecycle callback called when properties are enabled via
       * `_enableProperties`.
       *
       * Users may override this function to implement behavior that is
       * dependent on the element having its property data initialized, e.g.
       * from defaults (initialized from `constructor`, `_initializeProperties`),
       * `attributeChangedCallback`, or values propagated from host e.g. via
       * bindings.  `super.ready()` must be called to ensure the data system
       * becomes enabled.
       *
       * @return {void}
       * @public
       * @override
       */


      ready() {
        this.__dataReady = true;

        this._flushProperties();
      }
      /**
       * Initializes the local storage for property accessors.
       *
       * Provided as an override point for performing any setup work prior
       * to initializing the property accessor system.
       *
       * @return {void}
       * @protected
       * @override
       */


      _initializeProperties() {
        // Capture instance properties; these will be set into accessors
        // during first flush. Don't set them here, since we want
        // these to overwrite defaults/constructor assignments
        for (let p in this.__dataHasAccessor) {
          if (this.hasOwnProperty(p)) {
            this.__dataInstanceProps = this.__dataInstanceProps || {};
            this.__dataInstanceProps[p] = this[p];
            delete this[p];
          }
        }
      }
      /**
       * Called at ready time with bag of instance properties that overwrote
       * accessors when the element upgraded.
       *
       * The default implementation sets these properties back into the
       * setter at ready time.  This method is provided as an override
       * point for customizing or providing more efficient initialization.
       *
       * @param {Object} props Bag of property values that were overwritten
       *   when creating property accessors.
       * @return {void}
       * @protected
       * @override
       */


      _initializeInstanceProperties(props) {
        Object.assign(this, props);
      }
      /**
       * Updates the local storage for a property (via `_setPendingProperty`)
       * and enqueues a `_proeprtiesChanged` callback.
       *
       * @param {string} property Name of the property
       * @param {*} value Value to set
       * @return {void}
       * @protected
       * @override
       */


      _setProperty(property, value) {
        if (this._setPendingProperty(property, value)) {
          this._invalidateProperties();
        }
      }
      /**
       * Returns the value for the given property.
       * @param {string} property Name of property
       * @return {*} Value for the given property
       * @protected
       * @override
       */


      _getProperty(property) {
        return this.__data[property];
      }
      /* eslint-disable no-unused-vars */

      /**
       * Updates the local storage for a property, records the previous value,
       * and adds it to the set of "pending changes" that will be passed to the
       * `_propertiesChanged` callback.  This method does not enqueue the
       * `_propertiesChanged` callback.
       *
       * @param {string} property Name of the property
       * @param {*} value Value to set
       * @param {boolean=} ext Not used here; affordance for closure
       * @return {boolean} Returns true if the property changed
       * @protected
       * @override
       */


      _setPendingProperty(property, value, ext) {
        let old = this.__data[property];

        let changed = this._shouldPropertyChange(property, value, old);

        if (changed) {
          if (!this.__dataPending) {
            this.__dataPending = {};
            this.__dataOld = {};
          } // Ensure old is captured from the last turn


          if (this.__dataOld && !(property in this.__dataOld)) {
            this.__dataOld[property] = old;
          }

          this.__data[property] = value;
          this.__dataPending[property] = value;
        }

        return changed;
      }
      /* eslint-enable */

      /**
       * Marks the properties as invalid, and enqueues an async
       * `_propertiesChanged` callback.
       *
       * @return {void}
       * @protected
       * @override
       */


      _invalidateProperties() {
        if (!this.__dataInvalid && this.__dataReady) {
          this.__dataInvalid = true;
          microtask.run(() => {
            if (this.__dataInvalid) {
              this.__dataInvalid = false;

              this._flushProperties();
            }
          });
        }
      }
      /**
       * Call to enable property accessor processing. Before this method is
       * called accessor values will be set but side effects are
       * queued. When called, any pending side effects occur immediately.
       * For elements, generally `connectedCallback` is a normal spot to do so.
       * It is safe to call this method multiple times as it only turns on
       * property accessors once.
       *
       * @return {void}
       * @protected
       * @override
       */


      _enableProperties() {
        if (!this.__dataEnabled) {
          this.__dataEnabled = true;

          if (this.__dataInstanceProps) {
            this._initializeInstanceProperties(this.__dataInstanceProps);

            this.__dataInstanceProps = null;
          }

          this.ready();
        }
      }
      /**
       * Calls the `_propertiesChanged` callback with the current set of
       * pending changes (and old values recorded when pending changes were
       * set), and resets the pending set of changes. Generally, this method
       * should not be called in user code.
       *
       * @return {void}
       * @protected
       * @override
       */


      _flushProperties() {
        const props = this.__data;
        const changedProps = this.__dataPending;
        const old = this.__dataOld;

        if (this._shouldPropertiesChange(props, changedProps, old)) {
          this.__dataPending = null;
          this.__dataOld = null;

          this._propertiesChanged(props, changedProps, old);
        }
      }
      /**
       * Called in `_flushProperties` to determine if `_propertiesChanged`
       * should be called. The default implementation returns true if
       * properties are pending. Override to customize when
       * `_propertiesChanged` is called.
       * @param {!Object} currentProps Bag of all current accessor values
       * @param {?Object} changedProps Bag of properties changed since the last
       *   call to `_propertiesChanged`
       * @param {?Object} oldProps Bag of previous values for each property
       *   in `changedProps`
       * @return {boolean} true if changedProps is truthy
       * @override
       */


      _shouldPropertiesChange(currentProps, changedProps, oldProps) {
        // eslint-disable-line no-unused-vars
        return Boolean(changedProps);
      }
      /**
       * Callback called when any properties with accessors created via
       * `_createPropertyAccessor` have been set.
       *
       * @param {!Object} currentProps Bag of all current accessor values
       * @param {?Object} changedProps Bag of properties changed since the last
       *   call to `_propertiesChanged`
       * @param {?Object} oldProps Bag of previous values for each property
       *   in `changedProps`
       * @return {void}
       * @protected
       * @override
       */


      _propertiesChanged(currentProps, changedProps, oldProps) {} // eslint-disable-line no-unused-vars

      /**
       * Method called to determine whether a property value should be
       * considered as a change and cause the `_propertiesChanged` callback
       * to be enqueued.
       *
       * The default implementation returns `true` if a strict equality
       * check fails. The method always returns false for `NaN`.
       *
       * Override this method to e.g. provide stricter checking for
       * Objects/Arrays when using immutable patterns.
       *
       * @param {string} property Property name
       * @param {*} value New property value
       * @param {*} old Previous property value
       * @return {boolean} Whether the property should be considered a change
       *   and enqueue a `_proeprtiesChanged` callback
       * @protected
       * @override
       */


      _shouldPropertyChange(property, value, old) {
        return (// Strict equality check
          old !== value && ( // This ensures (old==NaN, value==NaN) always returns false
          old === old || value === value)
        );
      }
      /**
       * Implements native Custom Elements `attributeChangedCallback` to
       * set an attribute value to a property via `_attributeToProperty`.
       *
       * @param {string} name Name of attribute that changed
       * @param {?string} old Old attribute value
       * @param {?string} value New attribute value
       * @param {?string} namespace Attribute namespace.
       * @return {void}
       * @suppress {missingProperties} Super may or may not implement the callback
       * @override
       */


      attributeChangedCallback(name, old, value, namespace) {
        if (old !== value) {
          this._attributeToProperty(name, value);
        }

        if (super.attributeChangedCallback) {
          super.attributeChangedCallback(name, old, value, namespace);
        }
      }
      /**
       * Deserializes an attribute to its associated property.
       *
       * This method calls the `_deserializeValue` method to convert the string to
       * a typed value.
       *
       * @param {string} attribute Name of attribute to deserialize.
       * @param {?string} value of the attribute.
       * @param {*=} type type to deserialize to, defaults to the value
       * returned from `typeForProperty`
       * @return {void}
       * @override
       */


      _attributeToProperty(attribute, value, type) {
        if (!this.__serializing) {
          const map = this.__dataAttributes;
          const property = map && map[attribute] || attribute;
          this[property] = this._deserializeValue(value, type || this.constructor.typeForProperty(property));
        }
      }
      /**
       * Serializes a property to its associated attribute.
       *
       * @suppress {invalidCasts} Closure can't figure out `this` is an element.
       *
       * @param {string} property Property name to reflect.
       * @param {string=} attribute Attribute name to reflect to.
       * @param {*=} value Property value to refect.
       * @return {void}
       * @override
       */


      _propertyToAttribute(property, attribute, value) {
        this.__serializing = true;
        value = arguments.length < 3 ? this[property] : value;

        this._valueToNodeAttribute(
        /** @type {!HTMLElement} */
        this, value, attribute || this.constructor.attributeNameForProperty(property));

        this.__serializing = false;
      }
      /**
       * Sets a typed value to an HTML attribute on a node.
       *
       * This method calls the `_serializeValue` method to convert the typed
       * value to a string.  If the `_serializeValue` method returns `undefined`,
       * the attribute will be removed (this is the default for boolean
       * type `false`).
       *
       * @param {Element} node Element to set attribute to.
       * @param {*} value Value to serialize.
       * @param {string} attribute Attribute name to serialize to.
       * @return {void}
       * @override
       */


      _valueToNodeAttribute(node, value, attribute) {
        const str = this._serializeValue(value);

        if (str === undefined) {
          node.removeAttribute(attribute);
        } else {
          node.setAttribute(attribute, str);
        }
      }
      /**
       * Converts a typed JavaScript value to a string.
       *
       * This method is called when setting JS property values to
       * HTML attributes.  Users may override this method to provide
       * serialization for custom types.
       *
       * @param {*} value Property value to serialize.
       * @return {string | undefined} String serialized from the provided
       * property  value.
       * @override
       */


      _serializeValue(value) {
        switch (typeof value) {
          case 'boolean':
            return value ? '' : undefined;

          default:
            return value != null ? value.toString() : undefined;
        }
      }
      /**
       * Converts a string to a typed JavaScript value.
       *
       * This method is called when reading HTML attribute values to
       * JS properties.  Users may override this method to provide
       * deserialization for custom `type`s. Types for `Boolean`, `String`,
       * and `Number` convert attributes to the expected types.
       *
       * @param {?string} value Value to deserialize.
       * @param {*=} type Type to deserialize the string to.
       * @return {*} Typed value deserialized from the provided string.
       * @override
       */


      _deserializeValue(value, type) {
        switch (type) {
          case Boolean:
            return value !== null;

          case Number:
            return Number(value);

          default:
            return value;
        }
      }

    }

    return PropertiesChanged;
  });
  _exports.PropertiesChanged = PropertiesChanged;
  var propertiesChanged = {
    PropertiesChanged: PropertiesChanged
  }; // that won't have their values "saved" by `saveAccessorValue`, since
  // reading from an HTMLElement accessor from the context of a prototype throws

  _exports.$propertiesChanged = propertiesChanged;
  const nativeProperties = {};
  let proto = HTMLElement.prototype;

  while (proto) {
    let props = Object.getOwnPropertyNames(proto);

    for (let i = 0; i < props.length; i++) {
      nativeProperties[props[i]] = true;
    }

    proto = Object.getPrototypeOf(proto);
  }
  /**
   * Used to save the value of a property that will be overridden with
   * an accessor. If the `model` is a prototype, the values will be saved
   * in `__dataProto`, and it's up to the user (or downstream mixin) to
   * decide how/when to set these values back into the accessors.
   * If `model` is already an instance (it has a `__data` property), then
   * the value will be set as a pending property, meaning the user should
   * call `_invalidateProperties` or `_flushProperties` to take effect
   *
   * @param {Object} model Prototype or instance
   * @param {string} property Name of property
   * @return {void}
   * @private
   */


  function saveAccessorValue(model, property) {
    // Don't read/store value for any native properties since they could throw
    if (!nativeProperties[property]) {
      let value = model[property];

      if (value !== undefined) {
        if (model.__data) {
          // Adding accessor to instance; update the property
          // It is the user's responsibility to call _flushProperties
          model._setPendingProperty(property, value);
        } else {
          // Adding accessor to proto; save proto's value for instance-time use
          if (!model.__dataProto) {
            model.__dataProto = {};
          } else if (!model.hasOwnProperty(JSCompiler_renameProperty('__dataProto', model))) {
            model.__dataProto = Object.create(model.__dataProto);
          }

          model.__dataProto[property] = value;
        }
      }
    }
  }
  /**
   * Element class mixin that provides basic meta-programming for creating one
   * or more property accessors (getter/setter pair) that enqueue an async
   * (batched) `_propertiesChanged` callback.
   *
   * For basic usage of this mixin:
   *
   * -   Declare attributes to observe via the standard `static get observedAttributes()`. Use
   *     `dash-case` attribute names to represent `camelCase` property names.
   * -   Implement the `_propertiesChanged` callback on the class.
   * -   Call `MyClass.createPropertiesForAttributes()` **once** on the class to generate
   *     property accessors for each observed attribute. This must be called before the first
   *     instance is created, for example, by calling it before calling `customElements.define`.
   *     It can also be called lazily from the element's `constructor`, as long as it's guarded so
   *     that the call is only made once, when the first instance is created.
   * -   Call `this._enableProperties()` in the element's `connectedCallback` to enable
   *     the accessors.
   *
   * Any `observedAttributes` will automatically be
   * deserialized via `attributeChangedCallback` and set to the associated
   * property using `dash-case`-to-`camelCase` convention.
   *
   * @mixinFunction
   * @polymer
   * @appliesMixin PropertiesChanged
   * @summary Element class mixin for reacting to property changes from
   *   generated property accessors.
   */


  const PropertyAccessors = dedupingMixin(superClass => {
    /**
     * @constructor
     * @extends {superClass}
     * @implements {Polymer_PropertiesChanged}
     * @unrestricted
     * @private
     */
    const base = PropertiesChanged(superClass);
    /**
     * @polymer
     * @mixinClass
     * @implements {Polymer_PropertyAccessors}
     * @extends {base}
     * @unrestricted
     */

    class PropertyAccessors extends base {
      /**
       * Generates property accessors for all attributes in the standard
       * static `observedAttributes` array.
       *
       * Attribute names are mapped to property names using the `dash-case` to
       * `camelCase` convention
       *
       * @return {void}
       */
      static createPropertiesForAttributes() {
        let a$ = this.observedAttributes;

        for (let i = 0; i < a$.length; i++) {
          this.prototype._createPropertyAccessor(dashToCamelCase(a$[i]));
        }
      }
      /**
       * Returns an attribute name that corresponds to the given property.
       * By default, converts camel to dash case, e.g. `fooBar` to `foo-bar`.
       * @param {string} property Property to convert
       * @return {string} Attribute name corresponding to the given property.
       *
       * @protected
       */


      static attributeNameForProperty(property) {
        return camelToDashCase(property);
      }
      /**
       * Overrides PropertiesChanged implementation to initialize values for
       * accessors created for values that already existed on the element
       * prototype.
       *
       * @return {void}
       * @protected
       */


      _initializeProperties() {
        if (this.__dataProto) {
          this._initializeProtoProperties(this.__dataProto);

          this.__dataProto = null;
        }

        super._initializeProperties();
      }
      /**
       * Called at instance time with bag of properties that were overwritten
       * by accessors on the prototype when accessors were created.
       *
       * The default implementation sets these properties back into the
       * setter at instance time.  This method is provided as an override
       * point for customizing or providing more efficient initialization.
       *
       * @param {Object} props Bag of property values that were overwritten
       *   when creating property accessors.
       * @return {void}
       * @protected
       */


      _initializeProtoProperties(props) {
        for (let p in props) {
          this._setProperty(p, props[p]);
        }
      }
      /**
       * Ensures the element has the given attribute. If it does not,
       * assigns the given value to the attribute.
       *
       * @suppress {invalidCasts} Closure can't figure out `this` is infact an element
       *
       * @param {string} attribute Name of attribute to ensure is set.
       * @param {string} value of the attribute.
       * @return {void}
       */


      _ensureAttribute(attribute, value) {
        const el =
        /** @type {!HTMLElement} */
        this;

        if (!el.hasAttribute(attribute)) {
          this._valueToNodeAttribute(el, value, attribute);
        }
      }
      /**
       * Overrides PropertiesChanged implemention to serialize objects as JSON.
       *
       * @param {*} value Property value to serialize.
       * @return {string | undefined} String serialized from the provided property value.
       */


      _serializeValue(value) {
        /* eslint-disable no-fallthrough */
        switch (typeof value) {
          case 'object':
            if (value instanceof Date) {
              return value.toString();
            } else if (value) {
              try {
                return JSON.stringify(value);
              } catch (x) {
                return '';
              }
            }

          default:
            return super._serializeValue(value);
        }
      }
      /**
       * Converts a string to a typed JavaScript value.
       *
       * This method is called by Polymer when reading HTML attribute values to
       * JS properties.  Users may override this method on Polymer element
       * prototypes to provide deserialization for custom `type`s.  Note,
       * the `type` argument is the value of the `type` field provided in the
       * `properties` configuration object for a given property, and is
       * by convention the constructor for the type to deserialize.
       *
       *
       * @param {?string} value Attribute value to deserialize.
       * @param {*=} type Type to deserialize the string to.
       * @return {*} Typed value deserialized from the provided string.
       */


      _deserializeValue(value, type) {
        /**
         * @type {*}
         */
        let outValue;

        switch (type) {
          case Object:
            try {
              outValue = JSON.parse(
              /** @type {string} */
              value);
            } catch (x) {
              // allow non-JSON literals like Strings and Numbers
              outValue = value;
            }

            break;

          case Array:
            try {
              outValue = JSON.parse(
              /** @type {string} */
              value);
            } catch (x) {
              outValue = null;
              console.warn(`Polymer::Attributes: couldn't decode Array as JSON: ${value}`);
            }

            break;

          case Date:
            outValue = isNaN(value) ? String(value) : Number(value);
            outValue = new Date(outValue);
            break;

          default:
            outValue = super._deserializeValue(value, type);
            break;
        }

        return outValue;
      }
      /* eslint-enable no-fallthrough */

      /**
       * Overrides PropertiesChanged implementation to save existing prototype
       * property value so that it can be reset.
       * @param {string} property Name of the property
       * @param {boolean=} readOnly When true, no setter is created
       *
       * When calling on a prototype, any overwritten values are saved in
       * `__dataProto`, and it is up to the subclasser to decide how/when
       * to set those properties back into the accessor.  When calling on an
       * instance, the overwritten value is set via `_setPendingProperty`,
       * and the user should call `_invalidateProperties` or `_flushProperties`
       * for the values to take effect.
       * @protected
       * @return {void}
       */


      _definePropertyAccessor(property, readOnly) {
        saveAccessorValue(this, property);

        super._definePropertyAccessor(property, readOnly);
      }
      /**
       * Returns true if this library created an accessor for the given property.
       *
       * @param {string} property Property name
       * @return {boolean} True if an accessor was created
       */


      _hasAccessor(property) {
        return this.__dataHasAccessor && this.__dataHasAccessor[property];
      }
      /**
       * Returns true if the specified property has a pending change.
       *
       * @param {string} prop Property name
       * @return {boolean} True if property has a pending change
       * @protected
       */


      _isPropertyPending(prop) {
        return Boolean(this.__dataPending && prop in this.__dataPending);
      }

    }

    return PropertyAccessors;
  });
  _exports.PropertyAccessors = PropertyAccessors;
  var propertyAccessors = {
    PropertyAccessors: PropertyAccessors
  }; // This is a clear layering violation and gives favored-nation status to
  // dom-if and dom-repeat templates.  This is a conceit we're choosing to keep
  // a.) to ease 1.x backwards-compatibility due to loss of `is`, and
  // b.) to maintain if/repeat capability in parser-constrained elements
  //     (e.g. table, select) in lieu of native CE type extensions without
  //     massive new invention in this space (e.g. directive system)

  _exports.$propertyAccessors = propertyAccessors;
  const templateExtensions = {
    'dom-if': true,
    'dom-repeat': true
  };

  function wrapTemplateExtension(node) {
    let is = node.getAttribute('is');

    if (is && templateExtensions[is]) {
      let t = node;
      t.removeAttribute('is');
      node = t.ownerDocument.createElement(is);
      t.parentNode.replaceChild(node, t);
      node.appendChild(t);

      while (t.attributes.length) {
        node.setAttribute(t.attributes[0].name, t.attributes[0].value);
        t.removeAttribute(t.attributes[0].name);
      }
    }

    return node;
  }

  function findTemplateNode(root, nodeInfo) {
    // recursively ascend tree until we hit root
    let parent = nodeInfo.parentInfo && findTemplateNode(root, nodeInfo.parentInfo); // unwind the stack, returning the indexed node at each level

    if (parent) {
      // note: marginally faster than indexing via childNodes
      // (http://jsperf.com/childnodes-lookup)
      for (let n = parent.firstChild, i = 0; n; n = n.nextSibling) {
        if (nodeInfo.parentIndex === i++) {
          return n;
        }
      }
    } else {
      return root;
    }
  } // construct `$` map (from id annotations)


  function applyIdToMap(inst, map, node, nodeInfo) {
    if (nodeInfo.id) {
      map[nodeInfo.id] = node;
    }
  } // install event listeners (from event annotations)


  function applyEventListener(inst, node, nodeInfo) {
    if (nodeInfo.events && nodeInfo.events.length) {
      for (let j = 0, e$ = nodeInfo.events, e; j < e$.length && (e = e$[j]); j++) {
        inst._addMethodEventListenerToNode(node, e.name, e.value, inst);
      }
    }
  } // push configuration references at configure time


  function applyTemplateContent(inst, node, nodeInfo) {
    if (nodeInfo.templateInfo) {
      node._templateInfo = nodeInfo.templateInfo;
    }
  }

  function createNodeEventHandler(context, eventName, methodName) {
    // Instances can optionally have a _methodHost which allows redirecting where
    // to find methods. Currently used by `templatize`.
    context = context._methodHost || context;

    let handler = function (e) {
      if (context[methodName]) {
        context[methodName](e, e.detail);
      } else {
        console.warn('listener method `' + methodName + '` not defined');
      }
    };

    return handler;
  }
  /**
   * Element mixin that provides basic template parsing and stamping, including
   * the following template-related features for stamped templates:
   *
   * - Declarative event listeners (`on-eventname="listener"`)
   * - Map of node id's to stamped node instances (`this.$.id`)
   * - Nested template content caching/removal and re-installation (performance
   *   optimization)
   *
   * @mixinFunction
   * @polymer
   * @summary Element class mixin that provides basic template parsing and stamping
   */


  const TemplateStamp = dedupingMixin(
  /**
          * @template T
          * @param {function(new:T)} superClass Class to apply mixin to.
          * @return {function(new:T)} superClass with mixin applied.
          */
  superClass => {
    /**
     * @polymer
     * @mixinClass
     * @implements {Polymer_TemplateStamp}
     */
    class TemplateStamp extends superClass {
      /**
       * Scans a template to produce template metadata.
       *
       * Template-specific metadata are stored in the object returned, and node-
       * specific metadata are stored in objects in its flattened `nodeInfoList`
       * array.  Only nodes in the template that were parsed as nodes of
       * interest contain an object in `nodeInfoList`.  Each `nodeInfo` object
       * contains an `index` (`childNodes` index in parent) and optionally
       * `parent`, which points to node info of its parent (including its index).
       *
       * The template metadata object returned from this method has the following
       * structure (many fields optional):
       *
       * ```js
       *   {
       *     // Flattened list of node metadata (for nodes that generated metadata)
       *     nodeInfoList: [
       *       {
       *         // `id` attribute for any nodes with id's for generating `$` map
       *         id: {string},
       *         // `on-event="handler"` metadata
       *         events: [
       *           {
       *             name: {string},   // event name
       *             value: {string},  // handler method name
       *           }, ...
       *         ],
       *         // Notes when the template contained a `<slot>` for shady DOM
       *         // optimization purposes
       *         hasInsertionPoint: {boolean},
       *         // For nested `<template>`` nodes, nested template metadata
       *         templateInfo: {object}, // nested template metadata
       *         // Metadata to allow efficient retrieval of instanced node
       *         // corresponding to this metadata
       *         parentInfo: {number},   // reference to parent nodeInfo>
       *         parentIndex: {number},  // index in parent's `childNodes` collection
       *         infoIndex: {number},    // index of this `nodeInfo` in `templateInfo.nodeInfoList`
       *       },
       *       ...
       *     ],
       *     // When true, the template had the `strip-whitespace` attribute
       *     // or was nested in a template with that setting
       *     stripWhitespace: {boolean},
       *     // For nested templates, nested template content is moved into
       *     // a document fragment stored here; this is an optimization to
       *     // avoid the cost of nested template cloning
       *     content: {DocumentFragment}
       *   }
       * ```
       *
       * This method kicks off a recursive treewalk as follows:
       *
       * ```
       *    _parseTemplate <---------------------+
       *      _parseTemplateContent              |
       *        _parseTemplateNode  <------------|--+
       *          _parseTemplateNestedTemplate --+  |
       *          _parseTemplateChildNodes ---------+
       *          _parseTemplateNodeAttributes
       *            _parseTemplateNodeAttribute
       *
       * ```
       *
       * These methods may be overridden to add custom metadata about templates
       * to either `templateInfo` or `nodeInfo`.
       *
       * Note that this method may be destructive to the template, in that
       * e.g. event annotations may be removed after being noted in the
       * template metadata.
       *
       * @param {!HTMLTemplateElement} template Template to parse
       * @param {TemplateInfo=} outerTemplateInfo Template metadata from the outer
       *   template, for parsing nested templates
       * @return {!TemplateInfo} Parsed template metadata
       */
      static _parseTemplate(template, outerTemplateInfo) {
        // since a template may be re-used, memo-ize metadata
        if (!template._templateInfo) {
          let templateInfo = template._templateInfo = {};
          templateInfo.nodeInfoList = [];
          templateInfo.stripWhiteSpace = outerTemplateInfo && outerTemplateInfo.stripWhiteSpace || template.hasAttribute('strip-whitespace');

          this._parseTemplateContent(template, templateInfo, {
            parent: null
          });
        }

        return template._templateInfo;
      }

      static _parseTemplateContent(template, templateInfo, nodeInfo) {
        return this._parseTemplateNode(template.content, templateInfo, nodeInfo);
      }
      /**
       * Parses template node and adds template and node metadata based on
       * the current node, and its `childNodes` and `attributes`.
       *
       * This method may be overridden to add custom node or template specific
       * metadata based on this node.
       *
       * @param {Node} node Node to parse
       * @param {!TemplateInfo} templateInfo Template metadata for current template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       */


      static _parseTemplateNode(node, templateInfo, nodeInfo) {
        let noted;
        let element =
        /** @type {Element} */
        node;

        if (element.localName == 'template' && !element.hasAttribute('preserve-content')) {
          noted = this._parseTemplateNestedTemplate(element, templateInfo, nodeInfo) || noted;
        } else if (element.localName === 'slot') {
          // For ShadyDom optimization, indicating there is an insertion point
          templateInfo.hasInsertionPoint = true;
        }

        if (element.firstChild) {
          noted = this._parseTemplateChildNodes(element, templateInfo, nodeInfo) || noted;
        }

        if (element.hasAttributes && element.hasAttributes()) {
          noted = this._parseTemplateNodeAttributes(element, templateInfo, nodeInfo) || noted;
        }

        return noted;
      }
      /**
       * Parses template child nodes for the given root node.
       *
       * This method also wraps whitelisted legacy template extensions
       * (`is="dom-if"` and `is="dom-repeat"`) with their equivalent element
       * wrappers, collapses text nodes, and strips whitespace from the template
       * if the `templateInfo.stripWhitespace` setting was provided.
       *
       * @param {Node} root Root node whose `childNodes` will be parsed
       * @param {!TemplateInfo} templateInfo Template metadata for current template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {void}
       */


      static _parseTemplateChildNodes(root, templateInfo, nodeInfo) {
        if (root.localName === 'script' || root.localName === 'style') {
          return;
        }

        for (let node = root.firstChild, parentIndex = 0, next; node; node = next) {
          // Wrap templates
          if (node.localName == 'template') {
            node = wrapTemplateExtension(node);
          } // collapse adjacent textNodes: fixes an IE issue that can cause
          // text nodes to be inexplicably split =(
          // note that root.normalize() should work but does not so we do this
          // manually.


          next = node.nextSibling;

          if (node.nodeType === Node.TEXT_NODE) {
            let
            /** Node */
            n = next;

            while (n && n.nodeType === Node.TEXT_NODE) {
              node.textContent += n.textContent;
              next = n.nextSibling;
              root.removeChild(n);
              n = next;
            } // optionally strip whitespace


            if (templateInfo.stripWhiteSpace && !node.textContent.trim()) {
              root.removeChild(node);
              continue;
            }
          }

          let childInfo = {
            parentIndex,
            parentInfo: nodeInfo
          };

          if (this._parseTemplateNode(node, templateInfo, childInfo)) {
            childInfo.infoIndex = templateInfo.nodeInfoList.push(
            /** @type {!NodeInfo} */
            childInfo) - 1;
          } // Increment if not removed


          if (node.parentNode) {
            parentIndex++;
          }
        }
      }
      /**
       * Parses template content for the given nested `<template>`.
       *
       * Nested template info is stored as `templateInfo` in the current node's
       * `nodeInfo`. `template.content` is removed and stored in `templateInfo`.
       * It will then be the responsibility of the host to set it back to the
       * template and for users stamping nested templates to use the
       * `_contentForTemplate` method to retrieve the content for this template
       * (an optimization to avoid the cost of cloning nested template content).
       *
       * @param {HTMLTemplateElement} node Node to parse (a <template>)
       * @param {TemplateInfo} outerTemplateInfo Template metadata for current template
       *   that includes the template `node`
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       */


      static _parseTemplateNestedTemplate(node, outerTemplateInfo, nodeInfo) {
        let templateInfo = this._parseTemplate(node, outerTemplateInfo);

        let content = templateInfo.content = node.content.ownerDocument.createDocumentFragment();
        content.appendChild(node.content);
        nodeInfo.templateInfo = templateInfo;
        return true;
      }
      /**
       * Parses template node attributes and adds node metadata to `nodeInfo`
       * for nodes of interest.
       *
       * @param {Element} node Node to parse
       * @param {TemplateInfo} templateInfo Template metadata for current template
       * @param {NodeInfo} nodeInfo Node metadata for current template.
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       */


      static _parseTemplateNodeAttributes(node, templateInfo, nodeInfo) {
        // Make copy of original attribute list, since the order may change
        // as attributes are added and removed
        let noted = false;
        let attrs = Array.from(node.attributes);

        for (let i = attrs.length - 1, a; a = attrs[i]; i--) {
          noted = this._parseTemplateNodeAttribute(node, templateInfo, nodeInfo, a.name, a.value) || noted;
        }

        return noted;
      }
      /**
       * Parses a single template node attribute and adds node metadata to
       * `nodeInfo` for attributes of interest.
       *
       * This implementation adds metadata for `on-event="handler"` attributes
       * and `id` attributes.
       *
       * @param {Element} node Node to parse
       * @param {!TemplateInfo} templateInfo Template metadata for current template
       * @param {!NodeInfo} nodeInfo Node metadata for current template.
       * @param {string} name Attribute name
       * @param {string} value Attribute value
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       */


      static _parseTemplateNodeAttribute(node, templateInfo, nodeInfo, name, value) {
        // events (on-*)
        if (name.slice(0, 3) === 'on-') {
          node.removeAttribute(name);
          nodeInfo.events = nodeInfo.events || [];
          nodeInfo.events.push({
            name: name.slice(3),
            value
          });
          return true;
        } // static id
        else if (name === 'id') {
            nodeInfo.id = value;
            return true;
          }

        return false;
      }
      /**
       * Returns the `content` document fragment for a given template.
       *
       * For nested templates, Polymer performs an optimization to cache nested
       * template content to avoid the cost of cloning deeply nested templates.
       * This method retrieves the cached content for a given template.
       *
       * @param {HTMLTemplateElement} template Template to retrieve `content` for
       * @return {DocumentFragment} Content fragment
       */


      static _contentForTemplate(template) {
        let templateInfo =
        /** @type {HTMLTemplateElementWithInfo} */
        template._templateInfo;
        return templateInfo && templateInfo.content || template.content;
      }
      /**
       * Clones the provided template content and returns a document fragment
       * containing the cloned dom.
       *
       * The template is parsed (once and memoized) using this library's
       * template parsing features, and provides the following value-added
       * features:
       * * Adds declarative event listeners for `on-event="handler"` attributes
       * * Generates an "id map" for all nodes with id's under `$` on returned
       *   document fragment
       * * Passes template info including `content` back to templates as
       *   `_templateInfo` (a performance optimization to avoid deep template
       *   cloning)
       *
       * Note that the memoized template parsing process is destructive to the
       * template: attributes for bindings and declarative event listeners are
       * removed after being noted in notes, and any nested `<template>.content`
       * is removed and stored in notes as well.
       *
       * @param {!HTMLTemplateElement} template Template to stamp
       * @return {!StampedTemplate} Cloned template content
       * @override
       */


      _stampTemplate(template) {
        // Polyfill support: bootstrap the template if it has not already been
        if (template && !template.content && window.HTMLTemplateElement && HTMLTemplateElement.decorate) {
          HTMLTemplateElement.decorate(template);
        }

        let templateInfo = this.constructor._parseTemplate(template);

        let nodeInfo = templateInfo.nodeInfoList;
        let content = templateInfo.content || template.content;
        let dom =
        /** @type {DocumentFragment} */
        document.importNode(content, true); // NOTE: ShadyDom optimization indicating there is an insertion point

        dom.__noInsertionPoint = !templateInfo.hasInsertionPoint;
        let nodes = dom.nodeList = new Array(nodeInfo.length);
        dom.$ = {};

        for (let i = 0, l = nodeInfo.length, info; i < l && (info = nodeInfo[i]); i++) {
          let node = nodes[i] = findTemplateNode(dom, info);
          applyIdToMap(this, dom.$, node, info);
          applyTemplateContent(this, node, info);
          applyEventListener(this, node, info);
        }

        dom =
        /** @type {!StampedTemplate} */
        dom; // eslint-disable-line no-self-assign

        return dom;
      }
      /**
       * Adds an event listener by method name for the event provided.
       *
       * This method generates a handler function that looks up the method
       * name at handling time.
       *
       * @param {!EventTarget} node Node to add listener on
       * @param {string} eventName Name of event
       * @param {string} methodName Name of method
       * @param {*=} context Context the method will be called on (defaults
       *   to `node`)
       * @return {Function} Generated handler function
       * @override
       */


      _addMethodEventListenerToNode(node, eventName, methodName, context) {
        context = context || node;
        let handler = createNodeEventHandler(context, eventName, methodName);

        this._addEventListenerToNode(node, eventName, handler);

        return handler;
      }
      /**
       * Override point for adding custom or simulated event handling.
       *
       * @param {!EventTarget} node Node to add event listener to
       * @param {string} eventName Name of event
       * @param {function(!Event):void} handler Listener function to add
       * @return {void}
       * @override
       */


      _addEventListenerToNode(node, eventName, handler) {
        node.addEventListener(eventName, handler);
      }
      /**
       * Override point for adding custom or simulated event handling.
       *
       * @param {!EventTarget} node Node to remove event listener from
       * @param {string} eventName Name of event
       * @param {function(!Event):void} handler Listener function to remove
       * @return {void}
       * @override
       */


      _removeEventListenerFromNode(node, eventName, handler) {
        node.removeEventListener(eventName, handler);
      }

    }

    return TemplateStamp;
  });
  _exports.TemplateStamp = TemplateStamp;
  var templateStamp = {
    TemplateStamp: TemplateStamp
  }; // from multiple properties in the same turn

  _exports.$templateStamp = templateStamp;
  let dedupeId$1 = 0;
  /**
  * Property effect types; effects are stored on the prototype using these keys
  * @enum {string}
  */

  const TYPES = {
    COMPUTE: '__computeEffects',
    REFLECT: '__reflectEffects',
    NOTIFY: '__notifyEffects',
    PROPAGATE: '__propagateEffects',
    OBSERVE: '__observeEffects',
    READ_ONLY: '__readOnly'
  };
  /** @const {RegExp} */

  const capitalAttributeRegex = /[A-Z]/;
  /**
   * @typedef {{
   * name: (string | undefined),
   * structured: (boolean | undefined),
   * wildcard: (boolean | undefined)
   * }}
   */

  let DataTrigger; //eslint-disable-line no-unused-vars

  /**
   * @typedef {{
   * info: ?,
   * trigger: (!DataTrigger | undefined),
   * fn: (!Function | undefined)
   * }}
   */

  let DataEffect; //eslint-disable-line no-unused-vars

  let PropertyEffectsType; //eslint-disable-line no-unused-vars

  /**
   * Ensures that the model has an own-property map of effects for the given type.
   * The model may be a prototype or an instance.
   *
   * Property effects are stored as arrays of effects by property in a map,
   * by named type on the model. e.g.
   *
   *   __computeEffects: {
   *     foo: [ ... ],
   *     bar: [ ... ]
   *   }
   *
   * If the model does not yet have an effect map for the type, one is created
   * and returned.  If it does, but it is not an own property (i.e. the
   * prototype had effects), the the map is deeply cloned and the copy is
   * set on the model and returned, ready for new effects to be added.
   *
   * @param {Object} model Prototype or instance
   * @param {string} type Property effect type
   * @return {Object} The own-property map of effects for the given type
   * @private
   */

  function ensureOwnEffectMap(model, type) {
    let effects = model[type];

    if (!effects) {
      effects = model[type] = {};
    } else if (!model.hasOwnProperty(type)) {
      effects = model[type] = Object.create(model[type]);

      for (let p in effects) {
        let protoFx = effects[p];
        let instFx = effects[p] = Array(protoFx.length);

        for (let i = 0; i < protoFx.length; i++) {
          instFx[i] = protoFx[i];
        }
      }
    }

    return effects;
  } // -- effects ----------------------------------------------

  /**
   * Runs all effects of a given type for the given set of property changes
   * on an instance.
   *
   * @param {!PropertyEffectsType} inst The instance with effects to run
   * @param {Object} effects Object map of property-to-Array of effects
   * @param {Object} props Bag of current property changes
   * @param {Object=} oldProps Bag of previous values for changed properties
   * @param {boolean=} hasPaths True with `props` contains one or more paths
   * @param {*=} extraArgs Additional metadata to pass to effect function
   * @return {boolean} True if an effect ran for this property
   * @private
   */


  function runEffects(inst, effects, props, oldProps, hasPaths, extraArgs) {
    if (effects) {
      let ran = false;
      let id = dedupeId$1++;

      for (let prop in props) {
        if (runEffectsForProperty(inst, effects, id, prop, props, oldProps, hasPaths, extraArgs)) {
          ran = true;
        }
      }

      return ran;
    }

    return false;
  }
  /**
   * Runs a list of effects for a given property.
   *
   * @param {!PropertyEffectsType} inst The instance with effects to run
   * @param {Object} effects Object map of property-to-Array of effects
   * @param {number} dedupeId Counter used for de-duping effects
   * @param {string} prop Name of changed property
   * @param {*} props Changed properties
   * @param {*} oldProps Old properties
   * @param {boolean=} hasPaths True with `props` contains one or more paths
   * @param {*=} extraArgs Additional metadata to pass to effect function
   * @return {boolean} True if an effect ran for this property
   * @private
   */


  function runEffectsForProperty(inst, effects, dedupeId, prop, props, oldProps, hasPaths, extraArgs) {
    let ran = false;
    let rootProperty = hasPaths ? root(prop) : prop;
    let fxs = effects[rootProperty];

    if (fxs) {
      for (let i = 0, l = fxs.length, fx; i < l && (fx = fxs[i]); i++) {
        if ((!fx.info || fx.info.lastRun !== dedupeId) && (!hasPaths || pathMatchesTrigger(prop, fx.trigger))) {
          if (fx.info) {
            fx.info.lastRun = dedupeId;
          }

          fx.fn(inst, prop, props, oldProps, fx.info, hasPaths, extraArgs);
          ran = true;
        }
      }
    }

    return ran;
  }
  /**
   * Determines whether a property/path that has changed matches the trigger
   * criteria for an effect.  A trigger is a descriptor with the following
   * structure, which matches the descriptors returned from `parseArg`.
   * e.g. for `foo.bar.*`:
   * ```
   * trigger: {
   *   name: 'a.b',
   *   structured: true,
   *   wildcard: true
   * }
   * ```
   * If no trigger is given, the path is deemed to match.
   *
   * @param {string} path Path or property that changed
   * @param {DataTrigger} trigger Descriptor
   * @return {boolean} Whether the path matched the trigger
   */


  function pathMatchesTrigger(path, trigger) {
    if (trigger) {
      let triggerPath = trigger.name;
      return triggerPath == path || trigger.structured && isAncestor(triggerPath, path) || trigger.wildcard && isDescendant(triggerPath, path);
    } else {
      return true;
    }
  }
  /**
   * Implements the "observer" effect.
   *
   * Calls the method with `info.methodName` on the instance, passing the
   * new and old values.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {string} property Name of property
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {?} info Effect metadata
   * @return {void}
   * @private
   */


  function runObserverEffect(inst, property, props, oldProps, info) {
    let fn = typeof info.method === "string" ? inst[info.method] : info.method;
    let changedProp = info.property;

    if (fn) {
      fn.call(inst, inst.__data[changedProp], oldProps[changedProp]);
    } else if (!info.dynamicFn) {
      console.warn('observer method `' + info.method + '` not defined');
    }
  }
  /**
   * Runs "notify" effects for a set of changed properties.
   *
   * This method differs from the generic `runEffects` method in that it
   * will dispatch path notification events in the case that the property
   * changed was a path and the root property for that path didn't have a
   * "notify" effect.  This is to maintain 1.0 behavior that did not require
   * `notify: true` to ensure object sub-property notifications were
   * sent.
   *
   * @param {!PropertyEffectsType} inst The instance with effects to run
   * @param {Object} notifyProps Bag of properties to notify
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {boolean} hasPaths True with `props` contains one or more paths
   * @return {void}
   * @private
   */


  function runNotifyEffects(inst, notifyProps, props, oldProps, hasPaths) {
    // Notify
    let fxs = inst[TYPES.NOTIFY];
    let notified;
    let id = dedupeId$1++; // Try normal notify effects; if none, fall back to try path notification

    for (let prop in notifyProps) {
      if (notifyProps[prop]) {
        if (fxs && runEffectsForProperty(inst, fxs, id, prop, props, oldProps, hasPaths)) {
          notified = true;
        } else if (hasPaths && notifyPath(inst, prop, props)) {
          notified = true;
        }
      }
    } // Flush host if we actually notified and host was batching
    // And the host has already initialized clients; this prevents
    // an issue with a host observing data changes before clients are ready.


    let host;

    if (notified && (host = inst.__dataHost) && host._invalidateProperties) {
      host._invalidateProperties();
    }
  }
  /**
   * Dispatches {property}-changed events with path information in the detail
   * object to indicate a sub-path of the property was changed.
   *
   * @param {!PropertyEffectsType} inst The element from which to fire the event
   * @param {string} path The path that was changed
   * @param {Object} props Bag of current property changes
   * @return {boolean} Returns true if the path was notified
   * @private
   */


  function notifyPath(inst, path, props) {
    let rootProperty = root(path);

    if (rootProperty !== path) {
      let eventName = camelToDashCase(rootProperty) + '-changed';
      dispatchNotifyEvent(inst, eventName, props[path], path);
      return true;
    }

    return false;
  }
  /**
   * Dispatches {property}-changed events to indicate a property (or path)
   * changed.
   *
   * @param {!PropertyEffectsType} inst The element from which to fire the event
   * @param {string} eventName The name of the event to send ('{property}-changed')
   * @param {*} value The value of the changed property
   * @param {string | null | undefined} path If a sub-path of this property changed, the path
   *   that changed (optional).
   * @return {void}
   * @private
   * @suppress {invalidCasts}
   */


  function dispatchNotifyEvent(inst, eventName, value, path) {
    let detail = {
      value: value,
      queueProperty: true
    };

    if (path) {
      detail.path = path;
    }
    /** @type {!HTMLElement} */


    inst.dispatchEvent(new CustomEvent(eventName, {
      detail
    }));
  }
  /**
   * Implements the "notify" effect.
   *
   * Dispatches a non-bubbling event named `info.eventName` on the instance
   * with a detail object containing the new `value`.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {string} property Name of property
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {?} info Effect metadata
   * @param {boolean} hasPaths True with `props` contains one or more paths
   * @return {void}
   * @private
   */


  function runNotifyEffect(inst, property, props, oldProps, info, hasPaths) {
    let rootProperty = hasPaths ? root(property) : property;
    let path = rootProperty != property ? property : null;
    let value = path ? get(inst, path) : inst.__data[property];

    if (path && value === undefined) {
      value = props[property]; // specifically for .splices
    }

    dispatchNotifyEvent(inst, info.eventName, value, path);
  }
  /**
   * Handler function for 2-way notification events. Receives context
   * information captured in the `addNotifyListener` closure from the
   * `__notifyListeners` metadata.
   *
   * Sets the value of the notified property to the host property or path.  If
   * the event contained path information, translate that path to the host
   * scope's name for that path first.
   *
   * @param {CustomEvent} event Notification event (e.g. '<property>-changed')
   * @param {!PropertyEffectsType} inst Host element instance handling the notification event
   * @param {string} fromProp Child element property that was bound
   * @param {string} toPath Host property/path that was bound
   * @param {boolean} negate Whether the binding was negated
   * @return {void}
   * @private
   */


  function handleNotification(event, inst, fromProp, toPath, negate) {
    let value;
    let detail =
    /** @type {Object} */
    event.detail;
    let fromPath = detail && detail.path;

    if (fromPath) {
      toPath = translate(fromProp, toPath, fromPath);
      value = detail && detail.value;
    } else {
      value = event.currentTarget[fromProp];
    }

    value = negate ? !value : value;

    if (!inst[TYPES.READ_ONLY] || !inst[TYPES.READ_ONLY][toPath]) {
      if (inst._setPendingPropertyOrPath(toPath, value, true, Boolean(fromPath)) && (!detail || !detail.queueProperty)) {
        inst._invalidateProperties();
      }
    }
  }
  /**
   * Implements the "reflect" effect.
   *
   * Sets the attribute named `info.attrName` to the given property value.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {string} property Name of property
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {?} info Effect metadata
   * @return {void}
   * @private
   */


  function runReflectEffect(inst, property, props, oldProps, info) {
    let value = inst.__data[property];

    if (sanitizeDOMValue) {
      value = sanitizeDOMValue(value, info.attrName, 'attribute',
      /** @type {Node} */
      inst);
    }

    inst._propertyToAttribute(property, info.attrName, value);
  }
  /**
   * Runs "computed" effects for a set of changed properties.
   *
   * This method differs from the generic `runEffects` method in that it
   * continues to run computed effects based on the output of each pass until
   * there are no more newly computed properties.  This ensures that all
   * properties that will be computed by the initial set of changes are
   * computed before other effects (binding propagation, observers, and notify)
   * run.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {!Object} changedProps Bag of changed properties
   * @param {!Object} oldProps Bag of previous values for changed properties
   * @param {boolean} hasPaths True with `props` contains one or more paths
   * @return {void}
   * @private
   */


  function runComputedEffects(inst, changedProps, oldProps, hasPaths) {
    let computeEffects = inst[TYPES.COMPUTE];

    if (computeEffects) {
      let inputProps = changedProps;

      while (runEffects(inst, computeEffects, inputProps, oldProps, hasPaths)) {
        Object.assign(oldProps, inst.__dataOld);
        Object.assign(changedProps, inst.__dataPending);
        inputProps = inst.__dataPending;
        inst.__dataPending = null;
      }
    }
  }
  /**
   * Implements the "computed property" effect by running the method with the
   * values of the arguments specified in the `info` object and setting the
   * return value to the computed property specified.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {string} property Name of property
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {?} info Effect metadata
   * @return {void}
   * @private
   */


  function runComputedEffect(inst, property, props, oldProps, info) {
    let result = runMethodEffect(inst, property, props, oldProps, info);
    let computedProp = info.methodInfo;

    if (inst.__dataHasAccessor && inst.__dataHasAccessor[computedProp]) {
      inst._setPendingProperty(computedProp, result, true);
    } else {
      inst[computedProp] = result;
    }
  }
  /**
   * Computes path changes based on path links set up using the `linkPaths`
   * API.
   *
   * @param {!PropertyEffectsType} inst The instance whose props are changing
   * @param {string | !Array<(string|number)>} path Path that has changed
   * @param {*} value Value of changed path
   * @return {void}
   * @private
   */


  function computeLinkedPaths(inst, path, value) {
    let links = inst.__dataLinkedPaths;

    if (links) {
      let link;

      for (let a in links) {
        let b = links[a];

        if (isDescendant(a, path)) {
          link = translate(a, b, path);

          inst._setPendingPropertyOrPath(link, value, true, true);
        } else if (isDescendant(b, path)) {
          link = translate(b, a, path);

          inst._setPendingPropertyOrPath(link, value, true, true);
        }
      }
    }
  } // -- bindings ----------------------------------------------

  /**
   * Adds binding metadata to the current `nodeInfo`, and binding effects
   * for all part dependencies to `templateInfo`.
   *
   * @param {Function} constructor Class that `_parseTemplate` is currently
   *   running on
   * @param {TemplateInfo} templateInfo Template metadata for current template
   * @param {NodeInfo} nodeInfo Node metadata for current template node
   * @param {string} kind Binding kind, either 'property', 'attribute', or 'text'
   * @param {string} target Target property name
   * @param {!Array<!BindingPart>} parts Array of binding part metadata
   * @param {string=} literal Literal text surrounding binding parts (specified
   *   only for 'property' bindings, since these must be initialized as part
   *   of boot-up)
   * @return {void}
   * @private
   */


  function addBinding(constructor, templateInfo, nodeInfo, kind, target, parts, literal) {
    // Create binding metadata and add to nodeInfo
    nodeInfo.bindings = nodeInfo.bindings || [];
    let
    /** Binding */
    binding = {
      kind,
      target,
      parts,
      literal,
      isCompound: parts.length !== 1
    };
    nodeInfo.bindings.push(binding); // Add listener info to binding metadata

    if (shouldAddListener(binding)) {
      let {
        event,
        negate
      } = binding.parts[0];
      binding.listenerEvent = event || camelToDashCase(target) + '-changed';
      binding.listenerNegate = negate;
    } // Add "propagate" property effects to templateInfo


    let index = templateInfo.nodeInfoList.length;

    for (let i = 0; i < binding.parts.length; i++) {
      let part = binding.parts[i];
      part.compoundIndex = i;
      addEffectForBindingPart(constructor, templateInfo, binding, part, index);
    }
  }
  /**
   * Adds property effects to the given `templateInfo` for the given binding
   * part.
   *
   * @param {Function} constructor Class that `_parseTemplate` is currently
   *   running on
   * @param {TemplateInfo} templateInfo Template metadata for current template
   * @param {!Binding} binding Binding metadata
   * @param {!BindingPart} part Binding part metadata
   * @param {number} index Index into `nodeInfoList` for this node
   * @return {void}
   */


  function addEffectForBindingPart(constructor, templateInfo, binding, part, index) {
    if (!part.literal) {
      if (binding.kind === 'attribute' && binding.target[0] === '-') {
        console.warn('Cannot set attribute ' + binding.target + ' because "-" is not a valid attribute starting character');
      } else {
        let dependencies = part.dependencies;
        let info = {
          index,
          binding,
          part,
          evaluator: constructor
        };

        for (let j = 0; j < dependencies.length; j++) {
          let trigger = dependencies[j];

          if (typeof trigger == 'string') {
            trigger = parseArg(trigger);
            trigger.wildcard = true;
          }

          constructor._addTemplatePropertyEffect(templateInfo, trigger.rootProperty, {
            fn: runBindingEffect,
            info,
            trigger
          });
        }
      }
    }
  }
  /**
   * Implements the "binding" (property/path binding) effect.
   *
   * Note that binding syntax is overridable via `_parseBindings` and
   * `_evaluateBinding`.  This method will call `_evaluateBinding` for any
   * non-literal parts returned from `_parseBindings`.  However,
   * there is no support for _path_ bindings via custom binding parts,
   * as this is specific to Polymer's path binding syntax.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {string} path Name of property
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {?} info Effect metadata
   * @param {boolean} hasPaths True with `props` contains one or more paths
   * @param {Array} nodeList List of nodes associated with `nodeInfoList` template
   *   metadata
   * @return {void}
   * @private
   */


  function runBindingEffect(inst, path, props, oldProps, info, hasPaths, nodeList) {
    let node = nodeList[info.index];
    let binding = info.binding;
    let part = info.part; // Subpath notification: transform path and set to client
    // e.g.: foo="{{obj.sub}}", path: 'obj.sub.prop', set 'foo.prop'=obj.sub.prop

    if (hasPaths && part.source && path.length > part.source.length && binding.kind == 'property' && !binding.isCompound && node.__isPropertyEffectsClient && node.__dataHasAccessor && node.__dataHasAccessor[binding.target]) {
      let value = props[path];
      path = translate(part.source, binding.target, path);

      if (node._setPendingPropertyOrPath(path, value, false, true)) {
        inst._enqueueClient(node);
      }
    } else {
      let value = info.evaluator._evaluateBinding(inst, part, path, props, oldProps, hasPaths); // Propagate value to child


      applyBindingValue(inst, node, binding, part, value);
    }
  }
  /**
   * Sets the value for an "binding" (binding) effect to a node,
   * either as a property or attribute.
   *
   * @param {!PropertyEffectsType} inst The instance owning the binding effect
   * @param {Node} node Target node for binding
   * @param {!Binding} binding Binding metadata
   * @param {!BindingPart} part Binding part metadata
   * @param {*} value Value to set
   * @return {void}
   * @private
   */


  function applyBindingValue(inst, node, binding, part, value) {
    value = computeBindingValue(node, value, binding, part);

    if (sanitizeDOMValue) {
      value = sanitizeDOMValue(value, binding.target, binding.kind, node);
    }

    if (binding.kind == 'attribute') {
      // Attribute binding
      inst._valueToNodeAttribute(
      /** @type {Element} */
      node, value, binding.target);
    } else {
      // Property binding
      let prop = binding.target;

      if (node.__isPropertyEffectsClient && node.__dataHasAccessor && node.__dataHasAccessor[prop]) {
        if (!node[TYPES.READ_ONLY] || !node[TYPES.READ_ONLY][prop]) {
          if (node._setPendingProperty(prop, value)) {
            inst._enqueueClient(node);
          }
        }
      } else {
        inst._setUnmanagedPropertyToNode(node, prop, value);
      }
    }
  }
  /**
   * Transforms an "binding" effect value based on compound & negation
   * effect metadata, as well as handling for special-case properties
   *
   * @param {Node} node Node the value will be set to
   * @param {*} value Value to set
   * @param {!Binding} binding Binding metadata
   * @param {!BindingPart} part Binding part metadata
   * @return {*} Transformed value to set
   * @private
   */


  function computeBindingValue(node, value, binding, part) {
    if (binding.isCompound) {
      let storage = node.__dataCompoundStorage[binding.target];
      storage[part.compoundIndex] = value;
      value = storage.join('');
    }

    if (binding.kind !== 'attribute') {
      // Some browsers serialize `undefined` to `"undefined"`
      if (binding.target === 'textContent' || binding.target === 'value' && (node.localName === 'input' || node.localName === 'textarea')) {
        value = value == undefined ? '' : value;
      }
    }

    return value;
  }
  /**
   * Returns true if a binding's metadata meets all the requirements to allow
   * 2-way binding, and therefore a `<property>-changed` event listener should be
   * added:
   * - used curly braces
   * - is a property (not attribute) binding
   * - is not a textContent binding
   * - is not compound
   *
   * @param {!Binding} binding Binding metadata
   * @return {boolean} True if 2-way listener should be added
   * @private
   */


  function shouldAddListener(binding) {
    return Boolean(binding.target) && binding.kind != 'attribute' && binding.kind != 'text' && !binding.isCompound && binding.parts[0].mode === '{';
  }
  /**
   * Setup compound binding storage structures, notify listeners, and dataHost
   * references onto the bound nodeList.
   *
   * @param {!PropertyEffectsType} inst Instance that bas been previously bound
   * @param {TemplateInfo} templateInfo Template metadata
   * @return {void}
   * @private
   */


  function setupBindings(inst, templateInfo) {
    // Setup compound storage, dataHost, and notify listeners
    let {
      nodeList,
      nodeInfoList
    } = templateInfo;

    if (nodeInfoList.length) {
      for (let i = 0; i < nodeInfoList.length; i++) {
        let info = nodeInfoList[i];
        let node = nodeList[i];
        let bindings = info.bindings;

        if (bindings) {
          for (let i = 0; i < bindings.length; i++) {
            let binding = bindings[i];
            setupCompoundStorage(node, binding);
            addNotifyListener(node, inst, binding);
          }
        }

        node.__dataHost = inst;
      }
    }
  }
  /**
   * Initializes `__dataCompoundStorage` local storage on a bound node with
   * initial literal data for compound bindings, and sets the joined
   * literal parts to the bound property.
   *
   * When changes to compound parts occur, they are first set into the compound
   * storage array for that property, and then the array is joined to result in
   * the final value set to the property/attribute.
   *
   * @param {Node} node Bound node to initialize
   * @param {Binding} binding Binding metadata
   * @return {void}
   * @private
   */


  function setupCompoundStorage(node, binding) {
    if (binding.isCompound) {
      // Create compound storage map
      let storage = node.__dataCompoundStorage || (node.__dataCompoundStorage = {});
      let parts = binding.parts; // Copy literals from parts into storage for this binding

      let literals = new Array(parts.length);

      for (let j = 0; j < parts.length; j++) {
        literals[j] = parts[j].literal;
      }

      let target = binding.target;
      storage[target] = literals; // Configure properties with their literal parts

      if (binding.literal && binding.kind == 'property') {
        node[target] = binding.literal;
      }
    }
  }
  /**
   * Adds a 2-way binding notification event listener to the node specified
   *
   * @param {Object} node Child element to add listener to
   * @param {!PropertyEffectsType} inst Host element instance to handle notification event
   * @param {Binding} binding Binding metadata
   * @return {void}
   * @private
   */


  function addNotifyListener(node, inst, binding) {
    if (binding.listenerEvent) {
      let part = binding.parts[0];
      node.addEventListener(binding.listenerEvent, function (e) {
        handleNotification(e, inst, binding.target, part.source, part.negate);
      });
    }
  } // -- for method-based effects (complexObserver & computed) --------------

  /**
   * Adds property effects for each argument in the method signature (and
   * optionally, for the method name if `dynamic` is true) that calls the
   * provided effect function.
   *
   * @param {Element | Object} model Prototype or instance
   * @param {!MethodSignature} sig Method signature metadata
   * @param {string} type Type of property effect to add
   * @param {Function} effectFn Function to run when arguments change
   * @param {*=} methodInfo Effect-specific information to be included in
   *   method effect metadata
   * @param {boolean|Object=} dynamicFn Boolean or object map indicating whether
   *   method names should be included as a dependency to the effect. Note,
   *   defaults to true if the signature is static (sig.static is true).
   * @return {void}
   * @private
   */


  function createMethodEffect(model, sig, type, effectFn, methodInfo, dynamicFn) {
    dynamicFn = sig.static || dynamicFn && (typeof dynamicFn !== 'object' || dynamicFn[sig.methodName]);
    let info = {
      methodName: sig.methodName,
      args: sig.args,
      methodInfo,
      dynamicFn
    };

    for (let i = 0, arg; i < sig.args.length && (arg = sig.args[i]); i++) {
      if (!arg.literal) {
        model._addPropertyEffect(arg.rootProperty, type, {
          fn: effectFn,
          info: info,
          trigger: arg
        });
      }
    }

    if (dynamicFn) {
      model._addPropertyEffect(sig.methodName, type, {
        fn: effectFn,
        info: info
      });
    }
  }
  /**
   * Calls a method with arguments marshaled from properties on the instance
   * based on the method signature contained in the effect metadata.
   *
   * Multi-property observers, computed properties, and inline computing
   * functions call this function to invoke the method, then use the return
   * value accordingly.
   *
   * @param {!PropertyEffectsType} inst The instance the effect will be run on
   * @param {string} property Name of property
   * @param {Object} props Bag of current property changes
   * @param {Object} oldProps Bag of previous values for changed properties
   * @param {?} info Effect metadata
   * @return {*} Returns the return value from the method invocation
   * @private
   */


  function runMethodEffect(inst, property, props, oldProps, info) {
    // Instances can optionally have a _methodHost which allows redirecting where
    // to find methods. Currently used by `templatize`.
    let context = inst._methodHost || inst;
    let fn = context[info.methodName];

    if (fn) {
      let args = inst._marshalArgs(info.args, property, props);

      return fn.apply(context, args);
    } else if (!info.dynamicFn) {
      console.warn('method `' + info.methodName + '` not defined');
    }
  }

  const emptyArray = []; // Regular expressions used for binding

  const IDENT = '(?:' + '[a-zA-Z_$][\\w.:$\\-*]*' + ')';
  const NUMBER = '(?:' + '[-+]?[0-9]*\\.?[0-9]+(?:[eE][-+]?[0-9]+)?' + ')';
  const SQUOTE_STRING = '(?:' + '\'(?:[^\'\\\\]|\\\\.)*\'' + ')';
  const DQUOTE_STRING = '(?:' + '"(?:[^"\\\\]|\\\\.)*"' + ')';
  const STRING = '(?:' + SQUOTE_STRING + '|' + DQUOTE_STRING + ')';
  const ARGUMENT = '(?:(' + IDENT + '|' + NUMBER + '|' + STRING + ')\\s*' + ')';
  const ARGUMENTS = '(?:' + ARGUMENT + '(?:,\\s*' + ARGUMENT + ')*' + ')';
  const ARGUMENT_LIST = '(?:' + '\\(\\s*' + '(?:' + ARGUMENTS + '?' + ')' + '\\)\\s*' + ')';
  const BINDING = '(' + IDENT + '\\s*' + ARGUMENT_LIST + '?' + ')'; // Group 3

  const OPEN_BRACKET = '(\\[\\[|{{)' + '\\s*';
  const CLOSE_BRACKET = '(?:]]|}})';
  const NEGATE = '(?:(!)\\s*)?'; // Group 2

  const EXPRESSION = OPEN_BRACKET + NEGATE + BINDING + CLOSE_BRACKET;
  const bindingRegex = new RegExp(EXPRESSION, "g");
  /**
   * Create a string from binding parts of all the literal parts
   *
   * @param {!Array<BindingPart>} parts All parts to stringify
   * @return {string} String made from the literal parts
   */

  function literalFromParts(parts) {
    let s = '';

    for (let i = 0; i < parts.length; i++) {
      let literal = parts[i].literal;
      s += literal || '';
    }

    return s;
  }
  /**
   * Parses an expression string for a method signature, and returns a metadata
   * describing the method in terms of `methodName`, `static` (whether all the
   * arguments are literals), and an array of `args`
   *
   * @param {string} expression The expression to parse
   * @return {?MethodSignature} The method metadata object if a method expression was
   *   found, otherwise `undefined`
   * @private
   */


  function parseMethod(expression) {
    // tries to match valid javascript property names
    let m = expression.match(/([^\s]+?)\(([\s\S]*)\)/);

    if (m) {
      let methodName = m[1];
      let sig = {
        methodName,
        static: true,
        args: emptyArray
      };

      if (m[2].trim()) {
        // replace escaped commas with comma entity, split on un-escaped commas
        let args = m[2].replace(/\\,/g, '&comma;').split(',');
        return parseArgs(args, sig);
      } else {
        return sig;
      }
    }

    return null;
  }
  /**
   * Parses an array of arguments and sets the `args` property of the supplied
   * signature metadata object. Sets the `static` property to false if any
   * argument is a non-literal.
   *
   * @param {!Array<string>} argList Array of argument names
   * @param {!MethodSignature} sig Method signature metadata object
   * @return {!MethodSignature} The updated signature metadata object
   * @private
   */


  function parseArgs(argList, sig) {
    sig.args = argList.map(function (rawArg) {
      let arg = parseArg(rawArg);

      if (!arg.literal) {
        sig.static = false;
      }

      return arg;
    }, this);
    return sig;
  }
  /**
   * Parses an individual argument, and returns an argument metadata object
   * with the following fields:
   *
   *   {
   *     value: 'prop',        // property/path or literal value
   *     literal: false,       // whether argument is a literal
   *     structured: false,    // whether the property is a path
   *     rootProperty: 'prop', // the root property of the path
   *     wildcard: false       // whether the argument was a wildcard '.*' path
   *   }
   *
   * @param {string} rawArg The string value of the argument
   * @return {!MethodArg} Argument metadata object
   * @private
   */


  function parseArg(rawArg) {
    // clean up whitespace
    let arg = rawArg.trim() // replace comma entity with comma
    .replace(/&comma;/g, ',') // repair extra escape sequences; note only commas strictly need
    // escaping, but we allow any other char to be escaped since its
    // likely users will do this
    .replace(/\\(.)/g, '\$1'); // basic argument descriptor

    let a = {
      name: arg,
      value: '',
      literal: false
    }; // detect literal value (must be String or Number)

    let fc = arg[0];

    if (fc === '-') {
      fc = arg[1];
    }

    if (fc >= '0' && fc <= '9') {
      fc = '#';
    }

    switch (fc) {
      case "'":
      case '"':
        a.value = arg.slice(1, -1);
        a.literal = true;
        break;

      case '#':
        a.value = Number(arg);
        a.literal = true;
        break;
    } // if not literal, look for structured path


    if (!a.literal) {
      a.rootProperty = root(arg); // detect structured path (has dots)

      a.structured = isPath(arg);

      if (a.structured) {
        a.wildcard = arg.slice(-2) == '.*';

        if (a.wildcard) {
          a.name = arg.slice(0, -2);
        }
      }
    }

    return a;
  } // data api

  /**
   * Sends array splice notifications (`.splices` and `.length`)
   *
   * Note: this implementation only accepts normalized paths
   *
   * @param {!PropertyEffectsType} inst Instance to send notifications to
   * @param {Array} array The array the mutations occurred on
   * @param {string} path The path to the array that was mutated
   * @param {Array} splices Array of splice records
   * @return {void}
   * @private
   */


  function notifySplices(inst, array, path, splices) {
    let splicesPath = path + '.splices';
    inst.notifyPath(splicesPath, {
      indexSplices: splices
    });
    inst.notifyPath(path + '.length', array.length); // Null here to allow potentially large splice records to be GC'ed.

    inst.__data[splicesPath] = {
      indexSplices: null
    };
  }
  /**
   * Creates a splice record and sends an array splice notification for
   * the described mutation
   *
   * Note: this implementation only accepts normalized paths
   *
   * @param {!PropertyEffectsType} inst Instance to send notifications to
   * @param {Array} array The array the mutations occurred on
   * @param {string} path The path to the array that was mutated
   * @param {number} index Index at which the array mutation occurred
   * @param {number} addedCount Number of added items
   * @param {Array} removed Array of removed items
   * @return {void}
   * @private
   */


  function notifySplice(inst, array, path, index, addedCount, removed) {
    notifySplices(inst, array, path, [{
      index: index,
      addedCount: addedCount,
      removed: removed,
      object: array,
      type: 'splice'
    }]);
  }
  /**
   * Returns an upper-cased version of the string.
   *
   * @param {string} name String to uppercase
   * @return {string} Uppercased string
   * @private
   */


  function upper(name) {
    return name[0].toUpperCase() + name.substring(1);
  }
  /**
   * Element class mixin that provides meta-programming for Polymer's template
   * binding and data observation (collectively, "property effects") system.
   *
   * This mixin uses provides the following key static methods for adding
   * property effects to an element class:
   * - `addPropertyEffect`
   * - `createPropertyObserver`
   * - `createMethodObserver`
   * - `createNotifyingProperty`
   * - `createReadOnlyProperty`
   * - `createReflectedProperty`
   * - `createComputedProperty`
   * - `bindTemplate`
   *
   * Each method creates one or more property accessors, along with metadata
   * used by this mixin's implementation of `_propertiesChanged` to perform
   * the property effects.
   *
   * Underscored versions of the above methods also exist on the element
   * prototype for adding property effects on instances at runtime.
   *
   * Note that this mixin overrides several `PropertyAccessors` methods, in
   * many cases to maintain guarantees provided by the Polymer 1.x features;
   * notably it changes property accessors to be synchronous by default
   * whereas the default when using `PropertyAccessors` standalone is to be
   * async by default.
   *
   * @mixinFunction
   * @polymer
   * @appliesMixin TemplateStamp
   * @appliesMixin PropertyAccessors
   * @summary Element class mixin that provides meta-programming for Polymer's
   * template binding and data observation system.
   */


  const PropertyEffects = dedupingMixin(superClass => {
    /**
     * @constructor
     * @extends {superClass}
     * @implements {Polymer_PropertyAccessors}
     * @implements {Polymer_TemplateStamp}
     * @unrestricted
     * @private
     */
    const propertyEffectsBase = TemplateStamp(PropertyAccessors(superClass));
    /**
     * @polymer
     * @mixinClass
     * @implements {Polymer_PropertyEffects}
     * @extends {propertyEffectsBase}
     * @unrestricted
     */

    class PropertyEffects extends propertyEffectsBase {
      constructor() {
        super();
        /** @type {boolean} */
        // Used to identify users of this mixin, ala instanceof

        this.__isPropertyEffectsClient = true;
        /** @type {number} */
        // NOTE: used to track re-entrant calls to `_flushProperties`
        // path changes dirty check against `__dataTemp` only during one "turn"
        // and are cleared when `__dataCounter` returns to 0.

        this.__dataCounter = 0;
        /** @type {boolean} */

        this.__dataClientsReady;
        /** @type {Array} */

        this.__dataPendingClients;
        /** @type {Object} */

        this.__dataToNotify;
        /** @type {Object} */

        this.__dataLinkedPaths;
        /** @type {boolean} */

        this.__dataHasPaths;
        /** @type {Object} */

        this.__dataCompoundStorage;
        /** @type {Polymer_PropertyEffects} */

        this.__dataHost;
        /** @type {!Object} */

        this.__dataTemp;
        /** @type {boolean} */

        this.__dataClientsInitialized;
        /** @type {!Object} */

        this.__data;
        /** @type {!Object} */

        this.__dataPending;
        /** @type {!Object} */

        this.__dataOld;
        /** @type {Object} */

        this.__computeEffects;
        /** @type {Object} */

        this.__reflectEffects;
        /** @type {Object} */

        this.__notifyEffects;
        /** @type {Object} */

        this.__propagateEffects;
        /** @type {Object} */

        this.__observeEffects;
        /** @type {Object} */

        this.__readOnly;
        /** @type {!TemplateInfo} */

        this.__templateInfo;
      }

      get PROPERTY_EFFECT_TYPES() {
        return TYPES;
      }
      /**
       * @return {void}
       */


      _initializeProperties() {
        super._initializeProperties();

        hostStack.registerHost(this);
        this.__dataClientsReady = false;
        this.__dataPendingClients = null;
        this.__dataToNotify = null;
        this.__dataLinkedPaths = null;
        this.__dataHasPaths = false; // May be set on instance prior to upgrade

        this.__dataCompoundStorage = this.__dataCompoundStorage || null;
        this.__dataHost = this.__dataHost || null;
        this.__dataTemp = {};
        this.__dataClientsInitialized = false;
      }
      /**
       * Overrides `PropertyAccessors` implementation to provide a
       * more efficient implementation of initializing properties from
       * the prototype on the instance.
       *
       * @override
       * @param {Object} props Properties to initialize on the prototype
       * @return {void}
       */


      _initializeProtoProperties(props) {
        this.__data = Object.create(props);
        this.__dataPending = Object.create(props);
        this.__dataOld = {};
      }
      /**
       * Overrides `PropertyAccessors` implementation to avoid setting
       * `_setProperty`'s `shouldNotify: true`.
       *
       * @override
       * @param {Object} props Properties to initialize on the instance
       * @return {void}
       */


      _initializeInstanceProperties(props) {
        let readOnly = this[TYPES.READ_ONLY];

        for (let prop in props) {
          if (!readOnly || !readOnly[prop]) {
            this.__dataPending = this.__dataPending || {};
            this.__dataOld = this.__dataOld || {};
            this.__data[prop] = this.__dataPending[prop] = props[prop];
          }
        }
      } // Prototype setup ----------------------------------------

      /**
       * Equivalent to static `addPropertyEffect` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} property Property that should trigger the effect
       * @param {string} type Effect type, from this.PROPERTY_EFFECT_TYPES
       * @param {Object=} effect Effect metadata object
       * @return {void}
       * @protected
       */


      _addPropertyEffect(property, type, effect) {
        this._createPropertyAccessor(property, type == TYPES.READ_ONLY); // effects are accumulated into arrays per property based on type


        let effects = ensureOwnEffectMap(this, type)[property];

        if (!effects) {
          effects = this[type][property] = [];
        }

        effects.push(effect);
      }
      /**
       * Removes the given property effect.
       *
       * @param {string} property Property the effect was associated with
       * @param {string} type Effect type, from this.PROPERTY_EFFECT_TYPES
       * @param {Object=} effect Effect metadata object to remove
       * @return {void}
       */


      _removePropertyEffect(property, type, effect) {
        let effects = ensureOwnEffectMap(this, type)[property];
        let idx = effects.indexOf(effect);

        if (idx >= 0) {
          effects.splice(idx, 1);
        }
      }
      /**
       * Returns whether the current prototype/instance has a property effect
       * of a certain type.
       *
       * @param {string} property Property name
       * @param {string=} type Effect type, from this.PROPERTY_EFFECT_TYPES
       * @return {boolean} True if the prototype/instance has an effect of this type
       * @protected
       */


      _hasPropertyEffect(property, type) {
        let effects = this[type];
        return Boolean(effects && effects[property]);
      }
      /**
       * Returns whether the current prototype/instance has a "read only"
       * accessor for the given property.
       *
       * @param {string} property Property name
       * @return {boolean} True if the prototype/instance has an effect of this type
       * @protected
       */


      _hasReadOnlyEffect(property) {
        return this._hasPropertyEffect(property, TYPES.READ_ONLY);
      }
      /**
       * Returns whether the current prototype/instance has a "notify"
       * property effect for the given property.
       *
       * @param {string} property Property name
       * @return {boolean} True if the prototype/instance has an effect of this type
       * @protected
       */


      _hasNotifyEffect(property) {
        return this._hasPropertyEffect(property, TYPES.NOTIFY);
      }
      /**
       * Returns whether the current prototype/instance has a "reflect to attribute"
       * property effect for the given property.
       *
       * @param {string} property Property name
       * @return {boolean} True if the prototype/instance has an effect of this type
       * @protected
       */


      _hasReflectEffect(property) {
        return this._hasPropertyEffect(property, TYPES.REFLECT);
      }
      /**
       * Returns whether the current prototype/instance has a "computed"
       * property effect for the given property.
       *
       * @param {string} property Property name
       * @return {boolean} True if the prototype/instance has an effect of this type
       * @protected
       */


      _hasComputedEffect(property) {
        return this._hasPropertyEffect(property, TYPES.COMPUTE);
      } // Runtime ----------------------------------------

      /**
       * Sets a pending property or path.  If the root property of the path in
       * question had no accessor, the path is set, otherwise it is enqueued
       * via `_setPendingProperty`.
       *
       * This function isolates relatively expensive functionality necessary
       * for the public API (`set`, `setProperties`, `notifyPath`, and property
       * change listeners via {{...}} bindings), such that it is only done
       * when paths enter the system, and not at every propagation step.  It
       * also sets a `__dataHasPaths` flag on the instance which is used to
       * fast-path slower path-matching code in the property effects host paths.
       *
       * `path` can be a path string or array of path parts as accepted by the
       * public API.
       *
       * @param {string | !Array<number|string>} path Path to set
       * @param {*} value Value to set
       * @param {boolean=} shouldNotify Set to true if this change should
       *  cause a property notification event dispatch
       * @param {boolean=} isPathNotification If the path being set is a path
       *   notification of an already changed value, as opposed to a request
       *   to set and notify the change.  In the latter `false` case, a dirty
       *   check is performed and then the value is set to the path before
       *   enqueuing the pending property change.
       * @return {boolean} Returns true if the property/path was enqueued in
       *   the pending changes bag.
       * @protected
       */


      _setPendingPropertyOrPath(path, value, shouldNotify, isPathNotification) {
        if (isPathNotification || root(Array.isArray(path) ? path[0] : path) !== path) {
          // Dirty check changes being set to a path against the actual object,
          // since this is the entry point for paths into the system; from here
          // the only dirty checks are against the `__dataTemp` cache to prevent
          // duplicate work in the same turn only. Note, if this was a notification
          // of a change already set to a path (isPathNotification: true),
          // we always let the change through and skip the `set` since it was
          // already dirty checked at the point of entry and the underlying
          // object has already been updated
          if (!isPathNotification) {
            let old = get(this, path);
            path =
            /** @type {string} */
            set(this, path, value); // Use property-accessor's simpler dirty check

            if (!path || !super._shouldPropertyChange(path, value, old)) {
              return false;
            }
          }

          this.__dataHasPaths = true;

          if (this._setPendingProperty(
          /**@type{string}*/
          path, value, shouldNotify)) {
            computeLinkedPaths(this, path, value);
            return true;
          }
        } else {
          if (this.__dataHasAccessor && this.__dataHasAccessor[path]) {
            return this._setPendingProperty(
            /**@type{string}*/
            path, value, shouldNotify);
          } else {
            this[path] = value;
          }
        }

        return false;
      }
      /**
       * Applies a value to a non-Polymer element/node's property.
       *
       * The implementation makes a best-effort at binding interop:
       * Some native element properties have side-effects when
       * re-setting the same value (e.g. setting `<input>.value` resets the
       * cursor position), so we do a dirty-check before setting the value.
       * However, for better interop with non-Polymer custom elements that
       * accept objects, we explicitly re-set object changes coming from the
       * Polymer world (which may include deep object changes without the
       * top reference changing), erring on the side of providing more
       * information.
       *
       * Users may override this method to provide alternate approaches.
       *
       * @param {!Node} node The node to set a property on
       * @param {string} prop The property to set
       * @param {*} value The value to set
       * @return {void}
       * @protected
       */


      _setUnmanagedPropertyToNode(node, prop, value) {
        // It is a judgment call that resetting primitives is
        // "bad" and resettings objects is also "good"; alternatively we could
        // implement a whitelist of tag & property values that should never
        // be reset (e.g. <input>.value && <select>.value)
        if (value !== node[prop] || typeof value == 'object') {
          node[prop] = value;
        }
      }
      /**
       * Overrides the `PropertiesChanged` implementation to introduce special
       * dirty check logic depending on the property & value being set:
       *
       * 1. Any value set to a path (e.g. 'obj.prop': 42 or 'obj.prop': {...})
       *    Stored in `__dataTemp`, dirty checked against `__dataTemp`
       * 2. Object set to simple property (e.g. 'prop': {...})
       *    Stored in `__dataTemp` and `__data`, dirty checked against
       *    `__dataTemp` by default implementation of `_shouldPropertyChange`
       * 3. Primitive value set to simple property (e.g. 'prop': 42)
       *    Stored in `__data`, dirty checked against `__data`
       *
       * The dirty-check is important to prevent cycles due to two-way
       * notification, but paths and objects are only dirty checked against any
       * previous value set during this turn via a "temporary cache" that is
       * cleared when the last `_propertiesChanged` exits. This is so:
       * a. any cached array paths (e.g. 'array.3.prop') may be invalidated
       *    due to array mutations like shift/unshift/splice; this is fine
       *    since path changes are dirty-checked at user entry points like `set`
       * b. dirty-checking for objects only lasts one turn to allow the user
       *    to mutate the object in-place and re-set it with the same identity
       *    and have all sub-properties re-propagated in a subsequent turn.
       *
       * The temp cache is not necessarily sufficient to prevent invalid array
       * paths, since a splice can happen during the same turn (with pathological
       * user code); we could introduce a "fixup" for temporarily cached array
       * paths if needed: https://github.com/Polymer/polymer/issues/4227
       *
       * @override
       * @param {string} property Name of the property
       * @param {*} value Value to set
       * @param {boolean=} shouldNotify True if property should fire notification
       *   event (applies only for `notify: true` properties)
       * @return {boolean} Returns true if the property changed
       */


      _setPendingProperty(property, value, shouldNotify) {
        let propIsPath = this.__dataHasPaths && isPath(property);
        let prevProps = propIsPath ? this.__dataTemp : this.__data;

        if (this._shouldPropertyChange(property, value, prevProps[property])) {
          if (!this.__dataPending) {
            this.__dataPending = {};
            this.__dataOld = {};
          } // Ensure old is captured from the last turn


          if (!(property in this.__dataOld)) {
            this.__dataOld[property] = this.__data[property];
          } // Paths are stored in temporary cache (cleared at end of turn),
          // which is used for dirty-checking, all others stored in __data


          if (propIsPath) {
            this.__dataTemp[property] = value;
          } else {
            this.__data[property] = value;
          } // All changes go into pending property bag, passed to _propertiesChanged


          this.__dataPending[property] = value; // Track properties that should notify separately

          if (propIsPath || this[TYPES.NOTIFY] && this[TYPES.NOTIFY][property]) {
            this.__dataToNotify = this.__dataToNotify || {};
            this.__dataToNotify[property] = shouldNotify;
          }

          return true;
        }

        return false;
      }
      /**
       * Overrides base implementation to ensure all accessors set `shouldNotify`
       * to true, for per-property notification tracking.
       *
       * @override
       * @param {string} property Name of the property
       * @param {*} value Value to set
       * @return {void}
       */


      _setProperty(property, value) {
        if (this._setPendingProperty(property, value, true)) {
          this._invalidateProperties();
        }
      }
      /**
       * Overrides `PropertyAccessor`'s default async queuing of
       * `_propertiesChanged`: if `__dataReady` is false (has not yet been
       * manually flushed), the function no-ops; otherwise flushes
       * `_propertiesChanged` synchronously.
       *
       * @override
       * @return {void}
       */


      _invalidateProperties() {
        if (this.__dataReady) {
          this._flushProperties();
        }
      }
      /**
       * Enqueues the given client on a list of pending clients, whose
       * pending property changes can later be flushed via a call to
       * `_flushClients`.
       *
       * @param {Object} client PropertyEffects client to enqueue
       * @return {void}
       * @protected
       */


      _enqueueClient(client) {
        this.__dataPendingClients = this.__dataPendingClients || [];

        if (client !== this) {
          this.__dataPendingClients.push(client);
        }
      }
      /**
       * Overrides superclass implementation.
       *
       * @return {void}
       * @protected
       */


      _flushProperties() {
        this.__dataCounter++;

        super._flushProperties();

        this.__dataCounter--;
      }
      /**
       * Flushes any clients previously enqueued via `_enqueueClient`, causing
       * their `_flushProperties` method to run.
       *
       * @return {void}
       * @protected
       */


      _flushClients() {
        if (!this.__dataClientsReady) {
          this.__dataClientsReady = true;

          this._readyClients(); // Override point where accessors are turned on; importantly,
          // this is after clients have fully readied, providing a guarantee
          // that any property effects occur only after all clients are ready.


          this.__dataReady = true;
        } else {
          this.__enableOrFlushClients();
        }
      } // NOTE: We ensure clients either enable or flush as appropriate. This
      // handles two corner cases:
      // (1) clients flush properly when connected/enabled before the host
      // enables; e.g.
      //   (a) Templatize stamps with no properties and does not flush and
      //   (b) the instance is inserted into dom and
      //   (c) then the instance flushes.
      // (2) clients enable properly when not connected/enabled when the host
      // flushes; e.g.
      //   (a) a template is runtime stamped and not yet connected/enabled
      //   (b) a host sets a property, causing stamped dom to flush
      //   (c) the stamped dom enables.


      __enableOrFlushClients() {
        let clients = this.__dataPendingClients;

        if (clients) {
          this.__dataPendingClients = null;

          for (let i = 0; i < clients.length; i++) {
            let client = clients[i];

            if (!client.__dataEnabled) {
              client._enableProperties();
            } else if (client.__dataPending) {
              client._flushProperties();
            }
          }
        }
      }
      /**
       * Perform any initial setup on client dom. Called before the first
       * `_flushProperties` call on client dom and before any element
       * observers are called.
       *
       * @return {void}
       * @protected
       */


      _readyClients() {
        this.__enableOrFlushClients();
      }
      /**
       * Sets a bag of property changes to this instance, and
       * synchronously processes all effects of the properties as a batch.
       *
       * Property names must be simple properties, not paths.  Batched
       * path propagation is not supported.
       *
       * @param {Object} props Bag of one or more key-value pairs whose key is
       *   a property and value is the new value to set for that property.
       * @param {boolean=} setReadOnly When true, any private values set in
       *   `props` will be set. By default, `setProperties` will not set
       *   `readOnly: true` root properties.
       * @return {void}
       * @public
       */


      setProperties(props, setReadOnly) {
        for (let path in props) {
          if (setReadOnly || !this[TYPES.READ_ONLY] || !this[TYPES.READ_ONLY][path]) {
            //TODO(kschaaf): explicitly disallow paths in setProperty?
            // wildcard observers currently only pass the first changed path
            // in the `info` object, and you could do some odd things batching
            // paths, e.g. {'foo.bar': {...}, 'foo': null}
            this._setPendingPropertyOrPath(path, props[path], true);
          }
        }

        this._invalidateProperties();
      }
      /**
       * Overrides `PropertyAccessors` so that property accessor
       * side effects are not enabled until after client dom is fully ready.
       * Also calls `_flushClients` callback to ensure client dom is enabled
       * that was not enabled as a result of flushing properties.
       *
       * @override
       * @return {void}
       */


      ready() {
        // It is important that `super.ready()` is not called here as it
        // immediately turns on accessors. Instead, we wait until `readyClients`
        // to enable accessors to provide a guarantee that clients are ready
        // before processing any accessors side effects.
        this._flushProperties(); // If no data was pending, `_flushProperties` will not `flushClients`
        // so ensure this is done.


        if (!this.__dataClientsReady) {
          this._flushClients();
        } // Before ready, client notifications do not trigger _flushProperties.
        // Therefore a flush is necessary here if data has been set.


        if (this.__dataPending) {
          this._flushProperties();
        }
      }
      /**
       * Implements `PropertyAccessors`'s properties changed callback.
       *
       * Runs each class of effects for the batch of changed properties in
       * a specific order (compute, propagate, reflect, observe, notify).
       *
       * @param {!Object} currentProps Bag of all current accessor values
       * @param {?Object} changedProps Bag of properties changed since the last
       *   call to `_propertiesChanged`
       * @param {?Object} oldProps Bag of previous values for each property
       *   in `changedProps`
       * @return {void}
       */


      _propertiesChanged(currentProps, changedProps, oldProps) {
        // ----------------------------
        // let c = Object.getOwnPropertyNames(changedProps || {});
        // window.debug && console.group(this.localName + '#' + this.id + ': ' + c);
        // if (window.debug) { debugger; }
        // ----------------------------
        let hasPaths = this.__dataHasPaths;
        this.__dataHasPaths = false; // Compute properties

        runComputedEffects(this, changedProps, oldProps, hasPaths); // Clear notify properties prior to possible reentry (propagate, observe),
        // but after computing effects have a chance to add to them

        let notifyProps = this.__dataToNotify;
        this.__dataToNotify = null; // Propagate properties to clients

        this._propagatePropertyChanges(changedProps, oldProps, hasPaths); // Flush clients


        this._flushClients(); // Reflect properties


        runEffects(this, this[TYPES.REFLECT], changedProps, oldProps, hasPaths); // Observe properties

        runEffects(this, this[TYPES.OBSERVE], changedProps, oldProps, hasPaths); // Notify properties to host

        if (notifyProps) {
          runNotifyEffects(this, notifyProps, changedProps, oldProps, hasPaths);
        } // Clear temporary cache at end of turn


        if (this.__dataCounter == 1) {
          this.__dataTemp = {};
        } // ----------------------------
        // window.debug && console.groupEnd(this.localName + '#' + this.id + ': ' + c);
        // ----------------------------

      }
      /**
       * Called to propagate any property changes to stamped template nodes
       * managed by this element.
       *
       * @param {Object} changedProps Bag of changed properties
       * @param {Object} oldProps Bag of previous values for changed properties
       * @param {boolean} hasPaths True with `props` contains one or more paths
       * @return {void}
       * @protected
       */


      _propagatePropertyChanges(changedProps, oldProps, hasPaths) {
        if (this[TYPES.PROPAGATE]) {
          runEffects(this, this[TYPES.PROPAGATE], changedProps, oldProps, hasPaths);
        }

        let templateInfo = this.__templateInfo;

        while (templateInfo) {
          runEffects(this, templateInfo.propertyEffects, changedProps, oldProps, hasPaths, templateInfo.nodeList);
          templateInfo = templateInfo.nextTemplateInfo;
        }
      }
      /**
       * Aliases one data path as another, such that path notifications from one
       * are routed to the other.
       *
       * @param {string | !Array<string|number>} to Target path to link.
       * @param {string | !Array<string|number>} from Source path to link.
       * @return {void}
       * @public
       */


      linkPaths(to, from) {
        to = normalize(to);
        from = normalize(from);
        this.__dataLinkedPaths = this.__dataLinkedPaths || {};
        this.__dataLinkedPaths[to] = from;
      }
      /**
       * Removes a data path alias previously established with `_linkPaths`.
       *
       * Note, the path to unlink should be the target (`to`) used when
       * linking the paths.
       *
       * @param {string | !Array<string|number>} path Target path to unlink.
       * @return {void}
       * @public
       */


      unlinkPaths(path) {
        path = normalize(path);

        if (this.__dataLinkedPaths) {
          delete this.__dataLinkedPaths[path];
        }
      }
      /**
       * Notify that an array has changed.
       *
       * Example:
       *
       *     this.items = [ {name: 'Jim'}, {name: 'Todd'}, {name: 'Bill'} ];
       *     ...
       *     this.items.splice(1, 1, {name: 'Sam'});
       *     this.items.push({name: 'Bob'});
       *     this.notifySplices('items', [
       *       { index: 1, removed: [{name: 'Todd'}], addedCount: 1, object: this.items, type: 'splice' },
       *       { index: 3, removed: [], addedCount: 1, object: this.items, type: 'splice'}
       *     ]);
       *
       * @param {string} path Path that should be notified.
       * @param {Array} splices Array of splice records indicating ordered
       *   changes that occurred to the array. Each record should have the
       *   following fields:
       *    * index: index at which the change occurred
       *    * removed: array of items that were removed from this index
       *    * addedCount: number of new items added at this index
       *    * object: a reference to the array in question
       *    * type: the string literal 'splice'
       *
       *   Note that splice records _must_ be normalized such that they are
       *   reported in index order (raw results from `Object.observe` are not
       *   ordered and must be normalized/merged before notifying).
       * @return {void}
       * @public
      */


      notifySplices(path, splices) {
        let info = {
          path: ''
        };
        let array =
        /** @type {Array} */
        get(this, path, info);
        notifySplices(this, array, info.path, splices);
      }
      /**
       * Convenience method for reading a value from a path.
       *
       * Note, if any part in the path is undefined, this method returns
       * `undefined` (this method does not throw when dereferencing undefined
       * paths).
       *
       * @param {(string|!Array<(string|number)>)} path Path to the value
       *   to read.  The path may be specified as a string (e.g. `foo.bar.baz`)
       *   or an array of path parts (e.g. `['foo.bar', 'baz']`).  Note that
       *   bracketed expressions are not supported; string-based path parts
       *   *must* be separated by dots.  Note that when dereferencing array
       *   indices, the index may be used as a dotted part directly
       *   (e.g. `users.12.name` or `['users', 12, 'name']`).
       * @param {Object=} root Root object from which the path is evaluated.
       * @return {*} Value at the path, or `undefined` if any part of the path
       *   is undefined.
       * @public
       */


      get(path, root$$1) {
        return get(root$$1 || this, path);
      }
      /**
       * Convenience method for setting a value to a path and notifying any
       * elements bound to the same path.
       *
       * Note, if any part in the path except for the last is undefined,
       * this method does nothing (this method does not throw when
       * dereferencing undefined paths).
       *
       * @param {(string|!Array<(string|number)>)} path Path to the value
       *   to write.  The path may be specified as a string (e.g. `'foo.bar.baz'`)
       *   or an array of path parts (e.g. `['foo.bar', 'baz']`).  Note that
       *   bracketed expressions are not supported; string-based path parts
       *   *must* be separated by dots.  Note that when dereferencing array
       *   indices, the index may be used as a dotted part directly
       *   (e.g. `'users.12.name'` or `['users', 12, 'name']`).
       * @param {*} value Value to set at the specified path.
       * @param {Object=} root Root object from which the path is evaluated.
       *   When specified, no notification will occur.
       * @return {void}
       * @public
      */


      set(path, value, root$$1) {
        if (root$$1) {
          set(root$$1, path, value);
        } else {
          if (!this[TYPES.READ_ONLY] || !this[TYPES.READ_ONLY][
          /** @type {string} */
          path]) {
            if (this._setPendingPropertyOrPath(path, value, true)) {
              this._invalidateProperties();
            }
          }
        }
      }
      /**
       * Adds items onto the end of the array at the path specified.
       *
       * The arguments after `path` and return value match that of
       * `Array.prototype.push`.
       *
       * This method notifies other paths to the same array that a
       * splice occurred to the array.
       *
       * @param {string | !Array<string|number>} path Path to array.
       * @param {...*} items Items to push onto array
       * @return {number} New length of the array.
       * @public
       */


      push(path, ...items) {
        let info = {
          path: ''
        };
        let array =
        /** @type {Array}*/
        get(this, path, info);
        let len = array.length;
        let ret = array.push(...items);

        if (items.length) {
          notifySplice(this, array, info.path, len, items.length, []);
        }

        return ret;
      }
      /**
       * Removes an item from the end of array at the path specified.
       *
       * The arguments after `path` and return value match that of
       * `Array.prototype.pop`.
       *
       * This method notifies other paths to the same array that a
       * splice occurred to the array.
       *
       * @param {string | !Array<string|number>} path Path to array.
       * @return {*} Item that was removed.
       * @public
       */


      pop(path) {
        let info = {
          path: ''
        };
        let array =
        /** @type {Array} */
        get(this, path, info);
        let hadLength = Boolean(array.length);
        let ret = array.pop();

        if (hadLength) {
          notifySplice(this, array, info.path, array.length, 0, [ret]);
        }

        return ret;
      }
      /**
       * Starting from the start index specified, removes 0 or more items
       * from the array and inserts 0 or more new items in their place.
       *
       * The arguments after `path` and return value match that of
       * `Array.prototype.splice`.
       *
       * This method notifies other paths to the same array that a
       * splice occurred to the array.
       *
       * @param {string | !Array<string|number>} path Path to array.
       * @param {number} start Index from which to start removing/inserting.
       * @param {number=} deleteCount Number of items to remove.
       * @param {...*} items Items to insert into array.
       * @return {Array} Array of removed items.
       * @public
       */


      splice(path, start, deleteCount, ...items) {
        let info = {
          path: ''
        };
        let array =
        /** @type {Array} */
        get(this, path, info); // Normalize fancy native splice handling of crazy start values

        if (start < 0) {
          start = array.length - Math.floor(-start);
        } else if (start) {
          start = Math.floor(start);
        } // array.splice does different things based on the number of arguments
        // you pass in. Therefore, array.splice(0) and array.splice(0, undefined)
        // do different things. In the former, the whole array is cleared. In the
        // latter, no items are removed.
        // This means that we need to detect whether 1. one of the arguments
        // is actually passed in and then 2. determine how many arguments
        // we should pass on to the native array.splice
        //


        let ret; // Omit any additional arguments if they were not passed in

        if (arguments.length === 2) {
          ret = array.splice(start); // Either start was undefined and the others were defined, but in this
          // case we can safely pass on all arguments
          //
          // Note: this includes the case where none of the arguments were passed in,
          // e.g. this.splice('array'). However, if both start and deleteCount
          // are undefined, array.splice will not modify the array (as expected)
        } else {
          ret = array.splice(start, deleteCount, ...items);
        } // At the end, check whether any items were passed in (e.g. insertions)
        // or if the return array contains items (e.g. deletions).
        // Only notify if items were added or deleted.


        if (items.length || ret.length) {
          notifySplice(this, array, info.path, start, items.length, ret);
        }

        return ret;
      }
      /**
       * Removes an item from the beginning of array at the path specified.
       *
       * The arguments after `path` and return value match that of
       * `Array.prototype.pop`.
       *
       * This method notifies other paths to the same array that a
       * splice occurred to the array.
       *
       * @param {string | !Array<string|number>} path Path to array.
       * @return {*} Item that was removed.
       * @public
       */


      shift(path) {
        let info = {
          path: ''
        };
        let array =
        /** @type {Array} */
        get(this, path, info);
        let hadLength = Boolean(array.length);
        let ret = array.shift();

        if (hadLength) {
          notifySplice(this, array, info.path, 0, 0, [ret]);
        }

        return ret;
      }
      /**
       * Adds items onto the beginning of the array at the path specified.
       *
       * The arguments after `path` and return value match that of
       * `Array.prototype.push`.
       *
       * This method notifies other paths to the same array that a
       * splice occurred to the array.
       *
       * @param {string | !Array<string|number>} path Path to array.
       * @param {...*} items Items to insert info array
       * @return {number} New length of the array.
       * @public
       */


      unshift(path, ...items) {
        let info = {
          path: ''
        };
        let array =
        /** @type {Array} */
        get(this, path, info);
        let ret = array.unshift(...items);

        if (items.length) {
          notifySplice(this, array, info.path, 0, items.length, []);
        }

        return ret;
      }
      /**
       * Notify that a path has changed.
       *
       * Example:
       *
       *     this.item.user.name = 'Bob';
       *     this.notifyPath('item.user.name');
       *
       * @param {string} path Path that should be notified.
       * @param {*=} value Value at the path (optional).
       * @return {void}
       * @public
      */


      notifyPath(path, value) {
        /** @type {string} */
        let propPath;

        if (arguments.length == 1) {
          // Get value if not supplied
          let info = {
            path: ''
          };
          value = get(this, path, info);
          propPath = info.path;
        } else if (Array.isArray(path)) {
          // Normalize path if needed
          propPath = normalize(path);
        } else {
          propPath =
          /** @type{string} */
          path;
        }

        if (this._setPendingPropertyOrPath(propPath, value, true, true)) {
          this._invalidateProperties();
        }
      }
      /**
       * Equivalent to static `createReadOnlyProperty` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} property Property name
       * @param {boolean=} protectedSetter Creates a custom protected setter
       *   when `true`.
       * @return {void}
       * @protected
       */


      _createReadOnlyProperty(property, protectedSetter) {
        this._addPropertyEffect(property, TYPES.READ_ONLY);

        if (protectedSetter) {
          this['_set' + upper(property)] =
          /** @this {PropertyEffects} */
          function (value) {
            this._setProperty(property, value);
          };
        }
      }
      /**
       * Equivalent to static `createPropertyObserver` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} property Property name
       * @param {string|function(*,*)} method Function or name of observer method to call
       * @param {boolean=} dynamicFn Whether the method name should be included as
       *   a dependency to the effect.
       * @return {void}
       * @protected
       */


      _createPropertyObserver(property, method, dynamicFn) {
        let info = {
          property,
          method,
          dynamicFn: Boolean(dynamicFn)
        };

        this._addPropertyEffect(property, TYPES.OBSERVE, {
          fn: runObserverEffect,
          info,
          trigger: {
            name: property
          }
        });

        if (dynamicFn) {
          this._addPropertyEffect(
          /** @type {string} */
          method, TYPES.OBSERVE, {
            fn: runObserverEffect,
            info,
            trigger: {
              name: method
            }
          });
        }
      }
      /**
       * Equivalent to static `createMethodObserver` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} expression Method expression
       * @param {boolean|Object=} dynamicFn Boolean or object map indicating
       *   whether method names should be included as a dependency to the effect.
       * @return {void}
       * @protected
       */


      _createMethodObserver(expression, dynamicFn) {
        let sig = parseMethod(expression);

        if (!sig) {
          throw new Error("Malformed observer expression '" + expression + "'");
        }

        createMethodEffect(this, sig, TYPES.OBSERVE, runMethodEffect, null, dynamicFn);
      }
      /**
       * Equivalent to static `createNotifyingProperty` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} property Property name
       * @return {void}
       * @protected
       */


      _createNotifyingProperty(property) {
        this._addPropertyEffect(property, TYPES.NOTIFY, {
          fn: runNotifyEffect,
          info: {
            eventName: camelToDashCase(property) + '-changed',
            property: property
          }
        });
      }
      /**
       * Equivalent to static `createReflectedProperty` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} property Property name
       * @return {void}
       * @protected
       */


      _createReflectedProperty(property) {
        let attr = this.constructor.attributeNameForProperty(property);

        if (attr[0] === '-') {
          console.warn('Property ' + property + ' cannot be reflected to attribute ' + attr + ' because "-" is not a valid starting attribute name. Use a lowercase first letter for the property instead.');
        } else {
          this._addPropertyEffect(property, TYPES.REFLECT, {
            fn: runReflectEffect,
            info: {
              attrName: attr
            }
          });
        }
      }
      /**
       * Equivalent to static `createComputedProperty` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * @param {string} property Name of computed property to set
       * @param {string} expression Method expression
       * @param {boolean|Object=} dynamicFn Boolean or object map indicating
       *   whether method names should be included as a dependency to the effect.
       * @return {void}
       * @protected
       */


      _createComputedProperty(property, expression, dynamicFn) {
        let sig = parseMethod(expression);

        if (!sig) {
          throw new Error("Malformed computed expression '" + expression + "'");
        }

        createMethodEffect(this, sig, TYPES.COMPUTE, runComputedEffect, property, dynamicFn);
      }
      /**
       * Gather the argument values for a method specified in the provided array
       * of argument metadata.
       *
       * The `path` and `value` arguments are used to fill in wildcard descriptor
       * when the method is being called as a result of a path notification.
       *
       * @param {!Array<!MethodArg>} args Array of argument metadata
       * @param {string} path Property/path name that triggered the method effect
       * @param {Object} props Bag of current property changes
       * @return {Array<*>} Array of argument values
       * @private
       */


      _marshalArgs(args, path, props) {
        const data = this.__data;
        let values = [];

        for (let i = 0, l = args.length; i < l; i++) {
          let arg = args[i];
          let name = arg.name;
          let v;

          if (arg.literal) {
            v = arg.value;
          } else {
            if (arg.structured) {
              v = get(data, name); // when data is not stored e.g. `splices`

              if (v === undefined) {
                v = props[name];
              }
            } else {
              v = data[name];
            }
          }

          if (arg.wildcard) {
            // Only send the actual path changed info if the change that
            // caused the observer to run matched the wildcard
            let baseChanged = name.indexOf(path + '.') === 0;
            let matches$$1 = path.indexOf(name) === 0 && !baseChanged;
            values[i] = {
              path: matches$$1 ? path : name,
              value: matches$$1 ? props[path] : v,
              base: v
            };
          } else {
            values[i] = v;
          }
        }

        return values;
      } // -- static class methods ------------

      /**
       * Ensures an accessor exists for the specified property, and adds
       * to a list of "property effects" that will run when the accessor for
       * the specified property is set.  Effects are grouped by "type", which
       * roughly corresponds to a phase in effect processing.  The effect
       * metadata should be in the following form:
       *
       *     {
       *       fn: effectFunction, // Reference to function to call to perform effect
       *       info: { ... }       // Effect metadata passed to function
       *       trigger: {          // Optional triggering metadata; if not provided
       *         name: string      // the property is treated as a wildcard
       *         structured: boolean
       *         wildcard: boolean
       *       }
       *     }
       *
       * Effects are called from `_propertiesChanged` in the following order by
       * type:
       *
       * 1. COMPUTE
       * 2. PROPAGATE
       * 3. REFLECT
       * 4. OBSERVE
       * 5. NOTIFY
       *
       * Effect functions are called with the following signature:
       *
       *     effectFunction(inst, path, props, oldProps, info, hasPaths)
       *
       * @param {string} property Property that should trigger the effect
       * @param {string} type Effect type, from this.PROPERTY_EFFECT_TYPES
       * @param {Object=} effect Effect metadata object
       * @return {void}
       * @protected
       */


      static addPropertyEffect(property, type, effect) {
        this.prototype._addPropertyEffect(property, type, effect);
      }
      /**
       * Creates a single-property observer for the given property.
       *
       * @param {string} property Property name
       * @param {string|function(*,*)} method Function or name of observer method to call
       * @param {boolean=} dynamicFn Whether the method name should be included as
       *   a dependency to the effect.
       * @return {void}
       * @protected
       */


      static createPropertyObserver(property, method, dynamicFn) {
        this.prototype._createPropertyObserver(property, method, dynamicFn);
      }
      /**
       * Creates a multi-property "method observer" based on the provided
       * expression, which should be a string in the form of a normal JavaScript
       * function signature: `'methodName(arg1, [..., argn])'`.  Each argument
       * should correspond to a property or path in the context of this
       * prototype (or instance), or may be a literal string or number.
       *
       * @param {string} expression Method expression
       * @param {boolean|Object=} dynamicFn Boolean or object map indicating
       * @return {void}
       *   whether method names should be included as a dependency to the effect.
       * @protected
       */


      static createMethodObserver(expression, dynamicFn) {
        this.prototype._createMethodObserver(expression, dynamicFn);
      }
      /**
       * Causes the setter for the given property to dispatch `<property>-changed`
       * events to notify of changes to the property.
       *
       * @param {string} property Property name
       * @return {void}
       * @protected
       */


      static createNotifyingProperty(property) {
        this.prototype._createNotifyingProperty(property);
      }
      /**
       * Creates a read-only accessor for the given property.
       *
       * To set the property, use the protected `_setProperty` API.
       * To create a custom protected setter (e.g. `_setMyProp()` for
       * property `myProp`), pass `true` for `protectedSetter`.
       *
       * Note, if the property will have other property effects, this method
       * should be called first, before adding other effects.
       *
       * @param {string} property Property name
       * @param {boolean=} protectedSetter Creates a custom protected setter
       *   when `true`.
       * @return {void}
       * @protected
       */


      static createReadOnlyProperty(property, protectedSetter) {
        this.prototype._createReadOnlyProperty(property, protectedSetter);
      }
      /**
       * Causes the setter for the given property to reflect the property value
       * to a (dash-cased) attribute of the same name.
       *
       * @param {string} property Property name
       * @return {void}
       * @protected
       */


      static createReflectedProperty(property) {
        this.prototype._createReflectedProperty(property);
      }
      /**
       * Creates a computed property whose value is set to the result of the
       * method described by the given `expression` each time one or more
       * arguments to the method changes.  The expression should be a string
       * in the form of a normal JavaScript function signature:
       * `'methodName(arg1, [..., argn])'`
       *
       * @param {string} property Name of computed property to set
       * @param {string} expression Method expression
       * @param {boolean|Object=} dynamicFn Boolean or object map indicating whether
       *   method names should be included as a dependency to the effect.
       * @return {void}
       * @protected
       */


      static createComputedProperty(property, expression, dynamicFn) {
        this.prototype._createComputedProperty(property, expression, dynamicFn);
      }
      /**
       * Parses the provided template to ensure binding effects are created
       * for them, and then ensures property accessors are created for any
       * dependent properties in the template.  Binding effects for bound
       * templates are stored in a linked list on the instance so that
       * templates can be efficiently stamped and unstamped.
       *
       * @param {!HTMLTemplateElement} template Template containing binding
       *   bindings
       * @return {!TemplateInfo} Template metadata object
       * @protected
       */


      static bindTemplate(template) {
        return this.prototype._bindTemplate(template);
      } // -- binding ----------------------------------------------

      /**
       * Equivalent to static `bindTemplate` API but can be called on
       * an instance to add effects at runtime.  See that method for
       * full API docs.
       *
       * This method may be called on the prototype (for prototypical template
       * binding, to avoid creating accessors every instance) once per prototype,
       * and will be called with `runtimeBinding: true` by `_stampTemplate` to
       * create and link an instance of the template metadata associated with a
       * particular stamping.
       *
       * @param {!HTMLTemplateElement} template Template containing binding
       *   bindings
       * @param {boolean=} instanceBinding When false (default), performs
       *   "prototypical" binding of the template and overwrites any previously
       *   bound template for the class. When true (as passed from
       *   `_stampTemplate`), the template info is instanced and linked into
       *   the list of bound templates.
       * @return {!TemplateInfo} Template metadata object; for `runtimeBinding`,
       *   this is an instance of the prototypical template info
       * @protected
       */


      _bindTemplate(template, instanceBinding) {
        let templateInfo = this.constructor._parseTemplate(template);

        let wasPreBound = this.__templateInfo == templateInfo; // Optimization: since this is called twice for proto-bound templates,
        // don't attempt to recreate accessors if this template was pre-bound

        if (!wasPreBound) {
          for (let prop in templateInfo.propertyEffects) {
            this._createPropertyAccessor(prop);
          }
        }

        if (instanceBinding) {
          // For instance-time binding, create instance of template metadata
          // and link into list of templates if necessary
          templateInfo =
          /** @type {!TemplateInfo} */
          Object.create(templateInfo);
          templateInfo.wasPreBound = wasPreBound;

          if (!wasPreBound && this.__templateInfo) {
            let last = this.__templateInfoLast || this.__templateInfo;
            this.__templateInfoLast = last.nextTemplateInfo = templateInfo;
            templateInfo.previousTemplateInfo = last;
            return templateInfo;
          }
        }

        return this.__templateInfo = templateInfo;
      }
      /**
       * Adds a property effect to the given template metadata, which is run
       * at the "propagate" stage of `_propertiesChanged` when the template
       * has been bound to the element via `_bindTemplate`.
       *
       * The `effect` object should match the format in `_addPropertyEffect`.
       *
       * @param {Object} templateInfo Template metadata to add effect to
       * @param {string} prop Property that should trigger the effect
       * @param {Object=} effect Effect metadata object
       * @return {void}
       * @protected
       */


      static _addTemplatePropertyEffect(templateInfo, prop, effect) {
        let hostProps = templateInfo.hostProps = templateInfo.hostProps || {};
        hostProps[prop] = true;
        let effects = templateInfo.propertyEffects = templateInfo.propertyEffects || {};
        let propEffects = effects[prop] = effects[prop] || [];
        propEffects.push(effect);
      }
      /**
       * Stamps the provided template and performs instance-time setup for
       * Polymer template features, including data bindings, declarative event
       * listeners, and the `this.$` map of `id`'s to nodes.  A document fragment
       * is returned containing the stamped DOM, ready for insertion into the
       * DOM.
       *
       * This method may be called more than once; however note that due to
       * `shadycss` polyfill limitations, only styles from templates prepared
       * using `ShadyCSS.prepareTemplate` will be correctly polyfilled (scoped
       * to the shadow root and support CSS custom properties), and note that
       * `ShadyCSS.prepareTemplate` may only be called once per element. As such,
       * any styles required by in runtime-stamped templates must be included
       * in the main element template.
       *
       * @param {!HTMLTemplateElement} template Template to stamp
       * @return {!StampedTemplate} Cloned template content
       * @override
       * @protected
       */


      _stampTemplate(template) {
        // Ensures that created dom is `_enqueueClient`'d to this element so
        // that it can be flushed on next call to `_flushProperties`
        hostStack.beginHosting(this);

        let dom = super._stampTemplate(template);

        hostStack.endHosting(this);

        let templateInfo =
        /** @type {!TemplateInfo} */
        this._bindTemplate(template, true); // Add template-instance-specific data to instanced templateInfo


        templateInfo.nodeList = dom.nodeList; // Capture child nodes to allow unstamping of non-prototypical templates

        if (!templateInfo.wasPreBound) {
          let nodes = templateInfo.childNodes = [];

          for (let n = dom.firstChild; n; n = n.nextSibling) {
            nodes.push(n);
          }
        }

        dom.templateInfo = templateInfo; // Setup compound storage, 2-way listeners, and dataHost for bindings

        setupBindings(this, templateInfo); // Flush properties into template nodes if already booted

        if (this.__dataReady) {
          runEffects(this, templateInfo.propertyEffects, this.__data, null, false, templateInfo.nodeList);
        }

        return dom;
      }
      /**
       * Removes and unbinds the nodes previously contained in the provided
       * DocumentFragment returned from `_stampTemplate`.
       *
       * @param {!StampedTemplate} dom DocumentFragment previously returned
       *   from `_stampTemplate` associated with the nodes to be removed
       * @return {void}
       * @protected
       */


      _removeBoundDom(dom) {
        // Unlink template info
        let templateInfo = dom.templateInfo;

        if (templateInfo.previousTemplateInfo) {
          templateInfo.previousTemplateInfo.nextTemplateInfo = templateInfo.nextTemplateInfo;
        }

        if (templateInfo.nextTemplateInfo) {
          templateInfo.nextTemplateInfo.previousTemplateInfo = templateInfo.previousTemplateInfo;
        }

        if (this.__templateInfoLast == templateInfo) {
          this.__templateInfoLast = templateInfo.previousTemplateInfo;
        }

        templateInfo.previousTemplateInfo = templateInfo.nextTemplateInfo = null; // Remove stamped nodes

        let nodes = templateInfo.childNodes;

        for (let i = 0; i < nodes.length; i++) {
          let node = nodes[i];
          node.parentNode.removeChild(node);
        }
      }
      /**
       * Overrides default `TemplateStamp` implementation to add support for
       * parsing bindings from `TextNode`'s' `textContent`.  A `bindings`
       * array is added to `nodeInfo` and populated with binding metadata
       * with information capturing the binding target, and a `parts` array
       * with one or more metadata objects capturing the source(s) of the
       * binding.
       *
       * @override
       * @param {Node} node Node to parse
       * @param {TemplateInfo} templateInfo Template metadata for current template
       * @param {NodeInfo} nodeInfo Node metadata for current template node
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @protected
       * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
       */


      static _parseTemplateNode(node, templateInfo, nodeInfo) {
        let noted = super._parseTemplateNode(node, templateInfo, nodeInfo);

        if (node.nodeType === Node.TEXT_NODE) {
          let parts = this._parseBindings(node.textContent, templateInfo);

          if (parts) {
            // Initialize the textContent with any literal parts
            // NOTE: default to a space here so the textNode remains; some browsers
            // (IE) omit an empty textNode following cloneNode/importNode.
            node.textContent = literalFromParts(parts) || ' ';
            addBinding(this, templateInfo, nodeInfo, 'text', 'textContent', parts);
            noted = true;
          }
        }

        return noted;
      }
      /**
       * Overrides default `TemplateStamp` implementation to add support for
       * parsing bindings from attributes.  A `bindings`
       * array is added to `nodeInfo` and populated with binding metadata
       * with information capturing the binding target, and a `parts` array
       * with one or more metadata objects capturing the source(s) of the
       * binding.
       *
       * @override
       * @param {Element} node Node to parse
       * @param {TemplateInfo} templateInfo Template metadata for current template
       * @param {NodeInfo} nodeInfo Node metadata for current template node
       * @param {string} name Attribute name
       * @param {string} value Attribute value
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @protected
       * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
       */


      static _parseTemplateNodeAttribute(node, templateInfo, nodeInfo, name, value) {
        let parts = this._parseBindings(value, templateInfo);

        if (parts) {
          // Attribute or property
          let origName = name;
          let kind = 'property'; // The only way we see a capital letter here is if the attr has
          // a capital letter in it per spec. In this case, to make sure
          // this binding works, we go ahead and make the binding to the attribute.

          if (capitalAttributeRegex.test(name)) {
            kind = 'attribute';
          } else if (name[name.length - 1] == '$') {
            name = name.slice(0, -1);
            kind = 'attribute';
          } // Initialize attribute bindings with any literal parts


          let literal = literalFromParts(parts);

          if (literal && kind == 'attribute') {
            node.setAttribute(name, literal);
          } // Clear attribute before removing, since IE won't allow removing
          // `value` attribute if it previously had a value (can't
          // unconditionally set '' before removing since attributes with `$`
          // can't be set using setAttribute)


          if (node.localName === 'input' && origName === 'value') {
            node.setAttribute(origName, '');
          } // Remove annotation


          node.removeAttribute(origName); // Case hackery: attributes are lower-case, but bind targets
          // (properties) are case sensitive. Gambit is to map dash-case to
          // camel-case: `foo-bar` becomes `fooBar`.
          // Attribute bindings are excepted.

          if (kind === 'property') {
            name = dashToCamelCase(name);
          }

          addBinding(this, templateInfo, nodeInfo, kind, name, parts, literal);
          return true;
        } else {
          return super._parseTemplateNodeAttribute(node, templateInfo, nodeInfo, name, value);
        }
      }
      /**
       * Overrides default `TemplateStamp` implementation to add support for
       * binding the properties that a nested template depends on to the template
       * as `_host_<property>`.
       *
       * @override
       * @param {Node} node Node to parse
       * @param {TemplateInfo} templateInfo Template metadata for current template
       * @param {NodeInfo} nodeInfo Node metadata for current template node
       * @return {boolean} `true` if the visited node added node-specific
       *   metadata to `nodeInfo`
       * @protected
       * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
       */


      static _parseTemplateNestedTemplate(node, templateInfo, nodeInfo) {
        let noted = super._parseTemplateNestedTemplate(node, templateInfo, nodeInfo); // Merge host props into outer template and add bindings


        let hostProps = nodeInfo.templateInfo.hostProps;
        let mode = '{';

        for (let source in hostProps) {
          let parts = [{
            mode,
            source,
            dependencies: [source]
          }];
          addBinding(this, templateInfo, nodeInfo, 'property', '_host_' + source, parts);
        }

        return noted;
      }
      /**
       * Called to parse text in a template (either attribute values or
       * textContent) into binding metadata.
       *
       * Any overrides of this method should return an array of binding part
       * metadata  representing one or more bindings found in the provided text
       * and any "literal" text in between.  Any non-literal parts will be passed
       * to `_evaluateBinding` when any dependencies change.  The only required
       * fields of each "part" in the returned array are as follows:
       *
       * - `dependencies` - Array containing trigger metadata for each property
       *   that should trigger the binding to update
       * - `literal` - String containing text if the part represents a literal;
       *   in this case no `dependencies` are needed
       *
       * Additional metadata for use by `_evaluateBinding` may be provided in
       * each part object as needed.
       *
       * The default implementation handles the following types of bindings
       * (one or more may be intermixed with literal strings):
       * - Property binding: `[[prop]]`
       * - Path binding: `[[object.prop]]`
       * - Negated property or path bindings: `[[!prop]]` or `[[!object.prop]]`
       * - Two-way property or path bindings (supports negation):
       *   `{{prop}}`, `{{object.prop}}`, `{{!prop}}` or `{{!object.prop}}`
       * - Inline computed method (supports negation):
       *   `[[compute(a, 'literal', b)]]`, `[[!compute(a, 'literal', b)]]`
       *
       * The default implementation uses a regular expression for best
       * performance. However, the regular expression uses a white-list of
       * allowed characters in a data-binding, which causes problems for
       * data-bindings that do use characters not in this white-list.
       *
       * Instead of updating the white-list with all allowed characters,
       * there is a StrictBindingParser (see lib/mixins/strict-binding-parser)
       * that uses a state machine instead. This state machine is able to handle
       * all characters. However, it is slightly less performant, therefore we
       * extracted it into a separate optional mixin.
       *
       * @param {string} text Text to parse from attribute or textContent
       * @param {Object} templateInfo Current template metadata
       * @return {Array<!BindingPart>} Array of binding part metadata
       * @protected
       */


      static _parseBindings(text, templateInfo) {
        let parts = [];
        let lastIndex = 0;
        let m; // Example: "literal1{{prop}}literal2[[!compute(foo,bar)]]final"
        // Regex matches:
        //        Iteration 1:  Iteration 2:
        // m[1]: '{{'          '[['
        // m[2]: ''            '!'
        // m[3]: 'prop'        'compute(foo,bar)'

        while ((m = bindingRegex.exec(text)) !== null) {
          // Add literal part
          if (m.index > lastIndex) {
            parts.push({
              literal: text.slice(lastIndex, m.index)
            });
          } // Add binding part


          let mode = m[1][0];
          let negate = Boolean(m[2]);
          let source = m[3].trim();
          let customEvent = false,
              notifyEvent = '',
              colon = -1;

          if (mode == '{' && (colon = source.indexOf('::')) > 0) {
            notifyEvent = source.substring(colon + 2);
            source = source.substring(0, colon);
            customEvent = true;
          }

          let signature = parseMethod(source);
          let dependencies = [];

          if (signature) {
            // Inline computed function
            let {
              args,
              methodName
            } = signature;

            for (let i = 0; i < args.length; i++) {
              let arg = args[i];

              if (!arg.literal) {
                dependencies.push(arg);
              }
            }

            let dynamicFns = templateInfo.dynamicFns;

            if (dynamicFns && dynamicFns[methodName] || signature.static) {
              dependencies.push(methodName);
              signature.dynamicFn = true;
            }
          } else {
            // Property or path
            dependencies.push(source);
          }

          parts.push({
            source,
            mode,
            negate,
            customEvent,
            signature,
            dependencies,
            event: notifyEvent
          });
          lastIndex = bindingRegex.lastIndex;
        } // Add a final literal part


        if (lastIndex && lastIndex < text.length) {
          let literal = text.substring(lastIndex);

          if (literal) {
            parts.push({
              literal: literal
            });
          }
        }

        if (parts.length) {
          return parts;
        } else {
          return null;
        }
      }
      /**
       * Called to evaluate a previously parsed binding part based on a set of
       * one or more changed dependencies.
       *
       * @param {this} inst Element that should be used as scope for
       *   binding dependencies
       * @param {BindingPart} part Binding part metadata
       * @param {string} path Property/path that triggered this effect
       * @param {Object} props Bag of current property changes
       * @param {Object} oldProps Bag of previous values for changed properties
       * @param {boolean} hasPaths True with `props` contains one or more paths
       * @return {*} Value the binding part evaluated to
       * @protected
       */


      static _evaluateBinding(inst, part, path, props, oldProps, hasPaths) {
        let value;

        if (part.signature) {
          value = runMethodEffect(inst, path, props, oldProps, part.signature);
        } else if (path != part.source) {
          value = get(inst, part.source);
        } else {
          if (hasPaths && isPath(path)) {
            value = get(inst, path);
          } else {
            value = inst.__data[path];
          }
        }

        if (part.negate) {
          value = !value;
        }

        return value;
      }

    } // make a typing for closure :P


    PropertyEffectsType = PropertyEffects;
    return PropertyEffects;
  });
  /**
   * Helper api for enqueuing client dom created by a host element.
   *
   * By default elements are flushed via `_flushProperties` when
   * `connectedCallback` is called. Elements attach their client dom to
   * themselves at `ready` time which results from this first flush.
   * This provides an ordering guarantee that the client dom an element
   * creates is flushed before the element itself (i.e. client `ready`
   * fires before host `ready`).
   *
   * However, if `_flushProperties` is called *before* an element is connected,
   * as for example `Templatize` does, this ordering guarantee cannot be
   * satisfied because no elements are connected. (Note: Bound elements that
   * receive data do become enqueued clients and are properly ordered but
   * unbound elements are not.)
   *
   * To maintain the desired "client before host" ordering guarantee for this
   * case we rely on the "host stack. Client nodes registers themselves with
   * the creating host element when created. This ensures that all client dom
   * is readied in the proper order, maintaining the desired guarantee.
   *
   * @private
   */

  _exports.PropertyEffects = PropertyEffects;

  class HostStack {
    constructor() {
      this.stack = [];
    }
    /**
     * @param {*} inst Instance to add to hostStack
     * @return {void}
     */


    registerHost(inst) {
      if (this.stack.length) {
        let host = this.stack[this.stack.length - 1];

        host._enqueueClient(inst);
      }
    }
    /**
     * @param {*} inst Instance to begin hosting
     * @return {void}
     */


    beginHosting(inst) {
      this.stack.push(inst);
    }
    /**
     * @param {*} inst Instance to end hosting
     * @return {void}
     */


    endHosting(inst) {
      let stackLen = this.stack.length;

      if (stackLen && this.stack[stackLen - 1] == inst) {
        this.stack.pop();
      }
    }

  }

  const hostStack = new HostStack();
  var propertyEffects = {
    PropertyEffects: PropertyEffects
  };
  _exports.$propertyEffects = propertyEffects;

  function normalizeProperties(props) {
    const output = {};

    for (let p in props) {
      const o = props[p];
      output[p] = typeof o === 'function' ? {
        type: o
      } : o;
    }

    return output;
  }
  /**
   * Mixin that provides a minimal starting point to using the PropertiesChanged
   * mixin by providing a mechanism to declare properties in a static
   * getter (e.g. static get properties() { return { foo: String } }). Changes
   * are reported via the `_propertiesChanged` method.
   *
   * This mixin provides no specific support for rendering. Users are expected
   * to create a ShadowRoot and put content into it and update it in whatever
   * way makes sense. This can be done in reaction to properties changing by
   * implementing `_propertiesChanged`.
   *
   * @mixinFunction
   * @polymer
   * @appliesMixin PropertiesChanged
   * @summary Mixin that provides a minimal starting point for using
   * the PropertiesChanged mixin by providing a declarative `properties` object.
   */


  const PropertiesMixin = dedupingMixin(superClass => {
    /**
     * @constructor
     * @implements {Polymer_PropertiesChanged}
     * @private
     */
    const base = PropertiesChanged(superClass);
    /**
     * Returns the super class constructor for the given class, if it is an
     * instance of the PropertiesMixin.
     *
     * @param {!PropertiesMixinConstructor} constructor PropertiesMixin constructor
     * @return {?PropertiesMixinConstructor} Super class constructor
     */

    function superPropertiesClass(constructor) {
      const superCtor = Object.getPrototypeOf(constructor); // Note, the `PropertiesMixin` class below only refers to the class
      // generated by this call to the mixin; the instanceof test only works
      // because the mixin is deduped and guaranteed only to apply once, hence
      // all constructors in a proto chain will see the same `PropertiesMixin`

      return superCtor.prototype instanceof PropertiesMixin ?
      /** @type {!PropertiesMixinConstructor} */
      superCtor : null;
    }
    /**
     * Returns a memoized version of the `properties` object for the
     * given class. Properties not in object format are converted to at
     * least {type}.
     *
     * @param {PropertiesMixinConstructor} constructor PropertiesMixin constructor
     * @return {Object} Memoized properties object
     */


    function ownProperties(constructor) {
      if (!constructor.hasOwnProperty(JSCompiler_renameProperty('__ownProperties', constructor))) {
        let props = null;

        if (constructor.hasOwnProperty(JSCompiler_renameProperty('properties', constructor))) {
          const properties = constructor.properties;

          if (properties) {
            props = normalizeProperties(properties);
          }
        }

        constructor.__ownProperties = props;
      }

      return constructor.__ownProperties;
    }
    /**
     * @polymer
     * @mixinClass
     * @extends {base}
     * @implements {Polymer_PropertiesMixin}
     * @unrestricted
     */


    class PropertiesMixin extends base {
      /**
       * Implements standard custom elements getter to observes the attributes
       * listed in `properties`.
       * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
       */
      static get observedAttributes() {
        const props = this._properties;
        return props ? Object.keys(props).map(p => this.attributeNameForProperty(p)) : [];
      }
      /**
       * Finalizes an element definition, including ensuring any super classes
       * are also finalized. This includes ensuring property
       * accessors exist on the element prototype. This method calls
       * `_finalizeClass` to finalize each constructor in the prototype chain.
       * @return {void}
       */


      static finalize() {
        if (!this.hasOwnProperty(JSCompiler_renameProperty('__finalized', this))) {
          const superCtor = superPropertiesClass(
          /** @type {!PropertiesMixinConstructor} */
          this);

          if (superCtor) {
            superCtor.finalize();
          }

          this.__finalized = true;

          this._finalizeClass();
        }
      }
      /**
       * Finalize an element class. This includes ensuring property
       * accessors exist on the element prototype. This method is called by
       * `finalize` and finalizes the class constructor.
       *
       * @protected
       */


      static _finalizeClass() {
        const props = ownProperties(
        /** @type {!PropertiesMixinConstructor} */
        this);

        if (props) {
          this.createProperties(props);
        }
      }
      /**
       * Returns a memoized version of all properties, including those inherited
       * from super classes. Properties not in object format are converted to
       * at least {type}.
       *
       * @return {Object} Object containing properties for this class
       * @protected
       */


      static get _properties() {
        if (!this.hasOwnProperty(JSCompiler_renameProperty('__properties', this))) {
          const superCtor = superPropertiesClass(
          /** @type {!PropertiesMixinConstructor} */
          this);
          this.__properties = Object.assign({}, superCtor && superCtor._properties, ownProperties(
          /** @type {PropertiesMixinConstructor} */
          this));
        }

        return this.__properties;
      }
      /**
       * Overrides `PropertiesChanged` method to return type specified in the
       * static `properties` object for the given property.
       * @param {string} name Name of property
       * @return {*} Type to which to deserialize attribute
       *
       * @protected
       */


      static typeForProperty(name) {
        const info = this._properties[name];
        return info && info.type;
      }
      /**
       * Overrides `PropertiesChanged` method and adds a call to
       * `finalize` which lazily configures the element's property accessors.
       * @override
       * @return {void}
       */


      _initializeProperties() {
        this.constructor.finalize();

        super._initializeProperties();
      }
      /**
       * Called when the element is added to a document.
       * Calls `_enableProperties` to turn on property system from
       * `PropertiesChanged`.
       * @suppress {missingProperties} Super may or may not implement the callback
       * @return {void}
       * @override
       */


      connectedCallback() {
        if (super.connectedCallback) {
          super.connectedCallback();
        }

        this._enableProperties();
      }
      /**
       * Called when the element is removed from a document
       * @suppress {missingProperties} Super may or may not implement the callback
       * @return {void}
       * @override
       */


      disconnectedCallback() {
        if (super.disconnectedCallback) {
          super.disconnectedCallback();
        }
      }

    }

    return PropertiesMixin;
  });
  _exports.PropertiesMixin = PropertiesMixin;
  var propertiesMixin = {
    PropertiesMixin: PropertiesMixin
  };
  _exports.$propertiesMixin = propertiesMixin;
  const bundledImportMeta = { ...meta,
    url: new URL('../node_modules/%40polymer/polymer/lib/mixins/element-mixin.js', meta.url).href
  };
  const version = '3.0.5';
  /**
          * Element class mixin that provides the core API for Polymer's meta-programming
          * features including template stamping, data-binding, attribute deserialization,
          * and property change observation.
          *
          * Subclassers may provide the following static getters to return metadata
          * used to configure Polymer's features for the class:
          *
          * - `static get is()`: When the template is provided via a `dom-module`,
          *   users should return the `dom-module` id from a static `is` getter.  If
          *   no template is needed or the template is provided directly via the
          *   `template` getter, there is no need to define `is` for the element.
          *
          * - `static get template()`: Users may provide the template directly (as
          *   opposed to via `dom-module`) by implementing a static `template` getter.
          *   The getter must return an `HTMLTemplateElement`.
          *
          * - `static get properties()`: Should return an object describing
          *   property-related metadata used by Polymer features (key: property name
          *   value: object containing property metadata). Valid keys in per-property
          *   metadata include:
          *   - `type` (String|Number|Object|Array|...): Used by
          *     `attributeChangedCallback` to determine how string-based attributes
          *     are deserialized to JavaScript property values.
          *   - `notify` (boolean): Causes a change in the property to fire a
          *     non-bubbling event called `<property>-changed`. Elements that have
          *     enabled two-way binding to the property use this event to observe changes.
          *   - `readOnly` (boolean): Creates a getter for the property, but no setter.
          *     To set a read-only property, use the private setter method
          *     `_setProperty(property, value)`.
          *   - `observer` (string): Observer method name that will be called when
          *     the property changes. The arguments of the method are
          *     `(value, previousValue)`.
          *   - `computed` (string): String describing method and dependent properties
          *     for computing the value of this property (e.g. `'computeFoo(bar, zot)'`).
          *     Computed properties are read-only by default and can only be changed
          *     via the return value of the computing method.
          *
          * - `static get observers()`: Array of strings describing multi-property
          *   observer methods and their dependent properties (e.g.
          *   `'observeABC(a, b, c)'`).
          *
          * The base class provides default implementations for the following standard
          * custom element lifecycle callbacks; users may override these, but should
          * call the super method to ensure
          * - `constructor`: Run when the element is created or upgraded
          * - `connectedCallback`: Run each time the element is connected to the
          *   document
          * - `disconnectedCallback`: Run each time the element is disconnected from
          *   the document
          * - `attributeChangedCallback`: Run each time an attribute in
          *   `observedAttributes` is set or removed (note: this element's default
          *   `observedAttributes` implementation will automatically return an array
          *   of dash-cased attributes based on `properties`)
          *
          * @mixinFunction
          * @polymer
          * @appliesMixin PropertyEffects
          * @appliesMixin PropertiesMixin
          * @property rootPath {string} Set to the value of `rootPath`,
          *   which defaults to the main document path
          * @property importPath {string} Set to the value of the class's static
          *   `importPath` property, which defaults to the path of this element's
          *   `dom-module` (when `is` is used), but can be overridden for other
          *   import strategies.
          * @summary Element class mixin that provides the core API for Polymer's
          * meta-programming features.
          */

  _exports.version$1 = _exports.version = version;
  const ElementMixin = dedupingMixin(base => {
    /**
     * @constructor
     * @extends {base}
     * @implements {Polymer_PropertyEffects}
     * @implements {Polymer_PropertiesMixin}
     * @private
     */
    const polymerElementBase = PropertiesMixin(PropertyEffects(base));
    /**
     * Returns a list of properties with default values.
     * This list is created as an optimization since it is a subset of
     * the list returned from `_properties`.
     * This list is used in `_initializeProperties` to set property defaults.
     *
     * @param {PolymerElementConstructor} constructor Element class
     * @return {PolymerElementProperties} Flattened properties for this class
     *   that have default values
     * @private
     */

    function propertyDefaults(constructor) {
      if (!constructor.hasOwnProperty(JSCompiler_renameProperty('__propertyDefaults', constructor))) {
        constructor.__propertyDefaults = null;
        let props = constructor._properties;

        for (let p in props) {
          let info = props[p];

          if ('value' in info) {
            constructor.__propertyDefaults = constructor.__propertyDefaults || {};
            constructor.__propertyDefaults[p] = info;
          }
        }
      }

      return constructor.__propertyDefaults;
    }
    /**
     * Returns a memoized version of the `observers` array.
     * @param {PolymerElementConstructor} constructor Element class
     * @return {Array} Array containing own observers for the given class
     * @protected
     */


    function ownObservers(constructor) {
      if (!constructor.hasOwnProperty(JSCompiler_renameProperty('__ownObservers', constructor))) {
        constructor.__ownObservers = constructor.hasOwnProperty(JSCompiler_renameProperty('observers', constructor)) ?
        /** @type {PolymerElementConstructor} */
        constructor.observers : null;
      }

      return constructor.__ownObservers;
    }
    /**
     * Creates effects for a property.
     *
     * Note, once a property has been set to
     * `readOnly`, `computed`, `reflectToAttribute`, or `notify`
     * these values may not be changed. For example, a subclass cannot
     * alter these settings. However, additional `observers` may be added
     * by subclasses.
     *
     * The info object should contain property metadata as follows:
     *
     * * `type`: {function} type to which an attribute matching the property
     * is deserialized. Note the property is camel-cased from a dash-cased
     * attribute. For example, 'foo-bar' attribute is deserialized to a
     * property named 'fooBar'.
     *
     * * `readOnly`: {boolean} creates a readOnly property and
     * makes a private setter for the private of the form '_setFoo' for a
     * property 'foo',
     *
     * * `computed`: {string} creates a computed property. A computed property
     * is also automatically set to `readOnly: true`. The value is calculated
     * by running a method and arguments parsed from the given string. For
     * example 'compute(foo)' will compute a given property when the
     * 'foo' property changes by executing the 'compute' method. This method
     * must return the computed value.
     *
     * * `reflectToAttribute`: {boolean} If true, the property value is reflected
     * to an attribute of the same name. Note, the attribute is dash-cased
     * so a property named 'fooBar' is reflected as 'foo-bar'.
     *
     * * `notify`: {boolean} sends a non-bubbling notification event when
     * the property changes. For example, a property named 'foo' sends an
     * event named 'foo-changed' with `event.detail` set to the value of
     * the property.
     *
     * * observer: {string} name of a method that runs when the property
     * changes. The arguments of the method are (value, previousValue).
     *
     * Note: Users may want control over modifying property
     * effects via subclassing. For example, a user might want to make a
     * reflectToAttribute property not do so in a subclass. We've chosen to
     * disable this because it leads to additional complication.
     * For example, a readOnly effect generates a special setter. If a subclass
     * disables the effect, the setter would fail unexpectedly.
     * Based on feedback, we may want to try to make effects more malleable
     * and/or provide an advanced api for manipulating them.
     * Also consider adding warnings when an effect cannot be changed.
     *
     * @param {!PolymerElement} proto Element class prototype to add accessors
     *   and effects to
     * @param {string} name Name of the property.
     * @param {Object} info Info object from which to create property effects.
     * Supported keys:
     * @param {Object} allProps Flattened map of all properties defined in this
     *   element (including inherited properties)
     * @return {void}
     * @private
     */


    function createPropertyFromConfig(proto, name, info, allProps) {
      // computed forces readOnly...
      if (info.computed) {
        info.readOnly = true;
      } // Note, since all computed properties are readOnly, this prevents
      // adding additional computed property effects (which leads to a confusing
      // setup where multiple triggers for setting a property)
      // While we do have `hasComputedEffect` this is set on the property's
      // dependencies rather than itself.


      if (info.computed && !proto._hasReadOnlyEffect(name)) {
        proto._createComputedProperty(name, info.computed, allProps);
      }

      if (info.readOnly && !proto._hasReadOnlyEffect(name)) {
        proto._createReadOnlyProperty(name, !info.computed);
      }

      if (info.reflectToAttribute && !proto._hasReflectEffect(name)) {
        proto._createReflectedProperty(name);
      }

      if (info.notify && !proto._hasNotifyEffect(name)) {
        proto._createNotifyingProperty(name);
      } // always add observer


      if (info.observer) {
        proto._createPropertyObserver(name, info.observer, allProps[info.observer]);
      } // always create the mapping from attribute back to property for deserialization.


      proto._addPropertyToAttributeMap(name);
    }
    /**
     * Process all style elements in the element template. Styles with the
     * `include` attribute are processed such that any styles in
     * the associated "style modules" are included in the element template.
     * @param {PolymerElementConstructor} klass Element class
     * @param {!HTMLTemplateElement} template Template to process
     * @param {string} is Name of element
     * @param {string} baseURI Base URI for element
     * @private
     */


    function processElementStyles(klass, template, is, baseURI) {
      const templateStyles = template.content.querySelectorAll('style');
      const stylesWithImports = stylesFromTemplate(template); // insert styles from <link rel="import" type="css"> at the top of the template

      const linkedStyles = stylesFromModuleImports(is);
      const firstTemplateChild = template.content.firstElementChild;

      for (let idx = 0; idx < linkedStyles.length; idx++) {
        let s = linkedStyles[idx];
        s.textContent = klass._processStyleText(s.textContent, baseURI);
        template.content.insertBefore(s, firstTemplateChild);
      } // keep track of the last "concrete" style in the template we have encountered


      let templateStyleIndex = 0; // ensure all gathered styles are actually in this template.

      for (let i = 0; i < stylesWithImports.length; i++) {
        let s = stylesWithImports[i];
        let templateStyle = templateStyles[templateStyleIndex]; // if the style is not in this template, it's been "included" and
        // we put a clone of it in the template before the style that included it

        if (templateStyle !== s) {
          s = s.cloneNode(true);
          templateStyle.parentNode.insertBefore(s, templateStyle);
        } else {
          templateStyleIndex++;
        }

        s.textContent = klass._processStyleText(s.textContent, baseURI);
      }

      if (window.ShadyCSS) {
        window.ShadyCSS.prepareTemplate(template, is);
      }
    }
    /**
     * Look up template from dom-module for element
     *
     * @param {!string} is Element name to look up
     * @return {!HTMLTemplateElement} Template found in dom module, or
     *   undefined if not found
     * @protected
     */


    function getTemplateFromDomModule(is) {
      let template = null; // Under strictTemplatePolicy in 3.x+, dom-module lookup is only allowed
      // when opted-in via allowTemplateFromDomModule

      if (is && (!strictTemplatePolicy || allowTemplateFromDomModule)) {
        template = DomModule.import(is, 'template'); // Under strictTemplatePolicy, require any element with an `is`
        // specified to have a dom-module

        if (strictTemplatePolicy && !template) {
          throw new Error(`strictTemplatePolicy: expecting dom-module or null template for ${is}`);
        }
      }

      return template;
    }
    /**
     * @polymer
     * @mixinClass
     * @unrestricted
     * @implements {Polymer_ElementMixin}
     */


    class PolymerElement extends polymerElementBase {
      /**
       * Current Polymer version in Semver notation.
       * @type {string} Semver notation of the current version of Polymer.
       */
      static get polymerElementVersion() {
        return version;
      }
      /**
       * Override of PropertiesMixin _finalizeClass to create observers and
       * find the template.
       * @return {void}
       * @protected
       * @override
       * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
       */


      static _finalizeClass() {
        super._finalizeClass();

        if (this.hasOwnProperty(JSCompiler_renameProperty('is', this)) && this.is) {
          register(this.prototype);
        }

        const observers = ownObservers(this);

        if (observers) {
          this.createObservers(observers, this._properties);
        } // note: create "working" template that is finalized at instance time


        let template =
        /** @type {PolymerElementConstructor} */
        this.template;

        if (template) {
          if (typeof template === 'string') {
            console.error('template getter must return HTMLTemplateElement');
            template = null;
          } else {
            template = template.cloneNode(true);
          }
        }

        this.prototype._template = template;
      }
      /**
       * Override of PropertiesChanged createProperties to create accessors
       * and property effects for all of the properties.
       * @return {void}
       * @protected
       * @override
       */


      static createProperties(props) {
        for (let p in props) {
          createPropertyFromConfig(this.prototype, p, props[p], props);
        }
      }
      /**
       * Creates observers for the given `observers` array.
       * Leverages `PropertyEffects` to create observers.
       * @param {Object} observers Array of observer descriptors for
       *   this class
       * @param {Object} dynamicFns Object containing keys for any properties
       *   that are functions and should trigger the effect when the function
       *   reference is changed
       * @return {void}
       * @protected
       */


      static createObservers(observers, dynamicFns) {
        const proto = this.prototype;

        for (let i = 0; i < observers.length; i++) {
          proto._createMethodObserver(observers[i], dynamicFns);
        }
      }
      /**
       * Returns the template that will be stamped into this element's shadow root.
       *
       * If a `static get is()` getter is defined, the default implementation
       * will return the first `<template>` in a `dom-module` whose `id`
       * matches this element's `is`.
       *
       * Users may override this getter to return an arbitrary template
       * (in which case the `is` getter is unnecessary). The template returned
       * must be an `HTMLTemplateElement`.
       *
       * Note that when subclassing, if the super class overrode the default
       * implementation and the subclass would like to provide an alternate
       * template via a `dom-module`, it should override this getter and
       * return `DomModule.import(this.is, 'template')`.
       *
       * If a subclass would like to modify the super class template, it should
       * clone it rather than modify it in place.  If the getter does expensive
       * work such as cloning/modifying a template, it should memoize the
       * template for maximum performance:
       *
       *   let memoizedTemplate;
       *   class MySubClass extends MySuperClass {
       *     static get template() {
       *       if (!memoizedTemplate) {
       *         memoizedTemplate = super.template.cloneNode(true);
       *         let subContent = document.createElement('div');
       *         subContent.textContent = 'This came from MySubClass';
       *         memoizedTemplate.content.appendChild(subContent);
       *       }
       *       return memoizedTemplate;
       *     }
       *   }
       *
       * @return {!HTMLTemplateElement|string} Template to be stamped
       */


      static get template() {
        // Explanation of template-related properties:
        // - constructor.template (this getter): the template for the class.
        //     This can come from the prototype (for legacy elements), from a
        //     dom-module, or from the super class's template (or can be overridden
        //     altogether by the user)
        // - constructor._template: memoized version of constructor.template
        // - prototype._template: working template for the element, which will be
        //     parsed and modified in place. It is a cloned version of
        //     constructor.template, saved in _finalizeClass(). Note that before
        //     this getter is called, for legacy elements this could be from a
        //     _template field on the info object passed to Polymer(), a behavior,
        //     or set in registered(); once the static getter runs, a clone of it
        //     will overwrite it on the prototype as the working template.
        if (!this.hasOwnProperty(JSCompiler_renameProperty('_template', this))) {
          this._template = // If user has put template on prototype (e.g. in legacy via registered
          // callback or info object), prefer that first
          this.prototype.hasOwnProperty(JSCompiler_renameProperty('_template', this.prototype)) ? this.prototype._template : // Look in dom-module associated with this element's is
          getTemplateFromDomModule(
          /** @type {PolymerElementConstructor}*/
          this.is) || // Next look for superclass template (call the super impl this
          // way so that `this` points to the superclass)
          Object.getPrototypeOf(
          /** @type {PolymerElementConstructor}*/
          this.prototype).constructor.template;
        }

        return this._template;
      }
      /**
       * Set the template.
       *
       * @param {!HTMLTemplateElement|string} value Template to set.
       */


      static set template(value) {
        this._template = value;
      }
      /**
       * Path matching the url from which the element was imported.
       *
       * This path is used to resolve url's in template style cssText.
       * The `importPath` property is also set on element instances and can be
       * used to create bindings relative to the import path.
       *
       * For elements defined in ES modules, users should implement
       * `static get importMeta() { return import.meta; }`, and the default
       * implementation of `importPath` will  return `import.meta.url`'s path.
       * For elements defined in HTML imports, this getter will return the path
       * to the document containing a `dom-module` element matching this
       * element's static `is` property.
       *
       * Note, this path should contain a trailing `/`.
       *
       * @return {string} The import path for this element class
       * @suppress {missingProperties}
       */


      static get importPath() {
        if (!this.hasOwnProperty(JSCompiler_renameProperty('_importPath', this))) {
          const meta = this.importMeta;

          if (meta) {
            this._importPath = pathFromUrl(meta.url);
          } else {
            const module = DomModule.import(
            /** @type {PolymerElementConstructor} */
            this.is);
            this._importPath = module && module.assetpath || Object.getPrototypeOf(
            /** @type {PolymerElementConstructor}*/
            this.prototype).constructor.importPath;
          }
        }

        return this._importPath;
      }

      constructor() {
        super();
        /** @type {HTMLTemplateElement} */

        this._template;
        /** @type {string} */

        this._importPath;
        /** @type {string} */

        this.rootPath;
        /** @type {string} */

        this.importPath;
        /** @type {StampedTemplate | HTMLElement | ShadowRoot} */

        this.root;
        /** @type {!Object<string, !Element>} */

        this.$;
      }
      /**
       * Overrides the default `PropertyAccessors` to ensure class
       * metaprogramming related to property accessors and effects has
       * completed (calls `finalize`).
       *
       * It also initializes any property defaults provided via `value` in
       * `properties` metadata.
       *
       * @return {void}
       * @override
       * @suppress {invalidCasts}
       */


      _initializeProperties() {
        _exports.instanceCount = instanceCount = instanceCount + 1;
        this.constructor.finalize(); // note: finalize template when we have access to `localName` to
        // avoid dependence on `is` for polyfilling styling.

        this.constructor._finalizeTemplate(
        /** @type {!HTMLElement} */
        this.localName);

        super._initializeProperties(); // set path defaults


        this.rootPath = rootPath;
        this.importPath = this.constructor.importPath; // apply property defaults...

        let p$ = propertyDefaults(this.constructor);

        if (!p$) {
          return;
        }

        for (let p in p$) {
          let info = p$[p]; // Don't set default value if there is already an own property, which
          // happens when a `properties` property with default but no effects had
          // a property set (e.g. bound) by its host before upgrade

          if (!this.hasOwnProperty(p)) {
            let value = typeof info.value == 'function' ? info.value.call(this) : info.value; // Set via `_setProperty` if there is an accessor, to enable
            // initializing readOnly property defaults

            if (this._hasAccessor(p)) {
              this._setPendingProperty(p, value, true);
            } else {
              this[p] = value;
            }
          }
        }
      }
      /**
       * Gather style text for a style element in the template.
       *
       * @param {string} cssText Text containing styling to process
       * @param {string} baseURI Base URI to rebase CSS paths against
       * @return {string} The processed CSS text
       * @protected
       */


      static _processStyleText(cssText, baseURI) {
        return resolveCss(cssText, baseURI);
      }
      /**
      * Configures an element `proto` to function with a given `template`.
      * The element name `is` and extends `ext` must be specified for ShadyCSS
      * style scoping.
      *
      * @param {string} is Tag name (or type extension name) for this element
      * @return {void}
      * @protected
      */


      static _finalizeTemplate(is) {
        /** @const {HTMLTemplateElement} */
        const template = this.prototype._template;

        if (template && !template.__polymerFinalized) {
          template.__polymerFinalized = true;
          const importPath = this.importPath;
          const baseURI = importPath ? resolveUrl(importPath) : ''; // e.g. support `include="module-name"`, and ShadyCSS

          processElementStyles(this, template, is, baseURI);

          this.prototype._bindTemplate(template);
        }
      }
      /**
       * Provides a default implementation of the standard Custom Elements
       * `connectedCallback`.
       *
       * The default implementation enables the property effects system and
       * flushes any pending properties, and updates shimmed CSS properties
       * when using the ShadyCSS scoping/custom properties polyfill.
       *
       * @suppress {missingProperties, invalidCasts} Super may or may not implement the callback
       * @return {void}
       */


      connectedCallback() {
        if (window.ShadyCSS && this._template) {
          window.ShadyCSS.styleElement(
          /** @type {!HTMLElement} */
          this);
        }

        super.connectedCallback();
      }
      /**
       * Stamps the element template.
       *
       * @return {void}
       * @override
       */


      ready() {
        if (this._template) {
          this.root = this._stampTemplate(this._template);
          this.$ = this.root.$;
        }

        super.ready();
      }
      /**
       * Implements `PropertyEffects`'s `_readyClients` call. Attaches
       * element dom by calling `_attachDom` with the dom stamped from the
       * element's template via `_stampTemplate`. Note that this allows
       * client dom to be attached to the element prior to any observers
       * running.
       *
       * @return {void}
       * @override
       */


      _readyClients() {
        if (this._template) {
          this.root = this._attachDom(
          /** @type {StampedTemplate} */
          this.root);
        } // The super._readyClients here sets the clients initialized flag.
        // We must wait to do this until after client dom is created/attached
        // so that this flag can be checked to prevent notifications fired
        // during this process from being handled before clients are ready.


        super._readyClients();
      }
      /**
       * Attaches an element's stamped dom to itself. By default,
       * this method creates a `shadowRoot` and adds the dom to it.
       * However, this method may be overridden to allow an element
       * to put its dom in another location.
       *
       * @throws {Error}
       * @suppress {missingReturn}
       * @param {StampedTemplate} dom to attach to the element.
       * @return {ShadowRoot} node to which the dom has been attached.
       */


      _attachDom(dom) {
        if (this.attachShadow) {
          if (dom) {
            if (!this.shadowRoot) {
              this.attachShadow({
                mode: 'open'
              });
            }

            this.shadowRoot.appendChild(dom);
            return this.shadowRoot;
          }

          return null;
        } else {
          throw new Error('ShadowDOM not available. ' + // TODO(sorvell): move to compile-time conditional when supported
          'PolymerElement can create dom as children instead of in ' + 'ShadowDOM by setting `this.root = this;\` before \`ready\`.');
        }
      }
      /**
       * When using the ShadyCSS scoping and custom property shim, causes all
       * shimmed styles in this element (and its subtree) to be updated
       * based on current custom property values.
       *
       * The optional parameter overrides inline custom property styles with an
       * object of properties where the keys are CSS properties, and the values
       * are strings.
       *
       * Example: `this.updateStyles({'--color': 'blue'})`
       *
       * These properties are retained unless a value of `null` is set.
       *
       * Note: This function does not support updating CSS mixins.
       * You can not dynamically change the value of an `@apply`.
       *
       * @param {Object=} properties Bag of custom property key/values to
       *   apply to this element.
       * @return {void}
       * @suppress {invalidCasts}
       */


      updateStyles(properties) {
        if (window.ShadyCSS) {
          window.ShadyCSS.styleSubtree(
          /** @type {!HTMLElement} */
          this, properties);
        }
      }
      /**
       * Rewrites a given URL relative to a base URL. The base URL defaults to
       * the original location of the document containing the `dom-module` for
       * this element. This method will return the same URL before and after
       * bundling.
       *
       * Note that this function performs no resolution for URLs that start
       * with `/` (absolute URLs) or `#` (hash identifiers).  For general purpose
       * URL resolution, use `window.URL`.
       *
       * @param {string} url URL to resolve.
       * @param {string=} base Optional base URL to resolve against, defaults
       * to the element's `importPath`
       * @return {string} Rewritten URL relative to base
       */


      resolveUrl(url, base) {
        if (!base && this.importPath) {
          base = resolveUrl(this.importPath);
        }

        return resolveUrl(url, base);
      }
      /**
       * Overrides `PropertyAccessors` to add map of dynamic functions on
       * template info, for consumption by `PropertyEffects` template binding
       * code. This map determines which method templates should have accessors
       * created for them.
       *
       * @override
       * @suppress {missingProperties} Interfaces in closure do not inherit statics, but classes do
       */


      static _parseTemplateContent(template, templateInfo, nodeInfo) {
        templateInfo.dynamicFns = templateInfo.dynamicFns || this._properties;
        return super._parseTemplateContent(template, templateInfo, nodeInfo);
      }

    }

    return PolymerElement;
  });
  /**
   * Total number of Polymer element instances created.
   * @type {number}
   */

  _exports.ElementMixin = ElementMixin;
  let instanceCount = 0;
  /**
          * Array of Polymer element classes that have been finalized.
          * @type {Array<PolymerElement>}
          */

  _exports.instanceCount = instanceCount;
  const registrations = [];
  /**
          * @param {!PolymerElementConstructor} prototype Element prototype to log
          * @this {this}
          * @private
          */

  _exports.registrations = registrations;

  function _regLog(prototype) {
    console.log('[' + prototype.is + ']: registered');
  }
  /**
   * Registers a class prototype for telemetry purposes.
   * @param {HTMLElement} prototype Element prototype to register
   * @this {this}
   * @protected
   */


  function register(prototype) {
    registrations.push(prototype);
  }
  /**
   * Logs all elements registered with an `is` to the console.
   * @public
   * @this {this}
   */


  function dumpRegistrations() {
    registrations.forEach(_regLog);
  }
  /**
   * When using the ShadyCSS scoping and custom property shim, causes all
   * shimmed `styles` (via `custom-style`) in the document (and its subtree)
   * to be updated based on current custom property values.
   *
   * The optional parameter overrides inline custom property styles with an
   * object of properties where the keys are CSS properties, and the values
   * are strings.
   *
   * Example: `updateStyles({'--color': 'blue'})`
   *
   * These properties are retained unless a value of `null` is set.
   *
   * @param {Object=} props Bag of custom property key/values to
   *   apply to the document.
   * @return {void}
   */


  const updateStyles = function (props) {
    if (window.ShadyCSS) {
      window.ShadyCSS.styleDocument(props);
    }
  };

  _exports.updateStyles = updateStyles;
  var elementMixin = {
    version: version,
    ElementMixin: ElementMixin,

    get instanceCount() {
      return instanceCount;
    },

    registrations: registrations,
    register: register,
    dumpRegistrations: dumpRegistrations,
    updateStyles: updateStyles
  };
  _exports.$elementMixin = elementMixin;

  class LiteralString {
    constructor(string) {
      /** @type {string} */
      this.value = string.toString();
    }
    /**
     * @return {string} LiteralString string value
     * @override
     */


    toString() {
      return this.value;
    }

  }
  /**
   * @param {*} value Object to stringify into HTML
   * @return {string} HTML stringified form of `obj`
   */


  function literalValue(value) {
    if (value instanceof LiteralString) {
      return (
        /** @type {!LiteralString} */
        value.value
      );
    } else {
      throw new Error(`non-literal value passed to Polymer's htmlLiteral function: ${value}`);
    }
  }
  /**
   * @param {*} value Object to stringify into HTML
   * @return {string} HTML stringified form of `obj`
   */


  function htmlValue(value) {
    if (value instanceof HTMLTemplateElement) {
      return (
        /** @type {!HTMLTemplateElement } */
        value.innerHTML
      );
    } else if (value instanceof LiteralString) {
      return literalValue(value);
    } else {
      throw new Error(`non-template value passed to Polymer's html function: ${value}`);
    }
  }
  /**
   * A template literal tag that creates an HTML <template> element from the
   * contents of the string.
   *
   * This allows you to write a Polymer Template in JavaScript.
   *
   * Templates can be composed by interpolating `HTMLTemplateElement`s in
   * expressions in the JavaScript template literal. The nested template's
   * `innerHTML` is included in the containing template.  The only other
   * values allowed in expressions are those returned from `htmlLiteral`
   * which ensures only literal values from JS source ever reach the HTML, to
   * guard against XSS risks.
   *
   * All other values are disallowed in expressions to help prevent XSS
   * attacks; however, `htmlLiteral` can be used to compose static
   * string values into templates. This is useful to compose strings into
   * places that do not accept html, like the css text of a `style`
   * element.
   *
   * Example:
   *
   *     static get template() {
   *       return html`
   *         <style>:host{ content:"..." }</style>
   *         <div class="shadowed">${this.partialTemplate}</div>
   *         ${super.template}
   *       `;
   *     }
   *     static get partialTemplate() { return html`<span>Partial!</span>`; }
   *
   * @param {!ITemplateArray} strings Constant parts of tagged template literal
   * @param {...*} values Variable parts of tagged template literal
   * @return {!HTMLTemplateElement} Constructed HTMLTemplateElement
   */


  const html$1 = function html(strings, ...values) {
    const template =
    /** @type {!HTMLTemplateElement} */
    document.createElement('template');
    template.innerHTML = values.reduce((acc, v, idx) => acc + htmlValue(v) + strings[idx + 1], strings[0]);
    return template;
  };
  /**
   * An html literal tag that can be used with `html` to compose.
   * a literal string.
   *
   * Example:
   *
   *     static get template() {
   *       return html`
   *         <style>
   *           :host { display: block; }
   *           ${this.styleTemplate()}
   *         </style>
   *         <div class="shadowed">${staticValue}</div>
   *         ${super.template}
   *       `;
   *     }
   *     static get styleTemplate() {
   *        return htmlLiteral`.shadowed { background: gray; }`;
   *     }
   *
   * @param {!ITemplateArray} strings Constant parts of tagged template literal
   * @param {...*} values Variable parts of tagged template literal
   * @return {!LiteralString} Constructed literal string
   */


  _exports.html$2 = _exports.html$1 = html$1;

  const htmlLiteral = function (strings, ...values) {
    return new LiteralString(values.reduce((acc, v, idx) => acc + literalValue(v) + strings[idx + 1], strings[0]));
  };

  _exports.htmlLiteral = htmlLiteral;
  var htmlTag = {
    html: html$1,
    htmlLiteral: htmlLiteral
  };
  _exports.$htmlTag = htmlTag;
  const PolymerElement = ElementMixin(HTMLElement);
  _exports.PolymerElement = PolymerElement;
  var polymerElement = {
    version: version,
    PolymerElement: PolymerElement,
    html: html$1
  };
  _exports.$polymerElement = polymerElement;

  class Debouncer {
    constructor() {
      this._asyncModule = null;
      this._callback = null;
      this._timer = null;
    }
    /**
     * Sets the scheduler; that is, a module with the Async interface,
     * a callback and optional arguments to be passed to the run function
     * from the async module.
     *
     * @param {!AsyncInterface} asyncModule Object with Async interface.
     * @param {function()} callback Callback to run.
     * @return {void}
     */


    setConfig(asyncModule, callback) {
      this._asyncModule = asyncModule;
      this._callback = callback;
      this._timer = this._asyncModule.run(() => {
        this._timer = null;

        this._callback();
      });
    }
    /**
     * Cancels an active debouncer and returns a reference to itself.
     *
     * @return {void}
     */


    cancel() {
      if (this.isActive()) {
        this._asyncModule.cancel(
        /** @type {number} */
        this._timer);

        this._timer = null;
      }
    }
    /**
     * Flushes an active debouncer and returns a reference to itself.
     *
     * @return {void}
     */


    flush() {
      if (this.isActive()) {
        this.cancel();

        this._callback();
      }
    }
    /**
     * Returns true if the debouncer is active.
     *
     * @return {boolean} True if active.
     */


    isActive() {
      return this._timer != null;
    }
    /**
     * Creates a debouncer if no debouncer is passed as a parameter
     * or it cancels an active debouncer otherwise. The following
     * example shows how a debouncer can be called multiple times within a
     * microtask and "debounced" such that the provided callback function is
     * called once. Add this method to a custom element:
     *
     * ```js
     * import {microTask} from '@polymer/polymer/lib/utils/async.js';
     * import {Debouncer} from '@polymer/polymer/lib/utils/debounce.js';
     * // ...
     *
     * _debounceWork() {
     *   this._debounceJob = Debouncer.debounce(this._debounceJob,
     *       microTask, () => this._doWork());
     * }
     * ```
     *
     * If the `_debounceWork` method is called multiple times within the same
     * microtask, the `_doWork` function will be called only once at the next
     * microtask checkpoint.
     *
     * Note: In testing it is often convenient to avoid asynchrony. To accomplish
     * this with a debouncer, you can use `enqueueDebouncer` and
     * `flush`. For example, extend the above example by adding
     * `enqueueDebouncer(this._debounceJob)` at the end of the
     * `_debounceWork` method. Then in a test, call `flush` to ensure
     * the debouncer has completed.
     *
     * @param {Debouncer?} debouncer Debouncer object.
     * @param {!AsyncInterface} asyncModule Object with Async interface
     * @param {function()} callback Callback to run.
     * @return {!Debouncer} Returns a debouncer object.
     */


    static debounce(debouncer, asyncModule, callback) {
      if (debouncer instanceof Debouncer) {
        debouncer.cancel();
      } else {
        debouncer = new Debouncer();
      }

      debouncer.setConfig(asyncModule, callback);
      return debouncer;
    }

  }

  _exports.Debouncer = Debouncer;
  var debounce = {
    Debouncer: Debouncer
  };
  _exports.$debounce = debounce;
  let HAS_NATIVE_TA = typeof document.head.style.touchAction === 'string';
  let GESTURE_KEY = '__polymerGestures';
  let HANDLED_OBJ = '__polymerGesturesHandled';
  let TOUCH_ACTION = '__polymerGesturesTouchAction'; // radius for tap and track

  let TAP_DISTANCE = 25;
  let TRACK_DISTANCE = 5; // number of last N track positions to keep

  let TRACK_LENGTH = 2; // Disabling "mouse" handlers for 2500ms is enough

  let MOUSE_TIMEOUT = 2500;
  let MOUSE_EVENTS = ['mousedown', 'mousemove', 'mouseup', 'click']; // an array of bitmask values for mapping MouseEvent.which to MouseEvent.buttons

  let MOUSE_WHICH_TO_BUTTONS = [0, 1, 4, 2];

  let MOUSE_HAS_BUTTONS = function () {
    try {
      return new MouseEvent('test', {
        buttons: 1
      }).buttons === 1;
    } catch (e) {
      return false;
    }
  }();
  /**
   * @param {string} name Possible mouse event name
   * @return {boolean} true if mouse event, false if not
   */


  function isMouseEvent(name) {
    return MOUSE_EVENTS.indexOf(name) > -1;
  }
  /* eslint no-empty: ["error", { "allowEmptyCatch": true }] */
  // check for passive event listeners


  let SUPPORTS_PASSIVE = false;

  (function () {
    try {
      let opts = Object.defineProperty({}, 'passive', {
        get() {
          SUPPORTS_PASSIVE = true;
        }

      });
      window.addEventListener('test', null, opts);
      window.removeEventListener('test', null, opts);
    } catch (e) {}
  })();
  /**
   * Generate settings for event listeners, dependant on `passiveTouchGestures`
   *
   * @param {string} eventName Event name to determine if `{passive}` option is
   *   needed
   * @return {{passive: boolean} | undefined} Options to use for addEventListener
   *   and removeEventListener
   */


  function PASSIVE_TOUCH(eventName) {
    if (isMouseEvent(eventName) || eventName === 'touchend') {
      return;
    }

    if (HAS_NATIVE_TA && SUPPORTS_PASSIVE && passiveTouchGestures) {
      return {
        passive: true
      };
    } else {
      return;
    }
  } // Check for touch-only devices


  let IS_TOUCH_ONLY = navigator.userAgent.match(/iP(?:[oa]d|hone)|Android/); // keep track of any labels hit by the mouseCanceller

  /** @type {!Array<!HTMLLabelElement>} */

  const clickedLabels = [];
  /** @type {!Object<boolean>} */

  const labellable = {
    'button': true,
    'input': true,
    'keygen': true,
    'meter': true,
    'output': true,
    'textarea': true,
    'progress': true,
    'select': true
  }; // Defined at https://html.spec.whatwg.org/multipage/form-control-infrastructure.html#enabling-and-disabling-form-controls:-the-disabled-attribute

  /** @type {!Object<boolean>} */

  const canBeDisabled = {
    'button': true,
    'command': true,
    'fieldset': true,
    'input': true,
    'keygen': true,
    'optgroup': true,
    'option': true,
    'select': true,
    'textarea': true
  };
  /**
   * @param {HTMLElement} el Element to check labelling status
   * @return {boolean} element can have labels
   */

  function canBeLabelled(el) {
    return labellable[el.localName] || false;
  }
  /**
   * @param {HTMLElement} el Element that may be labelled.
   * @return {!Array<!HTMLLabelElement>} Relevant label for `el`
   */


  function matchingLabels(el) {
    let labels = Array.prototype.slice.call(
    /** @type {HTMLInputElement} */
    el.labels || []); // IE doesn't have `labels` and Safari doesn't populate `labels`
    // if element is in a shadowroot.
    // In this instance, finding the non-ancestor labels is enough,
    // as the mouseCancellor code will handle ancstor labels

    if (!labels.length) {
      labels = [];
      let root = el.getRootNode(); // if there is an id on `el`, check for all labels with a matching `for` attribute

      if (el.id) {
        let matching = root.querySelectorAll(`label[for = ${el.id}]`);

        for (let i = 0; i < matching.length; i++) {
          labels.push(
          /** @type {!HTMLLabelElement} */
          matching[i]);
        }
      }
    }

    return labels;
  } // touch will make synthetic mouse events
  // `preventDefault` on touchend will cancel them,
  // but this breaks `<input>` focus and link clicks
  // disable mouse handlers for MOUSE_TIMEOUT ms after
  // a touchend to ignore synthetic mouse events


  let mouseCanceller = function (mouseEvent) {
    // Check for sourceCapabilities, used to distinguish synthetic events
    // if mouseEvent did not come from a device that fires touch events,
    // it was made by a real mouse and should be counted
    // http://wicg.github.io/InputDeviceCapabilities/#dom-inputdevicecapabilities-firestouchevents
    let sc = mouseEvent.sourceCapabilities;

    if (sc && !sc.firesTouchEvents) {
      return;
    } // skip synthetic mouse events


    mouseEvent[HANDLED_OBJ] = {
      skip: true
    }; // disable "ghost clicks"

    if (mouseEvent.type === 'click') {
      let clickFromLabel = false;
      let path = mouseEvent.composedPath && mouseEvent.composedPath();

      if (path) {
        for (let i = 0; i < path.length; i++) {
          if (path[i].nodeType === Node.ELEMENT_NODE) {
            if (path[i].localName === 'label') {
              clickedLabels.push(path[i]);
            } else if (canBeLabelled(path[i])) {
              let ownerLabels = matchingLabels(path[i]); // check if one of the clicked labels is labelling this element

              for (let j = 0; j < ownerLabels.length; j++) {
                clickFromLabel = clickFromLabel || clickedLabels.indexOf(ownerLabels[j]) > -1;
              }
            }
          }

          if (path[i] === POINTERSTATE.mouse.target) {
            return;
          }
        }
      } // if one of the clicked labels was labelling the target element,
      // this is not a ghost click


      if (clickFromLabel) {
        return;
      }

      mouseEvent.preventDefault();
      mouseEvent.stopPropagation();
    }
  };
  /**
   * @param {boolean=} setup True to add, false to remove.
   * @return {void}
   */


  function setupTeardownMouseCanceller(setup) {
    let events = IS_TOUCH_ONLY ? ['click'] : MOUSE_EVENTS;

    for (let i = 0, en; i < events.length; i++) {
      en = events[i];

      if (setup) {
        // reset clickLabels array
        clickedLabels.length = 0;
        document.addEventListener(en, mouseCanceller, true);
      } else {
        document.removeEventListener(en, mouseCanceller, true);
      }
    }
  }

  function ignoreMouse(e) {
    if (!POINTERSTATE.mouse.mouseIgnoreJob) {
      setupTeardownMouseCanceller(true);
    }

    let unset = function () {
      setupTeardownMouseCanceller();
      POINTERSTATE.mouse.target = null;
      POINTERSTATE.mouse.mouseIgnoreJob = null;
    };

    POINTERSTATE.mouse.target = e.composedPath()[0];
    POINTERSTATE.mouse.mouseIgnoreJob = Debouncer.debounce(POINTERSTATE.mouse.mouseIgnoreJob, timeOut.after(MOUSE_TIMEOUT), unset);
  }
  /**
   * @param {MouseEvent} ev event to test for left mouse button down
   * @return {boolean} has left mouse button down
   */


  function hasLeftMouseButton(ev) {
    let type = ev.type; // exit early if the event is not a mouse event

    if (!isMouseEvent(type)) {
      return false;
    } // ev.button is not reliable for mousemove (0 is overloaded as both left button and no buttons)
    // instead we use ev.buttons (bitmask of buttons) or fall back to ev.which (deprecated, 0 for no buttons, 1 for left button)


    if (type === 'mousemove') {
      // allow undefined for testing events
      let buttons = ev.buttons === undefined ? 1 : ev.buttons;

      if (ev instanceof window.MouseEvent && !MOUSE_HAS_BUTTONS) {
        buttons = MOUSE_WHICH_TO_BUTTONS[ev.which] || 0;
      } // buttons is a bitmask, check that the left button bit is set (1)


      return Boolean(buttons & 1);
    } else {
      // allow undefined for testing events
      let button = ev.button === undefined ? 0 : ev.button; // ev.button is 0 in mousedown/mouseup/click for left button activation

      return button === 0;
    }
  }

  function isSyntheticClick(ev) {
    if (ev.type === 'click') {
      // ev.detail is 0 for HTMLElement.click in most browsers
      if (ev.detail === 0) {
        return true;
      } // in the worst case, check that the x/y position of the click is within
      // the bounding box of the target of the event
      // Thanks IE 10 >:(


      let t = _findOriginalTarget(ev); // make sure the target of the event is an element so we can use getBoundingClientRect,
      // if not, just assume it is a synthetic click


      if (!t.nodeType ||
      /** @type {Element} */
      t.nodeType !== Node.ELEMENT_NODE) {
        return true;
      }

      let bcr =
      /** @type {Element} */
      t.getBoundingClientRect(); // use page x/y to account for scrolling

      let x = ev.pageX,
          y = ev.pageY; // ev is a synthetic click if the position is outside the bounding box of the target

      return !(x >= bcr.left && x <= bcr.right && y >= bcr.top && y <= bcr.bottom);
    }

    return false;
  }

  let POINTERSTATE = {
    mouse: {
      target: null,
      mouseIgnoreJob: null
    },
    touch: {
      x: 0,
      y: 0,
      id: -1,
      scrollDecided: false
    }
  };

  function firstTouchAction(ev) {
    let ta = 'auto';
    let path = ev.composedPath && ev.composedPath();

    if (path) {
      for (let i = 0, n; i < path.length; i++) {
        n = path[i];

        if (n[TOUCH_ACTION]) {
          ta = n[TOUCH_ACTION];
          break;
        }
      }
    }

    return ta;
  }

  function trackDocument(stateObj, movefn, upfn) {
    stateObj.movefn = movefn;
    stateObj.upfn = upfn;
    document.addEventListener('mousemove', movefn);
    document.addEventListener('mouseup', upfn);
  }

  function untrackDocument(stateObj) {
    document.removeEventListener('mousemove', stateObj.movefn);
    document.removeEventListener('mouseup', stateObj.upfn);
    stateObj.movefn = null;
    stateObj.upfn = null;
  } // use a document-wide touchend listener to start the ghost-click prevention mechanism
  // Use passive event listeners, if supported, to not affect scrolling performance


  document.addEventListener('touchend', ignoreMouse, SUPPORTS_PASSIVE ? {
    passive: true
  } : false);
  /** @type {!Object<string, !GestureRecognizer>} */

  const gestures = {};
  /** @type {!Array<!GestureRecognizer>} */

  _exports.gestures = gestures;
  const recognizers = [];
  /**
          * Finds the element rendered on the screen at the provided coordinates.
          *
          * Similar to `document.elementFromPoint`, but pierces through
          * shadow roots.
          *
          * @param {number} x Horizontal pixel coordinate
          * @param {number} y Vertical pixel coordinate
          * @return {Element} Returns the deepest shadowRoot inclusive element
          * found at the screen position given.
          */

  _exports.recognizers = recognizers;

  function deepTargetFind(x, y) {
    let node = document.elementFromPoint(x, y);
    let next = node; // this code path is only taken when native ShadowDOM is used
    // if there is a shadowroot, it may have a node at x/y
    // if there is not a shadowroot, exit the loop

    while (next && next.shadowRoot && !window.ShadyDOM) {
      // if there is a node at x/y in the shadowroot, look deeper
      let oldNext = next;
      next = next.shadowRoot.elementFromPoint(x, y); // on Safari, elementFromPoint may return the shadowRoot host

      if (oldNext === next) {
        break;
      }

      if (next) {
        node = next;
      }
    }

    return node;
  }
  /**
   * a cheaper check than ev.composedPath()[0];
   *
   * @private
   * @param {Event|Touch} ev Event.
   * @return {EventTarget} Returns the event target.
   */


  function _findOriginalTarget(ev) {
    // shadowdom
    if (ev.composedPath) {
      const targets =
      /** @type {!Array<!EventTarget>} */
      ev.composedPath(); // It shouldn't be, but sometimes targets is empty (window on Safari).

      return targets.length > 0 ? targets[0] : ev.target;
    } // shadydom


    return ev.target;
  }
  /**
   * @private
   * @param {Event} ev Event.
   * @return {void}
   */


  function _handleNative(ev) {
    let handled;
    let type = ev.type;
    let node = ev.currentTarget;
    let gobj = node[GESTURE_KEY];

    if (!gobj) {
      return;
    }

    let gs = gobj[type];

    if (!gs) {
      return;
    }

    if (!ev[HANDLED_OBJ]) {
      ev[HANDLED_OBJ] = {};

      if (type.slice(0, 5) === 'touch') {
        ev =
        /** @type {TouchEvent} */
        ev; // eslint-disable-line no-self-assign

        let t = ev.changedTouches[0];

        if (type === 'touchstart') {
          // only handle the first finger
          if (ev.touches.length === 1) {
            POINTERSTATE.touch.id = t.identifier;
          }
        }

        if (POINTERSTATE.touch.id !== t.identifier) {
          return;
        }

        if (!HAS_NATIVE_TA) {
          if (type === 'touchstart' || type === 'touchmove') {
            _handleTouchAction(ev);
          }
        }
      }
    }

    handled = ev[HANDLED_OBJ]; // used to ignore synthetic mouse events

    if (handled.skip) {
      return;
    } // reset recognizer state


    for (let i = 0, r; i < recognizers.length; i++) {
      r = recognizers[i];

      if (gs[r.name] && !handled[r.name]) {
        if (r.flow && r.flow.start.indexOf(ev.type) > -1 && r.reset) {
          r.reset();
        }
      }
    } // enforce gesture recognizer order


    for (let i = 0, r; i < recognizers.length; i++) {
      r = recognizers[i];

      if (gs[r.name] && !handled[r.name]) {
        handled[r.name] = true;
        r[type](ev);
      }
    }
  }
  /**
   * @private
   * @param {TouchEvent} ev Event.
   * @return {void}
   */


  function _handleTouchAction(ev) {
    let t = ev.changedTouches[0];
    let type = ev.type;

    if (type === 'touchstart') {
      POINTERSTATE.touch.x = t.clientX;
      POINTERSTATE.touch.y = t.clientY;
      POINTERSTATE.touch.scrollDecided = false;
    } else if (type === 'touchmove') {
      if (POINTERSTATE.touch.scrollDecided) {
        return;
      }

      POINTERSTATE.touch.scrollDecided = true;
      let ta = firstTouchAction(ev);
      let shouldPrevent = false;
      let dx = Math.abs(POINTERSTATE.touch.x - t.clientX);
      let dy = Math.abs(POINTERSTATE.touch.y - t.clientY);

      if (!ev.cancelable) {// scrolling is happening
      } else if (ta === 'none') {
        shouldPrevent = true;
      } else if (ta === 'pan-x') {
        shouldPrevent = dy > dx;
      } else if (ta === 'pan-y') {
        shouldPrevent = dx > dy;
      }

      if (shouldPrevent) {
        ev.preventDefault();
      } else {
        prevent('track');
      }
    }
  }
  /**
   * Adds an event listener to a node for the given gesture type.
   *
   * @param {!EventTarget} node Node to add listener on
   * @param {string} evType Gesture type: `down`, `up`, `track`, or `tap`
   * @param {!function(!Event):void} handler Event listener function to call
   * @return {boolean} Returns true if a gesture event listener was added.
   */


  function addListener(node, evType, handler) {
    if (gestures[evType]) {
      _add(node, evType, handler);

      return true;
    }

    return false;
  }
  /**
   * Removes an event listener from a node for the given gesture type.
   *
   * @param {!EventTarget} node Node to remove listener from
   * @param {string} evType Gesture type: `down`, `up`, `track`, or `tap`
   * @param {!function(!Event):void} handler Event listener function previously passed to
   *  `addListener`.
   * @return {boolean} Returns true if a gesture event listener was removed.
   */


  function removeListener(node, evType, handler) {
    if (gestures[evType]) {
      _remove(node, evType, handler);

      return true;
    }

    return false;
  }
  /**
   * automate the event listeners for the native events
   *
   * @private
   * @param {!EventTarget} node Node on which to add the event.
   * @param {string} evType Event type to add.
   * @param {function(!Event)} handler Event handler function.
   * @return {void}
   */


  function _add(node, evType, handler) {
    let recognizer = gestures[evType];
    let deps = recognizer.deps;
    let name = recognizer.name;
    let gobj = node[GESTURE_KEY];

    if (!gobj) {
      node[GESTURE_KEY] = gobj = {};
    }

    for (let i = 0, dep, gd; i < deps.length; i++) {
      dep = deps[i]; // don't add mouse handlers on iOS because they cause gray selection overlays

      if (IS_TOUCH_ONLY && isMouseEvent(dep) && dep !== 'click') {
        continue;
      }

      gd = gobj[dep];

      if (!gd) {
        gobj[dep] = gd = {
          _count: 0
        };
      }

      if (gd._count === 0) {
        node.addEventListener(dep, _handleNative, PASSIVE_TOUCH(dep));
      }

      gd[name] = (gd[name] || 0) + 1;
      gd._count = (gd._count || 0) + 1;
    }

    node.addEventListener(evType, handler);

    if (recognizer.touchAction) {
      setTouchAction(node, recognizer.touchAction);
    }
  }
  /**
   * automate event listener removal for native events
   *
   * @private
   * @param {!EventTarget} node Node on which to remove the event.
   * @param {string} evType Event type to remove.
   * @param {function(!Event): void} handler Event handler function.
   * @return {void}
   */


  function _remove(node, evType, handler) {
    let recognizer = gestures[evType];
    let deps = recognizer.deps;
    let name = recognizer.name;
    let gobj = node[GESTURE_KEY];

    if (gobj) {
      for (let i = 0, dep, gd; i < deps.length; i++) {
        dep = deps[i];
        gd = gobj[dep];

        if (gd && gd[name]) {
          gd[name] = (gd[name] || 1) - 1;
          gd._count = (gd._count || 1) - 1;

          if (gd._count === 0) {
            node.removeEventListener(dep, _handleNative, PASSIVE_TOUCH(dep));
          }
        }
      }
    }

    node.removeEventListener(evType, handler);
  }
  /**
   * Registers a new gesture event recognizer for adding new custom
   * gesture event types.
   *
   * @param {!GestureRecognizer} recog Gesture recognizer descriptor
   * @return {void}
   */


  function register$1(recog) {
    recognizers.push(recog);

    for (let i = 0; i < recog.emits.length; i++) {
      gestures[recog.emits[i]] = recog;
    }
  }
  /**
   * @private
   * @param {string} evName Event name.
   * @return {Object} Returns the gesture for the given event name.
   */


  function _findRecognizerByEvent(evName) {
    for (let i = 0, r; i < recognizers.length; i++) {
      r = recognizers[i];

      for (let j = 0, n; j < r.emits.length; j++) {
        n = r.emits[j];

        if (n === evName) {
          return r;
        }
      }
    }

    return null;
  }
  /**
   * Sets scrolling direction on node.
   *
   * This value is checked on first move, thus it should be called prior to
   * adding event listeners.
   *
   * @param {!EventTarget} node Node to set touch action setting on
   * @param {string} value Touch action value
   * @return {void}
   */


  function setTouchAction(node, value) {
    if (HAS_NATIVE_TA && node instanceof HTMLElement) {
      // NOTE: add touchAction async so that events can be added in
      // custom element constructors. Otherwise we run afoul of custom
      // elements restriction against settings attributes (style) in the
      // constructor.
      microTask.run(() => {
        node.style.touchAction = value;
      });
    }

    node[TOUCH_ACTION] = value;
  }
  /**
   * Dispatches an event on the `target` element of `type` with the given
   * `detail`.
   * @private
   * @param {!EventTarget} target The element on which to fire an event.
   * @param {string} type The type of event to fire.
   * @param {!Object=} detail The detail object to populate on the event.
   * @return {void}
   */


  function _fire(target, type, detail) {
    let ev = new Event(type, {
      bubbles: true,
      cancelable: true,
      composed: true
    });
    ev.detail = detail;
    target.dispatchEvent(ev); // forward `preventDefault` in a clean way

    if (ev.defaultPrevented) {
      let preventer = detail.preventer || detail.sourceEvent;

      if (preventer && preventer.preventDefault) {
        preventer.preventDefault();
      }
    }
  }
  /**
   * Prevents the dispatch and default action of the given event name.
   *
   * @param {string} evName Event name.
   * @return {void}
   */


  function prevent(evName) {
    let recognizer = _findRecognizerByEvent(evName);

    if (recognizer.info) {
      recognizer.info.prevent = true;
    }
  }
  /**
   * Reset the 2500ms timeout on processing mouse input after detecting touch input.
   *
   * Touch inputs create synthesized mouse inputs anywhere from 0 to 2000ms after the touch.
   * This method should only be called during testing with simulated touch inputs.
   * Calling this method in production may cause duplicate taps or other Gestures.
   *
   * @return {void}
   */


  function resetMouseCanceller() {
    if (POINTERSTATE.mouse.mouseIgnoreJob) {
      POINTERSTATE.mouse.mouseIgnoreJob.flush();
    }
  }
  /* eslint-disable valid-jsdoc */


  register$1({
    name: 'downup',
    deps: ['mousedown', 'touchstart', 'touchend'],
    flow: {
      start: ['mousedown', 'touchstart'],
      end: ['mouseup', 'touchend']
    },
    emits: ['down', 'up'],
    info: {
      movefn: null,
      upfn: null
    },

    /**
     * @this {GestureRecognizer}
     * @return {void}
     */
    reset: function () {
      untrackDocument(this.info);
    },

    /**
     * @this {GestureRecognizer}
     * @param {MouseEvent} e
     * @return {void}
     */
    mousedown: function (e) {
      if (!hasLeftMouseButton(e)) {
        return;
      }

      let t = _findOriginalTarget(e);

      let self = this;

      let movefn = function movefn(e) {
        if (!hasLeftMouseButton(e)) {
          downupFire('up', t, e);
          untrackDocument(self.info);
        }
      };

      let upfn = function upfn(e) {
        if (hasLeftMouseButton(e)) {
          downupFire('up', t, e);
        }

        untrackDocument(self.info);
      };

      trackDocument(this.info, movefn, upfn);
      downupFire('down', t, e);
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchstart: function (e) {
      downupFire('down', _findOriginalTarget(e), e.changedTouches[0], e);
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchend: function (e) {
      downupFire('up', _findOriginalTarget(e), e.changedTouches[0], e);
    }
  });
  /**
   * @param {string} type
   * @param {EventTarget} target
   * @param {Event|Touch} event
   * @param {Event=} preventer
   * @return {void}
   */

  function downupFire(type, target, event, preventer) {
    if (!target) {
      return;
    }

    _fire(target, type, {
      x: event.clientX,
      y: event.clientY,
      sourceEvent: event,
      preventer: preventer,
      prevent: function (e) {
        return prevent(e);
      }
    });
  }

  register$1({
    name: 'track',
    touchAction: 'none',
    deps: ['mousedown', 'touchstart', 'touchmove', 'touchend'],
    flow: {
      start: ['mousedown', 'touchstart'],
      end: ['mouseup', 'touchend']
    },
    emits: ['track'],
    info: {
      x: 0,
      y: 0,
      state: 'start',
      started: false,
      moves: [],

      /** @this {GestureInfo} */
      addMove: function (move) {
        if (this.moves.length > TRACK_LENGTH) {
          this.moves.shift();
        }

        this.moves.push(move);
      },
      movefn: null,
      upfn: null,
      prevent: false
    },

    /**
     * @this {GestureRecognizer}
     * @return {void}
     */
    reset: function () {
      this.info.state = 'start';
      this.info.started = false;
      this.info.moves = [];
      this.info.x = 0;
      this.info.y = 0;
      this.info.prevent = false;
      untrackDocument(this.info);
    },

    /**
     * @this {GestureRecognizer}
     * @param {MouseEvent} e
     * @return {void}
     */
    mousedown: function (e) {
      if (!hasLeftMouseButton(e)) {
        return;
      }

      let t = _findOriginalTarget(e);

      let self = this;

      let movefn = function movefn(e) {
        let x = e.clientX,
            y = e.clientY;

        if (trackHasMovedEnough(self.info, x, y)) {
          // first move is 'start', subsequent moves are 'move', mouseup is 'end'
          self.info.state = self.info.started ? e.type === 'mouseup' ? 'end' : 'track' : 'start';

          if (self.info.state === 'start') {
            // if and only if tracking, always prevent tap
            prevent('tap');
          }

          self.info.addMove({
            x: x,
            y: y
          });

          if (!hasLeftMouseButton(e)) {
            // always fire "end"
            self.info.state = 'end';
            untrackDocument(self.info);
          }

          if (t) {
            trackFire(self.info, t, e);
          }

          self.info.started = true;
        }
      };

      let upfn = function upfn(e) {
        if (self.info.started) {
          movefn(e);
        } // remove the temporary listeners


        untrackDocument(self.info);
      }; // add temporary document listeners as mouse retargets


      trackDocument(this.info, movefn, upfn);
      this.info.x = e.clientX;
      this.info.y = e.clientY;
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchstart: function (e) {
      let ct = e.changedTouches[0];
      this.info.x = ct.clientX;
      this.info.y = ct.clientY;
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchmove: function (e) {
      let t = _findOriginalTarget(e);

      let ct = e.changedTouches[0];
      let x = ct.clientX,
          y = ct.clientY;

      if (trackHasMovedEnough(this.info, x, y)) {
        if (this.info.state === 'start') {
          // if and only if tracking, always prevent tap
          prevent('tap');
        }

        this.info.addMove({
          x: x,
          y: y
        });
        trackFire(this.info, t, ct);
        this.info.state = 'track';
        this.info.started = true;
      }
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchend: function (e) {
      let t = _findOriginalTarget(e);

      let ct = e.changedTouches[0]; // only trackend if track was started and not aborted

      if (this.info.started) {
        // reset started state on up
        this.info.state = 'end';
        this.info.addMove({
          x: ct.clientX,
          y: ct.clientY
        });
        trackFire(this.info, t, ct);
      }
    }
  });
  /**
   * @param {!GestureInfo} info
   * @param {number} x
   * @param {number} y
   * @return {boolean}
   */

  function trackHasMovedEnough(info, x, y) {
    if (info.prevent) {
      return false;
    }

    if (info.started) {
      return true;
    }

    let dx = Math.abs(info.x - x);
    let dy = Math.abs(info.y - y);
    return dx >= TRACK_DISTANCE || dy >= TRACK_DISTANCE;
  }
  /**
   * @param {!GestureInfo} info
   * @param {?EventTarget} target
   * @param {Touch} touch
   * @return {void}
   */


  function trackFire(info, target, touch) {
    if (!target) {
      return;
    }

    let secondlast = info.moves[info.moves.length - 2];
    let lastmove = info.moves[info.moves.length - 1];
    let dx = lastmove.x - info.x;
    let dy = lastmove.y - info.y;
    let ddx,
        ddy = 0;

    if (secondlast) {
      ddx = lastmove.x - secondlast.x;
      ddy = lastmove.y - secondlast.y;
    }

    _fire(target, 'track', {
      state: info.state,
      x: touch.clientX,
      y: touch.clientY,
      dx: dx,
      dy: dy,
      ddx: ddx,
      ddy: ddy,
      sourceEvent: touch,
      hover: function () {
        return deepTargetFind(touch.clientX, touch.clientY);
      }
    });
  }

  register$1({
    name: 'tap',
    deps: ['mousedown', 'click', 'touchstart', 'touchend'],
    flow: {
      start: ['mousedown', 'touchstart'],
      end: ['click', 'touchend']
    },
    emits: ['tap'],
    info: {
      x: NaN,
      y: NaN,
      prevent: false
    },

    /**
     * @this {GestureRecognizer}
     * @return {void}
     */
    reset: function () {
      this.info.x = NaN;
      this.info.y = NaN;
      this.info.prevent = false;
    },

    /**
     * @this {GestureRecognizer}
     * @param {MouseEvent} e
     * @return {void}
     */
    mousedown: function (e) {
      if (hasLeftMouseButton(e)) {
        this.info.x = e.clientX;
        this.info.y = e.clientY;
      }
    },

    /**
     * @this {GestureRecognizer}
     * @param {MouseEvent} e
     * @return {void}
     */
    click: function (e) {
      if (hasLeftMouseButton(e)) {
        trackForward(this.info, e);
      }
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchstart: function (e) {
      const touch = e.changedTouches[0];
      this.info.x = touch.clientX;
      this.info.y = touch.clientY;
    },

    /**
     * @this {GestureRecognizer}
     * @param {TouchEvent} e
     * @return {void}
     */
    touchend: function (e) {
      trackForward(this.info, e.changedTouches[0], e);
    }
  });
  /**
   * @param {!GestureInfo} info
   * @param {Event | Touch} e
   * @param {Event=} preventer
   * @return {void}
   */

  function trackForward(info, e, preventer) {
    let dx = Math.abs(e.clientX - info.x);
    let dy = Math.abs(e.clientY - info.y); // find original target from `preventer` for TouchEvents, or `e` for MouseEvents

    let t = _findOriginalTarget(preventer || e);

    if (!t || canBeDisabled[
    /** @type {!HTMLElement} */
    t.localName] && t.hasAttribute('disabled')) {
      return;
    } // dx,dy can be NaN if `click` has been simulated and there was no `down` for `start`


    if (isNaN(dx) || isNaN(dy) || dx <= TAP_DISTANCE && dy <= TAP_DISTANCE || isSyntheticClick(e)) {
      // prevent taps from being generated if an event has canceled them
      if (!info.prevent) {
        _fire(t, 'tap', {
          x: e.clientX,
          y: e.clientY,
          sourceEvent: e,
          preventer: preventer
        });
      }
    }
  }
  /* eslint-enable valid-jsdoc */

  /** @deprecated */


  const findOriginalTarget = _findOriginalTarget;
  /** @deprecated */

  _exports.findOriginalTarget = findOriginalTarget;
  const add = addListener;
  /** @deprecated */

  _exports.add = add;
  const remove = removeListener;
  _exports.remove = remove;
  var gestures$1 = {
    gestures: gestures,
    recognizers: recognizers,
    deepTargetFind: deepTargetFind,
    addListener: addListener,
    removeListener: removeListener,
    register: register$1,
    setTouchAction: setTouchAction,
    prevent: prevent,
    resetMouseCanceller: resetMouseCanceller,
    findOriginalTarget: findOriginalTarget,
    add: add,
    remove: remove
  };
  _exports.$gestures = gestures$1;
  const GestureEventListeners = dedupingMixin(
  /**
          * @template T
          * @param {function(new:T)} superClass Class to apply mixin to.
          * @return {function(new:T)} superClass with mixin applied.
          */
  superClass => {
    /**
     * @polymer
     * @mixinClass
     * @implements {Polymer_GestureEventListeners}
     */
    class GestureEventListeners extends superClass {
      /**
       * Add the event listener to the node if it is a gestures event.
       *
       * @param {!EventTarget} node Node to add event listener to
       * @param {string} eventName Name of event
       * @param {function(!Event):void} handler Listener function to add
       * @return {void}
       * @override
       */
      _addEventListenerToNode(node, eventName, handler) {
        if (!addListener(node, eventName, handler)) {
          super._addEventListenerToNode(node, eventName, handler);
        }
      }
      /**
       * Remove the event listener to the node if it is a gestures event.
       *
       * @param {!EventTarget} node Node to remove event listener from
       * @param {string} eventName Name of event
       * @param {function(!Event):void} handler Listener function to remove
       * @return {void}
       * @override
       */


      _removeEventListenerFromNode(node, eventName, handler) {
        if (!removeListener(node, eventName, handler)) {
          super._removeEventListenerFromNode(node, eventName, handler);
        }
      }

    }

    return GestureEventListeners;
  });
  _exports.GestureEventListeners = GestureEventListeners;
  var gestureEventListeners = {
    GestureEventListeners: GestureEventListeners
  };
  _exports.$gestureEventListeners = gestureEventListeners;

  class MorphRipple extends PolymerElement {
    static get template() {
      return html$1`
    <style>
      :host {
        --ripple-color: #2196f3;
        overflow: hidden;
      }

      :host, .container {
        display: block;
        position: absolute;
        top: 0; right: 0; bottom: 0; left: 0;
        /* pointer-events: none; */
      }

      .container span {
        transform: scale(0);
        border-radius: 100%;
        position: absolute;
        opacity: 0.75;
        background-color: var(--ripple-color);
        animation: ripple 1000ms;
      }

      @keyframes ripple {
        to {
          opacity: 0;
          transform: scale(2);
        }
      }
    </style>
    
    <div id="container" class="container"></div>
`;
    }

    static get is() {
      return 'morph-ripple';
    }

    static get properties() {
      return {};
    }

    ready() {
      super.ready();
      /**
       * Gesture addListener down
       *
       * @param  {Object} this - the button element
       * @param  {string} 'down' - event from key down that we want to listen
       * @param  {Object} e - refers to the element that event down have happened
       *
       */

      addListener(this, 'down', e => {
        this.showRipple(e);
      });
      /**
       * Gestures addListener up
       *
       * @param  {Object} this - the button element
       * @param  {string} 'up' - the type of event we want to listen which is the key up or finger up
       * @param  {Object} e    - refers to the element that event up have happened
       *
       * _debounce will limit the ripple function will fire
       */

      addListener(this, 'up', e => {
        this._debounce = Debouncer.debounce(this._debounce, timeOut.after(1000), () => this.cleanUp());
      });
    }
    /**
     * showRipple gives material design-like ripple effect when buttons are click
     *
     * @param  {Object} e - the button element that the event key down or finger down has happen
     *
     * @return {Object}   - returns the style attribute of the button element with corresponding css styling related to the ripple effect
     */


    showRipple(e) {
      const ripple = document.createElement('span');
      const size = this.offsetWidth;
      const pos = this.getBoundingClientRect(); // for computation of style top and left using Polymer Gesture implementation

      const x = e.detail.x - pos.left - size / 2;
      const y = e.detail.y - pos.top - size / 2;
      const style = 'top:' + y + 'px; left: ' + x + 'px; height: ' + size + 'px; width: ' + size + 'px;';
      this.$.container.appendChild(ripple);
      return ripple.setAttribute('style', style);
    }
    /**
     * clean up the container for the ripple effect
     */


    cleanUp() {
      while (this.$.container.firstChild) {
        this.$.container.removeChild(this.$.container.firstChild);
      }
    }

  }

  _exports.MorphRipple = MorphRipple;
  window.customElements.define(MorphRipple.is, MorphRipple);
  var morphRipple = {
    MorphRipple: MorphRipple
  };
  _exports.$morphRipple = morphRipple;
  var $_documentContainer = document.createElement('template');
  $_documentContainer.innerHTML =
  /*html*/
  `
<dom-module id="morph-shared-styles">
  <template>
    <style>
      :host([platform="ios"]) {
        font-family: -apple-system, 'SF UI Text', 'Helvetica Neue', Helvetica, Arial, sans-serif;
      }

      :host([platform="android"]) {
        font-family: Roboto, Noto, Helvetica, Arial, sans-serif;
      }
    </style>
  </template>
</dom-module>
`;
  document.head.appendChild($_documentContainer.content);
  /**
   * `morph-list-view-item`
   * Item component for list view
   *
   * @customElement
   * @extends HTMLElement
   * 
   * @demo demo/index.html
   */

  class MorphListViewItem extends LitElement {
    render() {
      return html`
    <style include="morph-shared-styles">
      :host {
        display: block;
        margin-bottom: 10px;
      }

      :host .container {
        display: flex;
        justify-content: space-between;
        align-items: var(--container-align-items, center);
        position: relative;
        white-space: nowrap;
        box-sizing: border-box;
        background-color: white;
        z-index: 9999;
      }

      :host .sub-container {
        width: 100%;
        display: flex;
        align-self: stretch;
        align-items: center;
        position: relative;
        min-width: 0;
      }

      :host([platform="ios"]) .container {
        padding-left: 15px;
        min-height: 44px;
      }

      :host([platform="android"]) .container {
        padding-left: 16px;
        min-height: 48px;
      }

      :host([platform="ios"][href]:not([nochevron])) .sub-container {
        padding-right: 15px;
      }
      
      :host([platform="android"][href]:not([nochevron])) .sub-container {
        padding-right: 16px;
      }

      :host([platform="ios"][contains-media]) ::slotted([slot="icon"]) {
        padding-top: 14px;
        padding-bottom: 14px;
      }

      :host([platform="ios"]) .container::before,
      :host([platform="ios"]) .expandable-content-container::after,
      :host([platform="ios"]:not([expandable])) .container::after,
      :host([platform="ios"]) .sub-container::after {
        content: '';
        position: absolute;
        background-color: #c8c7cc;
        left: 0;
        width: 100%;
        height: 1px;
        transform: scaleY(.5);
        transition: opacity 300ms;
      }
      
      :host([platform="ios"]) .sub-container::after,
      :host([platform="android"]) .sub-container::after {
        height: var(--sub-container-after-height, 1px);
        opacity: var(--sub-container-after-opacity, 1);
      }

      :host([platform="android"]) .container::before,
      :host([platform="android"]) .expandable-content-container::after,
      :host([platform="android"]:not([expandable])) .container::after,
      :host([platform="android"]) .sub-container::after {
        content: '';
        position: absolute;
        background-color: rgba(0,0,0,.12);
        left: 0;
        width: 100%;
        height: 1px;
        transform: scaleY(.5);
        transition: opacity 300ms;
      }

      :host([platform="ios"]) .sub-container::after {
        display: var(--display-inner-item-bottom-line, none);
        transform-origin: 50% 100%;
        bottom: 0;
      }

      :host([platform="android"]) .sub-container::after {
        display: var(--display-inner-item-bottom-line, none);
        transform-origin: 50% 100%;
        bottom: 0;
      }

      :host([platform="ios"]) .container::before {
        display: var(--display-top-line, block);
        transform-origin: 50% 0;
        top: 0;
      }

      :host([platform="android"]) .container::before {
        display: var(--display-top-line, block);
        transform-origin: 50% 0;
        top: 0;
      }

      :host([platform="ios"]) .container::after,
      :host([platform="ios"][expandable]) .expandable-content-container::after {
        display: var(--display-bottom-line, block);
        transform-origin: 50% 100%;
        bottom: 0;
      }

      :host([platform="android"]) .container::after,
      :host([platform="android"][expandable]) .expandable-content-container::after {
        display: var(--display-bottom-line, block);
        transform-origin: 50% 100%;
        bottom: 0;
      }

      :host .main-text {
        display: flex;
        justify-content: center;
        flex-direction: column;
        line-height: normal;
        width: 100%;
        padding-top: 8px;
        padding-bottom: 8px;
        min-width: 0;
      }

      :host([platform="ios"]) .main-text {
        font-size: 17px;
      }

      :host([platform="android"]) .main-text {
        font-size: 16px;
      }

      :host .main-text span {
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      :host([platform="android"]) .main-text ::slotted([slot="header"]),
      :host([platform="android"]) .main-text ::slotted([slot="footer"]), 
      :host([platform="ios"]) .main-text ::slotted([slot="header"]),
      :host([platform="ios"]) .main-text ::slotted([slot="footer"]) {
        font-weight: 400;
        font-size: 12px;
        line-height: 1.2;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }

      .main-text ::slotted([slot="footer"]) {
        color: #8e8e93;
      }

      :host([platform="ios"]) ::slotted([slot="secondary-content"]) {
        color: #8e8e93;
        font-size: 17px;
        padding-left: 5px;
        padding-right: 11px;
      }

      :host([platform="android"]) ::slotted([slot="secondary-content"]) {
        color: #757575;
        font-size: 14px;
        padding-left: 8px;
        padding-right: 18px;
      }

      :host ::slotted([slot="icon"]) {
        flex-grow: 0;
        flex-shrink: 0;
        margin-right: 15px;
      }

      :host([platform="android"]) ::slotted([slot="icon"]) {
        min-width: 40px;
      }

      :host([platform="ios"]) .expandable-content-container {
        position: relative;
        background-color: white;
        display: block;
        box-sizing: border-box;
        width: 100%;
        color: #6d6d72;
        overflow: hidden;
        transition: max-height 300ms;
      }

      :host([platform="android"]) .expandable-content-container {
        position: relative;
        background-color: white;
        display: block;
        box-sizing: border-box;
        width: 100%;
        color: #212121;
        overflow: hidden;
        line-height: 1.5;
        transition: max-height 300ms;
      }

      :host([platform="ios"]:not([expandable])) .expandable-content-container,
      :host([platform="android"]:not([expandable])) .expandable-content-container {
        display: none;
      }

      :host([platform="ios"]) ::slotted([slot="expandable-content"]) {
        display: block;
        padding: 10px 15px;
      }

      :host([platform="android"]) ::slotted([slot="expandable-content"]) {
        display: block;
        padding: 10px 16px;
      }

      :host([platform="ios"]:not([expanded])) .expandable-content-container,
      :host([platform="android"]:not([expanded])) .expandable-content-container {
        max-height: 1px !important;
      }

      a {
        color: inherit;
        cursor: default;
        text-decoration: none;
      }

      svg {
        flex-grow: 0;
        flex-shrink: 0;
      }

      :host(:not([platform="android"])) morph-ripple {
        display: none;
      }
      :host([platform="android"]) morph-ripple {
        --ripple-color:  var(--ripple-color-android-light, rgba(0,0,0,0.1));
      }
      
    </style>
    
    <a href="${ifDefined(this.href)}" @click="${event => this.clickHandler(event)}">
      <div class="container">
        <slot name="icon"></slot>

        <div class="sub-container">
          <div class="main-text">
            <slot name="header"></slot>
            <span>
              <slot></slot>
            </span>
            <slot name="footer"></slot>
          </div>

          <slot name="secondary-content"></slot>
          
          ${this.getRenderChevron()}
        </div>

        ${this.getRenderRipple()}
        
      </div>

      <div class="expandable-content-container" id="expandableContentContainer">
        <div><slot name="expandable-content"></slot></div>
      </div>
    </a>
    `;
    }

    static get is() {
      return 'morph-list-view-item';
    }

    static get properties() {
      return {
        platform: {
          type: String,
          reflect: true
        },
        href: {
          type: String,
          reflect: true
        },
        containsmedia: {
          type: Boolean,
          reflect: true
        },

        /** remove ripple effect */
        noripple: {
          type: Boolean,
          reflect: true
        },

        /** remove chevron svg on links */
        nochevron: {
          type: Boolean,
          reflect: true
        },
        expandable: {
          type: Boolean
        },
        expanded: {
          type: Boolean,
          reflect: true
        }
      };
    }
    /**
     * LitElement lifecycle called once just before first updated() is called
     */


    firstUpdated() {
      super.firstUpdated(); // check first if platform is already assigned in the html attribute before auto detecting platform using getPlatform()

      if (!this.hasAttribute('platform')) {
        this.platform = getPlatform$1();
      }

      if (this.expandable) {
        this._setMaxHeightForExpandableContentContainer();
      }
    }
    /**
     * Handles click events
     * @param {Object} event 
     */


    clickHandler(event) {
      if (this.expandable) {
        this._setMaxHeightForExpandableContentContainer();

        this.expanded = !this.expanded;

        this._expandedChanged();
      }
    }
    /**
     * Gets height of expandable content and assigns it to max-height to make it transition form open to close smoothly
     */


    _setMaxHeightForExpandableContentContainer() {
      let shadow = this.shadowRoot;
      let expandableContent = shadow.querySelector('#expandableContentContainer');
      const height = expandableContent.children[0].offsetHeight;
      expandableContent.style.maxHeight = height + 'px';
    }
    /**
     * returns html template of svg if all conditions are met and returns null if not
     */


    getRenderChevron() {
      if (this.hasAttribute('href') && !this.nochevron) {
        return html`
        <svg id="chevron-svg" width="8px" height="13px" viewBox="0 0 8 13" xmlns="http://www.w3.org/2000/svg">
          <polygon fill="#c7c7cc" transform="translate(1.500000, 6.500000) rotate(-45.000000) translate(-1.500000, -6.500000) "
            points="6 11 6 2 4 2 4 9 -3 9 -3 11 5 11"></polygon>
        </svg>
      `;
      } else {
        return null;
      }
    }
    /**
     * returns morph-ripple template if all conditions are met and returns null if not
     */


    getRenderRipple() {
      if (this.platform == 'android' && this.hasAttribute('href') && !this.noripple) {
        return html`<morph-ripple></morph-ripple>`;
      } else {
        return null;
      }
    }
    /**
     * dispatch custom event expandedChange. This is use together with this.expandable and when this.expanded is toggled
     */


    _expandedChanged() {
      // Fire a custom event for others to listen to when expanded change
      this.dispatchEvent(new CustomEvent('expandedChange', {
        detail: this.expanded
      }));
    }

  }

  _exports.MorphListViewItem = MorphListViewItem;
  window.customElements.define(MorphListViewItem.is, MorphListViewItem);
  var morphListViewItem = {
    MorphListViewItem: MorphListViewItem
  };
  _exports.$morphListViewItem = morphListViewItem;

  const getPlatform$2 = function () {
    let userAgent = navigator.userAgent || navigator.vendor || window.opera; // Windows Phone must come first because its UA also contains "Android"

    if (/windows phone/i.test(userAgent)) {
      return 'windows-phone';
    }

    if (/android/i.test(userAgent)) {
      return 'android';
    } // iOS detection from: http://stackoverflow.com/a/9039885/177710


    if (/iPad|iPhone|iPod/.test(userAgent) && !window.MSStream) {
      return 'ios';
    }

    return 'unknown';
  };

  _exports.getPlatform = getPlatform$2;
  var morphElement$2 = {
    getPlatform: getPlatform$2
  };
  _exports.$morphElement = morphElement$2;

  class MorphListViewDivider extends LitElement {
    render() {
      return html`
    <style include="morph-shared-styles">
      :host {
        white-space: nowrap;
        position: relative;
        max-width: 100%;
        text-overflow: ellipsis;
        overflow: hidden;
        z-index: 15;
        box-sizing: border-box;
        overflow: hidden;
        margin-top: -1px;
      }

      :host([platform="ios"]) {
        color: #8e8e93;
        display: block;
        height: 31px;
        line-height: 23.8px;
        padding: 4px 15px;
        background: #f7f7f7;
        font-size: 17px;
      }

      :host([platform="android"]) {
        color: rgba(0, 0, 0, 0.54);
        display: list-item;
        height: 48px;
        line-height: 48px;
        padding: 0px 16px;
        background: rgb(244, 244, 244);
        font-size: 14px;
      }
    </style>
    <slot></slot>
`;
    }

    static get is() {
      return 'morph-list-view-divider';
    }

    static get properties() {
      return {
        platform: {
          type: String,
          reflect: true
        }
      };
    }
    /**
     * LitElement lifecycle called once before the first updated() is called
     */


    firstUpdated() {
      super.firstUpdated(); // check for platform attribute if already set in HTML markup before auto detecting platform and assigning new value

      if (!this.hasAttribute('platform')) {
        this.platform = getPlatform$2();
      }
    }

  }

  _exports.MorphListViewDivider = MorphListViewDivider;
  window.customElements.define(MorphListViewDivider.is, MorphListViewDivider);
  var morphListViewDivider = {
    MorphListViewDivider: MorphListViewDivider
  };
  _exports.$morphListViewDivider = morphListViewDivider;
  console.log(driver);
  let pagesList;
  let topNavigationButtons;
  let navigationButtonTheory;
  let navigationButtonPractice;
  let headerButtonClassroom;
  document.addEventListener('WebViewApiReady', function () {
    Moduware.v0.API.Module.addEventListener('RawDataReceived', function (message) {
      if (message.moduleUuid != Moduware.Arguments.uuid) return;
      if (message.dataSource != '2800') return; // Parse data

      var decodedData = Uint8Array.from(atob(message.data), c => c.charCodeAt(0));

      for (var i = 0; i < decodedData.length / 4; i++) {
        var pinData = decodedData.slice(i * 4, (i + 1) * 4);
        var $pin = document.getElementById('pin-' + pinData[0]);

        if ($pin.type == 'gpio i') {
          $pin.value = pinData[2] == 0 ? 'low' : 'high';
        } else if ($pin.type == 'adc') {
          $pin.value = ((pinData[2] * 256 + pinData[3]) / 1023 * 3.3).toFixed(2);
        }
      }
    });
    Moduware.v0.API.Driver.LoadFromJson(Moduware.Arguments.uuid, driver, () => console.log('driver loaded'));
    Moduware.v0.API.addEventListener('BeforeExit', () => {
      Moduware.v0.API.Driver.RestoreDefault(Moduware.Arguments.uuid);
    });
  }); // document.addEventListener('DOMContentLoaded', function(event) {

  pagesList = Array.from(document.getElementsByClassName('page'));
  var videoContainer = document.getElementById('video-container');
  navigationButtonTheory = document.getElementById('navigation-button-theory');
  navigationButtonPractice = document.getElementById('navigation-button-practice');
  topNavigationButtons = navigationButtonTheory.parentNode; // Creating header on top of tile

  WebViewTileHeader.create('DevGames');
  WebViewTileHeader.customize({
    borderBottom: 'none'
  });
  WebViewTileHeader.addButton({
    id: 'header-button-classroom',
    image: 'img/icon-classroom.svg'
  }, () => {
    showPage('classroom');
  });
  headerButtonClassroom = document.getElementById('header-button-classroom');
  WebViewTileHeader.addEventListener('BackButtonClicked', () => {
    var currentPage = document.getElementsByClassName('page--active')[0];

    if (currentPage.classList.contains('page--classroom')) {
      showPage('theory');
    } else if (currentPage.classList.contains('page--archievements')) {
      showPage('classroom');
    } else {
      Moduware.v0.API.Exit();
    }
  });
  navigationButtonTheory.addEventListener('click', () => {
    showPage('theory');
  });
  navigationButtonPractice.addEventListener('click', () => {
    showPage('practice');
  });
  document.getElementById('classroom-button-archievements').addEventListener('click', () => {
    showPage('archievements');
  });
  var slideNavigationButtons = Array.from(document.getElementById('slide-navigation-buttons').children);
  slideNavigationButtons.forEach(el => el.addEventListener('click', () => {
    document.getElementById('page-practice-container').classList.toggle('wide-content--scrolled');
  }));
  document.getElementById('video-container__fullscreen-toggle').addEventListener('click', function () {
    this.parentNode.classList.toggle('video-container--fullscreen');
  });

  for (var i = 0; i < 16; i++) {
    if (i == 3) continue;
    document.getElementById('pin-' + i).addEventListener('click', function (pinNumber) {
      return function () {
        if (this.type == 'gpio o') {
          Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid, 'SetPinConfig', [pinNumber, 1, this.value == 'low' ? 0 : 1]);
        } else if (this.type == 'gpio i' || this.type == 'adc') {
          Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid, 'SetPinConfig', [pinNumber, this.type == 'gpio i' ? 0 : 2]);
        } else if (this.type == 'pwm') {
          Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid, 'SetPinConfig', [pinNumber, 3, this.value]);
        }
      };
    }(i));
  } //});


  var youtubeApiTag = document.createElement('script');
  youtubeApiTag.src = 'https://www.youtube.com/iframe_api';
  var firstScriptTag = document.getElementsByTagName('script')[0];
  firstScriptTag.parentNode.insertBefore(youtubeApiTag, firstScriptTag);
  var youtubePlayer;

  window.onYouTubeIframeAPIReady = function () {
    youtubePlayer = new YT.Player('youtube-player', {
      events: {
        'onReady': onPlayerReady,
        'onStateChange': onPlayerStateChange
      }
    });
  };

  var currentVideo = 0;
  /*
   * 0 - intro
   * 1 - explanation
   * 2 - exercise 1
   * 3 - exercise 2
   */

  function onPlayerReady(event) {
    event.target.playVideo();
    enterVideoFullScreen();
  }

  var stepTimeout;

  function onPlayerStateChange(event) {
    console.log('state', event.data);

    if (event.data == 0) {
      switch (currentVideo) {
        case 0:
          youtubePlayer.loadVideoById('1nqFOUf-k8c');
          break;

        case 1:
          youtubePlayer.loadVideoById('QmjuLapjJIs');
          break;

        case 2:
          document.getElementById('archievement-dialog').classList.add('archievement-dialog--visible');
          break;
      }

      currentVideo++;
    } else if (event.data == 1) {
      // started playing or unpaused
      if (currentVideo == 2) {
        var currentTime = youtubePlayer.getCurrentTime();

        if (currentTime < 44) {
          stepTimeout = setTimeout(() => stepStop(), (44 - currentTime + 1) * 1000);
        } else if (currentTime < 62) {
          stepTimeout = setTimeout(() => stepStop(), (62 - currentTime + 1) * 1000);
        }
      } else if (currentVideo == 3) {
        var currentTime = youtubePlayer.getCurrentTime();

        if (currentTime < 33) {
          stepTimeout = setTimeout(() => stepStop(), (33 - currentTime + 1) * 1000);
        } else if (currentTime < 50) {
          stepTimeout = setTimeout(() => stepStop(), (50 - currentTime + 1) * 1000);
        } else if (currentTime < 69) {
          stepTimeout = setTimeout(() => stepStop(), (69 - currentTime + 1) * 1000);
        } else if (currentTime < 103) {
          stepTimeout = setTimeout(() => stepStop(), (103 - currentTime + 1) * 1000);
        }
      }
    } else if (event.data == 2 || event.data == 3) {
      clearTimeout(stepTimeout);
    }
  }

  var progressSteps = Array.from(document.getElementsByClassName('steps-list__item'));
  progressSteps.forEach(e => e.addEventListener('click', function () {
    var stepEndTime = parseInt(this.dataset.endTime);
    youtubePlayer.seekTo(stepEndTime);
    youtubePlayer.playVideo();
    enterVideoFullScreen();
  }));
  document.getElementById('archievement-dialog__button').addEventListener('click', () => {
    document.getElementById('archievement-dialog').classList.remove('archievement-dialog--visible');
    youtubePlayer.loadVideoById('jCSg9RdjtTs');
    document.getElementById('progress-lesson-1-items').classList.add('display--none');
    document.getElementById('progress-lesson-2-items').classList.remove('display--none');
  });

  function stepStop() {
    youtubePlayer.pauseVideo();
    leaveVideoFullScreen();
  }

  function enterVideoFullScreen() {
    videoContainer.classList.add('video-container--fullscreen');
  }

  function leaveVideoFullScreen() {
    videoContainer.classList.remove('video-container--fullscreen');
  }

  function showPage(name) {
    pagesList.forEach(el => {
      if (el.classList.contains('page--' + name)) {
        el.classList.add('page--active');
      } else {
        el.classList.remove('page--active');
      }
    });

    if (name == 'classroom' || name == 'archievements') {
      topNavigationButtons.classList.add('navigation-buttons--hidden');
      WebViewTileHeader.customize({
        backgroundColor: '#F8F8F8'
      });
      headerButtonClassroom.classList.add('display--none');
    }

    if (name == 'classroom') {
      WebViewTileHeader.setTitle('Classroom');
    }

    if (name == 'archievements') {
      WebViewTileHeader.setTitle('Archievements');
    }

    if (name == 'theory' || name == 'practice') {
      topNavigationButtons.classList.remove('navigation-buttons--hidden');
      WebViewTileHeader.customize({
        backgroundColor: 'white'
      });
      WebViewTileHeader.setTitle('DevGames');
      headerButtonClassroom.classList.remove('display--none');
    }

    if (name == 'theory') {
      navigationButtonTheory.classList.add('navigation-buttons__button--active');
      navigationButtonPractice.classList.remove('navigation-buttons__button--active');
    }

    if (name == 'practice') {
      navigationButtonPractice.classList.add('navigation-buttons__button--active');
      navigationButtonTheory.classList.remove('navigation-buttons__button--active');
    }
  }
});