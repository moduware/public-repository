var laserDistanceAdjustmentsTable = {
  'batpaq': {
    1: +0.033, // 0.033m = 3.3cm = 33mm
    2: +0.008, // 0.008m = 0.8cm = 8mm
    3: +0.008, // 0.008m = 0.8cm = 8mm
    4: +0.033  // 0.033m = 3.3cm = 33mm
  }
};