define(["exports", "./my-app.js"], function (_exports, _myApp) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.MorphRipple = _exports.$morphRipple = void 0;

  function _templateObject6_f3d168f06e5e11eaa0a2275ae9a33b1d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        /* #wrapper {\n\t\t\t\t\toverflow: hidden;\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\ttop: 40px; right: 0;\n\t\t\t\t\twidth: 100%;\n\t\t\t\t\theight: calc(100% - 40px);\n\t\t\t\t}\n\n\t\t\t\tbody.platform-android #wrapper {\n\t\t\t\t\ttop: 55px;\n\t\t\t\t\theight: calc(100% - 55px)\n\t\t\t\t} */\n\n\t\t\t\t#wrapper {\n\t\t\t\t\theight: 100%;\n\t\t\t\t}\n\n\t\t\t\t.page--main {\n\t\t\t\t\tposition: absolute;\n\t\t\t\t\ttop: 0; left: 0;\n\t\t\t\t\twidth: 100%; height: 100%;\n\t\t\t\t\tbackground-color: #3A3A3A;\n\t\t\t\t\tdisplay: flex;\n\t\t\t\t\tflex-direction: column;\n\t\t\t\t\tjustify-content: space-between;\n\t\t\t\t\t/* z-index: 1; */\n\t\t\t\t}\n\n\t\t\t\th1 {\n\t\t\t\t\tcolor: white;\n\t\t\t\t\tpadding-top: 60px;\n\n\t\t\t\t}\n\n\t\t\t\t.page--main .svg-container {\n\t\t\t\t\t/* order: 1; */\n\t\t\t\t\tposition: relative;\n\t\t\t\t\ttop: 25%; left: 28%;\n\t\t\t\t\twidth: 200px;\n\t\t\t\t\theight: 250px;\n\t\t\t\t}\n\n\t\t\t\t.page--main .svg-case-module {\n\t\t\t\t\tposition: relative;\n\t\t\t\t\ttop: 0; left: 0;\n\t\t\t\t\t/* background-image: url('/images/case-module.svg'); */\n\t\t\t\t\twidth: 159px;\n\t\t\t\t\theight: 197px;\n\t\t\t\t\tz-index: 1;\n\t\t\t\t}\n\n\t\t\t\t/* .page--main .svg-disconnected {\n\t\t\t\t\tposition: relative;\n\t\t\t\t\ttop: -53%; left: 14%;\n\t\t\t\t\tbackground-image: url('../images/disconnected.svg');\n\t\t\t\t\twidth: 108px;\n\t\t\t\t\theight: 129px;\n\t\t\t\t\tz-index: 2;\n\t\t\t\t} */\n\n\t\t\t\t.page--main .svg-connected {\n\t\t\t\t\tposition: relative;\n\t\t\t\t\ttop: -53%; left: 14%;\n\t\t\t\t\t/* background-image: url('/images/connected.svg'); */\n\t\t\t\t\twidth: 109px;\n\t\t\t\t\theight: 129px;\n\t\t\t\t\tz-index: 2;\n\t\t\t\t}\n\n\t\t\t\t.page--main .text {\n\t\t\t\t\t/* order: 2; */\n\t\t\t\t\tcolor: #ffffff;\n\t\t\t\t\tfont-size: 13px;\n\t\t\t\t\tfont-weight: 400;\n\t\t\t\t\tline-height: 16px;\n\t\t\t\t\tmargin-top: 53%;\n\t\t\t\t\tmargin-left: 15%;\n\t\t\t\t\tmargin-right: 15%;\n\t\t\t\t\ttext-align: center;\n\t\t\t\t}\n\n\t\t\t\t.page--main .button-connect {\n\t\t\t\t\t/* order: 3; */\n\t\t\t\t\twidth: 328px;\n\t\t\t\t\theight: 56px;\n\t\t\t\t\tborder-radius: 5px;\n\t\t\t\t\tfont-size: 20px;\n\t\t\t\t\tfont-weight: 400;\n\t\t\t\t\tcolor: #FFFFFF;\n\t\t\t\t\tbackground-color: #4BC3DA;\n\t\t\t\t\tmargin: auto;\n\t\t\t\t\tmargin-bottom: 5px;\n          text-transform: none;\n\t\t\t\t}\n\n\t\t\t\tmorph-button {\n\t\t\t\t\t--color: #4bc3da;\n\t\t\t\t}\n\n\t\t\t\t.mdl-button--raised {\n\t\t\t\t\tbackground: rgba(158,158,158,.2);\n\t\t\t\t\tbox-shadow: 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.2),0 1px 5px rgba(0,0,0,.12);\n\t\t\t\t}\n\n\t\t\t\t/* .mdl-button--raised:active {\n\t\t\t\t\tbox-shadow: 0 4px 5px 0 rgba(0,0,0,.14),0 1px 10px 0 rgba(0,0,0,.12),0 2px 4px -1px rgba(0,0,0,.2);\n\t\t\t\t\tbackground-color: rgba(158,158,158,.4);\n\t\t\t\t} */\n\n\t\t\t\t/* .mdl-button--raised:focus:not(:active) {\n\t\t\t\t\tbox-shadow: 0 0 8px rgba(0,0,0,.18),0 8px 16px rgba(0,0,0,.36);\n\t\t\t\t\tbackground-color: rgba(158,158,158,.4);\n\t\t\t\t} */\n      "]);

    _templateObject6_f3d168f06e5e11eaa0a2275ae9a33b1d = function _templateObject6_f3d168f06e5e11eaa0a2275ae9a33b1d() {
      return data;
    };

    return data;
  }

  function _templateObject5_f3d168f06e5e11eaa0a2275ae9a33b1d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <div id=\"wrapper\" class=\"wrapper\">\n\n\t\t\t\t<div id=\"pageMain\" class=\"page page--main\">\n\n\t\t\t\t\t<div class=\"svg-container\">\n\t\t\t\t\t\t<div id=\"svg-case-module\" class=\"svg-case-module\">", "</div>\n\t\t\t\t\t\t<div id=\"svg-disconnected\" class=\"svg-disconnected\"></div>\n\t\t\t\t\t\t<div id=\"svg-connected\" class=\"svg-connected\">", "</div>\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"text\" id=\"text\">", "</div>\n\t\t\t\t\t<morph-button filled class=\"button-connect\" id=\"button-connect\" @click=\"", "\">", "</morph-button>\n\t\t\t\t\t<!-- <button class=\"button-file-manager mdl-button--raised hidden\" id=\"button-file-manager\">Open File Manager</button> -->\n\t\t\t\t</div>\n\n\t\t\t</div>\n    "]);

    _templateObject5_f3d168f06e5e11eaa0a2275ae9a33b1d = function _templateObject5_f3d168f06e5e11eaa0a2275ae9a33b1d() {
      return data;
    };

    return data;
  }

  function _templateObject4_f3d168f06e5e11eaa0a2275ae9a33b1d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      \n        :host {\n          --have-access-to-shared-colors: var(--morph-shared-colors-connected, black);\n        }\n      \n        /* if iOS assigning colors from iOS colors table */\n        :host([platform=\"ios\"]) {\n          /* default blue ios colors added here and don't need shared color file to work */\n          --polymorph-ios-blue-color: #007aff;\n          --polymorph-ios-blue-color--background: rgba(0, 122, 255, 0.15);\n      \n          --blue-color: var(--polymorph-ios-blue-color);\n          --blue-color--background: var(--polymorph-ios-blue-color--background);\n      \n          --red-color: var(--polymorph-ios-red-color);\n          --red-color--background: var(--polymorph-ios-red-color--background);\n      \n          --green-color: var(--polymorph-ios-green-color);\n          --green-color--background: var(--polymorph-ios-green-color--background);\n      \n          --gray-color: var(--polymorph-ios-gray-color);\n          --gray-color--background:var(--polymorph-ios-gray-color--background);\n        }\n      \n        /* if Android assigning colors from Android colors table */\n        :host([platform=\"android\"]) {\n          /* default blue android colors added here to make it work without shared colors file */\n          --polymorph-android-blue-color: #2196f3;\n          --polymorph-android-blue-color--background: #0D82DF;\n      \n          --blue-color: var(--polymorph-android-blue-color);\n          --blue-color--background: var(--polymorph-android-blue-color--background);\n      \n          --red-color: var(--polymorph-android-red-color);\n          --red-color--background: var(--polymorph-android-red-color--background);\n      \n          --green-color: var(--polymorph-android-green-color);\n          --green-color--background: var(--polymorph-android-green-color--background);\n      \n          --gray-color: var(--polymorph-android-gray-color);\n          --gray-color--background:var(--polymorph-android-gray-color--background);\n      \n          --android-raised-1-shadow: 0 1px 3px rgba(0,0,0,0.12), 0 1px 2px rgba(0,0,0,0.24);\n          --android-raised-2-shadow: 0 3px 6px rgba(0,0,0,0.16), 0 3px 6px rgba(0,0,0,0.23);\n        }\n      \n        /* Shared color configuration */\n        :host {\n          --color: var(--blue-color);\n          --active-color--background: var(--blue-color--background);\n          --filled-text-color: white;\n      \n          --font-size: 14px;\n        }\n      \n        /* Prebuilt colors */\n        :host([color=\"red\"]) {\n          --color: var(--red-color);\n          --active-color--background: var(--red-color--background);\n        }\n      \n        :host([color=\"green\"]) {\n          --color: var(--green-color);\n          --active-color--background: var(--green-color--background);\n        }\n      \n        :host([color=\"gray\"]) {\n          --color: var(--gray-color);\n          --active-color--background: var(--gray-color--background);\n        }\n      \n        /* Shared styles between platforms */\n        :host {\n          appearance: none;\n          background: none;\n          box-sizing: border-box;\n          color: var(--color);\n          cursor: pointer;\n          display: flex;\n          justify-content: center;\n          align-items: center;\n          font-size: var(--font-size);\n          margin: 0;\n          outline: 0;\n          overflow: hidden;\n          position: relative;\n          text-align: center;\n          text-decoration: none;\n          text-overflow:ellipsis;\n          white-space: nowrap;\n          -webkit-tap-highlight-color: transparent;\n      \n          /* We need to use system font here */\n          font-family: inherit;\n        }\n        \n        /* class to be used to make morph-button work with morph-swipeout */\n        :host([platform=\"ios\"].swiper-integration-class),\n        :host([platform=\"android\"].swiper-integration-class) {\n          height: 100%;\n          flex: 1;\n        }\n      \n        /* iOS only styles */\n        :host([platform=\"ios\"]) {\n          border-radius: 5px;\n          border: 1px solid var(--color);\n          cursor: pointer;\n          height: 29px;\n          line-height: 27px;\n          padding: 0 10px;\n          position: relative;\n          font-family: -apple-system, 'SF UI Text', 'Helvetica Neue', Helvetica, Arial, sans-serif;\n        }\n      \n        :host([platform=\"ios\"]:active) {\n          background: var(--active-color--background);\n        } \n      \n        :host([platform=\"ios\"][active]) {\n          background: var(--color);\n          color: var(--filled-text-color);\n        }\n      \n        :host([platform=\"ios\"][rounded]) {\n          border-radius: 27px 27px 27px 27px;\n        }\n      \n        :host([platform=\"ios\"][big]) {\n          font-size: 17px;\n          height: 44px;\n          line-height: 42px;\n        }\n      \n        :host([platform=\"ios\"][filled]) {\n          background: var(--color);\n          color: var(--filled-text-color);\n          border-color: transparent;\n        }\n      \n        :host([platform=\"ios\"][filled]:active) {\n          opacity: 0.8;\n        }\n      \n        /* Android only styles */\n        :host([platform=\"android\"]) {\n          border-radius: 2px;\n          height: 36px;\n          line-height: 36px;\n          min-width: 64px;;\n          padding: 0 8px;\n          text-transform: uppercase;\n          transform: translate3d(0,0,0);\n          transition: 300ms;\n          font-family: Roboto, Noto, Helvetica, Arial, sans-serif;\n        }\n      \n        :host([platform=\"android\"]:active) {\n          background: rgba(0, 0, 0, 0.1);\n        } \n      \n        :host([platform=\"android\"][big]) {\n          height: 48px;\n          line-height: 48px;\n          border-radius: 3px;\n        }\n      \n        :host([platform=\"android\"][filled]) {\n          --android-filled-background-color: var(--color);\n          background-color: var(--android-filled-background-color);\n          color: var(--filled-text-color);\n        }\n        \n        :host([platform=\"android\"][filled]:active) {\n          background: var(--active-color--background);\n        }\n      \n        :host([platform=\"android\"][raised]) {\n          box-shadow: var(--android-raised-1-shadow);\n        }\n      \n        :host([platform=\"android\"][raised]:active) {\n          box-shadow: var(--android-raised-2-shadow);\n        }\n      \n        :host(:not([platform=\"android\"])) morph-ripple {\n          display: none;\n        }\n      \n        :host([platform=\"android\"]) morph-ripple {\n          --ripple-color: var(--color);\n        }\n      \n        :host([platform=\"android\"][filled]) morph-ripple {\n          --ripple-color: white;\n        }\n      \n        /* important is to counter the border-radius on big buttons for android and others */\n        :host([flat]) {\n          border-radius: 0 !important;\n        }\n      "]);

    _templateObject4_f3d168f06e5e11eaa0a2275ae9a33b1d = function _templateObject4_f3d168f06e5e11eaa0a2275ae9a33b1d() {
      return data;
    };

    return data;
  }

  function _templateObject3_f3d168f06e5e11eaa0a2275ae9a33b1d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <a href$=\"[[link]]\" target$=\"[[target]]\" rel$=\"[[relation]]\">\n        <slot></slot>\n        <morph-ripple></morph-ripple>\n      </a>\n    "], ["\n      <a href\\$=\"[[link]]\" target\\$=\"[[target]]\" rel\\$=\"[[relation]]\">\n        <slot></slot>\n        <morph-ripple></morph-ripple>\n      </a>\n    "]);

    _templateObject3_f3d168f06e5e11eaa0a2275ae9a33b1d = function _templateObject3_f3d168f06e5e11eaa0a2275ae9a33b1d() {
      return data;
    };

    return data;
  }

  function _templateObject2_f3d168f06e5e11eaa0a2275ae9a33b1d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        :host {\n          --ripple-color: #2196f3;\n          overflow: hidden;\n        }\n\n        :host, .container {\n          display: block;\n          position: absolute;\n          top: 0; right: 0; bottom: 0; left: 0;\n          /* pointer-events: none; */\n        }\n\n        .container span {\n          transform: scale(0);\n          border-radius: 100%;\n          position: absolute;\n          opacity: 0.75;\n          background-color: var(--ripple-color);\n          animation: ripple 1000ms;\n        }\n\n        @keyframes ripple {\n          to {\n            opacity: 0;\n            transform: scale(2);\n          }\n        } \n      "]);

    _templateObject2_f3d168f06e5e11eaa0a2275ae9a33b1d = function _templateObject2_f3d168f06e5e11eaa0a2275ae9a33b1d() {
      return data;
    };

    return data;
  }

  function _templateObject_f3d168f06e5e11eaa0a2275ae9a33b1d() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <div id=\"container\" class=\"container\"></div>\n    "]);

    _templateObject_f3d168f06e5e11eaa0a2275ae9a33b1d = function _templateObject_f3d168f06e5e11eaa0a2275ae9a33b1d() {
      return data;
    };

    return data;
  }

  var MorphRipple =
  /*#__PURE__*/
  function (_LitElement) {
    babelHelpers.inherits(MorphRipple, _LitElement);

    function MorphRipple() {
      babelHelpers.classCallCheck(this, MorphRipple);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphRipple).apply(this, arguments));
    }

    babelHelpers.createClass(MorphRipple, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject_f3d168f06e5e11eaa0a2275ae9a33b1d());
      }
    }, {
      key: "firstUpdated",
      value: function firstUpdated() {
        var _this = this;

        babelHelpers.get(babelHelpers.getPrototypeOf(MorphRipple.prototype), "firstUpdated", this).call(this);
        /**
         * Gesture addListener down
         *
         * @param  {Object} this - the button element
         * @param  {string} 'down' - event from key down that we want to listen
         * @param  {Object} e - refers to the element that event down have happened
         *
         */

        (0, _myApp.addListener)(this, 'down', function (e) {
          _this.showRipple(e);
        });
        /**
         * Gestures addListener up
         *
         * @param  {Object} this - the button element
         * @param  {string} 'up' - the type of event we want to listen which is the key up or finger up
         * @param  {Object} e    - refers to the element that event up have happened
         *
         * _debounce will limit the ripple function will fire
         */

        (0, _myApp.addListener)(this, 'up', function (e) {
          _this._debounce = _myApp.Debouncer.debounce(_this._debounce, _myApp.timeOut.after(1000), function () {
            return _this.cleanUp();
          });
        });
      }
      /**
       * showRipple gives material design-like ripple effect when buttons are click
       *
       * @param  {Object} e - the button element that the event key down or finger down has happen
       *
       * @return {Object}   - returns the style attribute of the button element with corresponding css styling related to the ripple effect
       */

    }, {
      key: "showRipple",
      value: function showRipple(e) {
        var ripple = document.createElement('span');
        var size = this.offsetWidth;
        var pos = this.getBoundingClientRect(); // for computation of style top and left using Polymer Gesture implementation

        var x = e.detail.x - pos.left - size / 2;
        var y = e.detail.y - pos.top - size / 2;
        var style = 'top:' + y + 'px; left: ' + x + 'px; height: ' + size + 'px; width: ' + size + 'px;';
        var shadow = this.shadowRoot;
        var container = shadow.querySelector('#container');
        container.appendChild(ripple);
        return ripple.setAttribute('style', style);
      }
      /**
       * clean up the container for the ripple effect
       */

    }, {
      key: "cleanUp",
      value: function cleanUp() {
        var shadow = this.shadowRoot;
        var container = shadow.querySelector('#container');

        while (container.firstChild) {
          container.removeChild(container.firstChild);
        }
      }
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject2_f3d168f06e5e11eaa0a2275ae9a33b1d())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-ripple';
      }
    }, {
      key: "properties",
      get: function get() {
        return {};
      }
    }]);
    return MorphRipple;
  }(_myApp.LitElement);

  _exports.MorphRipple = MorphRipple;
  window.customElements.define(MorphRipple.is, MorphRipple);
  var morphRipple = {
    MorphRipple: MorphRipple
  };
  _exports.$morphRipple = morphRipple;

  var MorphButton =
  /*#__PURE__*/
  function (_LitElement2) {
    babelHelpers.inherits(MorphButton, _LitElement2);
    babelHelpers.createClass(MorphButton, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject3_f3d168f06e5e11eaa0a2275ae9a33b1d());
      }
    }], [{
      key: "styles",
      get: function get() {
        return [(0, _myApp.css)(_templateObject4_f3d168f06e5e11eaa0a2275ae9a33b1d())];
      }
    }, {
      key: "is",
      get: function get() {
        return 'morph-button';
      }
    }, {
      key: "properties",
      get: function get() {
        return {
          platform: {
            type: String,
            reflect: true
          },

          /** Common for both platforms */
          big: {
            type: Boolean,
            value: false,
            reflect: true
          },

          /** Common for both platforms */
          filled: {
            type: Boolean,
            value: false,
            reflect: true
          },

          /** Common for both platforms */
          color: {
            type: String,
            reflect: true,
            hasChanged: function hasChanged(value, oldValue) {
              return value !== oldValue;
            }
          },

          /** Common for both platforms */
          link: String,
          target: String,
          relation: String,

          /** iOS specific property */
          active: {
            type: Boolean,
            value: false,
            reflect: true
          },

          /** iOS specific property */
          rounded: {
            type: Boolean,
            value: false,
            reflectToAttribute: true
          },

          /** Android specific property */
          raised: {
            type: Boolean,
            value: false,
            reflectToAttribute: true
          },

          /** Remove round corners */
          flat: {
            type: Boolean,
            value: false,
            reflect: true
          }
        };
      }
    }]);

    function MorphButton() {
      var _this2;

      babelHelpers.classCallCheck(this, MorphButton);
      _this2 = babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(MorphButton).call(this));
      _this2.color = 'blue';
      return _this2;
    }
    /**
     * lit-element lifecycle called once before the first updated().
     */


    babelHelpers.createClass(MorphButton, [{
      key: "firstUpdated",
      value: function firstUpdated() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphButton.prototype), "firstUpdated", this).call(this); // check first if platform assigned in html markup before using getPlatform to auto detect platform

        if (!this.hasAttribute('platform')) {
          this.platform = (0, _myApp.getPlatform)();
        }
      }
    }, {
      key: "updated",
      value: function updated(changedProperties) {
        if (this.color) {
          this.colorAssigned(this.color);
        }
      }
    }, {
      key: "connectedCallback",
      value: function connectedCallback() {
        babelHelpers.get(babelHelpers.getPrototypeOf(MorphButton.prototype), "connectedCallback", this).call(this);
      }
      /**
       * colorAssigned function will fire a console.warn message depending on wether the standard color red gray and green were used
       *
       * @param  {[any]} oldValue old value of color property
       * @param  {any} newValue new value of color property
       *
       * @return {String}          gives a console warn message when shared-colors is not included
       */

    }, {
      key: "colorAssigned",
      value: function colorAssigned(value) {
        var sharedColorsNotConnected = !this.checkIfSharedStylesConnected();

        if (this.checkIfStandardColorUsed(value) && sharedColorsNotConnected) {
          console.warn("WARNING: You need to include morph-shared-colors if you want to use standard colors like ".concat(value, " in the color attribute of morph-button."));
        }
      }
      /**
       * checkIfStandardColorUsed checks if standard colors were used
       *
       * @param  {String} oldValue - old value of the color property from its observer
       *
       * @return {Boolean}          returns true if oldValue is equal to color red, gray or green else returns false
       */

    }, {
      key: "checkIfStandardColorUsed",
      value: function checkIfStandardColorUsed(oldValue) {
        if (oldValue == 'red' || oldValue == 'gray' || oldValue == 'green') {
          return true;
        }

        return false;
      }
      /**
        * checkIfSharedStylesConnected
        *
        * @return {Boolean} - return true if style not equal to 'deepskyblue' meaning shared color file not connected and returns false otherwise
        */

    }, {
      key: "checkIfSharedStylesConnected",
      value: function checkIfSharedStylesConnected() {
        var styleIncludedColor = this.getStyleShadyOrDOM();
        styleIncludedColor = styleIncludedColor.replace(/\s+/, '');

        if (styleIncludedColor != 'deepskyblue') {
          console.warn('WARNING: You need to include morph-shared-colors if you want to use standard colors!');
          return false;
        }

        return true;
      }
      /**
        * @return {Object} - returns the computed style based on if ShadyCSS is used or not 
        */

    }, {
      key: "getStyleShadyOrDOM",
      value: function getStyleShadyOrDOM() {
        if (typeof ShadyCSS != 'undefined') {
          return ShadyCSS.getComputedStyleValue(this, '--have-access-to-shared-colors');
        } else {
          return getComputedStyle(this).getPropertyValue('--have-access-to-shared-colors');
        }
      }
    }]);
    return MorphButton;
  }(_myApp.LitElement);

  window.customElements.define(MorphButton.is, MorphButton);

  var HomePage =
  /*#__PURE__*/
  function (_connect) {
    babelHelpers.inherits(HomePage, _connect);

    function HomePage() {
      babelHelpers.classCallCheck(this, HomePage);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(HomePage).apply(this, arguments));
    }

    babelHelpers.createClass(HomePage, [{
      key: "updated",
      value: function updated(changedProperties) {
        if (changedProperties.has('_language')) {
          (0, _myApp.use)(this._language);
        }
      }
    }, {
      key: "connectedCallback",
      value: function () {
        var _connectedCallback = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee() {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  (0, _myApp.registerTranslateConfig)({
                    loader: function loader(lang) {
                      return Promise.resolve(_myApp.$language[lang]);
                    }
                  });
                  babelHelpers.get(babelHelpers.getPrototypeOf(HomePage.prototype), "connectedCallback", this).call(this);

                case 2:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function connectedCallback() {
          return _connectedCallback.apply(this, arguments);
        }

        return connectedCallback;
      }()
    }, {
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject5_f3d168f06e5e11eaa0a2275ae9a33b1d(), _myApp.caseModule, this._usbConnected ? _myApp.connectedSymbol : _myApp.disconnectedSymbol, (0, _myApp.translate)('home-page.connect-instructions'), this.connectButtonClickHandler, this._usbConnected ? (0, _myApp.translate)('home-page.disconnect') : (0, _myApp.translate)('home-page.connect'));
      }
    }, {
      key: "connectButtonClickHandler",
      value: function () {
        var _connectButtonClickHandler = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee2() {
          return regeneratorRuntime.wrap(function _callee2$(_context2) {
            while (1) {
              switch (_context2.prev = _context2.next) {
                case 0:
                  _context2.t0 = _myApp.store;
                  _context2.next = 3;
                  return (0, _myApp.toggleUsbConnection)();

                case 3:
                  _context2.t1 = _context2.sent;

                  _context2.t0.dispatch.call(_context2.t0, _context2.t1);

                case 5:
                case "end":
                  return _context2.stop();
              }
            }
          }, _callee2);
        }));

        function connectButtonClickHandler() {
          return _connectButtonClickHandler.apply(this, arguments);
        }

        return connectButtonClickHandler;
      }()
    }, {
      key: "stateChanged",
      value: function stateChanged(state) {
        this._page = state.app.page;
        this._language = state.app.language;
        this._usbConnected = state.app.usbConnected;
      }
    }], [{
      key: "properties",
      get: function get() {
        return {
          _page: {
            type: String
          },
          _language: {
            type: String
          },
          _usbConnected: {
            type: Boolean
          }
        };
      }
    }, {
      key: "styles",
      get: function get() {
        return [// SharedStyles,
        _myApp.PageStyles, (0, _myApp.css)(_templateObject6_f3d168f06e5e11eaa0a2275ae9a33b1d())];
      }
    }]);
    return HomePage;
  }((0, _myApp.connect)(_myApp.store)(_myApp.PageViewElement));

  window.customElements.define('home-page', HomePage);
});