define(["./my-app.js"], function (_myApp) {
  "use strict";

  function _templateObject2_66234da06ebf11eaabf9559a5f5bc1ca() {
    var data = babelHelpers.taggedTemplateLiteral(["\n        h2 {\n\t\t\t\t\tcolor: red;\n        }\n      "]);

    _templateObject2_66234da06ebf11eaabf9559a5f5bc1ca = function _templateObject2_66234da06ebf11eaabf9559a5f5bc1ca() {
      return data;
    };

    return data;
  }

  function _templateObject_66234da06ebf11eaabf9559a5f5bc1ca() {
    var data = babelHelpers.taggedTemplateLiteral(["\n      <section>\n\t\t\t\t<h2>", "</h2>\n      </section>\n    "]);

    _templateObject_66234da06ebf11eaabf9559a5f5bc1ca = function _templateObject_66234da06ebf11eaabf9559a5f5bc1ca() {
      return data;
    };

    return data;
  }

  var PageOne =
  /*#__PURE__*/
  function (_connect) {
    babelHelpers.inherits(PageOne, _connect);

    function PageOne() {
      babelHelpers.classCallCheck(this, PageOne);
      return babelHelpers.possibleConstructorReturn(this, babelHelpers.getPrototypeOf(PageOne).apply(this, arguments));
    }

    babelHelpers.createClass(PageOne, [{
      key: "render",
      value: function render() {
        return (0, _myApp.html)(_templateObject_66234da06ebf11eaabf9559a5f5bc1ca(), (0, _myApp.get)('page-one.title'));
      }
    }, {
      key: "updated",
      value: function updated(changedProperties) {
        if (changedProperties.has('_language')) {
          (0, _myApp.use)(this._language);
        }
      }
    }, {
      key: "connectedCallback",
      value: function () {
        var _connectedCallback = babelHelpers.asyncToGenerator(
        /*#__PURE__*/
        regeneratorRuntime.mark(function _callee() {
          return regeneratorRuntime.wrap(function _callee$(_context) {
            while (1) {
              switch (_context.prev = _context.next) {
                case 0:
                  (0, _myApp.registerTranslateConfig)({
                    loader: function loader(lang) {
                      return Promise.resolve(_myApp.$language[lang]);
                    }
                  });
                  babelHelpers.get(babelHelpers.getPrototypeOf(PageOne.prototype), "connectedCallback", this).call(this);

                case 2:
                case "end":
                  return _context.stop();
              }
            }
          }, _callee, this);
        }));

        function connectedCallback() {
          return _connectedCallback.apply(this, arguments);
        }

        return connectedCallback;
      }()
    }, {
      key: "stateChanged",
      value: function stateChanged(state) {
        this._page = state.app.page;
        this._language = state.app.language;
      }
    }], [{
      key: "properties",
      get: function get() {
        return {
          _page: {
            type: String
          },
          _language: {
            type: String
          }
        };
      }
    }, {
      key: "styles",
      get: function get() {
        return [_myApp.SharedStyles, (0, _myApp.css)(_templateObject2_66234da06ebf11eaabf9559a5f5bc1ca())];
      }
    }]);
    return PageOne;
  }((0, _myApp.connect)(_myApp.store)(_myApp.PageViewElement));

  window.customElements.define('page-one', PageOne);
});