var levels = [
  {name : 'none', title : 'None', src: 'img/none.svg', color: '#48C3FA'},
  {name : 'average', title : 'Average', src: 'img/average.svg', color: '#42A9D6'},
  {name : 'average', title : 'Average', src: 'img/average.svg', color: '#42A9D6'},
  {name : 'bad', title : 'Bad', src: 'img/bad.svg', color: '#316F8B'},
];
