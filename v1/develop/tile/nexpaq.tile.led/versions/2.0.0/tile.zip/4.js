(window.webpackJsonp=window.webpackJsonp||[]).push([[4],{40:function(t,e,a){"use strict";a.d(e,"a",(function(){return s}));var o=a(0);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class s extends o.a{shouldUpdate(){return this.active}static get properties(){return{active:{type:Boolean}}}}},42:function(t,e,a){"use strict";a.r(e);var o=a(0),s=a(40),l=a(4),c=a(15),r=a(20),n=a(8),i=(a(21),a(29),a(10)),p=a(22),h=a(41),d=a(30),u=a(2);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
class b extends(Object(r.a)(c.a)(s.a)){render(){return o.c`
		<div style="background-color: ${this._currentUiColor}" id="wrapper" class="wrapper" data-color="${this._currentUiColorName}">
			<div class="page page__controls ">
        <div class="simple-controls ">
          <div class="color-control">
            <button style="background-color: rgb(238, 54, 54);" @click="${()=>c.a.dispatch(Object(l.m)(d.a.red))}"></button>
            <button style="background-color: rgb(1, 207, 88);" @click="${()=>c.a.dispatch(Object(l.m)(d.a.green))}"></button>
            <button style="background-color: rgb(17, 169, 255);" @click="${()=>c.a.dispatch(Object(l.m)(d.a.blue))}"></button>
            <button style="background-color: rgb(252, 187, 64);" @click="${()=>c.a.dispatch(Object(l.m)(d.a.yellow))}"></button>
            <button style="background-color: rgb(255, 255, 255);" @click="${()=>c.a.dispatch(Object(l.m)(d.a.white))}"></button>
          </div>
        </div> <!-- /.simple-controls -->
        <div class="shared-controls">
					<button class="led-button ${this._mainLightState===u.a.On?"active":""}" id="power-button" @click="${()=>this._powerButtonClickHandler()}">
						<svg width="128px" height="128px" viewBox="0 0 128 128" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
							<g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
									<g transform="translate(-116.000000, -256.000000)">
											<g transform="translate(116.000000, 256.000000)">
													<circle stroke="#000000" stroke-width="5" cx="64" cy="64" r="61.5" class="button-circle"></circle>
													<path d="M79.5,45.75 C85.166695,50.5833575 88,56.66663 88,64 C88,70.6667 85.66669,76.33331 81,81 C76.33331,85.66669 70.6667,88 64,88 C57.3333,88 51.66669,85.66669 47,81 C42.33331,76.33331 40,70.6667 40,64 C40,56.66663 42.833305,50.5833575 48.5,45.75 L52.25,49.5 C47.6666437,53.2500187 45.375,58.0833037 45.375,64 C45.375,69.1666925 47.1874819,73.5624819 50.8125,77.1875 C54.4375181,80.8125181 58.8333075,82.625 64,82.625 C69.1666925,82.625 73.5624819,80.8125181 77.1875,77.1875 C80.8125181,73.5624819 82.625,69.1666925 82.625,64 C82.625,58.0833037 80.3333563,53.291685 75.75,49.625 L79.5,45.75 Z M66.625,40 L66.625,66.625 L61.375,66.625 L61.375,40 L66.625,40 Z" fill="#000000" class="button-path"></path>
											</g>
									</g>
							</g>
						</svg>
					</button>
          <div class="flashcontrol">
            <button class="flashcontrol__flashbutton ${this._leftFlashState===u.a.On?"flashcontrol__flashbutton--active":""}"
										@click="${()=>c.a.dispatch(Object(l.v)())}"></button>
            <div class="onoffswitch">
							<input type="checkbox" class="checkbox"
										 ?checked="${this._lockState===u.a.On}"
										 @click="${()=>c.a.dispatch(Object(l.w)())}" id="myonoffswitch1">
              <label class="switch-label" for="myonoffswitch1"></label>
            </div>
            <button class="flashcontrol__flashbutton ${this._rightFlashState===u.a.On?"flashcontrol__flashbutton--active":""}"
										@click="${()=>c.a.dispatch(Object(l.y)())}"></button>
          </div>
        </div> <!-- /.shared-controls -->
      </div> <!-- /.page__controls -->
		</div>
    `}static get properties(){return{_page:{type:String},_language:{type:String},_currentUiColor:{type:String},_currentUiColorName:{type:String},_mainLightState:{type:Boolean},_lockState:{type:Boolean},_rightFlashState:{type:Boolean},_leftFlashState:{type:Boolean}}}static get styles(){return[n.m,n.d,n.e,n.g,n.h,n.i,n.a,n.b,n.c,n.f,n.j,n.k,n.l,n.n,o.b`
      #wrapper {
        top: -55px;
        height: calc(100% + 55px);
      }`]}firstUpdated(){super.firstUpdated(),Object(h.a)(this.shadowRoot.getElementById("power-button"),"down",t=>this._powerButtonPressedHandler(t)),Object(h.a)(this.shadowRoot.getElementById("power-button"),"up",t=>this._powerButtonReleasedHandler(t))}updated(t){t.has("_language")&&Object(i.d)(this._language)}async connectedCallback(){Object(i.b)({loader:t=>Promise.resolve(p[t])}),super.connectedCallback()}_powerButtonClickHandler(){this._lockState===u.a.On&&c.a.dispatch(Object(l.x)())}_powerButtonPressedHandler(t){this._lockState===u.a.Off&&c.a.dispatch(Object(l.u)())}_powerButtonReleasedHandler(t){this._lockState===u.a.Off&&c.a.dispatch(Object(l.t)())}stateChanged(t){this._page=t.app.page,this._language=t.app.language,this._currentUiColor=t.app.currentUiColor,this._currentUiColorName=t.app.currentUiColorName,this._mainLightState=t.app.ledsState,this._lockState=t.app.lockState,this._leftFlashState=t.app.flashLedLeftState,this._rightFlashState=t.app.flashLedRightState}}window.customElements.define("pallet-page",b)}}]);