!function(t){function e(e){for(var r,o,i=e[0],a=e[1],s=0,c=[];s<i.length;s++)o=i[s],Object.prototype.hasOwnProperty.call(n,o)&&n[o]&&c.push(n[o][0]),n[o]=0;for(r in a)Object.prototype.hasOwnProperty.call(a,r)&&(t[r]=a[r]);for(l&&l(e);c.length;)c.shift()()}var r={},n={1:0};function o(e){if(r[e])return r[e].exports;var n=r[e]={i:e,l:!1,exports:{}};return t[e].call(n.exports,n,n.exports,o),n.l=!0,n.exports}o.e=function(t){var e=[],r=n[t];if(0!==r)if(r)e.push(r[2]);else{var i=new Promise((function(e,o){r=n[t]=[e,o]}));e.push(r[2]=i);var a,s=document.createElement("script");s.charset="utf-8",s.timeout=120,o.nc&&s.setAttribute("nonce",o.nc),s.src=function(t){return o.p+""+({}[t]||t)+".js"}(t);var l=new Error;a=function(e){s.onerror=s.onload=null,clearTimeout(c);var r=n[t];if(0!==r){if(r){var o=e&&("load"===e.type?"missing":e.type),i=e&&e.target&&e.target.src;l.message="Loading chunk "+t+" failed.\n("+o+": "+i+")",l.name="ChunkLoadError",l.type=o,l.request=i,r[1](l)}n[t]=void 0}};var c=setTimeout((function(){a({type:"timeout",target:s})}),12e4);s.onerror=s.onload=a,document.head.appendChild(s)}return Promise.all(e)},o.m=t,o.c=r,o.d=function(t,e,r){o.o(t,e)||Object.defineProperty(t,e,{enumerable:!0,get:r})},o.r=function(t){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(t,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(t,"__esModule",{value:!0})},o.t=function(t,e){if(1&e&&(t=o(t)),8&e)return t;if(4&e&&"object"==typeof t&&t&&t.__esModule)return t;var r=Object.create(null);if(o.r(r),Object.defineProperty(r,"default",{enumerable:!0,value:t}),2&e&&"string"!=typeof t)for(var n in t)o.d(r,n,function(e){return t[e]}.bind(null,n));return r},o.n=function(t){var e=t&&t.__esModule?function(){return t.default}:function(){return t};return o.d(e,"a",e),e},o.o=function(t,e){return Object.prototype.hasOwnProperty.call(t,e)},o.p="",o.oe=function(t){throw console.error(t),t};var i=window.webpackJsonp=window.webpackJsonp||[],a=i.push.bind(i);i.push=e,i=i.slice();for(var s=0;s<i.length;s++)e(i[s]);var l=a;o(o.s=39)}([function(t,e,r){"use strict";var n=r(7),o=r(9),i=r(1);function a(t,e){const{element:{content:r},parts:n}=t,o=document.createTreeWalker(r,133,null,!1);let i=l(n),a=n[i],s=-1,c=0;const u=[];let h=null;for(;o.nextNode();){s++;const t=o.currentNode;for(t.previousSibling===h&&(h=null),e.has(t)&&(u.push(t),null===h&&(h=t)),null!==h&&c++;void 0!==a&&a.index===s;)a.index=null!==h?-1:a.index-c,i=l(n,i),a=n[i]}u.forEach(t=>t.parentNode.removeChild(t))}const s=t=>{let e=11===t.nodeType?0:1;const r=document.createTreeWalker(t,133,null,!1);for(;r.nextNode();)e++;return e},l=(t,e=-1)=>{for(let r=e+1;r<t.length;r++){const e=t[r];if(Object(i.d)(e))return r}return-1};var c=r(13),u=r(11),h=r(16);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const d=(t,e)=>`${t}--${e}`;let p=!0;void 0===window.ShadyCSS?p=!1:void 0===window.ShadyCSS.prepareTemplateDom&&(console.warn("Incompatible ShadyCSS version detected. Please update to at least @webcomponents/webcomponentsjs@2.0.2 and @webcomponents/shadycss@1.3.1."),p=!1);const f=t=>e=>{const r=d(e.type,t);let n=u.a.get(r);void 0===n&&(n={stringsArray:new WeakMap,keyString:new Map},u.a.set(r,n));let o=n.stringsArray.get(e.strings);if(void 0!==o)return o;const a=e.strings.join(i.f);if(o=n.keyString.get(a),void 0===o){const r=e.getTemplateElement();p&&window.ShadyCSS.prepareTemplateDom(r,t),o=new i.a(e,r),n.keyString.set(a,o)}return n.stringsArray.set(e.strings,o),o},g=["html","svg"],m=new Set,b=(t,e,r)=>{m.add(t);const n=r?r.element:document.createElement("template"),o=e.querySelectorAll("style"),{length:i}=o;if(0===i)return void window.ShadyCSS.prepareTemplateStyles(n,t);const c=document.createElement("style");for(let t=0;t<i;t++){const e=o[t];e.parentNode.removeChild(e),c.textContent+=e.textContent}(t=>{g.forEach(e=>{const r=u.a.get(d(e,t));void 0!==r&&r.keyString.forEach(t=>{const{element:{content:e}}=t,r=new Set;Array.from(e.querySelectorAll("style")).forEach(t=>{r.add(t)}),a(t,r)})})})(t);const h=n.content;r?function(t,e,r=null){const{element:{content:n},parts:o}=t;if(null==r)return void n.appendChild(e);const i=document.createTreeWalker(n,133,null,!1);let a=l(o),c=0,u=-1;for(;i.nextNode();){for(u++,i.currentNode===r&&(c=s(e),r.parentNode.insertBefore(e,r));-1!==a&&o[a].index===u;){if(c>0){for(;-1!==a;)o[a].index+=c,a=l(o,a);return}a=l(o,a)}}}(r,c,h.firstChild):h.insertBefore(c,h.firstChild),window.ShadyCSS.prepareTemplateStyles(n,t);const p=h.querySelector("style");if(window.ShadyCSS.nativeShadow&&null!==p)e.insertBefore(p.cloneNode(!0),e.firstChild);else if(r){h.insertBefore(c,h.firstChild);const t=new Set;t.add(c),a(r,t)}};window.JSCompiler_renameProperty=(t,e)=>t;const v={toAttribute(t,e){switch(e){case Boolean:return t?"":null;case Object:case Array:return null==t?t:JSON.stringify(t)}return t},fromAttribute(t,e){switch(e){case Boolean:return null!==t;case Number:return null===t?null:Number(t);case Object:case Array:return JSON.parse(t)}return t}},w=(t,e)=>e!==t&&(e==e||t==t),y={attribute:!0,type:String,converter:v,reflect:!1,hasChanged:w},_=Promise.resolve(!0);class x extends HTMLElement{constructor(){super(),this._updateState=0,this._instanceProperties=void 0,this._updatePromise=_,this._hasConnectedResolver=void 0,this._changedProperties=new Map,this._reflectingProperties=void 0,this.initialize()}static get observedAttributes(){this.finalize();const t=[];return this._classProperties.forEach((e,r)=>{const n=this._attributeNameForProperty(r,e);void 0!==n&&(this._attributeToPropertyMap.set(n,r),t.push(n))}),t}static _ensureClassProperties(){if(!this.hasOwnProperty(JSCompiler_renameProperty("_classProperties",this))){this._classProperties=new Map;const t=Object.getPrototypeOf(this)._classProperties;void 0!==t&&t.forEach((t,e)=>this._classProperties.set(e,t))}}static createProperty(t,e=y){if(this._ensureClassProperties(),this._classProperties.set(t,e),e.noAccessor||this.prototype.hasOwnProperty(t))return;const r="symbol"==typeof t?Symbol():`__${t}`;Object.defineProperty(this.prototype,t,{get(){return this[r]},set(e){const n=this[t];this[r]=e,this._requestUpdate(t,n)},configurable:!0,enumerable:!0})}static finalize(){const t=Object.getPrototypeOf(this);if(t.hasOwnProperty("finalized")||t.finalize(),this.finalized=!0,this._ensureClassProperties(),this._attributeToPropertyMap=new Map,this.hasOwnProperty(JSCompiler_renameProperty("properties",this))){const t=this.properties,e=[...Object.getOwnPropertyNames(t),..."function"==typeof Object.getOwnPropertySymbols?Object.getOwnPropertySymbols(t):[]];for(const r of e)this.createProperty(r,t[r])}}static _attributeNameForProperty(t,e){const r=e.attribute;return!1===r?void 0:"string"==typeof r?r:"string"==typeof t?t.toLowerCase():void 0}static _valueHasChanged(t,e,r=w){return r(t,e)}static _propertyValueFromAttribute(t,e){const r=e.type,n=e.converter||v,o="function"==typeof n?n:n.fromAttribute;return o?o(t,r):t}static _propertyValueToAttribute(t,e){if(void 0===e.reflect)return;const r=e.type,n=e.converter;return(n&&n.toAttribute||v.toAttribute)(t,r)}initialize(){this._saveInstanceProperties(),this._requestUpdate()}_saveInstanceProperties(){this.constructor._classProperties.forEach((t,e)=>{if(this.hasOwnProperty(e)){const t=this[e];delete this[e],this._instanceProperties||(this._instanceProperties=new Map),this._instanceProperties.set(e,t)}})}_applyInstanceProperties(){this._instanceProperties.forEach((t,e)=>this[e]=t),this._instanceProperties=void 0}connectedCallback(){this._updateState=32|this._updateState,this._hasConnectedResolver&&(this._hasConnectedResolver(),this._hasConnectedResolver=void 0)}disconnectedCallback(){}attributeChangedCallback(t,e,r){e!==r&&this._attributeToProperty(t,r)}_propertyToAttribute(t,e,r=y){const n=this.constructor,o=n._attributeNameForProperty(t,r);if(void 0!==o){const t=n._propertyValueToAttribute(e,r);if(void 0===t)return;this._updateState=8|this._updateState,null==t?this.removeAttribute(o):this.setAttribute(o,t),this._updateState=-9&this._updateState}}_attributeToProperty(t,e){if(8&this._updateState)return;const r=this.constructor,n=r._attributeToPropertyMap.get(t);if(void 0!==n){const t=r._classProperties.get(n)||y;this._updateState=16|this._updateState,this[n]=r._propertyValueFromAttribute(e,t),this._updateState=-17&this._updateState}}_requestUpdate(t,e){let r=!0;if(void 0!==t){const n=this.constructor,o=n._classProperties.get(t)||y;n._valueHasChanged(this[t],e,o.hasChanged)?(this._changedProperties.has(t)||this._changedProperties.set(t,e),!0!==o.reflect||16&this._updateState||(void 0===this._reflectingProperties&&(this._reflectingProperties=new Map),this._reflectingProperties.set(t,o))):r=!1}!this._hasRequestedUpdate&&r&&this._enqueueUpdate()}requestUpdate(t,e){return this._requestUpdate(t,e),this.updateComplete}async _enqueueUpdate(){let t,e;this._updateState=4|this._updateState;const r=this._updatePromise;this._updatePromise=new Promise((r,n)=>{t=r,e=n});try{await r}catch(t){}this._hasConnected||await new Promise(t=>this._hasConnectedResolver=t);try{const t=this.performUpdate();null!=t&&await t}catch(t){e(t)}t(!this._hasRequestedUpdate)}get _hasConnected(){return 32&this._updateState}get _hasRequestedUpdate(){return 4&this._updateState}get hasUpdated(){return 1&this._updateState}performUpdate(){this._instanceProperties&&this._applyInstanceProperties();let t=!1;const e=this._changedProperties;try{t=this.shouldUpdate(e),t&&this.update(e)}catch(e){throw t=!1,e}finally{this._markUpdated()}t&&(1&this._updateState||(this._updateState=1|this._updateState,this.firstUpdated(e)),this.updated(e))}_markUpdated(){this._changedProperties=new Map,this._updateState=-5&this._updateState}get updateComplete(){return this._getUpdateComplete()}_getUpdateComplete(){return this._updatePromise}shouldUpdate(t){return!0}update(t){void 0!==this._reflectingProperties&&this._reflectingProperties.size>0&&(this._reflectingProperties.forEach((t,e)=>this._propertyToAttribute(e,this[e],t)),this._reflectingProperties=void 0)}updated(t){}firstUpdated(t){}}x.finalized=!0;const k="adoptedStyleSheets"in Document.prototype&&"replace"in CSSStyleSheet.prototype,S=Symbol();class C{constructor(t,e){if(e!==S)throw new Error("CSSResult is not constructable. Use `unsafeCSS` or `css` instead.");this.cssText=t}get styleSheet(){return void 0===this._styleSheet&&(k?(this._styleSheet=new CSSStyleSheet,this._styleSheet.replaceSync(this.cssText)):this._styleSheet=null),this._styleSheet}toString(){return this.cssText}}const E=(t,...e)=>{const r=e.reduce((e,r,n)=>e+(t=>{if(t instanceof C)return t.cssText;if("number"==typeof t)return t;throw new Error(`Value passed to 'css' function must be a 'css' function result: ${t}. Use 'unsafeCSS' to pass non-literal values, but\n            take care to ensure page security.`)})(r)+t[n+1],t[0]);return new C(r,S)};r.d(e,"a",(function(){return M})),r.d(e,"c",(function(){return n.e})),r.d(e,"b",(function(){return E})),
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
(window.litElementVersions||(window.litElementVersions=[])).push("2.2.1");const O=t=>t.flat?t.flat(1/0):function t(e,r=[]){for(let n=0,o=e.length;n<o;n++){const o=e[n];Array.isArray(o)?t(o,r):r.push(o)}return r}(t);class M extends x{static finalize(){super.finalize.call(this),this._styles=this.hasOwnProperty(JSCompiler_renameProperty("styles",this))?this._getUniqueStyles():this._styles||[]}static _getUniqueStyles(){const t=this.styles,e=[];if(Array.isArray(t)){O(t).reduceRight((t,e)=>(t.add(e),t),new Set).forEach(t=>e.unshift(t))}else t&&e.push(t);return e}initialize(){super.initialize(),this.renderRoot=this.createRenderRoot(),window.ShadowRoot&&this.renderRoot instanceof window.ShadowRoot&&this.adoptStyles()}createRenderRoot(){return this.attachShadow({mode:"open"})}adoptStyles(){const t=this.constructor._styles;0!==t.length&&(void 0===window.ShadyCSS||window.ShadyCSS.nativeShadow?k?this.renderRoot.adoptedStyleSheets=t.map(t=>t.styleSheet):this._needsShimAdoptedStyleSheets=!0:window.ShadyCSS.ScopingShim.prepareAdoptedCssText(t.map(t=>t.cssText),this.localName))}connectedCallback(){super.connectedCallback(),this.hasUpdated&&void 0!==window.ShadyCSS&&window.ShadyCSS.styleElement(this)}update(t){super.update(t);const e=this.render();e instanceof n.c&&this.constructor.render(e,this.renderRoot,{scopeName:this.localName,eventContext:this}),this._needsShimAdoptedStyleSheets&&(this._needsShimAdoptedStyleSheets=!1,this.constructor._styles.forEach(t=>{const e=document.createElement("style");e.textContent=t.cssText,this.renderRoot.appendChild(e)}))}render(){}}M.finalized=!0,M.render=(t,e,r)=>{if(!r||"object"!=typeof r||!r.scopeName)throw new Error("The `scopeName` option is required.");const n=r.scopeName,i=c.a.has(e),a=p&&11===e.nodeType&&!!e.host,s=a&&!m.has(n),l=s?document.createDocumentFragment():e;if(Object(c.b)(t,l,Object.assign({templateFactory:f(n)},r)),s){const t=c.a.get(l);c.a.delete(l);const r=t.value instanceof h.a?t.value.template:void 0;b(n,l,r),Object(o.b)(e,e.firstChild),e.appendChild(l),c.a.set(e,t)}!i&&a&&window.ShadyCSS.styleElement(e.host)}},function(t,e,r){"use strict";r.d(e,"f",(function(){return n})),r.d(e,"g",(function(){return o})),r.d(e,"b",(function(){return a})),r.d(e,"a",(function(){return s})),r.d(e,"d",(function(){return c})),r.d(e,"c",(function(){return u})),r.d(e,"e",(function(){return h}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const n=`{{lit-${String(Math.random()).slice(2)}}}`,o=`\x3c!--${n}--\x3e`,i=new RegExp(`${n}|${o}`),a="$lit$";class s{constructor(t,e){this.parts=[],this.element=e;const r=[],o=[],s=document.createTreeWalker(e.content,133,null,!1);let c=0,d=-1,p=0;const{strings:f,values:{length:g}}=t;for(;p<g;){const t=s.nextNode();if(null!==t){if(d++,1===t.nodeType){if(t.hasAttributes()){const e=t.attributes,{length:r}=e;let n=0;for(let t=0;t<r;t++)l(e[t].name,a)&&n++;for(;n-- >0;){const e=f[p],r=h.exec(e)[2],n=r.toLowerCase()+a,o=t.getAttribute(n);t.removeAttribute(n);const s=o.split(i);this.parts.push({type:"attribute",index:d,name:r,strings:s}),p+=s.length-1}}"TEMPLATE"===t.tagName&&(o.push(t),s.currentNode=t.content)}else if(3===t.nodeType){const e=t.data;if(e.indexOf(n)>=0){const n=t.parentNode,o=e.split(i),s=o.length-1;for(let e=0;e<s;e++){let r,i=o[e];if(""===i)r=u();else{const t=h.exec(i);null!==t&&l(t[2],a)&&(i=i.slice(0,t.index)+t[1]+t[2].slice(0,-a.length)+t[3]),r=document.createTextNode(i)}n.insertBefore(r,t),this.parts.push({type:"node",index:++d})}""===o[s]?(n.insertBefore(u(),t),r.push(t)):t.data=o[s],p+=s}}else if(8===t.nodeType)if(t.data===n){const e=t.parentNode;null!==t.previousSibling&&d!==c||(d++,e.insertBefore(u(),t)),c=d,this.parts.push({type:"node",index:d}),null===t.nextSibling?t.data="":(r.push(t),d--),p++}else{let e=-1;for(;-1!==(e=t.data.indexOf(n,e+1));)this.parts.push({type:"node",index:-1}),p++}}else s.currentNode=o.pop()}for(const t of r)t.parentNode.removeChild(t)}}const l=(t,e)=>{const r=t.length-e.length;return r>=0&&t.slice(r)===e},c=t=>-1!==t.index,u=()=>document.createComment(""),h=/([ \x09\x0a\x0c\x0d])([^\0-\x1F\x7F-\x9F "'>=/]+)([ \x09\x0a\x0c\x0d]*=[ \x09\x0a\x0c\x0d]*(?:[^ \x09\x0a\x0c\x0d"'`<>=]*|"[^"]*|'[^']*))$/},function(t,e,r){"use strict";const n=Object.freeze({On:!0,Off:!1});e.a=n},function(t,e,r){"use strict";var n=r(33),o=r(36),i=[].slice,a=["keyword","gray","hex"],s={};Object.keys(o).forEach((function(t){s[i.call(o[t].labels).sort().join("")]=t}));var l={};function c(t,e){if(!(this instanceof c))return new c(t,e);if(e&&e in a&&(e=null),e&&!(e in o))throw new Error("Unknown model: "+e);var r,u;if(null==t)this.model="rgb",this.color=[0,0,0],this.valpha=1;else if(t instanceof c)this.model=t.model,this.color=t.color.slice(),this.valpha=t.valpha;else if("string"==typeof t){var h=n.get(t);if(null===h)throw new Error("Unable to parse color from string: "+t);this.model=h.model,u=o[this.model].channels,this.color=h.value.slice(0,u),this.valpha="number"==typeof h.value[u]?h.value[u]:1}else if(t.length){this.model=e||"rgb",u=o[this.model].channels;var d=i.call(t,0,u);this.color=p(d,u),this.valpha="number"==typeof t[u]?t[u]:1}else if("number"==typeof t)t&=16777215,this.model="rgb",this.color=[t>>16&255,t>>8&255,255&t],this.valpha=1;else{this.valpha=1;var f=Object.keys(t);"alpha"in t&&(f.splice(f.indexOf("alpha"),1),this.valpha="number"==typeof t.alpha?t.alpha:0);var g=f.sort().join("");if(!(g in s))throw new Error("Unable to parse color from object: "+JSON.stringify(t));this.model=s[g];var m=o[this.model].labels,b=[];for(r=0;r<m.length;r++)b.push(t[m[r]]);this.color=p(b)}if(l[this.model])for(u=o[this.model].channels,r=0;r<u;r++){var v=l[this.model][r];v&&(this.color[r]=v(this.color[r]))}this.valpha=Math.max(0,Math.min(1,this.valpha)),Object.freeze&&Object.freeze(this)}function u(t,e,r){return(t=Array.isArray(t)?t:[t]).forEach((function(t){(l[t]||(l[t]=[]))[e]=r})),t=t[0],function(n){var o;return arguments.length?(r&&(n=r(n)),(o=this[t]()).color[e]=n,o):(o=this[t]().color[e],r&&(o=r(o)),o)}}function h(t){return function(e){return Math.max(0,Math.min(t,e))}}function d(t){return Array.isArray(t)?t:[t]}function p(t,e){for(var r=0;r<e;r++)"number"!=typeof t[r]&&(t[r]=0);return t}c.prototype={toString:function(){return this.string()},toJSON:function(){return this[this.model]()},string:function(t){var e=this.model in n.to?this:this.rgb(),r=1===(e=e.round("number"==typeof t?t:1)).valpha?e.color:e.color.concat(this.valpha);return n.to[e.model](r)},percentString:function(t){var e=this.rgb().round("number"==typeof t?t:1),r=1===e.valpha?e.color:e.color.concat(this.valpha);return n.to.rgb.percent(r)},array:function(){return 1===this.valpha?this.color.slice():this.color.concat(this.valpha)},object:function(){for(var t={},e=o[this.model].channels,r=o[this.model].labels,n=0;n<e;n++)t[r[n]]=this.color[n];return 1!==this.valpha&&(t.alpha=this.valpha),t},unitArray:function(){var t=this.rgb().color;return t[0]/=255,t[1]/=255,t[2]/=255,1!==this.valpha&&t.push(this.valpha),t},unitObject:function(){var t=this.rgb().object();return t.r/=255,t.g/=255,t.b/=255,1!==this.valpha&&(t.alpha=this.valpha),t},round:function(t){return t=Math.max(t||0,0),new c(this.color.map(function(t){return function(e){return function(t,e){return Number(t.toFixed(e))}(e,t)}}(t)).concat(this.valpha),this.model)},alpha:function(t){return arguments.length?new c(this.color.concat(Math.max(0,Math.min(1,t))),this.model):this.valpha},red:u("rgb",0,h(255)),green:u("rgb",1,h(255)),blue:u("rgb",2,h(255)),hue:u(["hsl","hsv","hsl","hwb","hcg"],0,(function(t){return(t%360+360)%360})),saturationl:u("hsl",1,h(100)),lightness:u("hsl",2,h(100)),saturationv:u("hsv",1,h(100)),value:u("hsv",2,h(100)),chroma:u("hcg",1,h(100)),gray:u("hcg",2,h(100)),white:u("hwb",1,h(100)),wblack:u("hwb",2,h(100)),cyan:u("cmyk",0,h(100)),magenta:u("cmyk",1,h(100)),yellow:u("cmyk",2,h(100)),black:u("cmyk",3,h(100)),x:u("xyz",0,h(100)),y:u("xyz",1,h(100)),z:u("xyz",2,h(100)),l:u("lab",0,h(100)),a:u("lab",1),b:u("lab",2),keyword:function(t){return arguments.length?new c(t):o[this.model].keyword(this.color)},hex:function(t){return arguments.length?new c(t):n.to.hex(this.rgb().round().color)},rgbNumber:function(){var t=this.rgb().color;return(255&t[0])<<16|(255&t[1])<<8|255&t[2]},luminosity:function(){for(var t=this.rgb().color,e=[],r=0;r<t.length;r++){var n=t[r]/255;e[r]=n<=.03928?n/12.92:Math.pow((n+.055)/1.055,2.4)}return.2126*e[0]+.7152*e[1]+.0722*e[2]},contrast:function(t){var e=this.luminosity(),r=t.luminosity();return e>r?(e+.05)/(r+.05):(r+.05)/(e+.05)},level:function(t){var e=this.contrast(t);return e>=7.1?"AAA":e>=4.5?"AA":""},isDark:function(){var t=this.rgb().color;return(299*t[0]+587*t[1]+114*t[2])/1e3<128},isLight:function(){return!this.isDark()},negate:function(){for(var t=this.rgb(),e=0;e<3;e++)t.color[e]=255-t.color[e];return t},lighten:function(t){var e=this.hsl();return e.color[2]+=e.color[2]*t,e},darken:function(t){var e=this.hsl();return e.color[2]-=e.color[2]*t,e},saturate:function(t){var e=this.hsl();return e.color[1]+=e.color[1]*t,e},desaturate:function(t){var e=this.hsl();return e.color[1]-=e.color[1]*t,e},whiten:function(t){var e=this.hwb();return e.color[1]+=e.color[1]*t,e},blacken:function(t){var e=this.hwb();return e.color[2]+=e.color[2]*t,e},grayscale:function(){var t=this.rgb().color,e=.3*t[0]+.59*t[1]+.11*t[2];return c.rgb(e,e,e)},fade:function(t){return this.alpha(this.valpha-this.valpha*t)},opaquer:function(t){return this.alpha(this.valpha+this.valpha*t)},rotate:function(t){var e=this.hsl(),r=e.color[0];return r=(r=(r+t)%360)<0?360+r:r,e.color[0]=r,e},mix:function(t,e){if(!t||!t.rgb)throw new Error('Argument to "mix" was not a Color instance, but rather an instance of '+typeof t);var r=t.rgb(),n=this.rgb(),o=void 0===e?.5:e,i=2*o-1,a=r.alpha()-n.alpha(),s=((i*a==-1?i:(i+a)/(1+i*a))+1)/2,l=1-s;return c.rgb(s*r.red()+l*n.red(),s*r.green()+l*n.green(),s*r.blue()+l*n.blue(),r.alpha()*o+n.alpha()*(1-o))}},Object.keys(o).forEach((function(t){if(-1===a.indexOf(t)){var e=o[t].channels;c.prototype[t]=function(){if(this.model===t)return new c(this);if(arguments.length)return new c(arguments,t);var r="number"==typeof arguments[e]?e:this.valpha;return new c(d(o[this.model][t].raw(this.color)).concat(r),t)},c[t]=function(r){return"number"==typeof r&&(r=p(i.call(arguments),e)),new c(r,t)}}})),t.exports=c},function(t,e,r){"use strict";var n=r(17);var o=Object.freeze({Brightness:"brightness",Accuracy:"accuracy"});class i{constructor(){this.active=!1,this.period=100,this.colorPriority=o.Accuracy}start(){this.active||(this.active=!0,this._loop())}stop(){this.active=!1}update(){}async _loop(){for(;this.active;)await this.update(),await this._sleep(this.period)}_sleep(t){return new Promise((e,r)=>{setTimeout(()=>e(),t)})}}var a=r(3),s=r.n(a);let l=!1;function c(t,e,r,n){s.a.rgb(e,r,n).lightness()>70?0==l&&(l=!0,console.log("turn on temperature protection"),Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"TurnOnRgbLedTemperatureProtection",[300])):1==l&&(l=!1,console.log("turn off temperature protection"),Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"TurnOffRgbLedTemperatureProtection",[])),null!=t?t.setCommand(()=>Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"SetRGB",[e,r,n])):Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"SetRGB",[e,r,n])}var u=r(2),h=r(10);r.d(e,"d",(function(){return x})),r.d(e,"l",(function(){return k})),r.d(e,"i",(function(){return S})),r.d(e,"f",(function(){return C})),r.d(e,"j",(function(){return E})),r.d(e,"b",(function(){return O})),r.d(e,"a",(function(){return M})),r.d(e,"h",(function(){return P})),r.d(e,"g",(function(){return T})),r.d(e,"c",(function(){return A})),r.d(e,"e",(function(){return j})),r.d(e,"k",(function(){return N})),r.d(e,"r",(function(){return L})),r.d(e,"p",(function(){return R})),r.d(e,"s",(function(){return F})),r.d(e,"q",(function(){return U})),r.d(e,"z",(function(){return $})),r.d(e,"w",(function(){return V})),r.d(e,"x",(function(){return q})),r.d(e,"m",(function(){return G})),r.d(e,"u",(function(){return W})),r.d(e,"t",(function(){return Y})),r.d(e,"y",(function(){return J})),r.d(e,"v",(function(){return X})),r.d(e,"o",(function(){return Z})),r.d(e,"n",(function(){return Q})),r.d(e,"A",(function(){return tt}));
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
const d=new class{constructor(){this.commandSendInterval=100,this.active=!1,this._commandToSend=null}start(){if(this.active)throw new Exception("CommandBufferFilter already running");this.active=!0,this._loop()}stop(){this.active=!1}setCommand(t){this._commandToSend=t}_sleep(t){return new Promise((e,r)=>{setTimeout(()=>e(),t)})}_flush(){if(null==this._commandToSend)return;const t=this._commandToSend;this._commandToSend=null;try{t()}catch(t){console.error(t)}}async _loop(){for(;this.active;)this._flush(),await this._sleep(this.commandSendInterval)}};d.start();const p=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this._commandBufferFilter=t,this._color=[100,90,0]}stop(){super.stop(),c(this._commandBufferFilter,0,0,0)}update(){const t=this._getRandomArbitrary(.7,1.2),e=this._color.map(e=>e*t);c(this._commandBufferFilter,...e)}_getRandomArbitrary(t,e){return Math.random()*(e-t)+t}}(d),f=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this.colorPriority=o.Brightness,this._commandBufferFilter=t,this._period=0,this._redColor=[255,0,0],this._blueColor=[0,0,255],this._colorDuration=400}stop(){super.stop(),this._commandBufferFilter.setCommand(()=>Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetRGB",[0,0,0]))}async update(){this.active&&(await Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetRGB",this._redColor),await this._sleep(128)),this.active&&(await Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetRGB",this._blueColor),await this._sleep(128))}}(d),g=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this._commandBufferFilter=t}stop(){super.stop(),this._commandBufferFilter.setCommand(()=>Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetFlashes",[0,0]))}async update(){await Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetFlashes",[8e3,8e3]),await this._sleep(100),await Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetFlashes",[0,0])}}(d),m=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this._commandBufferFilter=t,this.period=1e3}stop(){super.stop(),this._commandBufferFilter.setCommand(()=>Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetFlashes",[0,0]))}async update(){await this._flash(200),await this._flash(200),await this._flash(200),await this._flash(500),await this._flash(500),await this._flash(500),await this._flash(200),await this._flash(200),await this._flash(200)}async _flash(t){this.active&&(await Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetFlashes",[8e3,8e3]),await this._sleep(t),await Moduware.v0.API.Module.SendCommand(Moduware.Arguments.uuid,"SetFlashes",[0,0]),await this._sleep(t))}}(d),b=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this._commandBufferFilter=t,this._color=s()("red")}stop(){super.stop(),c(this._commandBufferFilter,0,0,0)}async update(){this._color=this._color.rotate(2);const[t,e,r]=[this._color.red(),this._color.green(),this._color.blue()];c(this._commandBufferFilter,t,e,r)}}(d),v=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this.colorPriority=o.Brightness,this._commandBufferFilter=t,this.period=100,this._position=0,this._sequence=this._discoSequence()}stop(){super.stop(),c(this._commandBufferFilter,0,0,0)}async update(){const t=this._sequence[this._position];this._position++,this._position>=this._sequence.length&&(this._position=0),this.period=t.duration;const[e,r,n]=[t.r,t.g,t.b];c(this._commandBufferFilter,e,r,n)}_discoSequence(){return[{r:255,g:50,b:0,duration:100},{r:255,g:0,b:255,duration:100},{r:0,g:250,b:0,duration:1e3},{r:0,g:0,b:0,duration:100},{r:255,g:50,b:0,duration:100},{r:139,g:0,b:0,duration:100},{r:0,g:250,b:0,duration:100},{r:0,g:0,b:0,duration:100},{r:255,g:108,b:180,duration:1e3},{r:139,g:0,b:0,duration:100},{r:20,g:0,b:0,duration:100},{r:0,g:0,b:0,duration:100},{r:50,g:50,b:100,duration:100},{r:10,g:0,b:0,duration:100},{r:150,g:0,b:250,duration:100},{r:0,g:0,b:0,duration:100},{r:0,g:250,b:50,duration:100},{r:1,g:250,b:250,duration:100},{r:100,g:20,b:200,duration:1e3},{r:139,g:250,b:250,duration:100},{r:20,g:0,b:250,duration:1e3},{r:0,g:0,b:0,duration:100},{r:150,g:0,b:250,duration:100},{r:0,g:0,b:0,duration:100},{r:20,g:250,b:20,duration:100},{r:50,g:150,b:250,duration:100},{r:100,g:50,b:200,duration:1e3}]}}(d),w=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this.colorPriority=o.Brightness,this._commandBufferFilter=t,this._color=s.a.rgb(254,1,5),this._hueRange={left:25,right:310},this._lightnessRange={min:40,max:60},this._direction=1,this._speed=.5}stop(){super.stop(),c(this._commandBufferFilter,0,0,0)}async update(){this._color=this._color.rotate(this._speed*this._direction);const t=this._color.hue();t>this._hueRange.left&&t<this._hueRange.right&&(this._direction*=-1);const e=this._getRandomArbitrary(-.5,.5);let r=this._color.lightness();r+=e,r>this._lightnessRange.max&&(r=this._lightnessRange.max),r<this._lightnessRange.min&&(r=this._lightnessRange.min),this._color=this._color.lightness(r);const[n,o,i]=[this._color.red(),this._color.green(),this._color.blue()];c(this._commandBufferFilter,n,o,i)}_getRandomArbitrary(t,e){return Math.random()*(e-t)+t}}(d),y=new class extends i{constructor(t){if(super(),null==t)throw new Exception("Command buffer required for the theme");this._commandBufferFilter=t,this._color=s.a.rgb(1,239,239),this._hueRange={left:35,right:290},this._lightnessRange={min:40,max:60},this._direction=1,this._speed=.5}stop(){super.stop(),c(this._commandBufferFilter,0,0,0)}async update(){this._color=this._color.rotate(this._speed*this._direction);const t=this._color.hue();(t<this._hueRange.left||t>this._hueRange.right)&&(this._direction*=-1);const e=this._getRandomArbitrary(-.5,.5);let r=this._color.lightness();r+=e,r>this._lightnessRange.max&&(r=this._lightnessRange.max),r<this._lightnessRange.min&&(r=this._lightnessRange.min),this._color=this._color.lightness(r);const[n,o,i]=[this._color.red(),this._color.green(),this._color.blue()];c(this._commandBufferFilter,n,o,i)}_getRandomArbitrary(t,e){return Math.random()*(e-t)+t}}(d),_=new class{constructor(){this.themes={},this._currentTheme=null}addTheme(t,e){this.themes[t]=e}play(t){if(void 0===this.themes[t])throw new Exception("Unknown theme name");null!=this._currentTheme&&this._currentTheme.stop(),this._currentTheme=this.themes[t],this._currentTheme.colorPriority==o.Brightness?Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"PrioritizeColorBrightness",[]):this._currentTheme.colorPriority==o.Accuracy&&Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"PrioritizeColorAccuracy",[]),this._currentTheme.start()}stop(){null!=this._currentTheme&&(this._currentTheme.stop(),this._currentTheme=null)}};_.addTheme("CandleFlicker",p),_.addTheme("Police",f),_.addTheme("Strobe",g),_.addTheme("SOS",m),_.addTheme("Meditation",b),_.addTheme("Disco",v),_.addTheme("Romance",w),_.addTheme("Study",y);const x="GET_PLATFORM",k="UPDATE_PAGE",S="MODUWARE_API_READY",C="LOAD_LANGUAGE_TRANSLATION",E="THEME_TOGGLED",O="CURRENT_UI_COLOR_CHANGED",M="CURRENT_COLOR_CHANGED",P="MAIN_LIGHT_STATE_CHANGED",T="LOCK_TOGGLED",A="FLASH_TOGGLED",j="LIGHTNESS_CHANGED",N="UPDATE_HEADER_TITLE",L=()=>async t=>{let e=new Promise((t,e)=>{"undefined"==typeof Moduware?document.addEventListener("WebViewApiReady",t):t()});await e,t(z())},R=()=>{var t=Object(n.a)();return{type:x,platform:t}},z=()=>async t=>{t({type:S}),t(I()),Moduware.API.addEventListener("HardwareBackButtonPressed",()=>{t(H())})},F=t=>e=>{const r="/"===t?"home-page":t.slice(1);e(D(r))},I=()=>async t=>{t({type:C,language:Moduware.Arguments.language})},D=t=>e=>{switch(t){case"home-page":r.e(3).then(r.bind(null,46)).then(()=>{e(tt(Object(h.a)("home-page.title")))});break;case"pallet-page":Promise.all([r.e(0),r.e(4)]).then(r.bind(null,42)).then(()=>{e(tt(Object(h.a)("pallet-page.title")))});break;case"wheel-page":Promise.all([r.e(0),r.e(6)]).then(r.bind(null,43)).then(()=>{e(tt(Object(h.a)("wheel-page.title")))});break;case"themes-page":r.e(5).then(r.bind(null,44)).then(()=>{e(tt(Object(h.a)("themes-page.title")))});break;default:t="error-page",r.e(2).then(r.bind(null,45)).then(()=>{e(tt("error"))})}e(B(t))},B=t=>({type:k,page:t}),U=()=>(t,e)=>{"pallet-page"===e().app.page||"wheel-page"===e().app.page||"themes-page"===e().app.page||"error-page"===e().app.page?t(F("/home-page")):e().app.apiReady&&Moduware.API.Exit()},H=()=>(t,e)=>{Moduware&&("pallet-page"===e().app.page||"wheel-page"===e().app.page||"themes-page"===e().app.page||"error-page"===e().app.page?t(F("/home-page")):Moduware.API.Exit())},$=t=>(e,r)=>{""===t?(_.stop(),e({type:E,currentTheme:null})):null===r().app.currentTheme?(r().app.ledsState===u.a.On&&e(Y()),_.play(t),e({type:E,currentTheme:t})):r().app.currentTheme===t?(_.stop(),e({type:E,currentTheme:null})):r().app.currentTheme!==t&&(r().app.ledsState===u.a.On&&e(Y()),_.play(t),e({type:E,currentTheme:t}))},V=()=>(t,e)=>{e().app.lockState===u.a.On?(t({type:T,state:u.a.Off}),e().app.ledsState===u.a.On&&t(Y())):t({type:T,state:u.a.On})},q=()=>(t,e)=>{e().app.ledsState===u.a.On?t(Y()):t(W())},G=t=>(e,r)=>{e({type:O,color:t}),e({type:M,color:t.moduleColor}),r().app.ledsState===u.a.On&&e(W())},W=()=>(t,e)=>{"pallet-page"===e().app.page&&t({type:M,color:s()(e().app.currentUiColorName)}),null!==e().app.currentTheme&&t($(""));let r=function(t,e){if(null==t)throw new Exception("Color must be defined.");if("number"!=typeof e)throw new Exception("Adjustment must be a number.");if(e<-1||e>1)throw new Exception("Adjustment value must be between -1 and 1.");let r=t;if(e>0){const t=e;r=r.lighten(t)}else{const t=-1*e;r=r.darken(t)}return r}(e().app.currentColor,e().app.lightness);const[n,o,i]=[r.red(),r.green(),r.blue()];c(d,n,o,i),t({type:P,state:u.a.On})},Y=()=>t=>{c(d,0,0,0),t({type:P,state:u.a.Off})},J=()=>(t,e)=>{var r=e().app.flashLedLeftState===u.a.On?4e3:0,n=e().app.flashLedRightState===u.a.On?0:4e3;t(K(r,n))},X=()=>(t,e)=>{var r=e().app.flashLedRightState===u.a.On?4e3:0,n=e().app.flashLedLeftState===u.a.On?0:4e3;t(K(n,r))},K=(t,e)=>r=>{0===t&&0===e?Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"TurnOffFlashs",[]):Moduware.v1.Module.ExecuteCommand(Moduware.Arguments.uuid,"SetFlashes",[t,e]),r({type:A,leftState:0===t?u.a.Off:u.a.On,rightState:0===e?u.a.Off:u.a.On})},Z=t=>(e,r)=>{e({type:M,color:t}),r().app.ledsState===u.a.On&&e(W())},Q=t=>(e,r)=>{e({type:j,lightness:t}),r().app.ledsState===u.a.On&&e(W())},tt=t=>({type:N,headerTitle:t})},function(t,e,r){"use strict";r.d(e,"a",(function(){return h})),r.d(e,"b",(function(){return d})),r.d(e,"e",(function(){return p})),r.d(e,"c",(function(){return f})),r.d(e,"f",(function(){return g})),r.d(e,"d",(function(){return v}));var n=r(12),o=r(9),i=r(6),a=r(16),s=r(14),l=r(1);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const c=t=>null===t||!("object"==typeof t||"function"==typeof t),u=t=>Array.isArray(t)||!(!t||!t[Symbol.iterator]);class h{constructor(t,e,r){this.dirty=!0,this.element=t,this.name=e,this.strings=r,this.parts=[];for(let t=0;t<r.length-1;t++)this.parts[t]=this._createPart()}_createPart(){return new d(this)}_getValue(){const t=this.strings,e=t.length-1;let r="";for(let n=0;n<e;n++){r+=t[n];const e=this.parts[n];if(void 0!==e){const t=e.value;if(c(t)||!u(t))r+="string"==typeof t?t:String(t);else for(const e of t)r+="string"==typeof e?e:String(e)}}return r+=t[e],r}commit(){this.dirty&&(this.dirty=!1,this.element.setAttribute(this.name,this._getValue()))}}class d{constructor(t){this.value=void 0,this.committer=t}setValue(t){t===i.a||c(t)&&t===this.value||(this.value=t,Object(n.b)(t)||(this.committer.dirty=!0))}commit(){for(;Object(n.b)(this.value);){const t=this.value;this.value=i.a,t(this)}this.value!==i.a&&this.committer.commit()}}class p{constructor(t){this.value=void 0,this.__pendingValue=void 0,this.options=t}appendInto(t){this.startNode=t.appendChild(Object(l.c)()),this.endNode=t.appendChild(Object(l.c)())}insertAfterNode(t){this.startNode=t,this.endNode=t.nextSibling}appendIntoPart(t){t.__insert(this.startNode=Object(l.c)()),t.__insert(this.endNode=Object(l.c)())}insertAfterPart(t){t.__insert(this.startNode=Object(l.c)()),this.endNode=t.endNode,t.endNode=this.startNode}setValue(t){this.__pendingValue=t}commit(){for(;Object(n.b)(this.__pendingValue);){const t=this.__pendingValue;this.__pendingValue=i.a,t(this)}const t=this.__pendingValue;t!==i.a&&(c(t)?t!==this.value&&this.__commitText(t):t instanceof s.b?this.__commitTemplateResult(t):t instanceof Node?this.__commitNode(t):u(t)?this.__commitIterable(t):t===i.b?(this.value=i.b,this.clear()):this.__commitText(t))}__insert(t){this.endNode.parentNode.insertBefore(t,this.endNode)}__commitNode(t){this.value!==t&&(this.clear(),this.__insert(t),this.value=t)}__commitText(t){const e=this.startNode.nextSibling,r="string"==typeof(t=null==t?"":t)?t:String(t);e===this.endNode.previousSibling&&3===e.nodeType?e.data=r:this.__commitNode(document.createTextNode(r)),this.value=t}__commitTemplateResult(t){const e=this.options.templateFactory(t);if(this.value instanceof a.a&&this.value.template===e)this.value.update(t.values);else{const r=new a.a(e,t.processor,this.options),n=r._clone();r.update(t.values),this.__commitNode(n),this.value=r}}__commitIterable(t){Array.isArray(this.value)||(this.value=[],this.clear());const e=this.value;let r,n=0;for(const o of t)r=e[n],void 0===r&&(r=new p(this.options),e.push(r),0===n?r.appendIntoPart(this):r.insertAfterPart(e[n-1])),r.setValue(o),r.commit(),n++;n<e.length&&(e.length=n,this.clear(r&&r.endNode))}clear(t=this.startNode){Object(o.b)(this.startNode.parentNode,t.nextSibling,this.endNode)}}class f{constructor(t,e,r){if(this.value=void 0,this.__pendingValue=void 0,2!==r.length||""!==r[0]||""!==r[1])throw new Error("Boolean attributes can only contain a single expression");this.element=t,this.name=e,this.strings=r}setValue(t){this.__pendingValue=t}commit(){for(;Object(n.b)(this.__pendingValue);){const t=this.__pendingValue;this.__pendingValue=i.a,t(this)}if(this.__pendingValue===i.a)return;const t=!!this.__pendingValue;this.value!==t&&(t?this.element.setAttribute(this.name,""):this.element.removeAttribute(this.name),this.value=t),this.__pendingValue=i.a}}class g extends h{constructor(t,e,r){super(t,e,r),this.single=2===r.length&&""===r[0]&&""===r[1]}_createPart(){return new m(this)}_getValue(){return this.single?this.parts[0].value:super._getValue()}commit(){this.dirty&&(this.dirty=!1,this.element[this.name]=this._getValue())}}class m extends d{}let b=!1;try{const t={get capture(){return b=!0,!1}};window.addEventListener("test",t,t),window.removeEventListener("test",t,t)}catch(t){}class v{constructor(t,e,r){this.value=void 0,this.__pendingValue=void 0,this.element=t,this.eventName=e,this.eventContext=r,this.__boundHandleEvent=t=>this.handleEvent(t)}setValue(t){this.__pendingValue=t}commit(){for(;Object(n.b)(this.__pendingValue);){const t=this.__pendingValue;this.__pendingValue=i.a,t(this)}if(this.__pendingValue===i.a)return;const t=this.__pendingValue,e=this.value,r=null==t||null!=e&&(t.capture!==e.capture||t.once!==e.once||t.passive!==e.passive),o=null!=t&&(null==e||r);r&&this.element.removeEventListener(this.eventName,this.__boundHandleEvent,this.__options),o&&(this.__options=w(t),this.element.addEventListener(this.eventName,this.__boundHandleEvent,this.__options)),this.value=t,this.__pendingValue=i.a}handleEvent(t){"function"==typeof this.value?this.value.call(this.eventContext||this.element,t):this.value.handleEvent(t)}}const w=t=>t&&(b?{capture:t.capture,passive:t.passive,once:t.once}:t.capture)},function(t,e,r){"use strict";r.d(e,"a",(function(){return n})),r.d(e,"b",(function(){return o}));
/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const n={},o={}},function(t,e,r){"use strict";var n=r(5);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */const o=new class{handleAttributeExpressions(t,e,r,o){const i=e[0];if("."===i){return new n.f(t,e.slice(1),r).parts}return"@"===i?[new n.d(t,e.slice(1),o.eventContext)]:"?"===i?[new n.c(t,e.slice(1),r)]:new n.a(t,e,r).parts}handleTextExpression(t){return new n.e(t)}};var i=r(14),a=r(12);r(9),r(6),r(13),r(11),r(16),r(1);r.d(e,"e",(function(){return s})),r.d(e,"d",(function(){return a.a})),r.d(e,"a",(function(){return n.b})),r.d(e,"b",(function(){return n.e})),r.d(e,"c",(function(){return i.b})),
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
(window.litHtmlVersions||(window.litHtmlVersions=[])).push("1.1.2");const s=(t,...e)=>new i.b(t,e,"html",o)},function(t,e,r){"use strict";r.d(e,"d",(function(){return o})),r.d(e,"e",(function(){return i})),r.d(e,"g",(function(){return a})),r.d(e,"h",(function(){return s})),r.d(e,"i",(function(){return l})),r.d(e,"m",(function(){return c})),r.d(e,"a",(function(){return u})),r.d(e,"b",(function(){return h})),r.d(e,"c",(function(){return d})),r.d(e,"f",(function(){return p})),r.d(e,"j",(function(){return f})),r.d(e,"k",(function(){return g})),r.d(e,"l",(function(){return m})),r.d(e,"n",(function(){return b}));var n=r(0);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/const o=n.b`
`,i=n.b`
	* {
		outline: none;
		-webkit-tap-highlight-color: rgba(0,0,0,0);
	}

	img {
		max-width: 100%;
	}

	body {
		font-family: var(--main-font);
	}

	button {
		color: inherit;
		font-size: inherit;
		font-family: var(--main-font);
		border: 0;
		padding: 0;
		background-color: transparent;
	}

	.hidden {
		display: none !important;
	}

	.unselectable {
		user-select: none;
	}

	.wrapper {
		position: absolute;
		top: 0; left: 0;
		overflow: hidden;
		width: 100%;
		height: 100%;
		transition: 1s opacity;
	}
`,a=n.b`
	.wrapper {

	}

	.wrapper[data-color='white'] {
		color: var(--white);
	}

	.wrapper[data-color='red'] {
		color: var(--red);
	}

	.wrapper[data-color='green'] {
		color: var(--green);
	}

	.wrapper[data-color='blue'] {
		color: var(--blue);
	}

	.wrapper[data-color='yellow'] {
		color: var(--yellow);
	}

	.wrapper::before {
		content: '';
		display: block;
		position: fixed;
		height: 100vh;
		width: 100vw;
		top: 0;
		background-color: inherit;
	}

`,s=n.b`
	.page__selector {
		position: relative;
		color: black;
		font-family: Roboto, sans-serif;
	}

  /*:host([platform="android"]) .page__selector {
		padding-top: 55px;
	}

	:host([platform="ios"]) .page__selector {
		padding-top: 44px;
	}*/

	.page__selector__title {
		padding: 20px 17px;
		color: #333333;
		font-size: 14px;
		font-weight: 400;

	}

	:host([platform="ios"]) .page__selector__title {
		text-transform: uppercase;
		font-size: 13px;
		color: #6E6E70;
		padding-bottom: 10px;
	}


`,l=n.b`
.page__themes {
  position: relative;
  color: black;
  font-family: Roboto, sans-serif;
}

/* wrap this in .ios-10-below class spicific rules where grid is not supported */
.wrapper.ios-10-below .page__themes {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

.wrapper:not(.ios-10-below) .page__themes {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  grid-row-gap: 30px;
}

  /*body.platform-android .page__themes {
  padding-top: calc(55px + 20px);
}

body.platform-ios .page__themes {
  padding-top: calc(44px + 20px);
}

.wrapper:not(.ios-10-below) .page__themes .theme-button {
  grid-column-start: span 1;
}

.wrapper.ios-10-below .page__themes .theme-button {
  flex-grow: 0;
  flex-shrink: 0;
  flex-basis: calc(32% - 10px);
  margin: 5px;
}


`,c=n.b`
	body {
  --main-font: Roboto, Helvetica, Arial, sans-serif;

/* SIZES */
  --font-size: 16px;

/* COLORS */
  --hr-color: rgb(82, 80, 88);
  --text-color: rgb(255, 255, 255);
  --black: rgb(42, 42, 42);
  --red: rgb(238, 54, 54);
  --green: rgb(1, 207, 88);
  --blue: rgb(17, 169, 255);
  --yellow: rgb(252, 187, 64);
  --white: rgb(255, 255, 255);
}

`,u=n.b`
	.brightness-control {
		position: absolute;
		top: 90%; left: 50%;
		transform: translateX(-50%) translateY(-50%);
		width: calc(100% - 16px * 2);
	}

.brightness-control__labels {
  display: flex;
  justify-content: space-between;
}

.brightness-control__label {
  font-size: 14px;
  color:#333333;
  font-weight:500;
}

.brightness-control__range-container {
  position: relative;
  height: 2px;
  margin-top: 15px;
  background: rgba(0, 0, 0, 0.26);

}

:host([platform="ios"]) .brightness-control__range-container {
  height: 1px;
  background: #979898;
}

:host([platform="ios"]) .brightness-control__range-container::before,
:host([platform="ios"]) .brightness-control__range-container::after {
  content: '';
  width: 1px;
  height: 5px;
  background-color: #979898;
  position: absolute;
  top: 50%;
  transform: translateY(-50%);
}

:host([platform="ios"]) .brightness-control__range-container::before {
  left: 0;
}

:host([platform="ios"]) .brightness-control__range-container::after {
  right: 0;
}

.brightness-control__range-track-filled {
  position: absolute;
  top: 0; left: 0;
  height: 100%;
  background-color: black;
  will-change: width;

}

:host([platform="ios"]) .brightness-control__range-track-filled {
  display: none;
}

.brightness-control__range-thumb {
  --thumb-size: 12px;

  position: absolute;
  width: calc(100% - var(--thumb-size));
  height: 100%;
  border-radius: 50%;
  will-change: transform;
  z-index: 1;
}

:host([platform="ios"]) .brightness-control__range-thumb {
  --thumb-size: 24px;
}

.brightness-control__range-thumb::after {
  content: '';
  position: absolute;
  background-color: black;
  top: 0; left: 0;
  transform: translateY(-50%);
  width: var(--thumb-size); height: var(--thumb-size);
  border-radius: 50%;
  pointer-events: none;
}

:host([platform="ios"]) .brightness-control__range-thumb::after {
  background-color: white;
  box-shadow: 0 1px 2px rgba(0,0,0, 0.3), 0 6px 0 rgba(0,0,0, 0.05), 0 5px 5px rgba(0,0,0, 0.1);
}

.brightness-control__range {
  -webkit-appearance: none;
  background-color: transparent;
  position: absolute;
  width: 100%;
  height: 2px;
  margin: 0;

}
  .brightness-control__range::-webkit-slider-thumb {
    --clickable-area: 30px;

    box-sizing: border-box;
    position: relative;
    width: var(--clickable-area); height: var(--clickable-area);
    transform: translateY(calc(-50% + 1px));
    box-shadow: none;
    border-style: none;
    opacity: 0;
    -webkit-appearance: none;
    cursor: pointer;
    z-index: 1;
  }

.brightness-control__range::-webkit-slider-runnable-track,
.brightness-control__range::-moz-range-track {
  --clickable-area: 15px;

  background: transparent;
  width: 100%;
  height: 2px;
  border-top: var(--clickable-area) solid transparent;
  border-bottom: var(--clickable-area) solid transparent;
  cursor: pointer;
  box-shadow: none;
}

  /*.brightness-control__range::-webkit-slider-thumb,
.brightness-control__range::-moz-range-thumb {
  --clickable-area: 30px;

  box-sizing: border-box;
  position: relative;
  width: var(--clickable-area); height: var(--clickable-area);
  opacity: 0;
  transform: translateY(calc(-50% + 1px));
  box-shadow: none;
  border-style: none;
  -webkit-appearance: none;
  cursor: pointer;
  z-index: 1;
}
*/

`,h=n.b`
.color-control {
  position:absolute;
  width: 100%;
  height:20vw;
  left:0;
  bottom:0;
  color: $text-color;
  display:flex;
  align-content: stretch;
}

.color-control button {
  flex-grow: 1;
  margin: 0;
  border-radius: 0;
}

`,d=n.b`

	.flashcontrol {
  position: absolute;
  width: 100%;
  max-width: 260px;
  top: 75%; left: 50%;
  display: flex;
  transform: translateX(-50%);
  box-sizing: border-box;
  justify-content: space-between;
}

.flashcontrol__flashbutton {
  width: 44px;
  height: 44px;
  background-image: url(./images/flash.svg);
}

#wrapper[data-color="white"] .flashcontrol__flashbutton:not(.flashcontrol__flashbutton--active) {
  background-image: url(./images/flash_black.svg);
}

.flashcontrol__flashbutton--active {
  background-image: url(./images/flash_active.svg);
}



`,p=n.b`

.led-button {
  position: absolute;
  top: 50%; left: 50%;
  transform: translateX(-50%) translateY(-50%);
  width: 128px;
  height: 128px;
  border-radius: 50%;
  overflow: hidden;
}

#wrapper:not([data-color="white"]) .led-button .button-circle {
  stroke: white;
}

#wrapper:not([data-color="white"]) .led-button .button-path {
  fill: white;
}

#wrapper[data-controls="picker"] .led-button .button-circle {
  stroke: transparent;
}

.led-button.active .button-circle {
  fill: rgba(0, 0, 0, 0.5);
  stroke: transparent;
  stroke-width: 0;
  r: 64;
}

.led-button.active .button-path {
  fill: white;
}



`,f=n.b`
	.modes-list-item {
  position: relative;
  height: 72px;
  padding-left: 72px;
  color: #212121;
  font-size: 16px;
  display: flex;
  flex-direction: column;
  justify-content: center;
}

:host([platform="ios"]) .modes-list-item {
  box-shadow: 0 -1px 0 #C8C7CC, 0 1px 0 #C8C7CC;
  background-image: url(./images/chevron-icon.svg);
  background-repeat: no-repeat;
  background-position: calc(100% - 15px) 50%;
  margin-top: 1px;
}

.modes-list-item__icon {
  position: absolute;
  top: 50%;
  left: 32px;
  transform: translateX(-50%) translateY(-50%);
}

.modes-list-item__description {
  display: block;
  font-size: 14px;
  color: #747474;
  margin-top: 7px;
}

:host([platform="ios"]) .modes-list-item__description {
  font-size: 13px;
}



`,g=n.b`

	.onoffswitch {
		width:44px;
		height:44px;
	}

.checkbox {
  display: none;
}

.checkbox:checked + .switch-label{
  background-color: rgba(0,0,0,0.50);
  border-radius:3px;
}

#wrapper:not([data-color="white"]) .checkbox + .switch-label::before {
  background-image: url(./images/lock.svg);
}

#wrapper:not([data-color="white"]) .checkbox:checked + .switch-label::before {
  background-image: url(./images/lock_active.svg);
}

#wrapper[data-color="white"] .checkbox:checked + .switch-label:before {
  background-image: url(./images/lock_active.svg);
}


.switch-label {
  display: block;
  position: relative;
  overflow: hidden;
  width:44px;
  height:44px;
}

.switch-label::before {
  content:"";
  display: block;
  position: relative;
  top:50%;
  left:50%;
  transform: translateX(-50%) translateY(-50%);
  width:24px;
  height:24px;
  background-image: url(./images/lock_black.svg);
  background-repeat: no-repeat;
  background-size: auto 100%;
}




`,m=n.b`

	.theme-button {
  display: flex;
  flex-direction: column;
  align-items: center;
  color: #333333;
  font-size: 14px;
}

.theme-button__icon-container {
  width: 80px;
  height: 80px;
  background-color: #DFDFDF;
  border-radius: 50%;
  position: relative;
  margin-bottom: 15px;
}

.theme-button--custom .theme-button__icon-container {
  background-color: #9B9B9B;
}

.theme-button--active .theme-button__icon-container {
  background-color: #D12F3D;
}

.theme-button__icon {
  position: absolute;
  top: 50%; left: 50%;
  transform: translateX(-50%) translateY(-50%);
}



`,b=n.b`
.wheel {
  position: absolute;
  top: 50%; left: 50%;
  transform: translateX(-50%) translateY(-50%);
  width:100%;
  background-image: url(./images/color_wheel.png);
  background-repeat: no-repeat;
  background-size: 100%;
  background-position: 50%;
}

.wheel svg path {
  opacity: 0;
}
.wheel svg circle:not([stroke="#ffffff"]) {
  opacity: 0 !important;
}



`},function(t,e,r){"use strict";r.d(e,"a",(function(){return n})),r.d(e,"c",(function(){return o})),r.d(e,"b",(function(){return i}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const n=void 0!==window.customElements&&void 0!==window.customElements.polyfillWrapFlushCallback,o=(t,e,r=null,n=null)=>{for(;e!==r;){const r=e.nextSibling;t.insertBefore(e,n),e=r}},i=(t,e,r=null)=>{for(;e!==r;){const r=e.nextSibling;t.removeChild(e),e=r}}},function(t,e,r){"use strict";function n(t,e,r){return Object.entries(i(e||{})).reduce((t,[e,r])=>t.replace(new RegExp(`{{[  ]*${e}[  ]*}}`),String(i(r))),t)}function o(t,e){const r=t.split(".");let n=e.strings;for(;null!=n&&r.length>0;)n=n[r.shift()];return null!=n?n.toString():null}function i(t){return"function"==typeof t?t():t}let a={loader:()=>Promise.resolve({}),empty:t=>`[${t}]`,lookup:o,interpolate:n,translationCache:{}};function s(t){return a=Object.assign(Object.assign({},a),t)}function l(t,e,r=a){var n;n={previousStrings:r.strings,previousLang:r.lang,lang:r.lang=t,strings:r.strings=e},window.dispatchEvent(new CustomEvent("langChanged",{detail:n}))}async function c(t,e=a){const r=await async function(t,e=a){return await e.loader(t,e)}(t,e);e.translationCache={},l(t,r,e)}function u(t,e,r=a){let n=r.translationCache[t]||(r.translationCache[t]=r.lookup(t,r)||r.empty(t,r));return null!=(e=null!=e?i(e):null)?r.interpolate(n,e,r):n}var h=r(7);function d(t){return t instanceof h.b?t.startNode.isConnected:t instanceof h.a?t.committer.element.isConnected:t.element.isConnected}const p=new Map;var f;function g(t,e,r){const n=e(r);t.value!==n&&(t.setValue(n),t.commit())}!function(t,e){const r=e=>t(e.detail);window.addEventListener("langChanged",r,e)}(t=>{for(const[e,r]of p)d(e)&&g(e,r,t)}),f=p,setInterval(()=>{return t=()=>function(t){for(const[e]of t)d(e)||t.delete(e)}(f),void("requestIdleCallback"in window?window.requestIdleCallback(t):setTimeout(t));var t},6e4);const m=Object(h.d)(t=>e=>{p.set(e,t),g(e,t)}),b=(t,e)=>m(()=>u(t,e));r.d(e,"b",(function(){return s})),r.d(e,"d",(function(){return c})),r.d(e,"a",(function(){return u})),r.d(e,"c",(function(){return b}))},function(t,e,r){"use strict";r.d(e,"b",(function(){return o})),r.d(e,"a",(function(){return i}));var n=r(1);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */function o(t){let e=i.get(t.type);void 0===e&&(e={stringsArray:new WeakMap,keyString:new Map},i.set(t.type,e));let r=e.stringsArray.get(t.strings);if(void 0!==r)return r;const o=t.strings.join(n.f);return r=e.keyString.get(o),void 0===r&&(r=new n.a(t,t.getTemplateElement()),e.keyString.set(o,r)),e.stringsArray.set(t.strings,r),r}const i=new Map},function(t,e,r){"use strict";r.d(e,"a",(function(){return o})),r.d(e,"b",(function(){return i}));
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const n=new WeakMap,o=t=>(...e)=>{const r=t(...e);return n.set(r,!0),r},i=t=>"function"==typeof t&&n.has(t)},function(t,e,r){"use strict";r.d(e,"a",(function(){return a})),r.d(e,"b",(function(){return s}));var n=r(9),o=r(5),i=r(11);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const a=new WeakMap,s=(t,e,r)=>{let s=a.get(e);void 0===s&&(Object(n.b)(e,e.firstChild),a.set(e,s=new o.e(Object.assign({templateFactory:i.b},r))),s.appendInto(e)),s.setValue(t),s.commit()}},function(t,e,r){"use strict";r.d(e,"b",(function(){return a})),r.d(e,"a",(function(){return s}));var n=r(9),o=r(1);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
const i=` ${o.f} `;class a{constructor(t,e,r,n){this.strings=t,this.values=e,this.type=r,this.processor=n}getHTML(){const t=this.strings.length-1;let e="",r=!1;for(let n=0;n<t;n++){const t=this.strings[n],a=t.lastIndexOf("\x3c!--");r=(a>-1||r)&&-1===t.indexOf("--\x3e",a+1);const s=o.e.exec(t);e+=null===s?t+(r?i:o.g):t.substr(0,s.index)+s[1]+s[2]+o.b+s[3]+o.f}return e+=this.strings[t],e}getTemplateElement(){const t=document.createElement("template");return t.innerHTML=this.getHTML(),t}}class s extends a{getHTML(){return`<svg>${super.getHTML()}</svg>`}getTemplateElement(){const t=super.getTemplateElement(),e=t.content,r=e.firstChild;return e.removeChild(r),Object(n.c)(e,r.firstChild),t}}},function(t,e,r){"use strict";var n=r(18),o=function(){return Math.random().toString(36).substring(7).split("").join(".")},i={INIT:"@@redux/INIT"+o(),REPLACE:"@@redux/REPLACE"+o(),PROBE_UNKNOWN_ACTION:function(){return"@@redux/PROBE_UNKNOWN_ACTION"+o()}};function a(t){if("object"!=typeof t||null===t)return!1;for(var e=t;null!==Object.getPrototypeOf(e);)e=Object.getPrototypeOf(e);return Object.getPrototypeOf(t)===e}function s(t,e){var r=e&&e.type;return"Given "+(r&&'action "'+String(r)+'"'||"an action")+', reducer "'+t+'" returned undefined. To ignore an action, you must explicitly return the previous state. If you want this reducer to hold no value, you can return null instead of undefined.'}function l(t,e,r){return e in t?Object.defineProperty(t,e,{value:r,enumerable:!0,configurable:!0,writable:!0}):t[e]=r,t}function c(t,e){var r=Object.keys(t);return Object.getOwnPropertySymbols&&r.push.apply(r,Object.getOwnPropertySymbols(t)),e&&(r=r.filter((function(e){return Object.getOwnPropertyDescriptor(t,e).enumerable}))),r}function u(t){for(var e=1;e<arguments.length;e++){var r=null!=arguments[e]?arguments[e]:{};e%2?c(r,!0).forEach((function(e){l(t,e,r[e])})):Object.getOwnPropertyDescriptors?Object.defineProperties(t,Object.getOwnPropertyDescriptors(r)):c(r).forEach((function(e){Object.defineProperty(t,e,Object.getOwnPropertyDescriptor(r,e))}))}return t}function h(){for(var t=arguments.length,e=new Array(t),r=0;r<t;r++)e[r]=arguments[r];return 0===e.length?function(t){return t}:1===e.length?e[0]:e.reduce((function(t,e){return function(){return t(e.apply(void 0,arguments))}}))}function d(t){return function(e){var r=e.dispatch,n=e.getState;return function(e){return function(o){return"function"==typeof o?o(r,n,t):e(o)}}}}var p=d();p.withExtraArgument=d;var f=p;
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/var g=r(21);const m=(t,e)=>{return r="0",n=e-t.toString().length,new Array(n+1).join(r)+t;var r,n},b="undefined"!=typeof performance&&null!==performance&&"function"==typeof performance.now?performance:Date;var v=r(27);const w={E:{color:"#2196F3",text:"CHANGED:"},N:{color:"#4CAF50",text:"ADDED:"},D:{color:"#F44336",text:"DELETED:"},A:{color:"#2196F3",text:"ARRAY:"}};function y(t,e,r,n){const o=Object(v.a)(t,e);try{n?r.groupCollapsed("diff"):r.group("diff")}catch(t){r.log("diff")}o?o.forEach(t=>{const{kind:e}=t,n=function(t){const{kind:e,path:r,lhs:n,rhs:o,index:i,item:a}=t;switch(e){case"E":return[r.join("."),n,"→",o];case"N":return[r.join("."),o];case"D":return[r.join(".")];case"A":return[`${r.join(".")}[${i}]`,a];default:return[]}}(t);r.log(`%c ${w[e].text}`,function(t){return`color: ${w[t].color}; font-weight: bold`}(e),...n)}):r.log("—— no diff ——");try{r.groupEnd()}catch(t){r.log("—— diff end —— ")}}function _(t,e,r,n){switch(typeof t){case"object":return"function"==typeof t[n]?t[n](...r):t[n];case"function":return t(e);default:return t}}function x(t){const{timestamp:e,duration:r}=t;return(t,n,o)=>{const i=["action"];return i.push(`%c${String(t.type)}`),e&&i.push(`%c@ ${n}`),r&&i.push(`%c(in ${o.toFixed(2)} ms)`),i.join(" ")}}var k=function(t,e){const{logger:r,actionTransformer:n,titleFormatter:o=x(e),collapsed:i,colors:a,level:s,diff:l}=e,c=void 0===e.titleFormatter;t.forEach((u,h)=>{const{started:d,startedTime:p,action:f,prevState:g,error:b}=u;let{took:v,nextState:w}=u;const x=t[h+1];x&&(w=x.prevState,v=x.started-d);const k=n(f),S="function"==typeof i?i(()=>w,f,u):i,C=`${m((E=p).getHours(),2)}:${m(E.getMinutes(),2)}:${m(E.getSeconds(),2)}.${m(E.getMilliseconds(),3)}`;var E;const O=a.title?`color: ${a.title(k)};`:"",M=["color: gray; font-weight: lighter;"];M.push(O),e.timestamp&&M.push("color: gray; font-weight: lighter;"),e.duration&&M.push("color: gray; font-weight: lighter;");const P=o(k,C,v);try{S?a.title&&c?r.groupCollapsed(`%c ${P}`,...M):r.groupCollapsed(P):a.title&&c?r.group(`%c ${P}`,...M):r.group(P)}catch(t){r.log(P)}const T=_(s,k,[g],"prevState"),A=_(s,k,[k],"action"),j=_(s,k,[b,g],"error"),N=_(s,k,[w],"nextState");if(T)if(a.prevState){const t=`color: ${a.prevState(g)}; font-weight: bold`;r[T]("%c prev state",t,g)}else r[T]("prev state",g);if(A)if(a.action){const t=`color: ${a.action(k)}; font-weight: bold`;r[A]("%c action    ",t,k)}else r[A]("action    ",k);if(b&&j)if(a.error){const t=`color: ${a.error(b,g)}; font-weight: bold;`;r[j]("%c error     ",t,b)}else r[j]("error     ",b);if(N)if(a.nextState){const t=`color: ${a.nextState(w)}; font-weight: bold`;r[N]("%c next state",t,w)}else r[N]("next state",w);l&&y(g,w,r,S);try{r.groupEnd()}catch(t){r.log("—— log end ——")}})},S={level:"log",logger:console,logErrors:!0,collapsed:void 0,predicate:void 0,duration:!1,timestamp:!0,stateTransformer:t=>t,actionTransformer:t=>t,errorTransformer:t=>t,colors:{title:()=>"inherit",prevState:()=>"#9E9E9E",action:()=>"#03A9F4",nextState:()=>"#4CAF50",error:()=>"#F20404"},diff:!1,diffPredicate:void 0,transformer:void 0};function C(t={}){const e=Object.assign({},S,t),{logger:r,stateTransformer:n,errorTransformer:o,predicate:i,logErrors:a,diffPredicate:s}=e;if(void 0===r)return()=>t=>e=>t(e);if(t.getState&&t.dispatch)return console.error("[redux-logger] redux-logger not installed. Make sure to pass logger instance as middleware:\n// Logger with default options\nimport { logger } from 'redux-logger'\nconst store = createStore(\n  reducer,\n  applyMiddleware(logger)\n)\n// Or you can create your own logger with custom options http://bit.ly/redux-logger-options\nimport createLogger from 'redux-logger'\nconst logger = createLogger({\n  // ...options\n});\nconst store = createStore(\n  reducer,\n  applyMiddleware(logger)\n)\n"),()=>t=>e=>t(e);const l=[];return({getState:t})=>r=>c=>{if("function"==typeof i&&!i(t,c))return r(c);const u={};let h;if(l.push(u),u.started=b.now(),u.startedTime=new Date,u.prevState=n(t()),u.action=c,a)try{h=r(c)}catch(t){u.error=o(t)}else h=r(c);u.took=b.now()-u.started,u.nextState=n(t());const d=e.diff&&"function"==typeof s?s(t,c):e.diff;if(k(l,Object.assign({},e,{diff:d})),l.length=0,u.error)throw u.error;return h}}r.d(e,"a",(function(){return O}));
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
const E=C({collapsed:!0,diff:!0}),O=function t(e,r,o){var s;if("function"==typeof r&&"function"==typeof o||"function"==typeof o&&"function"==typeof arguments[3])throw new Error("It looks like you are passing several store enhancers to createStore(). This is not supported. Instead, compose them together to a single function.");if("function"==typeof r&&void 0===o&&(o=r,r=void 0),void 0!==o){if("function"!=typeof o)throw new Error("Expected the enhancer to be a function.");return o(t)(e,r)}if("function"!=typeof e)throw new Error("Expected the reducer to be a function.");var l=e,c=r,u=[],h=u,d=!1;function p(){h===u&&(h=u.slice())}function f(){if(d)throw new Error("You may not call store.getState() while the reducer is executing. The reducer has already received the state as an argument. Pass it down from the top reducer instead of reading it from the store.");return c}function g(t){if("function"!=typeof t)throw new Error("Expected the listener to be a function.");if(d)throw new Error("You may not call store.subscribe() while the reducer is executing. If you would like to be notified after the store has been updated, subscribe from a component and invoke store.getState() in the callback to access the latest state. See https://redux.js.org/api-reference/store#subscribelistener for more details.");var e=!0;return p(),h.push(t),function(){if(e){if(d)throw new Error("You may not unsubscribe from a store listener while the reducer is executing. See https://redux.js.org/api-reference/store#subscribelistener for more details.");e=!1,p();var r=h.indexOf(t);h.splice(r,1),u=null}}}function m(t){if(!a(t))throw new Error("Actions must be plain objects. Use custom middleware for async actions.");if(void 0===t.type)throw new Error('Actions may not have an undefined "type" property. Have you misspelled a constant?');if(d)throw new Error("Reducers may not dispatch actions.");try{d=!0,c=l(c,t)}finally{d=!1}for(var e=u=h,r=0;r<e.length;r++){(0,e[r])()}return t}function b(t){if("function"!=typeof t)throw new Error("Expected the nextReducer to be a function.");l=t,m({type:i.REPLACE})}function v(){var t,e=g;return(t={subscribe:function(t){if("object"!=typeof t||null===t)throw new TypeError("Expected the observer to be an object.");function r(){t.next&&t.next(f())}return r(),{unsubscribe:e(r)}}})[n.a]=function(){return this},t}return m({type:i.INIT}),(s={dispatch:m,subscribe:g,getState:f,replaceReducer:b})[n.a]=v,s}(t=>t,(window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__||h)((t=>e=>(r,n)=>{let o={};const i=e(r,n);return Object.assign({},i,{addReducers(e){const r=Object.assign({},o,e);this.replaceReducer(t(o=r))}})})((function(t){for(var e=Object.keys(t),r={},n=0;n<e.length;n++){var o=e[n];0,"function"==typeof t[o]&&(r[o]=t[o])}var a,l=Object.keys(r);try{!function(t){Object.keys(t).forEach((function(e){var r=t[e];if(void 0===r(void 0,{type:i.INIT}))throw new Error('Reducer "'+e+"\" returned undefined during initialization. If the state passed to the reducer is undefined, you must explicitly return the initial state. The initial state may not be undefined. If you don't want to set a value for this reducer, you can use null instead of undefined.");if(void 0===r(void 0,{type:i.PROBE_UNKNOWN_ACTION()}))throw new Error('Reducer "'+e+"\" returned undefined when probed with a random type. Don't try to handle "+i.INIT+' or other actions in "redux/*" namespace. They are considered private. Instead, you must return the current state for any unknown actions, unless it is undefined, in which case you must return the initial state, regardless of the action type. The initial state may not be undefined, but can be null.')}))}(r)}catch(t){a=t}return function(t,e){if(void 0===t&&(t={}),a)throw a;for(var n=!1,o={},i=0;i<l.length;i++){var c=l[i],u=r[c],h=t[c],d=u(h,e);if(void 0===d){var p=s(c,e);throw new Error(p)}o[c]=d,n=n||d!==h}return(n=n||l.length!==Object.keys(t).length)?o:t}})),function(){for(var t=arguments.length,e=new Array(t),r=0;r<t;r++)e[r]=arguments[r];return function(t){return function(){var r=t.apply(void 0,arguments),n=function(){throw new Error("Dispatching while constructing your middleware is not allowed. Other middleware would not be applied to this dispatch.")},o={getState:r.getState,dispatch:function(){return n.apply(void 0,arguments)}},i=e.map((function(t){return t(o)}));return u({},r,{dispatch:n=h.apply(void 0,i)(r.dispatch)})}}}(f,E)));O.addReducers({app:g.a})},function(t,e,r){"use strict";r.d(e,"a",(function(){return i}));var n=r(9),o=r(1);
/**
 * @license
 * Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at
 * http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at
 * http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
class i{constructor(t,e,r){this.__parts=[],this.template=t,this.processor=e,this.options=r}update(t){let e=0;for(const r of this.__parts)void 0!==r&&r.setValue(t[e]),e++;for(const t of this.__parts)void 0!==t&&t.commit()}_clone(){const t=n.a?this.template.element.content.cloneNode(!0):document.importNode(this.template.element.content,!0),e=[],r=this.template.parts,i=document.createTreeWalker(t,133,null,!1);let a,s=0,l=0,c=i.nextNode();for(;s<r.length;)if(a=r[s],Object(o.d)(a)){for(;l<a.index;)l++,"TEMPLATE"===c.nodeName&&(e.push(c),i.currentNode=c.content),null===(c=i.nextNode())&&(i.currentNode=e.pop(),c=i.nextNode());if("node"===a.type){const t=this.processor.handleTextExpression(this.options);t.insertAfterNode(c.previousSibling),this.__parts.push(t)}else this.__parts.push(...this.processor.handleAttributeExpressions(c,a.name,a.strings,this.options));s++}else this.__parts.push(void 0),s++;return n.a&&(document.adoptNode(t),customElements.upgrade(t)),t}}},function(t,e,r){"use strict";r.d(e,"a",(function(){return n}));const n=function(){let t=navigator.userAgent||navigator.vendor||window.opera;return/windows phone/i.test(t)?"windows-phone":/android/i.test(t)?"android":/iPad|iPhone|iPod/.test(t)&&!window.MSStream?"ios":"unknown"}},function(t,e,r){"use strict";(function(t,n){var o,i=r(28);o="undefined"!=typeof self?self:"undefined"!=typeof window?window:void 0!==t?t:n;var a=Object(i.a)(o);e.a=a}).call(this,r(25),r(38)(t))},function(t,e,r){"use strict";
/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/window.JSCompiler_renameProperty=function(t,e){return t}},function(t,e,r){"use strict";r.d(e,"a",(function(){return n}));
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
const n=t=>e=>class extends e{connectedCallback(){super.connectedCallback&&super.connectedCallback(),this._storeUnsubscribe=t.subscribe(()=>this.stateChanged(t.getState())),this.stateChanged(t.getState())}disconnectedCallback(){this._storeUnsubscribe(),super.disconnectedCallback&&super.disconnectedCallback()}stateChanged(t){}}},function(t,e,r){"use strict";var n=r(2),o=r(3),i=r.n(o),a=(r(30),r(4));
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
const s={page:"",apiReady:!1,language:"en",ledsState:n.a.Off,flashLedLeftState:n.a.Off,flashLedRightState:n.a.Off,lockState:n.a.On,currentColor:i()("white"),currentUiColor:"rgb(255, 255, 255)",currentUiColorName:"white",currentTheme:null,lightness:0,rgbTemperatureProtection:!1,headerTitle:"",platform:""};e.a=(t=s,e)=>{switch(e.type){case a.i:return{...t,apiReady:!0};case a.d:return{...t,platform:e.platform};case a.l:return{...t,page:e.page};case a.f:return{...t,language:e.language};case a.j:return{...t,currentTheme:e.currentTheme};case a.b:return{...t,currentUiColor:e.color.uiColorString,currentUiColorName:e.color.uiColorName};case a.a:return{...t,currentColor:e.color};case a.h:return{...t,ledsState:e.state};case a.g:return{...t,lockState:e.state};case a.c:return{...t,flashLedLeftState:e.leftState,flashLedRightState:e.rightState};case a.e:return{...t,lightness:e.lightness};case a.k:return{...t,headerTitle:e.headerTitle};default:return t}}},function(t,e,r){"use strict";r.r(e);const n={"home-page":{title:"LED",modes:"Modes"},"pallet-page":{title:"Simple Pallet",description:"5 simple colors to chose"},"wheel-page":{title:"Color wheel",description:"Pick your own color"},"themes-page":{title:"Themes",description:"Preset light moods"},brightness:{darker:"Darker",lighter:"Lighter"},themes:{candle:"Candle flicker",romance:"Romance",meditation:"Meditation",sos:"SOS",study:"Study",disco:"Disco",strobe:"Strobe",police:"Police"}},o={"home-page":{title:"LED灯",modes:"模式"},"pallet-page":{title:"基础调色板",description:"5种简单的颜色可供选择"},"wheel-page":{title:"色轮",description:"选择你自己的颜色"},"themes-page":{title:"主题",description:"预设氛围灯"},brightness:{darker:"更暗",lighter:"更亮"},themes:{candle:"烛光闪烁",romance:"浪漫",meditation:"冥想",sos:"紧急求救",study:"学习",disco:"迪斯科",strobe:"频闪",police:"警灯"}};r.d(e,"en",(function(){return n})),r.d(e,"zh",(function(){return o}))},function(t,e,r){"use strict";t.exports={aliceblue:[240,248,255],antiquewhite:[250,235,215],aqua:[0,255,255],aquamarine:[127,255,212],azure:[240,255,255],beige:[245,245,220],bisque:[255,228,196],black:[0,0,0],blanchedalmond:[255,235,205],blue:[0,0,255],blueviolet:[138,43,226],brown:[165,42,42],burlywood:[222,184,135],cadetblue:[95,158,160],chartreuse:[127,255,0],chocolate:[210,105,30],coral:[255,127,80],cornflowerblue:[100,149,237],cornsilk:[255,248,220],crimson:[220,20,60],cyan:[0,255,255],darkblue:[0,0,139],darkcyan:[0,139,139],darkgoldenrod:[184,134,11],darkgray:[169,169,169],darkgreen:[0,100,0],darkgrey:[169,169,169],darkkhaki:[189,183,107],darkmagenta:[139,0,139],darkolivegreen:[85,107,47],darkorange:[255,140,0],darkorchid:[153,50,204],darkred:[139,0,0],darksalmon:[233,150,122],darkseagreen:[143,188,143],darkslateblue:[72,61,139],darkslategray:[47,79,79],darkslategrey:[47,79,79],darkturquoise:[0,206,209],darkviolet:[148,0,211],deeppink:[255,20,147],deepskyblue:[0,191,255],dimgray:[105,105,105],dimgrey:[105,105,105],dodgerblue:[30,144,255],firebrick:[178,34,34],floralwhite:[255,250,240],forestgreen:[34,139,34],fuchsia:[255,0,255],gainsboro:[220,220,220],ghostwhite:[248,248,255],gold:[255,215,0],goldenrod:[218,165,32],gray:[128,128,128],green:[0,128,0],greenyellow:[173,255,47],grey:[128,128,128],honeydew:[240,255,240],hotpink:[255,105,180],indianred:[205,92,92],indigo:[75,0,130],ivory:[255,255,240],khaki:[240,230,140],lavender:[230,230,250],lavenderblush:[255,240,245],lawngreen:[124,252,0],lemonchiffon:[255,250,205],lightblue:[173,216,230],lightcoral:[240,128,128],lightcyan:[224,255,255],lightgoldenrodyellow:[250,250,210],lightgray:[211,211,211],lightgreen:[144,238,144],lightgrey:[211,211,211],lightpink:[255,182,193],lightsalmon:[255,160,122],lightseagreen:[32,178,170],lightskyblue:[135,206,250],lightslategray:[119,136,153],lightslategrey:[119,136,153],lightsteelblue:[176,196,222],lightyellow:[255,255,224],lime:[0,255,0],limegreen:[50,205,50],linen:[250,240,230],magenta:[255,0,255],maroon:[128,0,0],mediumaquamarine:[102,205,170],mediumblue:[0,0,205],mediumorchid:[186,85,211],mediumpurple:[147,112,219],mediumseagreen:[60,179,113],mediumslateblue:[123,104,238],mediumspringgreen:[0,250,154],mediumturquoise:[72,209,204],mediumvioletred:[199,21,133],midnightblue:[25,25,112],mintcream:[245,255,250],mistyrose:[255,228,225],moccasin:[255,228,181],navajowhite:[255,222,173],navy:[0,0,128],oldlace:[253,245,230],olive:[128,128,0],olivedrab:[107,142,35],orange:[255,165,0],orangered:[255,69,0],orchid:[218,112,214],palegoldenrod:[238,232,170],palegreen:[152,251,152],paleturquoise:[175,238,238],palevioletred:[219,112,147],papayawhip:[255,239,213],peachpuff:[255,218,185],peru:[205,133,63],pink:[255,192,203],plum:[221,160,221],powderblue:[176,224,230],purple:[128,0,128],rebeccapurple:[102,51,153],red:[255,0,0],rosybrown:[188,143,143],royalblue:[65,105,225],saddlebrown:[139,69,19],salmon:[250,128,114],sandybrown:[244,164,96],seagreen:[46,139,87],seashell:[255,245,238],sienna:[160,82,45],silver:[192,192,192],skyblue:[135,206,235],slateblue:[106,90,205],slategray:[112,128,144],slategrey:[112,128,144],snow:[255,250,250],springgreen:[0,255,127],steelblue:[70,130,180],tan:[210,180,140],teal:[0,128,128],thistle:[216,191,216],tomato:[255,99,71],turquoise:[64,224,208],violet:[238,130,238],wheat:[245,222,179],white:[255,255,255],whitesmoke:[245,245,245],yellow:[255,255,0],yellowgreen:[154,205,50]}},function(t,e,r){var n=r(23),o={};for(var i in n)n.hasOwnProperty(i)&&(o[n[i]]=i);var a=t.exports={rgb:{channels:3,labels:"rgb"},hsl:{channels:3,labels:"hsl"},hsv:{channels:3,labels:"hsv"},hwb:{channels:3,labels:"hwb"},cmyk:{channels:4,labels:"cmyk"},xyz:{channels:3,labels:"xyz"},lab:{channels:3,labels:"lab"},lch:{channels:3,labels:"lch"},hex:{channels:1,labels:["hex"]},keyword:{channels:1,labels:["keyword"]},ansi16:{channels:1,labels:["ansi16"]},ansi256:{channels:1,labels:["ansi256"]},hcg:{channels:3,labels:["h","c","g"]},apple:{channels:3,labels:["r16","g16","b16"]},gray:{channels:1,labels:["gray"]}};for(var s in a)if(a.hasOwnProperty(s)){if(!("channels"in a[s]))throw new Error("missing channels property: "+s);if(!("labels"in a[s]))throw new Error("missing channel labels property: "+s);if(a[s].labels.length!==a[s].channels)throw new Error("channel and label counts mismatch: "+s);var l=a[s].channels,c=a[s].labels;delete a[s].channels,delete a[s].labels,Object.defineProperty(a[s],"channels",{value:l}),Object.defineProperty(a[s],"labels",{value:c})}a.rgb.hsl=function(t){var e,r,n=t[0]/255,o=t[1]/255,i=t[2]/255,a=Math.min(n,o,i),s=Math.max(n,o,i),l=s-a;return s===a?e=0:n===s?e=(o-i)/l:o===s?e=2+(i-n)/l:i===s&&(e=4+(n-o)/l),(e=Math.min(60*e,360))<0&&(e+=360),r=(a+s)/2,[e,100*(s===a?0:r<=.5?l/(s+a):l/(2-s-a)),100*r]},a.rgb.hsv=function(t){var e,r,n,o,i,a=t[0]/255,s=t[1]/255,l=t[2]/255,c=Math.max(a,s,l),u=c-Math.min(a,s,l),h=function(t){return(c-t)/6/u+.5};return 0===u?o=i=0:(i=u/c,e=h(a),r=h(s),n=h(l),a===c?o=n-r:s===c?o=1/3+e-n:l===c&&(o=2/3+r-e),o<0?o+=1:o>1&&(o-=1)),[360*o,100*i,100*c]},a.rgb.hwb=function(t){var e=t[0],r=t[1],n=t[2];return[a.rgb.hsl(t)[0],100*(1/255*Math.min(e,Math.min(r,n))),100*(n=1-1/255*Math.max(e,Math.max(r,n)))]},a.rgb.cmyk=function(t){var e,r=t[0]/255,n=t[1]/255,o=t[2]/255;return[100*((1-r-(e=Math.min(1-r,1-n,1-o)))/(1-e)||0),100*((1-n-e)/(1-e)||0),100*((1-o-e)/(1-e)||0),100*e]},a.rgb.keyword=function(t){var e=o[t];if(e)return e;var r,i,a,s=1/0;for(var l in n)if(n.hasOwnProperty(l)){var c=n[l],u=(i=t,a=c,Math.pow(i[0]-a[0],2)+Math.pow(i[1]-a[1],2)+Math.pow(i[2]-a[2],2));u<s&&(s=u,r=l)}return r},a.keyword.rgb=function(t){return n[t]},a.rgb.xyz=function(t){var e=t[0]/255,r=t[1]/255,n=t[2]/255;return[100*(.4124*(e=e>.04045?Math.pow((e+.055)/1.055,2.4):e/12.92)+.3576*(r=r>.04045?Math.pow((r+.055)/1.055,2.4):r/12.92)+.1805*(n=n>.04045?Math.pow((n+.055)/1.055,2.4):n/12.92)),100*(.2126*e+.7152*r+.0722*n),100*(.0193*e+.1192*r+.9505*n)]},a.rgb.lab=function(t){var e=a.rgb.xyz(t),r=e[0],n=e[1],o=e[2];return n/=100,o/=108.883,r=(r/=95.047)>.008856?Math.pow(r,1/3):7.787*r+16/116,[116*(n=n>.008856?Math.pow(n,1/3):7.787*n+16/116)-16,500*(r-n),200*(n-(o=o>.008856?Math.pow(o,1/3):7.787*o+16/116))]},a.hsl.rgb=function(t){var e,r,n,o,i,a=t[0]/360,s=t[1]/100,l=t[2]/100;if(0===s)return[i=255*l,i,i];e=2*l-(r=l<.5?l*(1+s):l+s-l*s),o=[0,0,0];for(var c=0;c<3;c++)(n=a+1/3*-(c-1))<0&&n++,n>1&&n--,i=6*n<1?e+6*(r-e)*n:2*n<1?r:3*n<2?e+(r-e)*(2/3-n)*6:e,o[c]=255*i;return o},a.hsl.hsv=function(t){var e=t[0],r=t[1]/100,n=t[2]/100,o=r,i=Math.max(n,.01);return r*=(n*=2)<=1?n:2-n,o*=i<=1?i:2-i,[e,100*(0===n?2*o/(i+o):2*r/(n+r)),100*((n+r)/2)]},a.hsv.rgb=function(t){var e=t[0]/60,r=t[1]/100,n=t[2]/100,o=Math.floor(e)%6,i=e-Math.floor(e),a=255*n*(1-r),s=255*n*(1-r*i),l=255*n*(1-r*(1-i));switch(n*=255,o){case 0:return[n,l,a];case 1:return[s,n,a];case 2:return[a,n,l];case 3:return[a,s,n];case 4:return[l,a,n];case 5:return[n,a,s]}},a.hsv.hsl=function(t){var e,r,n,o=t[0],i=t[1]/100,a=t[2]/100,s=Math.max(a,.01);return n=(2-i)*a,r=i*s,[o,100*(r=(r/=(e=(2-i)*s)<=1?e:2-e)||0),100*(n/=2)]},a.hwb.rgb=function(t){var e,r,n,o,i,a,s,l=t[0]/360,c=t[1]/100,u=t[2]/100,h=c+u;switch(h>1&&(c/=h,u/=h),n=6*l-(e=Math.floor(6*l)),0!=(1&e)&&(n=1-n),o=c+n*((r=1-u)-c),e){default:case 6:case 0:i=r,a=o,s=c;break;case 1:i=o,a=r,s=c;break;case 2:i=c,a=r,s=o;break;case 3:i=c,a=o,s=r;break;case 4:i=o,a=c,s=r;break;case 5:i=r,a=c,s=o}return[255*i,255*a,255*s]},a.cmyk.rgb=function(t){var e=t[0]/100,r=t[1]/100,n=t[2]/100,o=t[3]/100;return[255*(1-Math.min(1,e*(1-o)+o)),255*(1-Math.min(1,r*(1-o)+o)),255*(1-Math.min(1,n*(1-o)+o))]},a.xyz.rgb=function(t){var e,r,n,o=t[0]/100,i=t[1]/100,a=t[2]/100;return r=-.9689*o+1.8758*i+.0415*a,n=.0557*o+-.204*i+1.057*a,e=(e=3.2406*o+-1.5372*i+-.4986*a)>.0031308?1.055*Math.pow(e,1/2.4)-.055:12.92*e,r=r>.0031308?1.055*Math.pow(r,1/2.4)-.055:12.92*r,n=n>.0031308?1.055*Math.pow(n,1/2.4)-.055:12.92*n,[255*(e=Math.min(Math.max(0,e),1)),255*(r=Math.min(Math.max(0,r),1)),255*(n=Math.min(Math.max(0,n),1))]},a.xyz.lab=function(t){var e=t[0],r=t[1],n=t[2];return r/=100,n/=108.883,e=(e/=95.047)>.008856?Math.pow(e,1/3):7.787*e+16/116,[116*(r=r>.008856?Math.pow(r,1/3):7.787*r+16/116)-16,500*(e-r),200*(r-(n=n>.008856?Math.pow(n,1/3):7.787*n+16/116))]},a.lab.xyz=function(t){var e,r,n,o=t[0];e=t[1]/500+(r=(o+16)/116),n=r-t[2]/200;var i=Math.pow(r,3),a=Math.pow(e,3),s=Math.pow(n,3);return r=i>.008856?i:(r-16/116)/7.787,e=a>.008856?a:(e-16/116)/7.787,n=s>.008856?s:(n-16/116)/7.787,[e*=95.047,r*=100,n*=108.883]},a.lab.lch=function(t){var e,r=t[0],n=t[1],o=t[2];return(e=360*Math.atan2(o,n)/2/Math.PI)<0&&(e+=360),[r,Math.sqrt(n*n+o*o),e]},a.lch.lab=function(t){var e,r=t[0],n=t[1];return e=t[2]/360*2*Math.PI,[r,n*Math.cos(e),n*Math.sin(e)]},a.rgb.ansi16=function(t){var e=t[0],r=t[1],n=t[2],o=1 in arguments?arguments[1]:a.rgb.hsv(t)[2];if(0===(o=Math.round(o/50)))return 30;var i=30+(Math.round(n/255)<<2|Math.round(r/255)<<1|Math.round(e/255));return 2===o&&(i+=60),i},a.hsv.ansi16=function(t){return a.rgb.ansi16(a.hsv.rgb(t),t[2])},a.rgb.ansi256=function(t){var e=t[0],r=t[1],n=t[2];return e===r&&r===n?e<8?16:e>248?231:Math.round((e-8)/247*24)+232:16+36*Math.round(e/255*5)+6*Math.round(r/255*5)+Math.round(n/255*5)},a.ansi16.rgb=function(t){var e=t%10;if(0===e||7===e)return t>50&&(e+=3.5),[e=e/10.5*255,e,e];var r=.5*(1+~~(t>50));return[(1&e)*r*255,(e>>1&1)*r*255,(e>>2&1)*r*255]},a.ansi256.rgb=function(t){if(t>=232){var e=10*(t-232)+8;return[e,e,e]}var r;return t-=16,[Math.floor(t/36)/5*255,Math.floor((r=t%36)/6)/5*255,r%6/5*255]},a.rgb.hex=function(t){var e=(((255&Math.round(t[0]))<<16)+((255&Math.round(t[1]))<<8)+(255&Math.round(t[2]))).toString(16).toUpperCase();return"000000".substring(e.length)+e},a.hex.rgb=function(t){var e=t.toString(16).match(/[a-f0-9]{6}|[a-f0-9]{3}/i);if(!e)return[0,0,0];var r=e[0];3===e[0].length&&(r=r.split("").map((function(t){return t+t})).join(""));var n=parseInt(r,16);return[n>>16&255,n>>8&255,255&n]},a.rgb.hcg=function(t){var e,r=t[0]/255,n=t[1]/255,o=t[2]/255,i=Math.max(Math.max(r,n),o),a=Math.min(Math.min(r,n),o),s=i-a;return e=s<=0?0:i===r?(n-o)/s%6:i===n?2+(o-r)/s:4+(r-n)/s+4,e/=6,[360*(e%=1),100*s,100*(s<1?a/(1-s):0)]},a.hsl.hcg=function(t){var e=t[1]/100,r=t[2]/100,n=1,o=0;return(n=r<.5?2*e*r:2*e*(1-r))<1&&(o=(r-.5*n)/(1-n)),[t[0],100*n,100*o]},a.hsv.hcg=function(t){var e=t[1]/100,r=t[2]/100,n=e*r,o=0;return n<1&&(o=(r-n)/(1-n)),[t[0],100*n,100*o]},a.hcg.rgb=function(t){var e=t[0]/360,r=t[1]/100,n=t[2]/100;if(0===r)return[255*n,255*n,255*n];var o,i=[0,0,0],a=e%1*6,s=a%1,l=1-s;switch(Math.floor(a)){case 0:i[0]=1,i[1]=s,i[2]=0;break;case 1:i[0]=l,i[1]=1,i[2]=0;break;case 2:i[0]=0,i[1]=1,i[2]=s;break;case 3:i[0]=0,i[1]=l,i[2]=1;break;case 4:i[0]=s,i[1]=0,i[2]=1;break;default:i[0]=1,i[1]=0,i[2]=l}return o=(1-r)*n,[255*(r*i[0]+o),255*(r*i[1]+o),255*(r*i[2]+o)]},a.hcg.hsv=function(t){var e=t[1]/100,r=e+t[2]/100*(1-e),n=0;return r>0&&(n=e/r),[t[0],100*n,100*r]},a.hcg.hsl=function(t){var e=t[1]/100,r=t[2]/100*(1-e)+.5*e,n=0;return r>0&&r<.5?n=e/(2*r):r>=.5&&r<1&&(n=e/(2*(1-r))),[t[0],100*n,100*r]},a.hcg.hwb=function(t){var e=t[1]/100,r=e+t[2]/100*(1-e);return[t[0],100*(r-e),100*(1-r)]},a.hwb.hcg=function(t){var e=t[1]/100,r=1-t[2]/100,n=r-e,o=0;return n<1&&(o=(r-n)/(1-n)),[t[0],100*n,100*o]},a.apple.rgb=function(t){return[t[0]/65535*255,t[1]/65535*255,t[2]/65535*255]},a.rgb.apple=function(t){return[t[0]/255*65535,t[1]/255*65535,t[2]/255*65535]},a.gray.rgb=function(t){return[t[0]/100*255,t[0]/100*255,t[0]/100*255]},a.gray.hsl=a.gray.hsv=function(t){return[0,0,t[0]]},a.gray.hwb=function(t){return[0,100,t[0]]},a.gray.cmyk=function(t){return[0,0,0,t[0]]},a.gray.lab=function(t){return[t[0],0,0]},a.gray.hex=function(t){var e=255&Math.round(t[0]/100*255),r=((e<<16)+(e<<8)+e).toString(16).toUpperCase();return"000000".substring(r.length)+r},a.rgb.gray=function(t){return[(t[0]+t[1]+t[2])/3/255*100]}},function(t,e){var r;r=function(){return this}();try{r=r||new Function("return this")()}catch(t){"object"==typeof window&&(r=window)}t.exports=r},function(t,e,r){"use strict";r(19);
/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/r.d(e,"b",(function(){return o})),r.d(e,"c",(function(){return i})),r.d(e,"a",(function(){return a}));
/**
@license
Copyright (c) 2017 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
window.ShadyDOM,Boolean(!window.ShadyCSS||window.ShadyCSS.nativeCss),window.customElements.polyfillWrapFlushCallback;(n=document.baseURI||window.location.href).substring(0,n.lastIndexOf("/")+1);var n;window.Polymer&&window.Polymer.sanitizeDOMValue;let o=!1;const i=function(t){o=t};let a=!0},function(t,e,r){"use strict";(function(t){var r,n,o=[];function i(t,e){t.super_=e,t.prototype=Object.create(e.prototype,{constructor:{value:t,enumerable:!1,writable:!0,configurable:!0}})}function a(t,e){Object.defineProperty(this,"kind",{value:t,enumerable:!0}),e&&e.length&&Object.defineProperty(this,"path",{value:e,enumerable:!0})}function s(t,e,r){s.super_.call(this,"E",t),Object.defineProperty(this,"lhs",{value:e,enumerable:!0}),Object.defineProperty(this,"rhs",{value:r,enumerable:!0})}function l(t,e){l.super_.call(this,"N",t),Object.defineProperty(this,"rhs",{value:e,enumerable:!0})}function c(t,e){c.super_.call(this,"D",t),Object.defineProperty(this,"lhs",{value:e,enumerable:!0})}function u(t,e,r){u.super_.call(this,"A",t),Object.defineProperty(this,"index",{value:e,enumerable:!0}),Object.defineProperty(this,"item",{value:r,enumerable:!0})}function h(t,e,r){var n=t.slice((r||e)+1||t.length);return t.length=e<0?t.length+e:e,t.push.apply(t,n),t}function d(t){var e=typeof t;return"object"!==e?e:t===Math?"math":null===t?"null":Array.isArray(t)?"array":"[object Date]"===Object.prototype.toString.call(t)?"date":"function"==typeof t.toString&&/^\/.*\//.test(t.toString())?"regexp":"object"}function p(t,e,r,n,o,i,a){a=a||[];var f=(o=o||[]).slice(0);if(void 0!==i){if(n){if("function"==typeof n&&n(f,i))return;if("object"==typeof n){if(n.prefilter&&n.prefilter(f,i))return;if(n.normalize){var g=n.normalize(f,i,t,e);g&&(t=g[0],e=g[1])}}}f.push(i)}"regexp"===d(t)&&"regexp"===d(e)&&(t=t.toString(),e=e.toString());var m=typeof t,b=typeof e,v="undefined"!==m||a&&a[a.length-1].lhs&&a[a.length-1].lhs.hasOwnProperty(i),w="undefined"!==b||a&&a[a.length-1].rhs&&a[a.length-1].rhs.hasOwnProperty(i);if(!v&&w)r(new l(f,e));else if(!w&&v)r(new c(f,t));else if(d(t)!==d(e))r(new s(f,t,e));else if("date"===d(t)&&t-e!=0)r(new s(f,t,e));else if("object"===m&&null!==t&&null!==e)if(a.filter((function(e){return e.lhs===t})).length)t!==e&&r(new s(f,t,e));else{if(a.push({lhs:t,rhs:e}),Array.isArray(t)){var y;t.length;for(y=0;y<t.length;y++)y>=e.length?r(new u(f,y,new c(void 0,t[y]))):p(t[y],e[y],r,n,f,y,a);for(;y<e.length;)r(new u(f,y,new l(void 0,e[y++])))}else{var _=Object.keys(t),x=Object.keys(e);_.forEach((function(o,i){var s=x.indexOf(o);s>=0?(p(t[o],e[o],r,n,f,o,a),x=h(x,s)):p(t[o],void 0,r,n,f,o,a)})),x.forEach((function(t){p(void 0,e[t],r,n,f,t,a)}))}a.length=a.length-1}else t!==e&&("number"===m&&isNaN(t)&&isNaN(e)||r(new s(f,t,e)))}function f(t,e,r,n){return n=n||[],p(t,e,(function(t){t&&n.push(t)}),r),n.length?n:void 0}function g(t,e,r){if(t&&e&&r&&r.kind){for(var n=t,o=-1,i=r.path?r.path.length-1:0;++o<i;)void 0===n[r.path[o]]&&(n[r.path[o]]="number"==typeof r.path[o]?[]:{}),n=n[r.path[o]];switch(r.kind){case"A":!function t(e,r,n){if(n.path&&n.path.length){var o,i=e[r],a=n.path.length-1;for(o=0;o<a;o++)i=i[n.path[o]];switch(n.kind){case"A":t(i[n.path[o]],n.index,n.item);break;case"D":delete i[n.path[o]];break;case"E":case"N":i[n.path[o]]=n.rhs}}else switch(n.kind){case"A":t(e[r],n.index,n.item);break;case"D":e=h(e,r);break;case"E":case"N":e[r]=n.rhs}return e}(r.path?n[r.path[o]]:n,r.index,r.item);break;case"D":delete n[r.path[o]];break;case"E":case"N":n[r.path[o]]=r.rhs}}}r="object"==typeof t&&t?t:"undefined"!=typeof window?window:{},(n=r.DeepDiff)&&o.push((function(){void 0!==n&&r.DeepDiff===f&&(r.DeepDiff=n,n=void 0)})),i(s,a),i(l,a),i(c,a),i(u,a),Object.defineProperties(f,{diff:{value:f,enumerable:!0},observableDiff:{value:p,enumerable:!0},applyDiff:{value:function(t,e,r){if(t&&e){p(t,e,(function(n){r&&!r(t,e,n)||g(t,e,n)}))}},enumerable:!0},applyChange:{value:g,enumerable:!0},revertChange:{value:function(t,e,r){if(t&&e&&r&&r.kind){var n,o,i=t;for(o=r.path.length-1,n=0;n<o;n++)void 0===i[r.path[n]]&&(i[r.path[n]]={}),i=i[r.path[n]];switch(r.kind){case"A":!function t(e,r,n){if(n.path&&n.path.length){var o,i=e[r],a=n.path.length-1;for(o=0;o<a;o++)i=i[n.path[o]];switch(n.kind){case"A":t(i[n.path[o]],n.index,n.item);break;case"D":case"E":i[n.path[o]]=n.lhs;break;case"N":delete i[n.path[o]]}}else switch(n.kind){case"A":t(e[r],n.index,n.item);break;case"D":case"E":e[r]=n.lhs;break;case"N":e=h(e,r)}return e}(i[r.path[n]],r.index,r.item);break;case"D":case"E":i[r.path[n]]=r.lhs;break;case"N":delete i[r.path[n]]}}},enumerable:!0},isConflict:{value:function(){return void 0!==n},enumerable:!0},noConflict:{value:function(){return o&&(o.forEach((function(t){t()})),o=null),f},enumerable:!0}}),e.a=f}).call(this,r(25))},function(t,e,r){"use strict";function n(t){var e,r=t.Symbol;return"function"==typeof r?r.observable?e=r.observable:(e=r("observable"),r.observable=e):e="@@observable",e}r.d(e,"a",(function(){return n}))},function(t,e,r){"use strict";var n=r(0);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/n.c`<svg height="24" viewBox="0 0 24 24" width="24"><path d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path></svg>`,n.c`<svg height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0zm18.31 6l-2.76 5z" fill="none"/><path id="cart-path" d="M11 9h2V6h3V4h-3V1h-2v3H8v2h3v3zm-4 9c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zm10 0c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2zm-9.83-3.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.86-7.01L19.42 4h-.01l-1.1 2-2.76 5H8.53l-.13-.27L6.16 6l-.95-2-.94-2H1v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.13 0-.25-.11-.25-.25z"/></svg>`,n.c`<svg height="24" viewBox="0 0 24 24" width="24"><path d="M22.73 22.73L2.77 2.77 2 2l-.73-.73L0 2.54l4.39 4.39 2.21 4.66-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h7.46l1.38 1.38c-.5.36-.83.95-.83 1.62 0 1.1.89 2 1.99 2 .67 0 1.26-.33 1.62-.84L21.46 24l1.27-1.27zM7.42 15c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h2.36l2 2H7.42zm8.13-2c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H6.54l9.01 9zM7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2z"/><path d="M0 0h24v24H0z" fill="none"/></svg>`,n.c`<svg height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M7 11v2h10v-2H7zm5-9C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>`,n.c`<svg height="24" viewBox="0 0 24 24" width="24"><path d="M0 0h24v24H0z" fill="none"/><path d="M13 7h-2v4H7v2h4v4h2v-4h4v-2h-4V7zm-1-5C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 18c-4.41 0-8-3.59-8-8s3.59-8 8-8 8 3.59 8 8-3.59 8-8 8z"/></svg>`},function(t,e,r){"use strict";var n=r(3),o=r.n(n);const i={red:{uiColor:o.a.rgb(238,54,54),moduleColor:o()("red"),uiColorString:"rgb(238, 54, 54)",uiColorName:"red"},green:{uiColor:o.a.rgb(1,207,88),moduleColor:o()("green"),uiColorString:"rgb(1, 207, 88)",uiColorName:"green"},blue:{uiColor:o.a.rgb(17,169,255),moduleColor:o()("blue"),uiColorString:"rgb(17, 169, 255)",uiColorName:"blue"},yellow:{uiColor:o.a.rgb(252,187,64),moduleColor:o()("yellow"),uiColorString:"rgb(252, 187, 64)",uiColorName:"yellow"},white:{uiColor:o.a.rgb(255,255,255),moduleColor:o()("white"),uiColorString:"rgb(255, 255, 255)",uiColorName:"white"}};e.a=i},function(t,e){!function(e){"use strict";var r=Object.prototype,n=r.hasOwnProperty,o="function"==typeof Symbol?Symbol:{},i=o.iterator||"@@iterator",a=o.asyncIterator||"@@asyncIterator",s=o.toStringTag||"@@toStringTag",l="object"==typeof t,c=e.regeneratorRuntime;if(c)l&&(t.exports=c);else{(c=e.regeneratorRuntime=l?t.exports:{}).wrap=g;var u={},h={};h[i]=function(){return this};var d=Object.getPrototypeOf,p=d&&d(d(E([])));p&&p!==r&&n.call(p,i)&&(h=p);var f=w.prototype=b.prototype=Object.create(h);v.prototype=f.constructor=w,w.constructor=v,w[s]=v.displayName="GeneratorFunction",c.isGeneratorFunction=function(t){var e="function"==typeof t&&t.constructor;return!!e&&(e===v||"GeneratorFunction"===(e.displayName||e.name))},c.mark=function(t){return Object.setPrototypeOf?Object.setPrototypeOf(t,w):(t.__proto__=w,s in t||(t[s]="GeneratorFunction")),t.prototype=Object.create(f),t},c.awrap=function(t){return{__await:t}},y(_.prototype),_.prototype[a]=function(){return this},c.AsyncIterator=_,c.async=function(t,e,r,n){var o=new _(g(t,e,r,n));return c.isGeneratorFunction(e)?o:o.next().then((function(t){return t.done?t.value:o.next()}))},y(f),f[s]="Generator",f[i]=function(){return this},f.toString=function(){return"[object Generator]"},c.keys=function(t){var e=[];for(var r in t)e.push(r);return e.reverse(),function r(){for(;e.length;){var n=e.pop();if(n in t)return r.value=n,r.done=!1,r}return r.done=!0,r}},c.values=E,C.prototype={constructor:C,reset:function(t){if(this.prev=0,this.next=0,this.sent=this._sent=void 0,this.done=!1,this.delegate=null,this.method="next",this.arg=void 0,this.tryEntries.forEach(S),!t)for(var e in this)"t"===e.charAt(0)&&n.call(this,e)&&!isNaN(+e.slice(1))&&(this[e]=void 0)},stop:function(){this.done=!0;var t=this.tryEntries[0].completion;if("throw"===t.type)throw t.arg;return this.rval},dispatchException:function(t){if(this.done)throw t;var e=this;function r(r,n){return a.type="throw",a.arg=t,e.next=r,n&&(e.method="next",e.arg=void 0),!!n}for(var o=this.tryEntries.length-1;o>=0;--o){var i=this.tryEntries[o],a=i.completion;if("root"===i.tryLoc)return r("end");if(i.tryLoc<=this.prev){var s=n.call(i,"catchLoc"),l=n.call(i,"finallyLoc");if(s&&l){if(this.prev<i.catchLoc)return r(i.catchLoc,!0);if(this.prev<i.finallyLoc)return r(i.finallyLoc)}else if(s){if(this.prev<i.catchLoc)return r(i.catchLoc,!0)}else{if(!l)throw new Error("try statement without catch or finally");if(this.prev<i.finallyLoc)return r(i.finallyLoc)}}}},abrupt:function(t,e){for(var r=this.tryEntries.length-1;r>=0;--r){var o=this.tryEntries[r];if(o.tryLoc<=this.prev&&n.call(o,"finallyLoc")&&this.prev<o.finallyLoc){var i=o;break}}i&&("break"===t||"continue"===t)&&i.tryLoc<=e&&e<=i.finallyLoc&&(i=null);var a=i?i.completion:{};return a.type=t,a.arg=e,i?(this.method="next",this.next=i.finallyLoc,u):this.complete(a)},complete:function(t,e){if("throw"===t.type)throw t.arg;return"break"===t.type||"continue"===t.type?this.next=t.arg:"return"===t.type?(this.rval=this.arg=t.arg,this.method="return",this.next="end"):"normal"===t.type&&e&&(this.next=e),u},finish:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var r=this.tryEntries[e];if(r.finallyLoc===t)return this.complete(r.completion,r.afterLoc),S(r),u}},catch:function(t){for(var e=this.tryEntries.length-1;e>=0;--e){var r=this.tryEntries[e];if(r.tryLoc===t){var n=r.completion;if("throw"===n.type){var o=n.arg;S(r)}return o}}throw new Error("illegal catch attempt")},delegateYield:function(t,e,r){return this.delegate={iterator:E(t),resultName:e,nextLoc:r},"next"===this.method&&(this.arg=void 0),u}}}function g(t,e,r,n){var o=e&&e.prototype instanceof b?e:b,i=Object.create(o.prototype),a=new C(n||[]);return i._invoke=function(t,e,r){var n="suspendedStart";return function(o,i){if("executing"===n)throw new Error("Generator is already running");if("completed"===n){if("throw"===o)throw i;return O()}for(r.method=o,r.arg=i;;){var a=r.delegate;if(a){var s=x(a,r);if(s){if(s===u)continue;return s}}if("next"===r.method)r.sent=r._sent=r.arg;else if("throw"===r.method){if("suspendedStart"===n)throw n="completed",r.arg;r.dispatchException(r.arg)}else"return"===r.method&&r.abrupt("return",r.arg);n="executing";var l=m(t,e,r);if("normal"===l.type){if(n=r.done?"completed":"suspendedYield",l.arg===u)continue;return{value:l.arg,done:r.done}}"throw"===l.type&&(n="completed",r.method="throw",r.arg=l.arg)}}}(t,r,a),i}function m(t,e,r){try{return{type:"normal",arg:t.call(e,r)}}catch(t){return{type:"throw",arg:t}}}function b(){}function v(){}function w(){}function y(t){["next","throw","return"].forEach((function(e){t[e]=function(t){return this._invoke(e,t)}}))}function _(t){var e;this._invoke=function(r,o){function i(){return new Promise((function(e,i){!function e(r,o,i,a){var s=m(t[r],t,o);if("throw"!==s.type){var l=s.arg,c=l.value;return c&&"object"==typeof c&&n.call(c,"__await")?Promise.resolve(c.__await).then((function(t){e("next",t,i,a)}),(function(t){e("throw",t,i,a)})):Promise.resolve(c).then((function(t){l.value=t,i(l)}),a)}a(s.arg)}(r,o,e,i)}))}return e=e?e.then(i,i):i()}}function x(t,e){var r=t.iterator[e.method];if(void 0===r){if(e.delegate=null,"throw"===e.method){if(t.iterator.return&&(e.method="return",e.arg=void 0,x(t,e),"throw"===e.method))return u;e.method="throw",e.arg=new TypeError("The iterator does not provide a 'throw' method")}return u}var n=m(r,t.iterator,e.arg);if("throw"===n.type)return e.method="throw",e.arg=n.arg,e.delegate=null,u;var o=n.arg;return o?o.done?(e[t.resultName]=o.value,e.next=t.nextLoc,"return"!==e.method&&(e.method="next",e.arg=void 0),e.delegate=null,u):o:(e.method="throw",e.arg=new TypeError("iterator result is not an object"),e.delegate=null,u)}function k(t){var e={tryLoc:t[0]};1 in t&&(e.catchLoc=t[1]),2 in t&&(e.finallyLoc=t[2],e.afterLoc=t[3]),this.tryEntries.push(e)}function S(t){var e=t.completion||{};e.type="normal",delete e.arg,t.completion=e}function C(t){this.tryEntries=[{tryLoc:"root"}],t.forEach(k,this),this.reset(!0)}function E(t){if(t){var e=t[i];if(e)return e.call(t);if("function"==typeof t.next)return t;if(!isNaN(t.length)){var r=-1,o=function e(){for(;++r<t.length;)if(n.call(t,r))return e.value=t[r],e.done=!1,e;return e.value=void 0,e.done=!0,e};return o.next=o}}return{next:O}}function O(){return{value:void 0,done:!0}}}(function(){return this}()||Function("return this")())},function(t,e){
/**
@license @nocompile
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
!function(){"use strict";!function(){if(void 0===window.Reflect||void 0===window.customElements||window.customElements.polyfillWrapFlushCallback)return;const t=HTMLElement;window.HTMLElement={HTMLElement:function(){return Reflect.construct(t,[],this.constructor)}}.HTMLElement,HTMLElement.prototype=t.prototype,HTMLElement.prototype.constructor=HTMLElement,Object.setPrototypeOf(HTMLElement,t)}()}()},function(t,e,r){var n=r(23),o=r(34),i={};for(var a in n)n.hasOwnProperty(a)&&(i[n[a]]=a);var s=t.exports={to:{},get:{}};function l(t,e,r){return Math.min(Math.max(e,t),r)}function c(t){var e=t.toString(16).toUpperCase();return e.length<2?"0"+e:e}s.get=function(t){var e,r;switch(t.substring(0,3).toLowerCase()){case"hsl":e=s.get.hsl(t),r="hsl";break;case"hwb":e=s.get.hwb(t),r="hwb";break;default:e=s.get.rgb(t),r="rgb"}return e?{model:r,value:e}:null},s.get.rgb=function(t){if(!t)return null;var e,r,o,i=[0,0,0,1];if(e=t.match(/^#([a-f0-9]{6})([a-f0-9]{2})?$/i)){for(o=e[2],e=e[1],r=0;r<3;r++){var a=2*r;i[r]=parseInt(e.slice(a,a+2),16)}o&&(i[3]=Math.round(parseInt(o,16)/255*100)/100)}else if(e=t.match(/^#([a-f0-9]{3,4})$/i)){for(o=(e=e[1])[3],r=0;r<3;r++)i[r]=parseInt(e[r]+e[r],16);o&&(i[3]=Math.round(parseInt(o+o,16)/255*100)/100)}else if(e=t.match(/^rgba?\(\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*,\s*([+-]?\d+)\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/)){for(r=0;r<3;r++)i[r]=parseInt(e[r+1],0);e[4]&&(i[3]=parseFloat(e[4]))}else{if(!(e=t.match(/^rgba?\(\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*,\s*([+-]?[\d\.]+)\%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/)))return(e=t.match(/(\D+)/))?"transparent"===e[1]?[0,0,0,0]:(i=n[e[1]])?(i[3]=1,i):null:null;for(r=0;r<3;r++)i[r]=Math.round(2.55*parseFloat(e[r+1]));e[4]&&(i[3]=parseFloat(e[4]))}for(r=0;r<3;r++)i[r]=l(i[r],0,255);return i[3]=l(i[3],0,1),i},s.get.hsl=function(t){if(!t)return null;var e=t.match(/^hsla?\(\s*([+-]?(?:\d*\.)?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/);if(e){var r=parseFloat(e[4]);return[(parseFloat(e[1])+360)%360,l(parseFloat(e[2]),0,100),l(parseFloat(e[3]),0,100),l(isNaN(r)?1:r,0,1)]}return null},s.get.hwb=function(t){if(!t)return null;var e=t.match(/^hwb\(\s*([+-]?\d*[\.]?\d+)(?:deg)?\s*,\s*([+-]?[\d\.]+)%\s*,\s*([+-]?[\d\.]+)%\s*(?:,\s*([+-]?[\d\.]+)\s*)?\)$/);if(e){var r=parseFloat(e[4]);return[(parseFloat(e[1])%360+360)%360,l(parseFloat(e[2]),0,100),l(parseFloat(e[3]),0,100),l(isNaN(r)?1:r,0,1)]}return null},s.to.hex=function(){var t=o(arguments);return"#"+c(t[0])+c(t[1])+c(t[2])+(t[3]<1?c(Math.round(255*t[3])):"")},s.to.rgb=function(){var t=o(arguments);return t.length<4||1===t[3]?"rgb("+Math.round(t[0])+", "+Math.round(t[1])+", "+Math.round(t[2])+")":"rgba("+Math.round(t[0])+", "+Math.round(t[1])+", "+Math.round(t[2])+", "+t[3]+")"},s.to.rgb.percent=function(){var t=o(arguments),e=Math.round(t[0]/255*100),r=Math.round(t[1]/255*100),n=Math.round(t[2]/255*100);return t.length<4||1===t[3]?"rgb("+e+"%, "+r+"%, "+n+"%)":"rgba("+e+"%, "+r+"%, "+n+"%, "+t[3]+")"},s.to.hsl=function(){var t=o(arguments);return t.length<4||1===t[3]?"hsl("+t[0]+", "+t[1]+"%, "+t[2]+"%)":"hsla("+t[0]+", "+t[1]+"%, "+t[2]+"%, "+t[3]+")"},s.to.hwb=function(){var t=o(arguments),e="";return t.length>=4&&1!==t[3]&&(e=", "+t[3]),"hwb("+t[0]+", "+t[1]+"%, "+t[2]+"%"+e+")"},s.to.keyword=function(t){return i[t.slice(0,3)]}},function(t,e,r){"use strict";var n=r(35),o=Array.prototype.concat,i=Array.prototype.slice,a=t.exports=function(t){for(var e=[],r=0,a=t.length;r<a;r++){var s=t[r];n(s)?e=o.call(e,i.call(s)):e.push(s)}return e};a.wrap=function(t){return function(){return t(a(arguments))}}},function(t,e){t.exports=function(t){return!(!t||"string"==typeof t)&&(t instanceof Array||Array.isArray(t)||t.length>=0&&(t.splice instanceof Function||Object.getOwnPropertyDescriptor(t,t.length-1)&&"String"!==t.constructor.name))}},function(t,e,r){var n=r(24),o=r(37),i={};Object.keys(n).forEach((function(t){i[t]={},Object.defineProperty(i[t],"channels",{value:n[t].channels}),Object.defineProperty(i[t],"labels",{value:n[t].labels});var e=o(t);Object.keys(e).forEach((function(r){var n=e[r];i[t][r]=function(t){var e=function(e){if(null==e)return e;arguments.length>1&&(e=Array.prototype.slice.call(arguments));var r=t(e);if("object"==typeof r)for(var n=r.length,o=0;o<n;o++)r[o]=Math.round(r[o]);return r};return"conversion"in t&&(e.conversion=t.conversion),e}(n),i[t][r].raw=function(t){var e=function(e){return null==e?e:(arguments.length>1&&(e=Array.prototype.slice.call(arguments)),t(e))};return"conversion"in t&&(e.conversion=t.conversion),e}(n)}))})),t.exports=i},function(t,e,r){var n=r(24);function o(t){var e=function(){for(var t={},e=Object.keys(n),r=e.length,o=0;o<r;o++)t[e[o]]={distance:-1,parent:null};return t}(),r=[t];for(e[t].distance=0;r.length;)for(var o=r.pop(),i=Object.keys(n[o]),a=i.length,s=0;s<a;s++){var l=i[s],c=e[l];-1===c.distance&&(c.distance=e[o].distance+1,c.parent=o,r.unshift(l))}return e}function i(t,e){return function(r){return e(t(r))}}function a(t,e){for(var r=[e[t].parent,t],o=n[e[t].parent][t],a=e[t].parent;e[a].parent;)r.unshift(e[a].parent),o=i(n[e[a].parent][a],o),a=e[a].parent;return o.conversion=r,o}t.exports=function(t){for(var e=o(t),r={},n=Object.keys(e),i=n.length,s=0;s<i;s++){var l=n[s];null!==e[l].parent&&(r[l]=a(l,e))}return r}},function(t,e){t.exports=function(t){if(!t.webpackPolyfill){var e=Object.create(t);e.children||(e.children=[]),Object.defineProperty(e,"loaded",{enumerable:!0,get:function(){return e.l}}),Object.defineProperty(e,"id",{enumerable:!0,get:function(){return e.i}}),Object.defineProperty(e,"exports",{enumerable:!0}),e.webpackPolyfill=1}return e}},function(t,e,r){"use strict";r.r(e);r(31),r(32);var n=r(0),o=r(26),i=r(20),a=r(15),s=r(4),l=(r(29),r(17));class c extends n.a{static get is(){return"moduware-header"}static get properties(){return{title:{type:String},backButtonIcon:{type:String},platform:{type:String,reflect:!0}}}constructor(){super(),this.title="Tile",this.platform=Object(l.a)(),this.backButtonIcon=""}static get styles(){return[n.b`
        :host([hidden]) {
          display: none;
        }

        :host,
        *,
        * * {
          box-sizing: border-box;
        }
      
        svg {
          width: auto;
        }
      
        :host {
          --style-font-family: Roboto, 'Roboto Regular', Helvetica, Tahoma, sans-serif;
          --style-font-size: 16px;
          --style-background-color: white;
      
          --ios-header-height: 44px;
          --android-header-height: 55px;
          --header-side-padding: 3vw;
      
          --font-size-android: 15px;
          --title-selection-line-height: 45px;
      
          --brand-color: #D02E3D;
          --gray-color: #606060;
          --title-selecting-border-color: #E4E4E4;
      
          --text-color: var(--gray-color);
          --secondary-text-color: var(--gray-color);
          --style-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
          --style-shadow-android: 0 2px 4px rgba(0, 0, 0, 0.12);
        }
      
        :host {
          z-index: var(--header-z-index, 1);
          position: fixed;
          top: 0;
          left: 0;
      
          width: 100vw;
          height: var(--ios-header-height);
          padding: 0;
      
          font-size: var(--style-font-size);
          font-weight: normal;
          line-height: var(--ios-header-height);
          color: var(--text-color);
          font-family: var(--style-font-family);
          text-align: right;
      
          background-color: var(--style-background-color);
          -webkit-user-select: none;
          user-select: none;
        }
      
        :host([platform="ios"]:not(.nxp-no-shadow)) {
          border-color: #C8C7CC;
          border-style: solid;
          border-width: 0 0 0.5px 0;
        }
      
        :host([platform="android"]) {
          height: var(--android-header-height);
          padding: 0 var(--header-side-padding);
          line-height: var(--android-header-height);
          color: var(--gray-color);
      
          font-size: var(--font-size-android);
          font-weight: 300;
        }
      
        :host([platform="android"]:not(.nxp-no-shadow)) {
          box-shadow: var(--style-shadow-android);
        }
      
        button {
          padding: 0;
          margin: 0;
          background: none;
          border: 0;
          outline: none;
        }
      
        .title {
          z-index: -1;
          position: absolute;
          top: 0;
          left: 0;
      
          width: 100%;
          height: 100%;
          margin: 0;
      
          text-align: center;
          font-size: calc(var(--style-font-size) + 1px);
          line-height: inherit;
          text-transform: inherit;
          color: inherit;
          font-weight: 400;
      
          background-color: transparent;
        }
      
        :host([platform="android"])>h1 {
          text-align: left;
          font-size: calc(var(--font-size-android) + 5px);
          padding-left: 70px;
        }
      
        :host([platform="android"].nxp-back-button-hidden)>h1 {
          padding-left: 16px;
        }
      
        .back-button {
          padding: 0 var(--header-side-padding) !important;
          line-height: inherit;
        }
      
        :host(:not([platform="android"])) .nxp-button-back-android,
        :host([platform="android"]) .nxp-button-back-ios {
          display: none;
        }
      
        :host([platform="android"]) .back-button svg {
          margin-top: -4px;
        }
      
        .back-button-icon {
          display: inline-block;
        }
      
        .nxp-custom-back-button .nxp-button-back-android,
        .nxp-custom-back-button .nxp-button-back-ios {
          display: none;
        }
      
        .nxp-buttons-container {
          display: inline-block;
        }
      
        .nxp-buttons-container.nxp-buttons-container--disabled {
          opacity: 0.3;
          pointer-events: none;
        }
      
        .nxp-buttons-container>button {
          line-height: inherit;
          padding: 0 4vw !important;
          position: relative;
        }
      
        :host([platform="ios"]) .nxp-buttons-container>button {
          color: #D02E3D;
          font-size: 17px;
        }
      
        .nxp-buttons-container>button .nxp-button-number {
          position: absolute;
          top: 50%;
          left: 50%;
          transform: translateX(15%) translateY(-85%);
          padding-right: 1px;
      
          display: flex;
          justify-content: center;
          align-items: center;
      
          height: 18px;
          min-width: 18px;
          border: 2px solid white;
          border-radius: 9px;
      
          background-color: #01CF9F;
          font-size: 10px;
          color: white;
          line-height: 1em;
        }
      
        .nxp-buttons-container>button .nxp-button-number:empty {
          display: none;
        }
      
        .nxp-buttons-container>button:last-child {
          padding-right: var(--header-side-padding) !important;
        }
      
        .back-button svg,
        .back-button img,
        .nxp-buttons-container>button>svg,
        .nxp-buttons-container>button>img {
          vertical-align: middle;
        }
      
        .back-button {
          float: left;
          max-width: var(--ios-header-height);
        }

        :host ::slotted([slot='right-placeholder']) {
          vertical-align: middle;
          display: inline-flex;
          color: #d12f3d;
        }
        
        :host([platform='ios']) ::slotted([slot='right-placeholder']) {
          padding-right: var(--header-side-padding);
        }
      `]}render(){return n.c`
      <h1 class="title">${this.title}</h1>
      <button class="back-button" @click="${this.backButtonTapHandler}">
        ${""==this.backButtonIcon?this.getBackButtonIcon():n.c`<img src="${this.backButtonIcon}" class="back-button-icon">`}
      </button>
      <div class="nxp-buttons-container" id="nxp-buttons-container"></div>
      <slot name="right-placeholder"></slot>
    `}getBackButtonIcon(){return"ios"==this.platform?n.c`
            <svg width="12px" height="15px" viewBox="8 35 12 15" class="back-button-icon nxp-button-back-ios">
              <path d="M10.0158703,41.9904883 C9.9622537,41.6002828 10.0847659,41.1909469 10.3798254,40.8958873 L15.8958873,35.3798254 C16.4016182,34.8740945 17.2192549,34.8717794 17.7300286,35.3825531 C18.2372659,35.8897904 18.2323789,36.7170716 17.7327562,37.2166943 L12.9476424,42.0018082 L17.7327562,46.786922 C18.2384871,47.2926529 18.2408023,48.1102896 17.7300286,48.6210633 C17.2227913,49.1283006 16.39551,49.1234135 15.8958873,48.6237909 L10.3798254,43.107729 C10.0754324,42.8033359 9.95341094,42.3859492 10.0158703,41.9904883 Z"
                id="Combined-Shape" stroke="none" fill="#D02E3D" fill-rule="evenodd"></path>
            </svg>
          `:n.c`
        <svg width="16px" height="16px" viewBox="0 0 16 16" class="back-button-icon nxp-button-back-android">
          <polygon class="nxp-svg-shape" transform="translate(-4,-4)" fill-rule="evenodd" fill="#D02E3D" points="20 11 7.8 11 13.4 5.4 12 4 4 12 12 20 13.4 18.6 7.8 13 20 13"></polygon>
        </svg>
      `}backButtonTapHandler(t){this.dispatchEvent(new CustomEvent("back-button-click",{}))}}window.customElements.define(c.is,c);var u=r(10),h=r(22),d=r(8);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
class p extends(Object(i.a)(a.a)(n.a)){static get properties(){return{platform:{type:String,reflect:!0},appTitle:{type:String},_headerTitle:{type:String},_page:{type:String},_language:{type:String},_currentUiColorName:{type:String}}}static get styles(){return[d.d,d.e,d.g,d.h,d.i,d.a,d.b,d.c,d.f,d.j,d.k,d.l,d.n,d.m,n.b`
        :host {
          display: flex;
          height: 100%;

          --app-drawer-width: 256px;

          --app-primary-color: #E91E63;
          --app-secondary-color: #293237;
          --app-dark-text-color: var(--app-secondary-color);
          --app-light-text-color: white;
          --app-section-even-color: #f7f7f7;
          --app-section-odd-color: white;

          --app-header-background-color: transparent;
          --app-header-text-color: var(--app-dark-text-color);
          --app-header-selected-color: var(--app-primary-color);

          --app-drawer-background-color: var(--app-secondary-color);
          --app-drawer-text-color: var(--app-light-text-color);
          --app-drawer-selected-color: #78909C;
        }

        moduware-header {
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          text-align: center;
          background-color: var(--app-header-background-color);
          color: var(--app-header-text-color);
          /*border-bottom: 1px solid #eee;*/
          border: none;
          box-shadow: none;
          --back-button-color: black;
        }

        .toolbar-top {
          background-color: var(--app-header-background-color);
        }

        [main-title] {
          font-family: 'Pacifico';
          text-transform: lowercase;
          font-size: 30px;
          /* In the narrow layout, the toolbar is offset by the width of the
          drawer button, and the text looks not centered. Add a padding to
          match that button */
          padding-right: 44px;
        }

        .toolbar-list {
          display: none;
        }

        .toolbar-list > a {
          display: inline-block;
          color: var(--app-header-text-color);
          text-decoration: none;
          line-height: 30px;
          padding: 4px 24px;
        }

        .toolbar-list > a[selected] {
          color: var(--app-header-selected-color);
          border-bottom: 4px solid var(--app-header-selected-color);
        }

        .menu-btn {
          background: none;
          border: none;
          fill: var(--app-header-text-color);
          cursor: pointer;
          height: 44px;
          width: 44px;
        }

        .drawer-list {
          box-sizing: border-box;
          width: 100%;
          height: 100%;
          padding: 24px;
          background: var(--app-drawer-background-color);
          position: relative;
        }

        .drawer-list > a {
          display: block;
          text-decoration: none;
          color: var(--app-drawer-text-color);
          line-height: 40px;
          padding: 0 24px;
        }

        .drawer-list > a[selected] {
          color: var(--app-drawer-selected-color);
        }

        /* Workaround for IE11 displaying <main> as inline */
        main {
          display: block;
        }

        .main-content {
          display: flex;
          box-sizing: border-box;
          /*min-height: 100vh;*/
          min-height: auto;
          flex-grow: 1;
        }

      :host([platform="android"]) .main-content {
        padding-top: 55px;
      }

      :host([platform="ios"]) .main-content {
        padding-top: 44px;
      }

        .page {
          display: none;
          flex-grow: 1;
          position: relative;
        }

        .page[active] {
          display: block;
        }

        footer {
          padding: 24px;
          background: var(--app-drawer-background-color);
          color: var(--app-drawer-text-color);
          text-align: center;
        }

        /* Wide layout: when the viewport width is bigger than 460px, layout
        changes to a wide layout */
        @media (min-width: 460px) {
          .toolbar-list {
            display: block;
          }

          .menu-btn {
            display: none;
          }

          .main-content {
            padding-top: 107px;
          }

          /* The drawer button isn't shown in the wide layout, so we don't
          need to offset the title */
          [main-title] {
            padding-right: 0px;
          }
        }
      `]}render(){return n.c`
      <!-- Webview Header -->
      <moduware-header
        @back-button-click="${()=>a.a.dispatch(Object(s.q)())}"
        title="${this._headerTitle}"
        style="color: ${"pallet-page"!=this._page||"white"==this._currentUiColorName?"black":"white"}; --back-button-color: ${"pallet-page"!=this._page||"white"==this._currentUiColorName?"black":"white"};" >
			</moduware-header>
			<!-- Main content -->
			<main role="main" class="main-content">
					<home-page class="page" ?active="${"home-page"===this._page}"></home-page>
					<pallet-page class="page" ?active="${"pallet-page"===this._page}"></pallet-page>
					<wheel-page class="page" ?active="${"wheel-page"===this._page}"></wheel-page>
					<themes-page class="page" ?active="${"themes-page"===this._page}"></themes-page>
					<error-page class="page" ?active="${"error-page"===this._page}"></error-page>
			</main>
    `}constructor(){super(),a.a.dispatch(Object(s.p)()),Object(o.c)(!0)}async connectedCallback(){Object(u.b)({loader:t=>Promise.resolve(h[t])}),super.connectedCallback()}firstUpdated(){a.a.dispatch(Object(s.s)("/home-page")),a.a.dispatch(Object(s.r)()),a.a.dispatch(Object(s.A)(Object(u.a)("home-page.title")))}updated(t){t.has("_page"),t.has("_language")&&Object(u.d)(this._language)}stateChanged(t){this.platform=t.app.platform,this._page=t.app.page,this._language=t.app.language,this._headerTitle=t.app.headerTitle,this._currentUiColorName=t.app.currentUiColorName}}window.customElements.define("my-app",p)}]);