(window.webpackJsonp=window.webpackJsonp||[]).push([[6],{40:function(t,e,a){"use strict";a.d(e,"a",(function(){return n}));var s=a(0);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/class n extends s.a{shouldUpdate(){return this.active}static get properties(){return{active:{type:Boolean}}}}},43:function(t,e,a){"use strict";a.r(e);var s=a(0),n=a(40),l=a(4),r=a(15),o=a(20),i=a(8),c=(a(21),a(29),a(10)),h=a(22),d=a(41),p=(a(30),a(2)),g=a(3),_=a.n(g);
/**
@license
Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
Code distributed by Google as part of the polymer project is also
subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
*/
class u extends(Object(o.a)(r.a)(n.a)){render(){return s.c`
		<div data-color="white" id="wrapper" class="wrapper">
			<div class="page page__controls ">
				<div class="picker-controls">
          <div class="wheel-control">
            <div class="wheel" id="colorWheel"></div>
          </div>
          <div class="brightness-control">
            <!-- <div id="textbox">
              <p class="alignleft">Darker</p>
              <p class="alignright">Lighter</p>
            </div> -->
            <div class="brightness-control__labels">
              <span class="brightness-control__label brightness-control__label--left">${Object(c.c)("brightness.darker")}</span>
              <span class="brightness-control__label brightness-control__label--right">${Object(c.c)("brightness.lighter")}</span>
            </div>
            <div class="brightness-control__range-container" id="range-container">
              <input type="range" id="nxprange" class="brightness-control__range" min="-1" max="1" step="0.01" value="${this._lightness}" @input="${t=>this._lightnessChangeHandler(t)}" >
              <div class="brightness-control__range-track-filled" id="brightness-control__range-track-filled"></div>
              <div class="brightness-control__range-thumb" id="brightness-control__range-thumb"></div>
            </div>
            <!-- <output for="nxprange" id="position"></output> -->
          </div>
				</div> <!-- /.picker-controls -->
        <div class="shared-controls">
          <button class="led-button ${this._mainLightState===p.a.On?"active":""}" id="power-button2"  @click="${()=>this._powerButtonClickHandler()}">
            <svg width="128px" height="128px" viewBox="0 0 128 128" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
              <g stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">
                  <g transform="translate(-116.000000, -256.000000)">
                      <g transform="translate(116.000000, 256.000000)">
                          <circle stroke="#000000" stroke-width="5" cx="64" cy="64" r="61.5" class="button-circle" style="stroke: transparent;"></circle>
                          <path d="M79.5,45.75 C85.166695,50.5833575 88,56.66663 88,64 C88,70.6667 85.66669,76.33331 81,81 C76.33331,85.66669 70.6667,88 64,88 C57.3333,88 51.66669,85.66669 47,81 C42.33331,76.33331 40,70.6667 40,64 C40,56.66663 42.833305,50.5833575 48.5,45.75 L52.25,49.5 C47.6666437,53.2500187 45.375,58.0833037 45.375,64 C45.375,69.1666925 47.1874819,73.5624819 50.8125,77.1875 C54.4375181,80.8125181 58.8333075,82.625 64,82.625 C69.1666925,82.625 73.5624819,80.8125181 77.1875,77.1875 C80.8125181,73.5624819 82.625,69.1666925 82.625,64 C82.625,58.0833037 80.3333563,53.291685 75.75,49.625 L79.5,45.75 Z M66.625,40 L66.625,66.625 L61.375,66.625 L61.375,40 L66.625,40 Z" fill="#000000" class="button-path"></path>
                      </g>
                  </g>
              </g>
            </svg>
          </button>
          <div class="flashcontrol">
            <button class="flashcontrol__flashbutton ${this._leftFlashState===p.a.On?"flashcontrol__flashbutton--active":""}"
										@click="${()=>r.a.dispatch(Object(l.v)())}"></button>
            <div class="onoffswitch">
              <input type="checkbox" class="checkbox"
											?checked="${this._lockState===p.a.On}"
											@click="${()=>r.a.dispatch(Object(l.w)())}" id="myonoffswitch2">
              <label class="switch-label" for="myonoffswitch2"></label>
            </div>
            <button class="flashcontrol__flashbutton ${this._rightFlashState===p.a.On?"flashcontrol__flashbutton--active":""}"
										@click="${()=>r.a.dispatch(Object(l.y)())}"></button>
          </div>
        </div> <!-- /.shared-controls -->
      </div> <!-- /.page__controls -->
		</div>
    `}static get properties(){return{platform:{type:String,reflect:!0},_page:{type:String},_language:{type:String},_currentUiColor:{type:String},_currentUiColorName:{type:String},_mainLightState:{type:Boolean},_lockState:{type:Boolean},_rightFlashState:{type:Boolean},_leftFlashState:{type:Boolean},_lightness:{type:Number}}}static get styles(){return[i.d,i.e,i.g,i.h,i.i,i.a,i.b,i.c,i.f,i.j,i.k,i.l,i.n,i.m,s.b`
      #wrapper {
        top: -55px;
        height: calc(100% + 55px);
      }
      `]}updated(t){t.has("_language")&&Object(c.d)(this._language)}async connectedCallback(){Object(c.b)({loader:t=>Promise.resolve(h[t])}),super.connectedCallback()}firstUpdated(){super.firstUpdated(),Object(d.a)(this.shadowRoot.getElementById("power-button2"),"down",t=>this._powerButtonPressedHandler(t)),Object(d.a)(this.shadowRoot.getElementById("power-button2"),"up",t=>this._powerButtonReleasedHandler(t)),Raphael.colorwheel(this.shadowRoot.getElementById("colorWheel"),220,400).onchange((function(t){r.a.dispatch(Object(l.o)(_.a.rgb(t.r,t.g,t.b)))}));var t=this.shadowRoot.getElementById("nxprange");t.addEventListener("input",t=>this._renderBrightnessRange(parseFloat(t.target.value))),this._renderBrightnessRange(parseFloat(t.value))}_renderBrightnessRange(t){var e=this.shadowRoot.getElementById("brightness-control__range-track-filled"),a=this.shadowRoot.getElementById("brightness-control__range-thumb"),s=100*(t+1)/2;e.style.width=s+"%",a.style.transform="translateX("+s+"%)"}_lightnessChangeHandler(t){r.a.dispatch(Object(l.n)(Number(this.shadowRoot.getElementById("nxprange").value)))}updated(t){t.has("_language")&&Object(c.d)(this._language)}_powerButtonClickHandler(){this._lockState===p.a.On&&r.a.dispatch(Object(l.x)())}_powerButtonPressedHandler(t){this._lockState===p.a.Off&&r.a.dispatch(Object(l.u)())}_powerButtonReleasedHandler(t){this._lockState===p.a.Off&&r.a.dispatch(Object(l.t)())}stateChanged(t){this.platform=t.app.platform,this._page=t.app.page,this._language=t.app.language,this._currentUiColor=t.app.currentUiColor,this._currentUiColorName=t.app.currentUiColorName,this._mainLightState=t.app.ledsState,this._lockState=t.app.lockState,this._leftFlashState=t.app.flashLedLeftState,this._rightFlashState=t.app.flashLedRightState,this._lightness=t.app.lightness}}window.customElements.define("wheel-page",u)}}]);