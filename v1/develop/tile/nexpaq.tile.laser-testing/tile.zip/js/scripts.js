/* =========== ON PAGE LOAD HANDLER */
document.addEventListener('DOMContentLoaded', function(event) {
	Nexpaq.Header.create('Laser Pointer Testing');
});

document.addEventListener('NexpaqAPIReady', function() {
	document.getElementById('turnLaserOn').addEventListener('click', function() {
		console.log("laser on");
		Nexpaq.API.Module.SendCommand(Nexpaq.Arguments[0], 'TurnOnLaser', []);
	});

	document.getElementById('turnLaserOff').addEventListener('click', function() {
		console.log("laser off");
		Nexpaq.API.Module.SendCommand(Nexpaq.Arguments[0], 'TurnOffLaser', []);
	});

	Nexpaq.API.addEventListener('BeforeExit', beforeExitActions);
});

function beforeExitActions() {
	Nexpaq.API.Module.SendCommand(Nexpaq.Arguments[0], 'TurnOffLaser', []);
}
